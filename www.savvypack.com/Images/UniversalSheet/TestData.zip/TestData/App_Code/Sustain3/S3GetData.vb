﻿Imports Microsoft.VisualBasic
Imports System.Web.SessionState
Imports System.Data
Imports System.Data.OleDb
Imports System
Public Class S3GetData

    Public Class Selectdata
        Dim Sustain3Connection As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
        Public Function GetUsernamePassword(ByVal Id As String) As DataTable
            Dim Dts As New DataTable()
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
                Dim StrSql As String = "Select Uname,Upwd From Ulogin Where ID= " & Id
                Dts = odbUtil.FillDataTable(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function

        Public Function GetInuseCount(ByVal UserName As String) As DataTable
            Dim Dts As New DataTable
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")

                Dim StrSql As String = "Select * from inuse where Username='" + UserName + "'"
                Dts = odbUtil.FillDataTable(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function

        Public Function GetCases(ByVal UserName As String, ByVal Password As String) As DataTable
            Dim Dts As New DataTable
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                Dim StrSql As String = "SELECT caseID,caseDE1,('Case:'||caseID||' - '|| caseDE1||' ' || caseDE2) as CaseDe FROM permissionscases WHERE username='" + UserName + "'"
                StrSql = StrSql + "UNION SELECT caseID,caseDE1,('Case:'||caseID||' - '|| caseDE1||' ' || caseDE2) as CaseDe  FROM basecases ORDER BY caseDE1"

                Dts = odbUtil.FillDataTable(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function
        Public Function GetCasesS3(ByVal UserName As String, ByVal Password As String, ByVal LiceAdmin As String) As DataTable
            Dim Dts As New DataTable
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                Dim StrSql As String = ""
                If LiceAdmin = "Y" Then
                    StrSql = "SELECT CASEID,CASEDE1,('CASE:'||CASEID||' - '|| CASEDE1||' ' || CASEDE2|| '     STATUS:'|| MS.STATUS) AS CASEDE,MS.STATUSID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID WHERE username='" + UserName + "'"
                Else
                    StrSql = "SELECT CASEID,CASEDE1, CASEDE,STATUSID FROM ("
                    StrSql = StrSql + "(SELECT CASEID,CASEDE1,('CASE:'||CASEID||' - '|| CASEDE1||' ' || CASEDE2|| (CASE WHEN MS.STATUS IS NULL THEN '' ELSE   '     STATUS:'|| MS.STATUS END)) AS CASEDE,0 STATUSID FROM PERMISSIONSCASES LEFT OUTER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID WHERE username='" + UserName + "' ) "
                    StrSql = StrSql + "UNION (SELECT CASEID,CASEDE1,('CASE:'||CASEID||' - '|| CASEDE1||' ' || CASEDE2|| '     STATUS:'|| MS.STATUS) AS CASEDE,MS.STATUSID  FROM PERMISSIONSCASES  INNER JOIN ECON.USERS ON UPPER(USERS.USERNAME)=UPPER(PERMISSIONSCASES.USERNAME) "
                    StrSql = StrSql + "INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID "
                    StrSql = StrSql + "WHERE USERS.LICENSEID IN (SELECT USERS.LICENSEID FROM ECON.USERS WHERE UPPER(USERNAME)='" + UserName.ToUpper() + "') "
                    StrSql = StrSql + "AND PERMISSIONSCASES.STATUSID IN (3,5)) "
                    StrSql = StrSql + ") ORDER BY CASEDE1"
                End If


                Dts = odbUtil.FillDataTable(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function

        Public Function GetCouser(ByVal UserName As String) As DataTable
            Dim Dts As New DataTable
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")


                Dim StrSql As String = " Select Users.Username , Users.userid From Users  where exists"
                StrSql = StrSql + " (select 1 from UserPermissions "
                StrSql = StrSql + " Inner Join Services on Services.SERVICEID = UserPermissions.SERVICEID "
                StrSql = StrSql + " where UserPermissions.UserID =Users.UserID and  Services.SERVICEDE='SUSTAIN3'  "
                'StrSql = StrSql + " and Users.company IN(select Users.company from users where username='" + UserName + "')"
                StrSql = StrSql + "AND USERS.LICENSEID=(SELECT LICENSEID FROM USERS WHERE UPPER(USERNAME)='" + UserName.ToUpper.ToString() + "') "
                StrSql = StrSql + " )order by  Users.Username"

                Dts = odbUtil.FillDataTable(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function

        Public Function GetDescription(ByVal AssumptionID As String) As String
            Dim Des As String = ""
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")

                Dim StrSql As String = "Select DESCRIPTION from ASSUMPTIONS where ASSUMPTIONID = " + AssumptionID.ToString() + " "
                Dim Dts As New DataTable()
                Dts = odbUtil.FillDataTable(StrSql, MyConnectionString)
                Des = Dts.Rows(0).Item("DESCRIPTION")
                Return Des
            Catch ex As Exception
                Throw
                Return Des
            End Try
        End Function


        Public Function Cases(ByVal ID As String) As String
            Dim CaseIDs As String = ""
            Try

                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")

                Dim StrSqlCases As String = ""
                StrSqlCases = "select to_char( nvl(Assumptions.Case1,0) )  ||  ',' || to_char( nvl(Assumptions.Case2,0))    ||   ',' ||  to_char( nvl(Assumptions.Case3,0) )  ||   ',' || to_char( nvl(Assumptions.Case4,0) )  ||  ',' ||  to_char( nvl(Assumptions.Case5,0) )  ||  ',' ||  to_char ( nvl(Assumptions.Case6,0) ) ||   ',' || to_char( nvl(Assumptions.Case7,0)  )  ||   ','  ||  to_char( nvl(Assumptions.Case8,0)  )  ||  ',' || to_char( nvl(Assumptions.Case9,0) )   ||   ','  || to_Char( nvl(Assumptions.Case10,0) )  as Cases   from  Assumptions WHERE Assumptions.AssumptionId =" + ID + ""
                Dim Cs As New DataTable()
                Cs = odbUtil.FillDataTable(StrSqlCases, MyConnectionString)
                CaseIDs = Cs.Rows(0).Item("Cases").ToString()
                Return CaseIDs
            Catch ex As Exception
                Return CaseIDs
            End Try
        End Function
        Public Function CasesS3(ByVal AssumId As String) As String()
            Dim CaseIDs() As String
            Dim i As New Integer
            Try

                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                Dim StrSql As String = ""
                'StrSqlCases = "select to_char( nvl(Assumptions.Case1,0) )  ||  ',' || to_char( nvl(Assumptions.Case2,0))    ||   ',' ||  to_char( nvl(Assumptions.Case3,0) )  ||   ',' || to_char( nvl(Assumptions.Case4,0) )  ||  ',' ||  to_char( nvl(Assumptions.Case5,0) )  ||  ',' ||  to_char ( nvl(Assumptions.Case6,0) ) ||   ',' || to_char( nvl(Assumptions.Case7,0)  )  ||   ','  ||  to_char( nvl(Assumptions.Case8,0)  )  ||  ',' || to_char( nvl(Assumptions.Case9,0) )   ||   ','  || to_Char( nvl(Assumptions.Case10,0) )  as Cases   from  Assumptions WHERE Assumptions.AssumptionId =" + ID + ""

                StrSql = "SELECT DISTINCT(P.CASEID) FROM PERMISSIONSCASES P  "
                StrSql = StrSql + "WHERE P.CASEID IN "
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND CASEID=CASE1)>0 THEN 0 ELSE NVL(CASE1,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE2)>0 THEN 0 ELSE NVL(CASE2,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE3)>0 THEN 0 ELSE NVL(CASE3,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE4)>0 THEN 0 ELSE NVL(CASE4,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE5)>0 THEN 0 ELSE NVL(CASE5,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT   (CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE6)>0 THEN 0 ELSE NVL(CASE6,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT   (CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE7)>0 THEN 0 ELSE NVL(CASE7,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT   (CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE8)>0 THEN 0 ELSE NVL(CASE8,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT  (CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE9)>0 THEN 0 ELSE NVL(CASE9,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT  (CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE10)>0 THEN 0 ELSE NVL(CASE10,0) END )  AS C "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                StrSql = StrSql + ")"

                Dim Cs As New DataTable()
                Cs = odbUtil.FillDataTable(StrSql, MyConnectionString)
                ReDim CaseIDs(Cs.Rows.Count - 1)
                For i = 0 To Cs.Rows.Count - 1
                    CaseIDs(i) = Cs.Rows(i).Item("CASEID").ToString()
                Next

                Return CaseIDs
            Catch ex As Exception
                Return CaseIDs
            End Try



        End Function

        Public Function GetSavedCaseAsperUser(ByVal UserName As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSqlSaved As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")

                StrSqlSaved = "SELECT distinct Assumptions.AssumptionId,"
                StrSqlSaved = StrSqlSaved + "( Assumptions.AssumptionId ||' - ' ||"
                StrSqlSaved = StrSqlSaved + "Assumptions.DESCRIPTION || ' : ' ||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case1 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case2 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case3 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case4 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case5 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case6 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case7 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case8 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case9 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case10 "
                StrSqlSaved = StrSqlSaved + ")As Des  FROM Assumptions  Assumptions "
                StrSqlSaved = StrSqlSaved + " inner join PERMASSUMPTIONS"
                StrSqlSaved = StrSqlSaved + " on Assumptions.AssumptionId  = PERMASSUMPTIONS.AssumptionId "
                StrSqlSaved = StrSqlSaved + " and Assumptions.saved = 1 and Assumptions.MODULE=1"
                StrSqlSaved = StrSqlSaved + " and PERMASSUMPTIONS.username='" + UserName + "'"
                Dts = odbUtil.FillDataSet(StrSqlSaved, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function
        Public Function GetSavedCaseAsperUser(ByVal UserName As String, ByVal AssumptionId As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSqlSaved As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")

                StrSqlSaved = "SELECT distinct Assumptions.AssumptionId, "
                StrSqlSaved = StrSqlSaved + "Assumptions.DESCRIPTION,"
                StrSqlSaved = StrSqlSaved + "(nvl(Assumptions.Case1,0) || ', '||"
                StrSqlSaved = StrSqlSaved + "nvl(Assumptions.Case2,0) || ', '||"
                StrSqlSaved = StrSqlSaved + "nvl(Assumptions.Case3,0) || ', '||"
                StrSqlSaved = StrSqlSaved + "nvl(Assumptions.Case4,0) || ', '||"
                StrSqlSaved = StrSqlSaved + "nvl(Assumptions.Case5,0) || ', '||"
                StrSqlSaved = StrSqlSaved + "nvl(Assumptions.Case6,0) || ', '||"
                StrSqlSaved = StrSqlSaved + "nvl(Assumptions.Case7,0) || ', '||"
                StrSqlSaved = StrSqlSaved + "nvl(Assumptions.Case8,0) || ', '||"
                StrSqlSaved = StrSqlSaved + "nvl(Assumptions.Case9,0) || ', '||"
                StrSqlSaved = StrSqlSaved + "nvl(Assumptions.Case10,0))CaseIds, "
                StrSqlSaved = StrSqlSaved + "( Assumptions.AssumptionId ||' - ' ||"
                StrSqlSaved = StrSqlSaved + "Assumptions.DESCRIPTION || ', Cases: ' ||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case1 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case2 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case3 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case4 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case5 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case6 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case7 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case8 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case9 || ' '||"
                StrSqlSaved = StrSqlSaved + "Assumptions.Case10 "
                StrSqlSaved = StrSqlSaved + ")As Des  FROM Assumptions  Assumptions "

                StrSqlSaved = StrSqlSaved + " inner join PERMASSUMPTIONS"
                StrSqlSaved = StrSqlSaved + " on Assumptions.AssumptionId  = PERMASSUMPTIONS.AssumptionId "
                StrSqlSaved = StrSqlSaved + " and Assumptions.saved = 1 and Assumptions.MODULE=1"
                StrSqlSaved = StrSqlSaved + " and UPPER(PERMASSUMPTIONS.username)='" + UserName.ToUpper() + "' "
                StrSqlSaved = StrSqlSaved + "WHERE Assumptions.AssumptionId = CASE WHEN " + AssumptionId.ToString() + " = -1 THEN "
                StrSqlSaved = StrSqlSaved + "Assumptions.AssumptionId "
                StrSqlSaved = StrSqlSaved + "ELSE "
                StrSqlSaved = StrSqlSaved + "" + AssumptionId.ToString() + " "
                StrSqlSaved = StrSqlSaved + "END "

                Dts = odbUtil.FillDataSet(StrSqlSaved, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function
        Public Function GetEditCases(ByVal UserName As String, ByVal ID As String, ByVal flag As String) As DataTable
            Dim Dts As New DataTable()
            Dim i As New Integer
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                Dim StrSql As String = ""
                StrSql = "SELECT CASEID,CASEDE1,CASEDE FROM  "
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT CASEID, "
                StrSql = StrSql + "CASEDE1, "
                StrSql = StrSql + "('CASE:'||CASEID||' - '|| CASEDE1||' ' || CASEDE2) AS CASEDE "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE Upper(username)='" + UserName.ToUpper() + "' "
                StrSql = StrSql + " UNION "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "CASEID, "
                StrSql = StrSql + "CASEDE1, "
                StrSql = StrSql + "('CASE:'||CASEID||' - '|| CASEDE1||' ' || CASEDE2) AS CASEDE "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Where CASEID "
                If flag = "true" Then
                    StrSql = StrSql + "NOT IN "
                Else
                    StrSql = StrSql + "IN "
                End If
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT CASE as Caseid "
                StrSql = StrSql + "FROM "
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT CASE1 AS CASE FROM  Econ3.ASSUMPTIONS WHERE Econ3.ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE2 AS CASE FROM  Econ3.ASSUMPTIONS WHERE Econ3.ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE3 AS CASE FROM Econ3.ASSUMPTIONS WHERE Econ3.ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE4 AS CASE FROM  Econ3.ASSUMPTIONS WHERE Econ3.ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE5 AS CASE FROM  Econ3.ASSUMPTIONS WHERE Econ3.ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE6 AS CASE FROM  Econ3.ASSUMPTIONS WHERE Econ3.ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE7 AS CASE FROM  Econ3.ASSUMPTIONS WHERE Econ3.ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE8 AS CASE FROM  Econ3.ASSUMPTIONS WHERE Econ3.ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE9 AS CASE FROM  Econ3.ASSUMPTIONS WHERE Econ3.ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE10 AS CASE FROM  Econ3.ASSUMPTIONS WHERE Econ3.ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSql = StrSql + ")A "
                StrSql = StrSql + "WHERE A.CASE  <>  0 "
                StrSql = StrSql + ") "
                Dts = odbUtil.FillDataTable(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Return Dts
            End Try



        End Function
        Public Function GetEditCasesS3(ByVal UserName As String, ByVal ID As String, ByVal flag As String, ByVal LiceAdmin As String) As DataTable
            Dim Dts As New DataTable()
            Dim i As New Integer
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                Dim StrSql As String = ""
                If LiceAdmin = "Y" Then
                    StrSql = "SELECT CASEID,CASEDE1,CASEDE FROM  "
                    StrSql = StrSql + "( "
                    StrSql = StrSql + "SELECT CASEID, "
                    StrSql = StrSql + "CASEDE1, "
                    StrSql = StrSql + "('CASE:'||CASEID||' - '|| CASEDE1||' ' || CASEDE2|| '     STATUS:'|| MS.STATUS) AS CASEDE "
                    StrSql = StrSql + "FROM PERMISSIONSCASES LEFT OUTER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID "
                    StrSql = StrSql + "WHERE Upper(username)='" + UserName.ToUpper() + "' "
                    StrSql = StrSql + ") "
                Else
                    StrSql = "SELECT CASEID,CASEDE1, CASEDE FROM ("
                    StrSql = StrSql + "(SELECT CASEID,CASEDE1,('CASE:'||CASEID||' - '|| CASEDE1||' ' || CASEDE2|| (CASE WHEN MS.STATUS IS NULL THEN '' ELSE   '     STATUS:'|| MS.STATUS END)) AS CASEDE FROM PERMISSIONSCASES LEFT OUTER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID WHERE username='" + UserName + "' ) "
                    StrSql = StrSql + "UNION (SELECT CASEID,CASEDE1,('CASE:'||CASEID||' - '|| CASEDE1||' ' || CASEDE2|| '     STATUS:'|| MS.STATUS) AS CASEDE  FROM PERMISSIONSCASES  INNER JOIN ECON.USERS ON UPPER(USERS.USERNAME)=UPPER(PERMISSIONSCASES.USERNAME) "
                    StrSql = StrSql + "LEFT OUTER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID "
                    StrSql = StrSql + "WHERE USERS.LICENSEID IN (SELECT USERS.LICENSEID FROM ECON.USERS WHERE UPPER(USERNAME)='" + UserName.ToUpper() + "') "
                    StrSql = StrSql + "AND PERMISSIONSCASES.STATUSID IN (3,5)) "
                    StrSql = StrSql + ") "
                End If

                StrSql = StrSql + "Where CASEID "
                If flag = "true" Then
                    StrSql = StrSql + "NOT IN "
                Else
                    StrSql = StrSql + "IN "
                End If
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT CASE as Caseid "
                StrSql = StrSql + "FROM "
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT CASE1 AS CASE FROM  ECON3.ASSUMPTIONS WHERE ECON3.ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE2 AS CASE FROM  ECON3.ASSUMPTIONS WHERE ECON3.ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE3 AS CASE FROM  ECON3.ASSUMPTIONS WHERE ECON3.ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE4 AS CASE FROM  ECON3.ASSUMPTIONS WHERE ECON3.ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE5 AS CASE FROM  ECON3.ASSUMPTIONS WHERE ECON3.ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE6 AS CASE FROM  ECON3.ASSUMPTIONS WHERE ECON3.ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE7 AS CASE FROM  ECON3.ASSUMPTIONS WHERE ECON3.ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE8 AS CASE FROM  ECON3.ASSUMPTIONS WHERE ECON3.ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE9 AS CASE FROM  ECON3.ASSUMPTIONS WHERE ECON3.ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASE10 AS CASE FROM  ECON3.ASSUMPTIONS WHERE ECON3.ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSql = StrSql + ")A "
                StrSql = StrSql + "WHERE A.CASE  <>  0 "
                StrSql = StrSql + ") "
                Dts = odbUtil.FillDataTable(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Return Dts
            End Try



        End Function

#Region "Supporting Assumption Pages SQL"
        Public Function GetMaterials() As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
                StrSql = "select Matid, (Matid||':'||matde1||' '||matde2) MaterialDes ,price,sg from Materials ORDER BY matde1"

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function Cases1(ByVal ID As String) As String()
            Dim CaseIDs() As String
            Dim i As New Integer
            Try

                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")

                Dim StrSqlCases As String = ""
                'StrSqlCases = "select to_char( nvl(Assumptions.Case1,0) )  ||  ',' || to_char( nvl(Assumptions.Case2,0))    ||   ',' ||  to_char( nvl(Assumptions.Case3,0) )  ||   ',' || to_char( nvl(Assumptions.Case4,0) )  ||  ',' ||  to_char( nvl(Assumptions.Case5,0) )  ||  ',' ||  to_char ( nvl(Assumptions.Case6,0) ) ||   ',' || to_char( nvl(Assumptions.Case7,0)  )  ||   ','  ||  to_char( nvl(Assumptions.Case8,0)  )  ||  ',' || to_char( nvl(Assumptions.Case9,0) )   ||   ','  || to_Char( nvl(Assumptions.Case10,0) )  as Cases   from  Assumptions WHERE Assumptions.AssumptionId =" + ID + ""

                StrSqlCases = "SELECT *  "
                StrSqlCases = StrSqlCases + "FROM "
                StrSqlCases = StrSqlCases + "( "
                StrSqlCases = StrSqlCases + "SELECT CASE1 AS CASE FROM  ASSUMPTIONS WHERE ASSUMPTIONS.ASSUMPTIONID = " + ID + ""
                StrSqlCases = StrSqlCases + "UNION "
                StrSqlCases = StrSqlCases + "SELECT CASE2 AS CASE FROM  ASSUMPTIONS WHERE ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSqlCases = StrSqlCases + "UNION "
                StrSqlCases = StrSqlCases + "SELECT CASE3 AS CASE FROM  ASSUMPTIONS WHERE ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSqlCases = StrSqlCases + "UNION "
                StrSqlCases = StrSqlCases + "SELECT CASE4 AS CASE FROM  ASSUMPTIONS WHERE ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSqlCases = StrSqlCases + "UNION "
                StrSqlCases = StrSqlCases + "SELECT CASE5 AS CASE FROM  ASSUMPTIONS WHERE ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSqlCases = StrSqlCases + "UNION "
                StrSqlCases = StrSqlCases + "SELECT CASE6 AS CASE FROM  ASSUMPTIONS WHERE ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSqlCases = StrSqlCases + "UNION "
                StrSqlCases = StrSqlCases + "SELECT CASE7 AS CASE FROM  ASSUMPTIONS WHERE ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSqlCases = StrSqlCases + "UNION "
                StrSqlCases = StrSqlCases + "SELECT CASE8 AS CASE FROM  ASSUMPTIONS WHERE ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSqlCases = StrSqlCases + "UNION "
                StrSqlCases = StrSqlCases + "SELECT CASE9 AS CASE FROM  ASSUMPTIONS WHERE ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSqlCases = StrSqlCases + "UNION "
                StrSqlCases = StrSqlCases + "SELECT CASE10 AS CASE FROM  ASSUMPTIONS WHERE ASSUMPTIONS.ASSUMPTIONID = " + ID + " "
                StrSqlCases = StrSqlCases + ")A "
                StrSqlCases = StrSqlCases + "WHERE A.CASE  <>  0 "

                Dim Cs As New DataTable()
                Cs = odbUtil.FillDataTable(StrSqlCases, MyConnectionString)
                ReDim CaseIDs(Cs.Rows.Count - 1)
                For i = 0 To Cs.Rows.Count - 1
                    CaseIDs(i) = Cs.Rows(i).Item("CASE").ToString()
                Next

                Return CaseIDs
            Catch ex As Exception
                Return CaseIDs
            End Try



        End Function

        Public Function GetSustainMaterials() As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT TYPEID,TYPE FROM HEALTHANDSAFETY ORDER BY TYPEID"

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function GetDepartment() As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
                StrSql = "SELECT PROCID,(PROCDE1||' '||PROCDE2)PROCDE FROM PROCESS ORDER BY PROCDE"

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function GetProductFormat(ByVal Unit As String) As DataSet
            Dim Dts As New DataSet()
            Try
                'DataBase Connection
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = ""
                MyConnectionString = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
                Dim Sql1 As String = " SELECT FORMATID, FORMATDE1, FORMATDE2,(FORMATID||' . '||FORMATDE1||''||FORMATDE2) AS DES FROM PRODUCTFORMAT"
                Dim Sql2 As String = " SELECT FORMATID, FORMATDE1, FORMATDE2,(FORMATID||' . '||FORMATDE1||''||FORMATDE2) AS DES FROM PRODUCTFORMAT2"

                If Unit = 0 Then
                    Dts = odbUtil.FillDataSet(Sql1, MyConnectionString)
                Else
                    Dts = odbUtil.FillDataSet(Sql2, MyConnectionString)
                End If

                Return Dts
            Catch ex As Exception
                Return Dts
            End Try



        End Function

        Public Function GetPalletItems(ByVal InventoryType As String, ByVal Effdate As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  PALLETID, (PALLETDE1||' '||PALLETDE2)PALLETDES  "
                StrSql = StrSql + "FROM PALLETARCH "
                StrSql = StrSql + "WHERE PALLETARCH.INVENTORYTYPE = " + InventoryType + " "
                StrSql = StrSql + "AND PALLETARCH.EFFDATE = TO_DATE('" + Effdate + "','MM/DD/YYYY') "



                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function GetEquipments() As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
                StrSql = "SELECT EQUIPID,(EQUIPDE1||' '||EQUIPDE2) AS EQUIPDES FROM EQUIPMENT ORDER BY  EQUIPDES"
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function GetEquipments2() As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
                StrSql = "SELECT EQUIPID,(EQUIPDE1||' '||EQUIPDE2) AS EQUIPDES FROM EQUIPMENT2 ORDER BY  EQUIPDES"
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function GetPositions(ByVal Country As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "PERSID, "
                StrSql = StrSql + "(PERSDE1||''||PERSDE2) AS PERSDE "
                StrSql = StrSql + "FROM "
                StrSql = StrSql + " " + Country + "  "
                StrSql = StrSql + "ORDER BY PERSDE  "
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function
#End Region

#Region "Assumption Pages SQL"

        Public Function Preferences(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT   PREF.CASEID,  "
                StrSql = StrSql + "( CASE WHEN PREF.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = PREF.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = PREF.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "INTV.INVENTORY, "
                StrSql = StrSql + "TO_CHAR(PREF.EFFDATE,'MON DD,YYYY')EFFDATE, "
                StrSql = StrSql + "(CASE WHEN PREF.UNITS = 0 THEN "
                StrSql = StrSql + "'English' "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "'Metric' "
                StrSql = StrSql + "END)UNIT "
                StrSql = StrSql + "FROM PREFERENCES PREF "
                StrSql = StrSql + "INNER JOIN INVENTORYTYPE INTV "
                StrSql = StrSql + "ON INTV.INVENTORYID = PREF.INVENTORYTYPE "
                StrSql = StrSql + "WHERE PREF.CASEID IN(" + CaseIds + ") ORDER BY CASEID "




                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function ExtrusionInput(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "MAT.CASEID, "
                StrSql = StrSql + "( CASE WHEN MAT.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = MAT.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = MAT.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "MAT.M1, "
                StrSql = StrSql + "MAT.M2, "
                StrSql = StrSql + "MAT.M3, "
                StrSql = StrSql + "MAT.M4, "
                StrSql = StrSql + "MAT.M5, "
                StrSql = StrSql + "MAT.M6, "
                StrSql = StrSql + "MAT.M7, "
                StrSql = StrSql + "MAT.M8, "
                StrSql = StrSql + "MAT.M9, "
                StrSql = StrSql + "MAT.M10, "
                StrSql = StrSql + "(MAT.T1*PREF.CONVTHICK) AS THICK1, "
                StrSql = StrSql + "(MAT.T2*PREF.CONVTHICK) AS THICK2, "
                StrSql = StrSql + "(MAT.T3*PREF.CONVTHICK) AS THICK3, "
                StrSql = StrSql + "(MAT.T4*PREF.CONVTHICK) AS THICK4, "
                StrSql = StrSql + "(MAT.T5*PREF.CONVTHICK) AS THICK5, "
                StrSql = StrSql + "(MAT.T6*PREF.CONVTHICK) AS THICK6, "
                StrSql = StrSql + "(MAT.T7*PREF.CONVTHICK) AS THICK7, "
                StrSql = StrSql + "(MAT.T8*PREF.CONVTHICK) AS THICK8, "
                StrSql = StrSql + "(MAT.T9*PREF.CONVTHICK) AS THICK9, "
                StrSql = StrSql + "(MAT.T10*PREF.CONVTHICK) AS THICK10, "
                StrSql = StrSql + "MAT.R1, "
                StrSql = StrSql + "MAT.R2, "
                StrSql = StrSql + "MAT.R3, "
                StrSql = StrSql + "MAT.R4, "
                StrSql = StrSql + "MAT.R5, "
                StrSql = StrSql + "MAT.R6, "
                StrSql = StrSql + "MAT.R7, "
                StrSql = StrSql + "MAT.R8, "
                StrSql = StrSql + "MAT.R9, "
                StrSql = StrSql + "MAT.R10, "
                StrSql = StrSql + "(MAT1.JOULE/PREF.CONVWT) AS ERGYS1, "
                StrSql = StrSql + "(MAT2.JOULE/PREF.CONVWT) AS ERGYS2, "
                StrSql = StrSql + "(MAT3.JOULE/PREF.CONVWT) AS ERGYS3, "
                StrSql = StrSql + "(MAT4.JOULE/PREF.CONVWT) AS ERGYS4, "
                StrSql = StrSql + "(MAT5.JOULE/PREF.CONVWT) AS ERGYS5, "
                StrSql = StrSql + "(MAT6.JOULE/PREF.CONVWT) AS ERGYS6, "
                StrSql = StrSql + "(MAT7.JOULE/PREF.CONVWT) AS ERGYS7, "
                StrSql = StrSql + "(MAT8.JOULE/PREF.CONVWT) AS ERGYS8, "
                StrSql = StrSql + "(MAT9.JOULE/PREF.CONVWT) AS ERGYS9, "
                StrSql = StrSql + "(MAT10.JOULE/PREF.CONVWT) AS ERGYS10, "
                StrSql = StrSql + "(MATERGY.M1/PREF.CONVWT) AS ERGYP1, "
                StrSql = StrSql + "(MATERGY.M2/PREF.CONVWT) AS ERGYP2, "
                StrSql = StrSql + "(MATERGY.M3/PREF.CONVWT) AS ERGYP3, "
                StrSql = StrSql + "(MATERGY.M4/PREF.CONVWT) AS ERGYP4, "
                StrSql = StrSql + "(MATERGY.M5/PREF.CONVWT) AS ERGYP5, "
                StrSql = StrSql + "(MATERGY.M6/PREF.CONVWT) AS ERGYP6, "
                StrSql = StrSql + "(MATERGY.M7/PREF.CONVWT) AS ERGYP7, "
                StrSql = StrSql + "(MATERGY.M8/PREF.CONVWT) AS ERGYP8, "
                StrSql = StrSql + "(MATERGY.M9/PREF.CONVWT) AS ERGYP9, "
                StrSql = StrSql + "(MATERGY.M10/PREF.CONVWT) AS ERGYP10, "
                StrSql = StrSql + "MAT1.PRICE AS CO2S1, "
                StrSql = StrSql + "MAT2.PRICE AS CO2S2, "
                StrSql = StrSql + "MAT3.PRICE AS CO2S3, "
                StrSql = StrSql + "MAT4.PRICE AS CO2S4, "
                StrSql = StrSql + "MAT5.PRICE AS CO2S5, "
                StrSql = StrSql + "MAT6.PRICE AS CO2S6, "
                StrSql = StrSql + "MAT7.PRICE AS CO2S7, "
                StrSql = StrSql + "MAT8.PRICE AS CO2S8, "
                StrSql = StrSql + "MAT9.PRICE AS CO2S9, "
                StrSql = StrSql + "MAT10.PRICE AS CO2S10, "
                StrSql = StrSql + "MAT.S1 AS CO2P1, "
                StrSql = StrSql + "MAT.S2 AS CO2P2, "
                StrSql = StrSql + "MAT.S3 AS CO2P3, "
                StrSql = StrSql + "MAT.S4 AS CO2P4, "
                StrSql = StrSql + "MAT.S5 AS CO2P5, "
                StrSql = StrSql + "MAT.S6 AS CO2P6, "
                StrSql = StrSql + "MAT.S7 AS CO2P7, "
                StrSql = StrSql + "MAT.S8 AS CO2P8, "
                StrSql = StrSql + "MAT.S9 AS CO2P9, "
                StrSql = StrSql + "MAT.S10 AS CO2P10, "
                StrSql = StrSql + "(MAT1.SHIP*PREF.CONVTHICK3) AS SHIPS1, "
                StrSql = StrSql + "(MAT2.SHIP*PREF.CONVTHICK3) AS SHIPS2, "
                StrSql = StrSql + "(MAT3.SHIP*PREF.CONVTHICK3) AS SHIPS3, "
                StrSql = StrSql + "(MAT4.SHIP*PREF.CONVTHICK3) AS SHIPS4, "
                StrSql = StrSql + "(MAT5.SHIP*PREF.CONVTHICK3) AS SHIPS5, "
                StrSql = StrSql + "(MAT6.SHIP*PREF.CONVTHICK3) AS SHIPS6, "
                StrSql = StrSql + "(MAT7.SHIP*PREF.CONVTHICK3) AS SHIPS7, "
                StrSql = StrSql + "(MAT8.SHIP*PREF.CONVTHICK3) AS SHIPS8, "
                StrSql = StrSql + "(MAT9.SHIP*PREF.CONVTHICK3) AS SHIPS9, "
                StrSql = StrSql + "(MAT10.SHIP*PREF.CONVTHICK3) AS SHIPS10, "
                StrSql = StrSql + "(MATSHIP.M1*PREF.CONVTHICK3) AS SHIPP1, "
                StrSql = StrSql + "(MATSHIP.M2*PREF.CONVTHICK3) AS SHIPP2, "
                StrSql = StrSql + "(MATSHIP.M3*PREF.CONVTHICK3) AS SHIPP3, "
                StrSql = StrSql + "(MATSHIP.M4*PREF.CONVTHICK3) AS SHIPP4, "
                StrSql = StrSql + "(MATSHIP.M5*PREF.CONVTHICK3) AS SHIPP5, "
                StrSql = StrSql + "(MATSHIP.M6*PREF.CONVTHICK3) AS SHIPP6, "
                StrSql = StrSql + "(MATSHIP.M7*PREF.CONVTHICK3) AS SHIPP7, "
                StrSql = StrSql + "(MATSHIP.M8*PREF.CONVTHICK3) AS SHIPP8, "
                StrSql = StrSql + "(MATSHIP.M9*PREF.CONVTHICK3) AS SHIPP9, "
                StrSql = StrSql + "(MATSHIP.M10*PREF.CONVTHICK3) AS SHIPP10, "
                StrSql = StrSql + "MAT1.RECOVERY AS RECOS1, "
                StrSql = StrSql + "MAT2.RECOVERY AS RECOS2, "
                StrSql = StrSql + "MAT3.RECOVERY AS RECOS3, "
                StrSql = StrSql + "MAT4.RECOVERY AS RECOS4, "
                StrSql = StrSql + "MAT5.RECOVERY AS RECOS5, "
                StrSql = StrSql + "MAT6.RECOVERY AS RECOS6, "
                StrSql = StrSql + "MAT7.RECOVERY AS RECOS7, "
                StrSql = StrSql + "MAT8.RECOVERY AS RECOS8, "
                StrSql = StrSql + "MAT9.RECOVERY AS RECOS9, "
                StrSql = StrSql + "MAT10.RECOVERY AS RECOS10, "
                StrSql = StrSql + "MAT.RE1 AS RECOP1, "
                StrSql = StrSql + "MAT.RE2 AS RECOP2, "
                StrSql = StrSql + "MAT.RE3 AS RECOP3, "
                StrSql = StrSql + "MAT.RE4 AS RECOP4, "
                StrSql = StrSql + "MAT.RE5 AS RECOP5, "
                StrSql = StrSql + "MAT.RE6 AS RECOP6, "
                StrSql = StrSql + "MAT.RE7 AS RECOP7, "
                StrSql = StrSql + "MAT.RE8 AS RECOP8, "
                StrSql = StrSql + "MAT.RE9 AS RECOP9, "
                StrSql = StrSql + "MAT.RE10 AS RECOP10, "
                StrSql = StrSql + "MAT1.OSHAFACTOR AS SUSS1, "
                StrSql = StrSql + "MAT2.OSHAFACTOR AS SUSS2, "
                StrSql = StrSql + "MAT3.OSHAFACTOR AS SUSS3, "
                StrSql = StrSql + "MAT4.OSHAFACTOR AS SUSS4, "
                StrSql = StrSql + "MAT5.OSHAFACTOR AS SUSS5, "
                StrSql = StrSql + "MAT6.OSHAFACTOR AS SUSS6, "
                StrSql = StrSql + "MAT7.OSHAFACTOR AS SUSS7, "
                StrSql = StrSql + "MAT8.OSHAFACTOR AS SUSS8, "
                StrSql = StrSql + "MAT9.OSHAFACTOR AS SUSS9, "
                StrSql = StrSql + "MAT10.OSHAFACTOR AS SUSS10, "
                StrSql = StrSql + "MAT.OSH1 AS SUSP1, "
                StrSql = StrSql + "MAT.OSH2 AS SUSP2, "
                StrSql = StrSql + "MAT.OSH3 AS SUSP3, "
                StrSql = StrSql + "MAT.OSH4 AS SUSP4, "
                StrSql = StrSql + "MAT.OSH5 AS SUSP5, "
                StrSql = StrSql + "MAT.OSH6 AS SUSP6, "
                StrSql = StrSql + "MAT.OSH7 AS SUSP7, "
                StrSql = StrSql + "MAT.OSH8 AS SUSP8, "
                StrSql = StrSql + "MAT.OSH9 AS SUSP9, "
                StrSql = StrSql + "MAT.OSH10 AS SUSP10, "
                StrSql = StrSql + "MAT1.POSTCONSUMER AS PCRECS1, "
                StrSql = StrSql + "MAT2.POSTCONSUMER AS PCRECS2, "
                StrSql = StrSql + "MAT3.POSTCONSUMER AS PCRECS3, "
                StrSql = StrSql + "MAT4.POSTCONSUMER AS PCRECS4, "
                StrSql = StrSql + "MAT5.POSTCONSUMER AS PCRECS5, "
                StrSql = StrSql + "MAT6.POSTCONSUMER AS PCRECS6, "
                StrSql = StrSql + "MAT7.POSTCONSUMER AS PCRECS7, "
                StrSql = StrSql + "MAT8.POSTCONSUMER AS PCRECS8, "
                StrSql = StrSql + "MAT9.POSTCONSUMER AS PCRECS9, "
                StrSql = StrSql + "MAT10.POSTCONSUMER AS PCRECS10, "
                StrSql = StrSql + "MAT.POC1 AS PCRECP1, "
                StrSql = StrSql + "MAT.POC2 AS PCRECP2, "
                StrSql = StrSql + "MAT.POC3 AS PCRECP3, "
                StrSql = StrSql + "MAT.POC4 AS PCRECP4, "
                StrSql = StrSql + "MAT.POC5 AS PCRECP5, "
                StrSql = StrSql + "MAT.POC6 AS PCRECP6, "
                StrSql = StrSql + "MAT.POC7 AS PCRECP7, "
                StrSql = StrSql + "MAT.POC8 AS PCRECP8, "
                StrSql = StrSql + "MAT.POC9 AS PCRECP9, "
                StrSql = StrSql + "MAT.POC10 AS PCRECP10, "
                StrSql = StrSql + "MAT.E1, "
                StrSql = StrSql + "MAT.E2, "
                StrSql = StrSql + "MAT.E3, "
                StrSql = StrSql + "MAT.E4, "
                StrSql = StrSql + "MAT.E5, "
                StrSql = StrSql + "MAT.E6, "
                StrSql = StrSql + "MAT.E7, "
                StrSql = StrSql + "MAT.E8, "
                StrSql = StrSql + "MAT.E9, "
                StrSql = StrSql + "MAT.E10, "
                StrSql = StrSql + "MAT.SG1 AS SGP1, "
                StrSql = StrSql + "MAT.SG2 AS SGP2, "
                StrSql = StrSql + "MAT.SG3 AS SGP3, "
                StrSql = StrSql + "MAT.SG4 AS SGP4, "
                StrSql = StrSql + "MAT.SG5 AS SGP5, "
                StrSql = StrSql + "MAT.SG6 AS SGP6, "
                StrSql = StrSql + "MAT.SG7 AS SGP7, "
                StrSql = StrSql + "MAT.SG8 AS SGP8, "
                StrSql = StrSql + "MAT.SG9 AS SGP9, "
                StrSql = StrSql + "MAT.SG10 AS SGP10, "
                StrSql = StrSql + "MATS1.SG AS SGS1, "
                StrSql = StrSql + "MATS2.SG AS SGS2, "
                StrSql = StrSql + "MATS3.SG AS SGS3, "
                StrSql = StrSql + "MATS4.SG AS SGS4, "
                StrSql = StrSql + "MATS5.SG AS SGS5, "
                StrSql = StrSql + "MATS6.SG AS SGS6, "
                StrSql = StrSql + "MATS7.SG AS SGS7, "
                StrSql = StrSql + "MATS8.SG AS SGS8, "
                StrSql = StrSql + "MATS9.SG AS SGS9, "
                StrSql = StrSql + "MATS10.SG AS SGS10, "
                StrSql = StrSql + "(MATOUT.M1/PREF.CONVAREA) AS WTPARA1, "
                StrSql = StrSql + "(MATOUT.M2/PREF.CONVAREA) AS WTPARA2, "
                StrSql = StrSql + "(MATOUT.M3/PREF.CONVAREA) AS WTPARA3, "
                StrSql = StrSql + "(MATOUT.M4/PREF.CONVAREA) AS WTPARA4, "
                StrSql = StrSql + "(MATOUT.M5/PREF.CONVAREA) AS WTPARA5, "
                StrSql = StrSql + "(MATOUT.M6/PREF.CONVAREA) AS WTPARA6, "
                StrSql = StrSql + "(MATOUT.M7/PREF.CONVAREA) AS WTPARA7, "
                StrSql = StrSql + "(MATOUT.M8/PREF.CONVAREA) AS WTPARA8, "
                StrSql = StrSql + "(MATOUT.M9/PREF.CONVAREA) AS WTPARA9, "
                StrSql = StrSql + "(MATOUT.M10/PREF.CONVAREA) AS WTPARA10, "
                StrSql = StrSql + "(MAT.PS1*PREF.CONVWT) AS SHIPUNIT1, "
                StrSql = StrSql + "(MAT.PS2*PREF.CONVWT) AS SHIPUNIT2, "
                StrSql = StrSql + "(MAT.PS3*PREF.CONVWT) AS SHIPUNIT3, "
                StrSql = StrSql + "(MAT.PS4*PREF.CONVWT) AS SHIPUNIT4, "
                StrSql = StrSql + "(MAT.PS5*PREF.CONVWT) AS SHIPUNIT5, "
                StrSql = StrSql + "(MAT.PS6*PREF.CONVWT) AS SHIPUNIT6, "
                StrSql = StrSql + "(MAT.PS7*PREF.CONVWT) AS SHIPUNIT7, "
                StrSql = StrSql + "(MAT.PS8*PREF.CONVWT) AS SHIPUNIT8, "
                StrSql = StrSql + "(MAT.PS9*PREF.CONVWT) AS SHIPUNIT9, "
                StrSql = StrSql + "(MAT.PS10*PREF.CONVWT) AS SHIPUNIT10, "
                StrSql = StrSql + "MAT.D1, "
                StrSql = StrSql + "MAT.D2, "
                StrSql = StrSql + "MAT.D3, "
                StrSql = StrSql + "MAT.D4, "
                StrSql = StrSql + "MAT.D5, "
                StrSql = StrSql + "MAT.D6, "
                StrSql = StrSql + "MAT.D7, "
                StrSql = StrSql + "MAT.D8, "
                StrSql = StrSql + "MAT.D9, "
                StrSql = StrSql + "MAT.D10, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM MATERIALINPUT MAT "
                StrSql = StrSql + "INNER JOIN MATERIALSARCH MAT1 "
                StrSql = StrSql + "ON MAT1.EFFDATE = MAT.EFFDATE "
                StrSql = StrSql + "AND MAT1.INVENTORYTYPE =  MAT.INVENTORYTYPE "
                StrSql = StrSql + "AND MAT1.MATID = MAT.M1 "
                StrSql = StrSql + "INNER JOIN MATERIALSARCH MAT2 "
                StrSql = StrSql + "ON MAT2.EFFDATE = MAT.EFFDATE "
                StrSql = StrSql + "AND MAT2.INVENTORYTYPE =  MAT.INVENTORYTYPE "
                StrSql = StrSql + "AND MAT2.MATID = MAT.M2 "
                StrSql = StrSql + "INNER JOIN MATERIALSARCH MAT3 "
                StrSql = StrSql + "ON MAT3.EFFDATE = MAT.EFFDATE "
                StrSql = StrSql + "AND MAT3.INVENTORYTYPE =  MAT.INVENTORYTYPE "
                StrSql = StrSql + "AND MAT3.MATID = MAT.M3 "
                StrSql = StrSql + "INNER JOIN MATERIALSARCH MAT4 "
                StrSql = StrSql + "ON MAT4.EFFDATE = MAT.EFFDATE "
                StrSql = StrSql + "AND MAT4.INVENTORYTYPE =  MAT.INVENTORYTYPE "
                StrSql = StrSql + "AND MAT4.MATID = MAT.M4 "
                StrSql = StrSql + "INNER JOIN MATERIALSARCH MAT5 "
                StrSql = StrSql + "ON MAT5.EFFDATE = MAT.EFFDATE "
                StrSql = StrSql + "AND MAT5.INVENTORYTYPE =  MAT.INVENTORYTYPE "
                StrSql = StrSql + "AND MAT5.MATID = MAT.M5 "
                StrSql = StrSql + "INNER JOIN MATERIALSARCH MAT6 "
                StrSql = StrSql + "ON MAT6.EFFDATE = MAT.EFFDATE "
                StrSql = StrSql + "AND MAT6.INVENTORYTYPE =  MAT.INVENTORYTYPE "
                StrSql = StrSql + "AND MAT6.MATID = MAT.M6 "
                StrSql = StrSql + "INNER JOIN MATERIALSARCH MAT7 "
                StrSql = StrSql + "ON MAT7.EFFDATE = MAT.EFFDATE "
                StrSql = StrSql + "AND MAT7.INVENTORYTYPE =  MAT.INVENTORYTYPE "
                StrSql = StrSql + "AND MAT7.MATID = MAT.M7 "
                StrSql = StrSql + "INNER JOIN MATERIALSARCH MAT8 "
                StrSql = StrSql + "ON MAT8.EFFDATE = MAT.EFFDATE "
                StrSql = StrSql + "AND MAT8.INVENTORYTYPE =  MAT.INVENTORYTYPE "
                StrSql = StrSql + "AND MAT8.MATID = MAT.M8 "
                StrSql = StrSql + "INNER JOIN MATERIALSARCH MAT9 "
                StrSql = StrSql + "ON MAT9.EFFDATE = MAT.EFFDATE "
                StrSql = StrSql + "AND MAT9.INVENTORYTYPE =  MAT.INVENTORYTYPE "
                StrSql = StrSql + "AND MAT9.MATID = MAT.M9 "
                StrSql = StrSql + "INNER JOIN MATERIALSARCH MAT10 "
                StrSql = StrSql + "ON MAT10.EFFDATE = MAT.EFFDATE "
                StrSql = StrSql + "AND MAT10.INVENTORYTYPE =  MAT.INVENTORYTYPE "
                StrSql = StrSql + "AND MAT10.MATID = MAT.M10 "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=MAT.CASEID "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATS1 "
                StrSql = StrSql + "ON MATS1.MATID = MAT.M1 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATS2 "
                StrSql = StrSql + "ON MATS2.MATID = MAT.M2 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATS3 "
                StrSql = StrSql + "ON MATS3.MATID = MAT.M3 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATS4 "
                StrSql = StrSql + "ON MATS4.MATID = MAT.M4 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATS5 "
                StrSql = StrSql + "ON MATS5.MATID = MAT.M5 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATS6 "
                StrSql = StrSql + "ON MATS6.MATID = MAT.M6 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATS7 "
                StrSql = StrSql + "ON MATS7.MATID = MAT.M7 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATS8 "
                StrSql = StrSql + "ON MATS8.MATID = MAT.M8 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATS9 "
                StrSql = StrSql + "ON MATS9.MATID = MAT.M9 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATS10 "
                StrSql = StrSql + "ON MATS10.MATID = MAT.M10 "
                StrSql = StrSql + "INNER JOIN MATENERGYPREF MATERGY "
                StrSql = StrSql + "ON MATERGY.CASEID=MAT.CASEID "
                StrSql = StrSql + "INNER JOIN MATSHIPPREF MATSHIP "
                StrSql = StrSql + "ON MATSHIP.CASEID=MAT.CASEID "
                StrSql = StrSql + "INNER JOIN MATERIALOUTPUT MATOUT "
                StrSql = StrSql + "ON MATOUT.CASEID=MAT.CASEID "
                StrSql = StrSql + "WHERE MAT.CASEID IN(" + CaseIds + ") ORDER BY MAT.CASEID"



                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function PalletInNew(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "PINNEW.CASEID, "
                StrSql = StrSql + "( CASE WHEN PINNEW.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = PINNEW.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = PINNEW.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "PINNEW.INVENTORYTYPE, "
                StrSql = StrSql + "TO_CHAR(PINNEW.EFFDATE,'MM/DD/YYYY')EFFDATE, "
                StrSql = StrSql + "PINNEW.A1 AS PMATA1, "
                StrSql = StrSql + "PINNEW.A2 AS PMATA2, "
                StrSql = StrSql + "PINNEW.A3 AS PMATA3, "
                StrSql = StrSql + "PINNEW.A4 AS PMATA4, "
                StrSql = StrSql + "PINNEW.A5 AS PMATA5, "
                StrSql = StrSql + "PINNEW.A6 AS PMATA6, "
                StrSql = StrSql + "PINNEW.A7 AS PMATA7, "
                StrSql = StrSql + "PINNEW.A8 AS PMATA8, "
                StrSql = StrSql + "PINNEW.A9 AS PMATA9, "
                StrSql = StrSql + "PINNEW.A10 AS PMATA10, "
                StrSql = StrSql + "PINNEW.B1 AS PMATB1, "
                StrSql = StrSql + "PINNEW.B2 AS PMATB2, "
                StrSql = StrSql + "PINNEW.B3 AS PMATB3, "
                StrSql = StrSql + "PINNEW.B4 AS PMATB4, "
                StrSql = StrSql + "PINNEW.B5 AS PMATB5, "
                StrSql = StrSql + "PINNEW.B6 AS PMATB6, "
                StrSql = StrSql + "PINNEW.B7 AS PMATB7, "
                StrSql = StrSql + "PINNEW.B8 AS PMATB8, "
                StrSql = StrSql + "PINNEW.B9 AS PMATB9, "
                StrSql = StrSql + "PINNEW.B10 AS PMATB10, "
                StrSql = StrSql + "PINNEW.C1 AS PMATC1, "
                StrSql = StrSql + "PINNEW.C2 AS PMATC2, "
                StrSql = StrSql + "PINNEW.C3 AS PMATC3, "
                StrSql = StrSql + "PINNEW.C4 AS PMATC4, "
                StrSql = StrSql + "PINNEW.C5 AS PMATC5, "
                StrSql = StrSql + "PINNEW.C6 AS PMATC6, "
                StrSql = StrSql + "PINNEW.C7 AS PMATC7, "
                StrSql = StrSql + "PINNEW.C8 AS PMATC8, "
                StrSql = StrSql + "PINNEW.C9 AS PMATC9, "
                StrSql = StrSql + "PINNEW.C10 AS PMATC10, "
                StrSql = StrSql + "PINNEW.D1 AS PMATD1, "
                StrSql = StrSql + "PINNEW.D2 AS PMATD2, "
                StrSql = StrSql + "PINNEW.D3 AS PMATD3, "
                StrSql = StrSql + "PINNEW.D4 AS PMATD4, "
                StrSql = StrSql + "PINNEW.D5 AS PMATD5, "
                StrSql = StrSql + "PINNEW.D6 AS PMATD6, "
                StrSql = StrSql + "PINNEW.D7 AS PMATD7, "
                StrSql = StrSql + "PINNEW.D8 AS PMATD8, "
                StrSql = StrSql + "PINNEW.D9 AS PMATD9, "
                StrSql = StrSql + "PINNEW.D10 AS PMATD10, "
                StrSql = StrSql + "PINNEW.E1 AS PMATE1, "
                StrSql = StrSql + "PINNEW.E2 AS PMATE2, "
                StrSql = StrSql + "PINNEW.E3 AS PMATE3, "
                StrSql = StrSql + "PINNEW.E4 AS PMATE4, "
                StrSql = StrSql + "PINNEW.E5 AS PMATE5, "
                StrSql = StrSql + "PINNEW.E6 AS PMATE6, "
                StrSql = StrSql + "PINNEW.E7 AS PMATE7, "
                StrSql = StrSql + "PINNEW.E8 AS PMATE8, "
                StrSql = StrSql + "PINNEW.E9 AS PMATE9, "
                StrSql = StrSql + "PINNEW.E10 AS PMATE10, "
                StrSql = StrSql + "PINNEW.F1 AS PMATF1, "
                StrSql = StrSql + "PINNEW.F2 AS PMATF2, "
                StrSql = StrSql + "PINNEW.F3 AS PMATF3, "
                StrSql = StrSql + "PINNEW.F4 AS PMATF4, "
                StrSql = StrSql + "PINNEW.F5 AS PMATF5, "
                StrSql = StrSql + "PINNEW.F6 AS PMATF6, "
                StrSql = StrSql + "PINNEW.F7 AS PMATF7, "
                StrSql = StrSql + "PINNEW.F8 AS PMATF8, "
                StrSql = StrSql + "PINNEW.F9 AS PMATF9, "
                StrSql = StrSql + "PINNEW.F10 AS PMATF10, "
                StrSql = StrSql + "PINNEW.G1 AS PMATG1, "
                StrSql = StrSql + "PINNEW.G2 AS PMATG2, "
                StrSql = StrSql + "PINNEW.G3 AS PMATG3, "
                StrSql = StrSql + "PINNEW.G4 AS PMATG4, "
                StrSql = StrSql + "PINNEW.G5 AS PMATG5, "
                StrSql = StrSql + "PINNEW.G6 AS PMATG6, "
                StrSql = StrSql + "PINNEW.G7 AS PMATG7, "
                StrSql = StrSql + "PINNEW.G8 AS PMATG8, "
                StrSql = StrSql + "PINNEW.G9 AS PMATG9, "
                StrSql = StrSql + "PINNEW.G10 AS PMATG10, "
                StrSql = StrSql + "PINNEW.H1 AS PMATH1, "
                StrSql = StrSql + "PINNEW.H2 AS PMATH2, "
                StrSql = StrSql + "PINNEW.H3 AS PMATH3, "
                StrSql = StrSql + "PINNEW.H4 AS PMATH4, "
                StrSql = StrSql + "PINNEW.H5 AS PMATH5, "
                StrSql = StrSql + "PINNEW.H6 AS PMATH6, "
                StrSql = StrSql + "PINNEW.H7 AS PMATH7, "
                StrSql = StrSql + "PINNEW.H8 AS PMATH8, "
                StrSql = StrSql + "PINNEW.H9 AS PMATH9, "
                StrSql = StrSql + "PINNEW.H10 AS PMATH10, "
                StrSql = StrSql + "PINNEW.I1 AS PMATI1, "
                StrSql = StrSql + "PINNEW.I2 AS PMATI2, "
                StrSql = StrSql + "PINNEW.I3 AS PMATI3, "
                StrSql = StrSql + "PINNEW.I4 AS PMATI4, "
                StrSql = StrSql + "PINNEW.I5 AS PMATI5, "
                StrSql = StrSql + "PINNEW.I6 AS PMATI6, "
                StrSql = StrSql + "PINNEW.I7 AS PMATI7, "
                StrSql = StrSql + "PINNEW.I8 AS PMATI8, "
                StrSql = StrSql + "PINNEW.I9 AS PMATI9, "
                StrSql = StrSql + "PINNEW.I10 AS PMATI10, "
                StrSql = StrSql + "PINNEW.J1 AS PMATJ1, "
                StrSql = StrSql + "PINNEW.J2 AS PMATJ2, "
                StrSql = StrSql + "PINNEW.J3 AS PMATJ3, "
                StrSql = StrSql + "PINNEW.J4 AS PMATJ4, "
                StrSql = StrSql + "PINNEW.J5 AS PMATJ5, "
                StrSql = StrSql + "PINNEW.J6 AS PMATJ6, "
                StrSql = StrSql + "PINNEW.J7 AS PMATJ7, "
                StrSql = StrSql + "PINNEW.J8 AS PMATJ8, "
                StrSql = StrSql + "PINNEW.J9 AS PMATJ9, "
                StrSql = StrSql + "PINNEW.J10 AS PMATJ10, "
                StrSql = StrSql + "PINNEWNUM.A1 AS PNUMA1, "
                StrSql = StrSql + "PINNEWNUM.A2 AS PNUMA2, "
                StrSql = StrSql + "PINNEWNUM.A3 AS PNUMA3, "
                StrSql = StrSql + "PINNEWNUM.A4 AS PNUMA4, "
                StrSql = StrSql + "PINNEWNUM.A5 AS PNUMA5, "
                StrSql = StrSql + "PINNEWNUM.A6 AS PNUMA6, "
                StrSql = StrSql + "PINNEWNUM.A7 AS PNUMA7, "
                StrSql = StrSql + "PINNEWNUM.A8 AS PNUMA8, "
                StrSql = StrSql + "PINNEWNUM.A9 AS PNUMA9, "
                StrSql = StrSql + "PINNEWNUM.A10 AS PNUMA10, "
                StrSql = StrSql + "PINNEWNUM.B1 AS PNUMB1, "
                StrSql = StrSql + "PINNEWNUM.B2 AS PNUMB2, "
                StrSql = StrSql + "PINNEWNUM.B3 AS PNUMB3, "
                StrSql = StrSql + "PINNEWNUM.B4 AS PNUMB4, "
                StrSql = StrSql + "PINNEWNUM.B5 AS PNUMB5, "
                StrSql = StrSql + "PINNEWNUM.B6 AS PNUMB6, "
                StrSql = StrSql + "PINNEWNUM.B7 AS PNUMB7, "
                StrSql = StrSql + "PINNEWNUM.B8 AS PNUMB8, "
                StrSql = StrSql + "PINNEWNUM.B9 AS PNUMB9, "
                StrSql = StrSql + "PINNEWNUM.B10 AS PNUMB10, "
                StrSql = StrSql + "PINNEWNUM.C1 AS PNUMC1, "
                StrSql = StrSql + "PINNEWNUM.C2 AS PNUMC2, "
                StrSql = StrSql + "PINNEWNUM.C3 AS PNUMC3, "
                StrSql = StrSql + "PINNEWNUM.C4 AS PNUMC4, "
                StrSql = StrSql + "PINNEWNUM.C5 AS PNUMC5, "
                StrSql = StrSql + "PINNEWNUM.C6 AS PNUMC6, "
                StrSql = StrSql + "PINNEWNUM.C7 AS PNUMC7, "
                StrSql = StrSql + "PINNEWNUM.C8 AS PNUMC8, "
                StrSql = StrSql + "PINNEWNUM.C9 AS PNUMC9, "
                StrSql = StrSql + "PINNEWNUM.C10 AS PNUMC10, "
                StrSql = StrSql + "PINNEWNUM.D1 AS PNUMD1, "
                StrSql = StrSql + "PINNEWNUM.D2 AS PNUMD2, "
                StrSql = StrSql + "PINNEWNUM.D3 AS PNUMD3, "
                StrSql = StrSql + "PINNEWNUM.D4 AS PNUMD4, "
                StrSql = StrSql + "PINNEWNUM.D5 AS PNUMD5, "
                StrSql = StrSql + "PINNEWNUM.D6 AS PNUMD6, "
                StrSql = StrSql + "PINNEWNUM.D7 AS PNUMD7, "
                StrSql = StrSql + "PINNEWNUM.D8 AS PNUMD8, "
                StrSql = StrSql + "PINNEWNUM.D9 AS PNUMD9, "
                StrSql = StrSql + "PINNEWNUM.D10 AS PNUMD10, "
                StrSql = StrSql + "PINNEWNUM.E1 AS PNUME1, "
                StrSql = StrSql + "PINNEWNUM.E2 AS PNUME2, "
                StrSql = StrSql + "PINNEWNUM.E3 AS PNUME3, "
                StrSql = StrSql + "PINNEWNUM.E4 AS PNUME4, "
                StrSql = StrSql + "PINNEWNUM.E5 AS PNUME5, "
                StrSql = StrSql + "PINNEWNUM.E6 AS PNUME6, "
                StrSql = StrSql + "PINNEWNUM.E7 AS PNUME7, "
                StrSql = StrSql + "PINNEWNUM.E8 AS PNUME8, "
                StrSql = StrSql + "PINNEWNUM.E9 AS PNUME9, "
                StrSql = StrSql + "PINNEWNUM.E10 AS PNUME10, "
                StrSql = StrSql + "PINNEWNUM.F1 AS PNUMF1, "
                StrSql = StrSql + "PINNEWNUM.F2 AS PNUMF2, "
                StrSql = StrSql + "PINNEWNUM.F3 AS PNUMF3, "
                StrSql = StrSql + "PINNEWNUM.F4 AS PNUMF4, "
                StrSql = StrSql + "PINNEWNUM.F5 AS PNUMF5, "
                StrSql = StrSql + "PINNEWNUM.F6 AS PNUMF6, "
                StrSql = StrSql + "PINNEWNUM.F7 AS PNUMF7, "
                StrSql = StrSql + "PINNEWNUM.F8 AS PNUMF8, "
                StrSql = StrSql + "PINNEWNUM.F9 AS PNUMF9, "
                StrSql = StrSql + "PINNEWNUM.F10 AS PNUMF10, "
                StrSql = StrSql + "PINNEWNUM.G1 AS PNUMG1, "
                StrSql = StrSql + "PINNEWNUM.G2 AS PNUMG2, "
                StrSql = StrSql + "PINNEWNUM.G3 AS PNUMG3, "
                StrSql = StrSql + "PINNEWNUM.G4 AS PNUMG4, "
                StrSql = StrSql + "PINNEWNUM.G5 AS PNUMG5, "
                StrSql = StrSql + "PINNEWNUM.G6 AS PNUMG6, "
                StrSql = StrSql + "PINNEWNUM.G7 AS PNUMG7, "
                StrSql = StrSql + "PINNEWNUM.G8 AS PNUMG8, "
                StrSql = StrSql + "PINNEWNUM.G9 AS PNUMG9, "
                StrSql = StrSql + "PINNEWNUM.G10 AS PNUMG10, "
                StrSql = StrSql + "PINNEWNUM.H1 AS PNUMH1, "
                StrSql = StrSql + "PINNEWNUM.H2 AS PNUMH2, "
                StrSql = StrSql + "PINNEWNUM.H3 AS PNUMH3, "
                StrSql = StrSql + "PINNEWNUM.H4 AS PNUMH4, "
                StrSql = StrSql + "PINNEWNUM.H5 AS PNUMH5, "
                StrSql = StrSql + "PINNEWNUM.H6 AS PNUMH6, "
                StrSql = StrSql + "PINNEWNUM.H7 AS PNUMH7, "
                StrSql = StrSql + "PINNEWNUM.H8 AS PNUMH8, "
                StrSql = StrSql + "PINNEWNUM.H9 AS PNUMH9, "
                StrSql = StrSql + "PINNEWNUM.H10 AS PNUMH10, "
                StrSql = StrSql + "PINNEWNUM.I1 AS PNUMI1, "
                StrSql = StrSql + "PINNEWNUM.I2 AS PNUMI2, "
                StrSql = StrSql + "PINNEWNUM.I3 AS PNUMI3, "
                StrSql = StrSql + "PINNEWNUM.I4 AS PNUMI4, "
                StrSql = StrSql + "PINNEWNUM.I5 AS PNUMI5, "
                StrSql = StrSql + "PINNEWNUM.I6 AS PNUMI6, "
                StrSql = StrSql + "PINNEWNUM.I7 AS PNUMI7, "
                StrSql = StrSql + "PINNEWNUM.I8 AS PNUMI8, "
                StrSql = StrSql + "PINNEWNUM.I9 AS PNUMI9, "
                StrSql = StrSql + "PINNEWNUM.I10 AS PNUMI10, "
                StrSql = StrSql + "PINNEWNUM.J1 AS PNUMJ1, "
                StrSql = StrSql + "PINNEWNUM.J2 AS PNUMJ2, "
                StrSql = StrSql + "PINNEWNUM.J3 AS PNUMJ3, "
                StrSql = StrSql + "PINNEWNUM.J4 AS PNUMJ4, "
                StrSql = StrSql + "PINNEWNUM.J5 AS PNUMJ5, "
                StrSql = StrSql + "PINNEWNUM.J6 AS PNUMJ6, "
                StrSql = StrSql + "PINNEWNUM.J7 AS PNUMJ7, "
                StrSql = StrSql + "PINNEWNUM.J8 AS PNUMJ8, "
                StrSql = StrSql + "PINNEWNUM.J9 AS PNUMJ9, "
                StrSql = StrSql + "PINNEWNUM.J10 AS PNUMJ10, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM PALLETINNEW PINNEW "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=PINNEW.CASEID "
                StrSql = StrSql + "INNER JOIN PALLETINNEWNUMBER PINNEWNUM "
                StrSql = StrSql + "ON PINNEWNUM.CASEID = PINNEW.CASEID "
                StrSql = StrSql + "WHERE PINNEW.CASEID IN(" + CaseIds + ") ORDER BY PINNEW.CASEID "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function RwMaterial(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                StrSql = "SELECT  (MAT1.MATDE1||' '||MAT1.MATDE2) AS MATDE1,  "
                StrSql = StrSql + "(MAT2.MATDE1||' '||MAT2.MATDE2) AS MATDE2, "
                StrSql = StrSql + "(MAT3.MATDE1||' '||MAT3.MATDE2)AS MATDE3, "
                StrSql = StrSql + "(MAT4.MATDE1||' '||MAT4.MATDE2) AS MATDE4, "
                StrSql = StrSql + "(MAT5.MATDE1||' '||MAT5.MATDE2)AS MATDE5, "
                StrSql = StrSql + "(MAT6.MATDE1||' '||MAT6.MATDE2) AS MATDE6, "
                StrSql = StrSql + "(MAT7.MATDE1||' '||MAT7.MATDE2) AS MATDE7, "
                StrSql = StrSql + "(MAT8.MATDE1||' '||MAT8.MATDE2)AS MATDE8, "
                StrSql = StrSql + "(MAT9.MATDE1||' '||MAT9.MATDE2)AS MATDE9, "
                StrSql = StrSql + "(MAT10.MATDE1||' '||MAT10.MATDE2) AS MATDE10 "
                StrSql = StrSql + "FROM MATERIALINPUT MAT "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT1 "
                StrSql = StrSql + "ON MAT1.MATID = MAT.M1 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT2 "
                StrSql = StrSql + "ON MAT2.MATID = MAT.M2 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT3 "
                StrSql = StrSql + "ON MAT3.MATID = MAT.M3 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT4 "
                StrSql = StrSql + "ON MAT4.MATID = MAT.M4 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT5 "
                StrSql = StrSql + "ON MAT5.MATID = MAT.M5 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT6 "
                StrSql = StrSql + "ON MAT6.MATID = MAT.M6 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT7 "
                StrSql = StrSql + "ON MAT7.MATID = MAT.M7 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT8 "
                StrSql = StrSql + "ON MAT8.MATID = MAT.M8 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT9 "
                StrSql = StrSql + "ON MAT9.MATID = MAT.M9 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT10 "
                StrSql = StrSql + "ON MAT10.MATID = MAT.M10 "
                StrSql = StrSql + "WHERE MAT.CASEID IN(" + CaseIds + ") ORDER BY MAT.CASEID "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function ProductFormat(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT DISTINCT  "
                StrSql = StrSql + "PRODUCTFORMATIN.CASEID, "
                StrSql = StrSql + "( CASE WHEN PRODUCTFORMATIN.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = PRODUCTFORMATIN.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = PRODUCTFORMATIN.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "PRODUCTFORMATIN.M1, "
                StrSql = StrSql + "(PRODUCTFORMATIN.M2*PREFERENCES.CONVTHICK) AS M2, "
                StrSql = StrSql + "(PRODUCTFORMATIN.M3*PREFERENCES.CONVTHICK) AS M3, "
                StrSql = StrSql + "(PRODUCTFORMATIN.M4*PREFERENCES.CONVTHICK) AS M4, "
                StrSql = StrSql + "PRODUCTFORMATIN.M5, "
                StrSql = StrSql + "PRODUCTFORMATIN.M6, "
                StrSql = StrSql + "PREFERENCES.UNITS, "
                StrSql = StrSql + "NVL(PRODUCTFORMAT.M1,PRODUCTFORMAT2.M1 ) AS FORMAT_M1, "
                StrSql = StrSql + "NVL(PRODUCTFORMAT.M2,PRODUCTFORMAT2.M2 ) AS FORMAT_M2, "
                StrSql = StrSql + "NVL(PRODUCTFORMAT.M3,PRODUCTFORMAT2.M3 ) AS FORMAT_M3, "
                StrSql = StrSql + "NVL(PRODUCTFORMAT.M4,PRODUCTFORMAT2.M4 ) AS FORMAT_M4, "
                StrSql = StrSql + "NVL(PRODUCTFORMAT.M5,PRODUCTFORMAT2.M5 ) AS FORMAT_M5, "
                StrSql = StrSql + "(PRODUCTFORMATIN.PRODWT*PREFERENCES.CONVWT) AS PRODWT, "
                StrSql = StrSql + "(TOTAL.PRODWT*PREFERENCES.CONVWT) AS CONTWT, "
                StrSql = StrSql + "PREFERENCES.UNITS, "
                StrSql = StrSql + "PREFERENCES.TITLE1, "
                StrSql = StrSql + "PREFERENCES.TITLE3, "
                StrSql = StrSql + "PREFERENCES.TITLE2, "
                StrSql = StrSql + "PREFERENCES.TITLE4, "
                StrSql = StrSql + "PREFERENCES.TITLE5, "
                StrSql = StrSql + "PREFERENCES.TITLE6, "
                StrSql = StrSql + "PREFERENCES.TITLE7, "
                StrSql = StrSql + "PREFERENCES.TITLE8, "
                StrSql = StrSql + "PREFERENCES.TITLE9, "
                StrSql = StrSql + "PREFERENCES.TITLE10, "
                StrSql = StrSql + "PREFERENCES.TITLE11, "
                StrSql = StrSql + "PREFERENCES.TITLE12, "
                StrSql = StrSql + "PREFERENCES.UNITS "
                StrSql = StrSql + "FROM PRODUCTFORMATIN "
                StrSql = StrSql + "INNER JOIN PREFERENCES "
                StrSql = StrSql + "ON PREFERENCES.CASEID = PRODUCTFORMATIN.CASEID "
                StrSql = StrSql + "INNER JOIN TOTAL "
                StrSql = StrSql + "ON TOTAL.CASEID = PRODUCTFORMATIN.CASEID "
                StrSql = StrSql + "LEFT OUTER JOIN ECON.PRODUCTFORMAT "
                StrSql = StrSql + "ON PRODUCTFORMAT.FORMATID = PRODUCTFORMATIN.M1 "
                StrSql = StrSql + "AND PREFERENCES.UNITS = 0 "
                StrSql = StrSql + "LEFT OUTER JOIN ECON.PRODUCTFORMAT2 "
                StrSql = StrSql + "ON PRODUCTFORMAT2.FORMATID = PRODUCTFORMATIN.M1 "
                StrSql = StrSql + "AND PREFERENCES.UNITS = 1 "
                StrSql = StrSql + "WHERE PRODUCTFORMATIN.CASEID IN(" + CaseIds + ") ORDER BY PRODUCTFORMATIN.CASEID"



                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function PalletAndTruck(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT TKLP.CASEID,  "
                StrSql = StrSql + "( CASE WHEN TKLP.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = TKLP.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = TKLP.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(TKLP.M1*PREF.CONVTHICK) AS PALLETWIDTH, "
                StrSql = StrSql + "(TKLP.M2*PREF.CONVTHICK)	AS PALLETLENGTH, "
                StrSql = StrSql + "(TKLP.M3*PREF.CONVTHICK) AS PALLETHEIGHT, "
                StrSql = StrSql + "TKLP.M4 AS CARTONSNUMBER, "
                StrSql = StrSql + "TKLP.M5 AS PRODUCTNUMBER, "
                StrSql = StrSql + "(TKLP.T1*PREF.CONVTHICK) AS TRUCKWIDTH, "
                StrSql = StrSql + "(TKLP.T2*PREF.CONVTHICK) AS TRUCKLENGTH, "
                StrSql = StrSql + "(TKLP.T3*PREF.CONVTHICK) AS TRUCKHEIGHT, "
                StrSql = StrSql + "(TKLP.T4*PREF.CONVWT) AS TRUCKWEIGHTLIMIT, "
                StrSql = StrSql + "TKLP.T5 AS TRUCKNUMBER, "
                StrSql = StrSql + "(TOTAL.TOTWTPERT*PREF.CONVWT) AS CALCULATEDWEIGHT, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM TRUCKPALLETIN TKLP "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = TKLP.CASEID "
                StrSql = StrSql + "INNER JOIN TOTAL "
                StrSql = StrSql + "ON TOTAL.CASEID = TKLP.CASEID "
                StrSql = StrSql + "WHERE TKLP.CASEID IN(" + CaseIds + ") ORDER BY TKLP.CASEID"




                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function PalletIn(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT PAT.CASEID,  "
                StrSql = StrSql + "( CASE WHEN PAT.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = PAT.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = PAT.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "PAT.INVENTORYTYPE, "
                StrSql = StrSql + "TO_CHAR(PAT.EFFDATE,'MM/DD/YYYY')EFFDATE, "
                StrSql = StrSql + "PAT.M1, "
                StrSql = StrSql + "PAT.M2, "
                StrSql = StrSql + "PAT.M3, "
                StrSql = StrSql + "PAT.M4, "
                StrSql = StrSql + "PAT.M5, "
                StrSql = StrSql + "PAT.M6, "
                StrSql = StrSql + "PAT.M7, "
                StrSql = StrSql + "PAT.M8, "
                StrSql = StrSql + "PAT.M9, "
                StrSql = StrSql + "PAT.M10, "
                StrSql = StrSql + "PAT.R1, "
                StrSql = StrSql + "PAT.R2, "
                StrSql = StrSql + "PAT.R3, "
                StrSql = StrSql + "PAT.R4, "
                StrSql = StrSql + "PAT.R5, "
                StrSql = StrSql + "PAT.R6, "
                StrSql = StrSql + "PAT.R7, "
                StrSql = StrSql + "PAT.R8, "
                StrSql = StrSql + "PAT.R9, "
                StrSql = StrSql + "PAT.R10, "
                StrSql = StrSql + "PAT.T1, "
                StrSql = StrSql + "PAT.T2, "
                StrSql = StrSql + "PAT.T3, "
                StrSql = StrSql + "PAT.T4, "
                StrSql = StrSql + "PAT.T5, "
                StrSql = StrSql + "PAT.T6, "
                StrSql = StrSql + "PAT.T7, "
                StrSql = StrSql + "PAT.T8, "
                StrSql = StrSql + "PAT.T9, "
                StrSql = StrSql + "PAT.T10, "
                StrSql = StrSql + "(PAT1.WEIGHT*PREF.CONVWT) AS WS1, "
                StrSql = StrSql + "(PAT2.WEIGHT*PREF.CONVWT) AS WS2, "
                StrSql = StrSql + "(PAT3.WEIGHT*PREF.CONVWT) AS WS3, "
                StrSql = StrSql + "(PAT4.WEIGHT*PREF.CONVWT) AS WS4, "
                StrSql = StrSql + "(PAT5.WEIGHT*PREF.CONVWT) AS WS5, "
                StrSql = StrSql + "(PAT6.WEIGHT*PREF.CONVWT) AS WS6, "
                StrSql = StrSql + "(PAT7.WEIGHT*PREF.CONVWT) AS WS7, "
                StrSql = StrSql + "(PAT8.WEIGHT*PREF.CONVWT) AS WS8, "
                StrSql = StrSql + "(PAT9.WEIGHT*PREF.CONVWT) AS WS9, "
                StrSql = StrSql + "(PAT10.WEIGHT*PREF.CONVWT) AS WS10, "
                StrSql = StrSql + "(PAT.W1*PREF.CONVWT) AS WP1, "
                StrSql = StrSql + "(PAT.W2*PREF.CONVWT) AS WP2, "
                StrSql = StrSql + "(PAT.W3*PREF.CONVWT) AS WP3, "
                StrSql = StrSql + "(PAT.W4*PREF.CONVWT) AS WP4, "
                StrSql = StrSql + "(PAT.W5*PREF.CONVWT) AS WP5, "
                StrSql = StrSql + "(PAT.W6*PREF.CONVWT) AS WP6, "
                StrSql = StrSql + "(PAT.W7*PREF.CONVWT) AS WP7, "
                StrSql = StrSql + "(PAT.W8*PREF.CONVWT) AS WP8, "
                StrSql = StrSql + "(PAT.W9*PREF.CONVWT) AS WP9, "
                StrSql = StrSql + "(PAT.W10*PREF.CONVWT) AS WP10, "
                StrSql = StrSql + "(PAT1.JOULE/PREF.CONVWT) AS ERGYS1, "
                StrSql = StrSql + "(PAT2.JOULE/PREF.CONVWT) AS ERGYS2, "
                StrSql = StrSql + "(PAT3.JOULE/PREF.CONVWT) AS ERGYS3, "
                StrSql = StrSql + "(PAT4.JOULE/PREF.CONVWT) AS ERGYS4, "
                StrSql = StrSql + "(PAT5.JOULE/PREF.CONVWT) AS ERGYS5, "
                StrSql = StrSql + "(PAT6.JOULE/PREF.CONVWT) AS ERGYS6, "
                StrSql = StrSql + "(PAT7.JOULE/PREF.CONVWT) AS ERGYS7, "
                StrSql = StrSql + "(PAT8.JOULE/PREF.CONVWT) AS ERGYS8, "
                StrSql = StrSql + "(PAT9.JOULE/PREF.CONVWT) AS ERGYS9, "
                StrSql = StrSql + "(PAT10.JOULE/PREF.CONVWT) AS ERGYS10, "
                StrSql = StrSql + "(PATERGY.M1/PREF.CONVWT) AS ERGYP1, "
                StrSql = StrSql + "(PATERGY.M2/PREF.CONVWT) AS ERGYP2, "
                StrSql = StrSql + "(PATERGY.M3/PREF.CONVWT) AS ERGYP3, "
                StrSql = StrSql + "(PATERGY.M4/PREF.CONVWT) AS ERGYP4, "
                StrSql = StrSql + "(PATERGY.M5/PREF.CONVWT) AS ERGYP5, "
                StrSql = StrSql + "(PATERGY.M6/PREF.CONVWT) AS ERGYP6, "
                StrSql = StrSql + "(PATERGY.M7/PREF.CONVWT) AS ERGYP7, "
                StrSql = StrSql + "(PATERGY.M8/PREF.CONVWT) AS ERGYP8, "
                StrSql = StrSql + "(PATERGY.M9/PREF.CONVWT) AS ERGYP9, "
                StrSql = StrSql + "(PATERGY.M10/PREF.CONVWT) AS ERGYP10, "
                StrSql = StrSql + "(PAT1.PRICE) AS GHGS1, "
                StrSql = StrSql + "(PAT2.PRICE) AS GHGS2, "
                StrSql = StrSql + "(PAT3.PRICE) AS GHGS3, "
                StrSql = StrSql + "(PAT4.PRICE) AS GHGS4, "
                StrSql = StrSql + "(PAT5.PRICE) AS GHGS5, "
                StrSql = StrSql + "(PAT6.PRICE) AS GHGS6, "
                StrSql = StrSql + "(PAT7.PRICE) AS GHGS7, "
                StrSql = StrSql + "(PAT8.PRICE) AS GHGS8, "
                StrSql = StrSql + "(PAT9.PRICE) AS GHGS9, "
                StrSql = StrSql + "(PAT10.PRICE) AS GHGS10, "
                StrSql = StrSql + "(PAT.P1) AS GHGP1, "
                StrSql = StrSql + "(PAT.P2) AS GHGP2, "
                StrSql = StrSql + "(PAT.P3) AS GHGP3, "
                StrSql = StrSql + "(PAT.P4) AS GHGP4, "
                StrSql = StrSql + "(PAT.P5) AS GHGP5, "
                StrSql = StrSql + "(PAT.P6) AS GHGP6, "
                StrSql = StrSql + "(PAT.P7) AS GHGP7, "
                StrSql = StrSql + "(PAT.P8) AS GHGP8, "
                StrSql = StrSql + "(PAT.P9) AS GHGP9, "
                StrSql = StrSql + "(PAT.P10) AS GHGP10, "
                StrSql = StrSql + "(PAT1.RECOVERYSUG) AS RECS1, "
                StrSql = StrSql + "(PAT2.RECOVERYSUG) AS RECS2, "
                StrSql = StrSql + "(PAT3.RECOVERYSUG) AS RECS3, "
                StrSql = StrSql + "(PAT4.RECOVERYSUG) AS RECS4, "
                StrSql = StrSql + "(PAT5.RECOVERYSUG) AS RECS5, "
                StrSql = StrSql + "(PAT6.RECOVERYSUG) AS RECS6, "
                StrSql = StrSql + "(PAT7.RECOVERYSUG) AS RECS7, "
                StrSql = StrSql + "(PAT8.RECOVERYSUG) AS RECS8, "
                StrSql = StrSql + "(PAT9.RECOVERYSUG) AS RECS9, "
                StrSql = StrSql + "(PAT10.RECOVERYSUG) AS RECS10, "
                StrSql = StrSql + "(PAT.REC1) AS RECP1, "
                StrSql = StrSql + "(PAT.REC2) AS RECP2, "
                StrSql = StrSql + "(PAT.REC3) AS RECP3, "
                StrSql = StrSql + "(PAT.REC4) AS RECP4, "
                StrSql = StrSql + "(PAT.REC5) AS RECP5, "
                StrSql = StrSql + "(PAT.REC6) AS RECP6, "
                StrSql = StrSql + "(PAT.REC7) AS RECP7, "
                StrSql = StrSql + "(PAT.REC8) AS RECP8, "
                StrSql = StrSql + "(PAT.REC9) AS RECP9, "
                StrSql = StrSql + "(PAT.REC10) AS RECP10, "
                StrSql = StrSql + "(PAT1.OSHAFACTOR) AS OSHAS1, "
                StrSql = StrSql + "(PAT2.OSHAFACTOR) AS OSHAS2, "
                StrSql = StrSql + "(PAT3.OSHAFACTOR) AS OSHAS3, "
                StrSql = StrSql + "(PAT4.OSHAFACTOR) AS OSHAS4, "
                StrSql = StrSql + "(PAT5.OSHAFACTOR) AS OSHAS5, "
                StrSql = StrSql + "(PAT6.OSHAFACTOR) AS OSHAS6, "
                StrSql = StrSql + "(PAT7.OSHAFACTOR) AS OSHAS7, "
                StrSql = StrSql + "(PAT8.OSHAFACTOR) AS OSHAS8, "
                StrSql = StrSql + "(PAT9.OSHAFACTOR) AS OSHAS9, "
                StrSql = StrSql + "(PAT10.OSHAFACTOR) AS OSHAS10, "
                StrSql = StrSql + "(PAT.OSH1) AS OSHAP1, "
                StrSql = StrSql + "(PAT.OSH2) AS OSHAP2, "
                StrSql = StrSql + "(PAT.OSH3) AS OSHAP3, "
                StrSql = StrSql + "(PAT.OSH4) AS OSHAP4, "
                StrSql = StrSql + "(PAT.OSH5) AS OSHAP5, "
                StrSql = StrSql + "(PAT.OSH6) AS OSHAP6, "
                StrSql = StrSql + "(PAT.OSH7) AS OSHAP7, "
                StrSql = StrSql + "(PAT.OSH8) AS OSHAP8, "
                StrSql = StrSql + "(PAT.OSH9) AS OSHAP9, "
                StrSql = StrSql + "(PAT.OSH10) AS OSHAP10, "
                StrSql = StrSql + "(PAT1.POSTCONSUMER) AS POCS1, "
                StrSql = StrSql + "(PAT2.POSTCONSUMER) AS POCS2, "
                StrSql = StrSql + "(PAT3.POSTCONSUMER) AS POCS3, "
                StrSql = StrSql + "(PAT4.POSTCONSUMER) AS POCS4, "
                StrSql = StrSql + "(PAT5.POSTCONSUMER) AS POCS5, "
                StrSql = StrSql + "(PAT6.POSTCONSUMER) AS POCS6, "
                StrSql = StrSql + "(PAT7.POSTCONSUMER) AS POCS7, "
                StrSql = StrSql + "(PAT8.POSTCONSUMER) AS POCS8, "
                StrSql = StrSql + "(PAT9.POSTCONSUMER) AS POCS9, "
                StrSql = StrSql + "(PAT10.POSTCONSUMER) AS POCS10, "
                StrSql = StrSql + "(PAT.POC1) AS POCP1, "
                StrSql = StrSql + "(PAT.POC2) AS POCP2, "
                StrSql = StrSql + "(PAT.POC3) AS POCP3, "
                StrSql = StrSql + "(PAT.POC4) AS POCP4, "
                StrSql = StrSql + "(PAT.POC5) AS POCP5, "
                StrSql = StrSql + "(PAT.POC6) AS POCP6, "
                StrSql = StrSql + "(PAT.POC7) AS POCP7, "
                StrSql = StrSql + "(PAT.POC8) AS POCP8, "
                StrSql = StrSql + "(PAT.POC9) AS POCP9, "
                StrSql = StrSql + "(PAT.POC10) AS POCP10, "
                StrSql = StrSql + "(PAT1.SHIP*PREF.CONVTHICK3) AS SDS1, "
                StrSql = StrSql + "(PAT2.SHIP*PREF.CONVTHICK3) AS SDS2, "
                StrSql = StrSql + "(PAT3.SHIP*PREF.CONVTHICK3) AS SDS3, "
                StrSql = StrSql + "(PAT4.SHIP*PREF.CONVTHICK3) AS SDS4, "
                StrSql = StrSql + "(PAT5.SHIP*PREF.CONVTHICK3) AS SDS5, "
                StrSql = StrSql + "(PAT6.SHIP*PREF.CONVTHICK3) AS SDS6, "
                StrSql = StrSql + "(PAT7.SHIP*PREF.CONVTHICK3) AS SDS7, "
                StrSql = StrSql + "(PAT8.SHIP*PREF.CONVTHICK3) AS SDS8, "
                StrSql = StrSql + "(PAT9.SHIP*PREF.CONVTHICK3) AS SDS9, "
                StrSql = StrSql + "(PAT10.SHIP*PREF.CONVTHICK3) AS SDS10, "
                StrSql = StrSql + "(PAT.SD1*PREF.CONVTHICK3) AS SDP1, "
                StrSql = StrSql + "(PAT.SD2*PREF.CONVTHICK3) AS SDP2, "
                StrSql = StrSql + "(PAT.SD3*PREF.CONVTHICK3) AS SDP3, "
                StrSql = StrSql + "(PAT.SD4*PREF.CONVTHICK3) AS SDP4, "
                StrSql = StrSql + "(PAT.SD5*PREF.CONVTHICK3) AS SDP5, "
                StrSql = StrSql + "(PAT.SD6*PREF.CONVTHICK3) AS SDP6, "
                StrSql = StrSql + "(PAT.SD7*PREF.CONVTHICK3) AS SDP7, "
                StrSql = StrSql + "(PAT.SD8*PREF.CONVTHICK3) AS SDP8, "
                StrSql = StrSql + "(PAT.SD9*PREF.CONVTHICK3) AS SDP9, "
                StrSql = StrSql + "(PAT.SD10*PREF.CONVTHICK3) AS SDP10, "
                StrSql = StrSql + "PAT.D1, "
                StrSql = StrSql + "PAT.D2, "
                StrSql = StrSql + "PAT.D3, "
                StrSql = StrSql + "PAT.D4, "
                StrSql = StrSql + "PAT.D5, "
                StrSql = StrSql + "PAT.D6, "
                StrSql = StrSql + "PAT.D7, "
                StrSql = StrSql + "PAT.D8, "
                StrSql = StrSql + "PAT.D9, "
                StrSql = StrSql + "PAT.D10, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM PALLETIN PAT "
                StrSql = StrSql + "INNER JOIN PALLETARCH PAT1 "
                StrSql = StrSql + "ON PAT1.EFFDATE = PAT.EFFDATE "
                StrSql = StrSql + "AND PAT1.INVENTORYTYPE =  PAT.INVENTORYTYPE "
                StrSql = StrSql + "AND PAT1.PALLETID = PAT.M1 "
                StrSql = StrSql + "INNER JOIN PALLETARCH PAT2 "
                StrSql = StrSql + "ON PAT2.EFFDATE = PAT.EFFDATE "
                StrSql = StrSql + "AND PAT2.INVENTORYTYPE =  PAT.INVENTORYTYPE "
                StrSql = StrSql + "AND PAT2.PALLETID = PAT.M2 "
                StrSql = StrSql + "INNER JOIN PALLETARCH PAT3 "
                StrSql = StrSql + "ON PAT3.EFFDATE = PAT.EFFDATE "
                StrSql = StrSql + "AND PAT3.INVENTORYTYPE =  PAT.INVENTORYTYPE "
                StrSql = StrSql + "AND PAT3.PALLETID = PAT.M3 "
                StrSql = StrSql + "INNER JOIN PALLETARCH PAT4 "
                StrSql = StrSql + "ON PAT4.EFFDATE = PAT.EFFDATE "
                StrSql = StrSql + "AND PAT4.INVENTORYTYPE =  PAT.INVENTORYTYPE "
                StrSql = StrSql + "AND PAT4.PALLETID = PAT.M4 "
                StrSql = StrSql + "INNER JOIN PALLETARCH PAT5 "
                StrSql = StrSql + "ON PAT5.EFFDATE = PAT.EFFDATE "
                StrSql = StrSql + "AND PAT5.INVENTORYTYPE =  PAT.INVENTORYTYPE "
                StrSql = StrSql + "AND PAT5.PALLETID = PAT.M5 "
                StrSql = StrSql + "INNER JOIN PALLETARCH PAT6 "
                StrSql = StrSql + "ON PAT6.EFFDATE = PAT.EFFDATE "
                StrSql = StrSql + "AND PAT6.INVENTORYTYPE =  PAT.INVENTORYTYPE "
                StrSql = StrSql + "AND PAT6.PALLETID = PAT.M6 "
                StrSql = StrSql + "INNER JOIN PALLETARCH PAT7 "
                StrSql = StrSql + "ON PAT7.EFFDATE = PAT.EFFDATE "
                StrSql = StrSql + "AND PAT7.INVENTORYTYPE =  PAT.INVENTORYTYPE "
                StrSql = StrSql + "AND PAT7.PALLETID = PAT.M7 "
                StrSql = StrSql + "INNER JOIN PALLETARCH PAT8 "
                StrSql = StrSql + "ON PAT8.EFFDATE = PAT.EFFDATE "
                StrSql = StrSql + "AND PAT8.INVENTORYTYPE =  PAT.INVENTORYTYPE "
                StrSql = StrSql + "AND PAT8.PALLETID = PAT.M8 "
                StrSql = StrSql + "INNER JOIN PALLETARCH PAT9 "
                StrSql = StrSql + "ON PAT9.EFFDATE = PAT.EFFDATE "
                StrSql = StrSql + "AND PAT9.INVENTORYTYPE =  PAT.INVENTORYTYPE "
                StrSql = StrSql + "AND PAT9.PALLETID = PAT.M9 "
                StrSql = StrSql + "INNER JOIN PALLETARCH PAT10 "
                StrSql = StrSql + "ON PAT10.EFFDATE = PAT.EFFDATE "
                StrSql = StrSql + "AND PAT10.INVENTORYTYPE =  PAT.INVENTORYTYPE "
                StrSql = StrSql + "AND PAT10.PALLETID = PAT.M10 "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=PAT.CASEID "
                StrSql = StrSql + "INNER JOIN PALLETENERGYPREF PATERGY "
                StrSql = StrSql + "ON PATERGY.CASEID=PAT.CASEID "
                StrSql = StrSql + "WHERE PAT.CASEID IN(" + CaseIds + ") ORDER BY PAT.CASEID"





                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function PlantConfig(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "PLANTCONFIG.CASEID, "
                StrSql = StrSql + "( CASE WHEN PLANTCONFIG.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = PLANTCONFIG.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = PLANTCONFIG.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "PLANTCONFIG.M1 AS D1P1, "
                StrSql = StrSql + "PLANTCONFIG.T1 AS D1P2, "
                StrSql = StrSql + "PLANTCONFIG.S1 AS D1P3, "
                StrSql = StrSql + "PLANTCONFIG.Y1 AS D1P4, "
                StrSql = StrSql + "PLANTCONFIG.D1 AS D1P5, "
                StrSql = StrSql + "PLANTCONFIG.Z1 AS D1P6, "
                StrSql = StrSql + "PLANTCONFIG.B1 AS D1P7, "
                StrSql = StrSql + "PLANTCONFIG.R1 AS D1P8, "
                StrSql = StrSql + "PLANTCONFIG.K1 AS D1P9, "
                StrSql = StrSql + "PLANTCONFIG.P1 AS D1P10, "
                StrSql = StrSql + "PLANTCONFIG.M2 AS D2P1, "
                StrSql = StrSql + "PLANTCONFIG.T2 AS D2P2, "
                StrSql = StrSql + "PLANTCONFIG.S2 AS D2P3, "
                StrSql = StrSql + "PLANTCONFIG.Y2 AS D2P4, "
                StrSql = StrSql + "PLANTCONFIG.D2 AS D2P5, "
                StrSql = StrSql + "PLANTCONFIG.Z2 AS D2P6, "
                StrSql = StrSql + "PLANTCONFIG.B2 AS D2P7, "
                StrSql = StrSql + "PLANTCONFIG.R2 AS D2P8, "
                StrSql = StrSql + "PLANTCONFIG.K2 AS D2P9, "
                StrSql = StrSql + "PLANTCONFIG.P2 AS D2P10, "
                StrSql = StrSql + "PLANTCONFIG.M3 AS D3P1, "
                StrSql = StrSql + "PLANTCONFIG.T3 AS D3P2, "
                StrSql = StrSql + "PLANTCONFIG.S3 AS D3P3, "
                StrSql = StrSql + "PLANTCONFIG.Y3 AS D3P4, "
                StrSql = StrSql + "PLANTCONFIG.D3 AS D3P5, "
                StrSql = StrSql + "PLANTCONFIG.Z3 AS D3P6, "
                StrSql = StrSql + "PLANTCONFIG.B3 AS D3P7, "
                StrSql = StrSql + "PLANTCONFIG.R3 AS D3P8, "
                StrSql = StrSql + "PLANTCONFIG.K3 AS D3P9, "
                StrSql = StrSql + "PLANTCONFIG.P3 AS D3P10, "
                StrSql = StrSql + "PLANTCONFIG.M4 AS D4P1, "
                StrSql = StrSql + "PLANTCONFIG.T4 AS D4P2, "
                StrSql = StrSql + "PLANTCONFIG.S4 AS D4P3, "
                StrSql = StrSql + "PLANTCONFIG.Y4 AS D4P4, "
                StrSql = StrSql + "PLANTCONFIG.D4 AS D4P5, "
                StrSql = StrSql + "PLANTCONFIG.Z4 AS D4P6, "
                StrSql = StrSql + "PLANTCONFIG.B4 AS D4P7, "
                StrSql = StrSql + "PLANTCONFIG.R4 AS D4P8, "
                StrSql = StrSql + "PLANTCONFIG.K4 AS D4P9, "
                StrSql = StrSql + "PLANTCONFIG.P4 AS D4P10, "
                StrSql = StrSql + "PLANTCONFIG.M5 AS D5P1, "
                StrSql = StrSql + "PLANTCONFIG.T5 AS D5P2, "
                StrSql = StrSql + "PLANTCONFIG.S5 AS D5P3, "
                StrSql = StrSql + "PLANTCONFIG.Y5 AS D5P4, "
                StrSql = StrSql + "PLANTCONFIG.D5 AS D5P5, "
                StrSql = StrSql + "PLANTCONFIG.Z5 AS D5P6, "
                StrSql = StrSql + "PLANTCONFIG.B5 AS D5P7, "
                StrSql = StrSql + "PLANTCONFIG.R5 AS D5P8, "
                StrSql = StrSql + "PLANTCONFIG.K5 AS D5P9, "
                StrSql = StrSql + "PLANTCONFIG.P5 AS D5P10, "
                StrSql = StrSql + "PLANTCONFIG.M6 AS D6P1, "
                StrSql = StrSql + "PLANTCONFIG.T6 AS D6P2, "
                StrSql = StrSql + "PLANTCONFIG.S6 AS D6P3, "
                StrSql = StrSql + "PLANTCONFIG.Y6 AS D6P4, "
                StrSql = StrSql + "PLANTCONFIG.D6 AS D6P5, "
                StrSql = StrSql + "PLANTCONFIG.Z6 AS D6P6, "
                StrSql = StrSql + "PLANTCONFIG.B6 AS D6P7, "
                StrSql = StrSql + "PLANTCONFIG.R6 AS D6P8, "
                StrSql = StrSql + "PLANTCONFIG.K6 AS D6P9, "
                StrSql = StrSql + "PLANTCONFIG.P6 AS D6P10, "
                StrSql = StrSql + "PLANTCONFIG.M7 AS D7P1, "
                StrSql = StrSql + "PLANTCONFIG.T7 AS D7P2, "
                StrSql = StrSql + "PLANTCONFIG.S7 AS D7P3, "
                StrSql = StrSql + "PLANTCONFIG.Y7 AS D7P4, "
                StrSql = StrSql + "PLANTCONFIG.D7 AS D7P5, "
                StrSql = StrSql + "PLANTCONFIG.Z7 AS D7P6, "
                StrSql = StrSql + "PLANTCONFIG.B7 AS D7P7, "
                StrSql = StrSql + "PLANTCONFIG.R7 AS D7P8, "
                StrSql = StrSql + "PLANTCONFIG.K7 AS D7P9, "
                StrSql = StrSql + "PLANTCONFIG.P7 AS D7P10, "
                StrSql = StrSql + "PLANTCONFIG.M8 AS D8P1, "
                StrSql = StrSql + "PLANTCONFIG.T8 AS D8P2, "
                StrSql = StrSql + "PLANTCONFIG.S8 AS D8P3, "
                StrSql = StrSql + "PLANTCONFIG.Y8 AS D8P4, "
                StrSql = StrSql + "PLANTCONFIG.D8 AS D8P5, "
                StrSql = StrSql + "PLANTCONFIG.Z8 AS D8P6, "
                StrSql = StrSql + "PLANTCONFIG.B8 AS D8P7, "
                StrSql = StrSql + "PLANTCONFIG.R8 AS D8P8, "
                StrSql = StrSql + "PLANTCONFIG.K8 AS D8P9, "
                StrSql = StrSql + "PLANTCONFIG.P8 AS D8P10, "
                StrSql = StrSql + "PLANTCONFIG.M9 AS D9P1, "
                StrSql = StrSql + "PLANTCONFIG.T9 AS D9P2, "
                StrSql = StrSql + "PLANTCONFIG.S9 AS D9P3, "
                StrSql = StrSql + "PLANTCONFIG.Y9 AS D9P4, "
                StrSql = StrSql + "PLANTCONFIG.D9 AS D9P5, "
                StrSql = StrSql + "PLANTCONFIG.Z9 AS D9P6, "
                StrSql = StrSql + "PLANTCONFIG.B9 AS D9P7, "
                StrSql = StrSql + "PLANTCONFIG.R9 AS D9P8, "
                StrSql = StrSql + "PLANTCONFIG.K9 AS D9P9, "
                StrSql = StrSql + "PLANTCONFIG.P9 AS D9P10, "
                StrSql = StrSql + "PLANTCONFIG.M10 AS D10P1, "
                StrSql = StrSql + "PLANTCONFIG.T10 AS D10P2, "
                StrSql = StrSql + "PLANTCONFIG.S10 AS D10P3, "
                StrSql = StrSql + "PLANTCONFIG.Y10 AS D10P4, "
                StrSql = StrSql + "PLANTCONFIG.D10 AS D10P5, "
                StrSql = StrSql + "PLANTCONFIG.Z10 AS D10P6, "
                StrSql = StrSql + "PLANTCONFIG.B10 AS D10P7, "
                StrSql = StrSql + "PLANTCONFIG.R10 AS D10P8, "
                StrSql = StrSql + "PLANTCONFIG.K10 AS D10P9, "
                StrSql = StrSql + "PLANTCONFIG.P10 AS D10P10 "
                StrSql = StrSql + "FROM PLANTCONFIG "
                StrSql = StrSql + "WHERE PLANTCONFIG.CASEID  IN(" + CaseIds + ") ORDER BY PLANTCONFIG.CASEID "





                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function Effeciency(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                StrSql = "SELECT DISTINCT  "
                StrSql = StrSql + "MATERIALEFF.CASEID, "
                StrSql = StrSql + "( CASE WHEN MATERIALEFF.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = PLANTCONFIG.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = MATERIALEFF.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(MATERIALS1.MATDE1 ||' '|| MATERIALS1.MATDE2  )  AS MATERIAL1DES, "
                StrSql = StrSql + "(MATERIALS2.MATDE1 ||' '|| MATERIALS2.MATDE2  )  AS MATERIAL2DES, "
                StrSql = StrSql + "(MATERIALS3.MATDE1 ||' '|| MATERIALS3.MATDE2  )  AS MATERIAL3DES, "
                StrSql = StrSql + "(MATERIALS4.MATDE1 ||' '|| MATERIALS4.MATDE2  )  AS MATERIAL4DES, "
                StrSql = StrSql + "(MATERIALS5.MATDE1 ||' '|| MATERIALS5.MATDE2  )  AS MATERIAL5DES, "
                StrSql = StrSql + "(MATERIALS6.MATDE1 ||' '|| MATERIALS6.MATDE2  )  AS MATERIAL6DES, "
                StrSql = StrSql + "(MATERIALS7.MATDE1 ||' '|| MATERIALS7.MATDE2  )  AS MATERIAL7DES, "
                StrSql = StrSql + "(MATERIALS8.MATDE1 ||' '|| MATERIALS8.MATDE2  )  AS MATERIAL8DES, "
                StrSql = StrSql + "(MATERIALS9.MATDE1 ||' '|| MATERIALS9.MATDE2  )  AS MATERIAL9DES, "
                StrSql = StrSql + "(MATERIALS10.MATDE1 ||' '|| MATERIALS10.MATDE2  )  AS MATERIAL10DES, "
                StrSql = StrSql + "(PROCESS1.PROCDE1 ||' '|| PROCESS1.PROCDE2 ) AS PROCESS1DES, "
                StrSql = StrSql + "(PROCESS2.PROCDE1 ||' '|| PROCESS2.PROCDE2 ) AS PROCESS2DES, "
                StrSql = StrSql + "(PROCESS3.PROCDE1 ||' '|| PROCESS3.PROCDE2 ) AS PROCESS3DES, "
                StrSql = StrSql + "(PROCESS4.PROCDE1 ||' '|| PROCESS4.PROCDE2 ) AS PROCESS4DES, "
                StrSql = StrSql + "(PROCESS5.PROCDE1 ||' '|| PROCESS5.PROCDE2 ) AS PROCESS5DES, "
                StrSql = StrSql + "(PROCESS6.PROCDE1 ||' '|| PROCESS6.PROCDE2 ) AS PROCESS6DES, "
                StrSql = StrSql + "(PROCESS7.PROCDE1 ||' '|| PROCESS7.PROCDE2 ) AS PROCESS7DES, "
                StrSql = StrSql + "(PROCESS8.PROCDE1 ||' '|| PROCESS8.PROCDE2 ) AS PROCESS8DES, "
                StrSql = StrSql + "(PROCESS9.PROCDE1 ||' '|| PROCESS9.PROCDE2 ) AS PROCESS9DES, "
                StrSql = StrSql + "(PROCESS10.PROCDE1 ||' '|| PROCESS10.PROCDE2 ) AS PROCESS10DES, "
                StrSql = StrSql + "MATERIALEFF.T1 AS LAYER1DEPT1, "
                StrSql = StrSql + "MATERIALEFF.T2 AS LAYER1DEPT2, "
                StrSql = StrSql + "MATERIALEFF.T3 AS LAYER1DEPT3, "
                StrSql = StrSql + "MATERIALEFF.T4 AS LAYER1DEPT4, "
                StrSql = StrSql + "MATERIALEFF.T5 AS LAYER1DEPT5, "
                StrSql = StrSql + "MATERIALEFF.T6 AS LAYER1DEPT6, "
                StrSql = StrSql + "MATERIALEFF.T7 AS LAYER1DEPT7, "
                StrSql = StrSql + "MATERIALEFF.T8 AS LAYER1DEPT8, "
                StrSql = StrSql + "MATERIALEFF.T9 AS LAYER1DEPT9, "
                StrSql = StrSql + "MATERIALEFF.T10 AS LAYER1DEPT10, "
                StrSql = StrSql + "MATERIALEFF.S1 AS LAYER2DEPT1, "
                StrSql = StrSql + "MATERIALEFF.S2 AS LAYER2DEPT2, "
                StrSql = StrSql + "MATERIALEFF.S3 AS LAYER2DEPT3, "
                StrSql = StrSql + "MATERIALEFF.S4 AS LAYER2DEPT4, "
                StrSql = StrSql + "MATERIALEFF.S5 AS LAYER2DEPT5, "
                StrSql = StrSql + "MATERIALEFF.S6 AS LAYER2DEPT6, "
                StrSql = StrSql + "MATERIALEFF.S7 AS LAYER2DEPT7, "
                StrSql = StrSql + "MATERIALEFF.S8 AS LAYER2DEPT8, "
                StrSql = StrSql + "MATERIALEFF.S9 AS LAYER2DEPT9, "
                StrSql = StrSql + "MATERIALEFF.S10 AS LAYER2DEPT10, "
                StrSql = StrSql + "MATERIALEFF.Y1 AS LAYER3DEPT1, "
                StrSql = StrSql + "MATERIALEFF.Y2 AS LAYER3DEPT2, "
                StrSql = StrSql + "MATERIALEFF.Y3 AS LAYER3DEPT3, "
                StrSql = StrSql + "MATERIALEFF.Y4 AS LAYER3DEPT4, "
                StrSql = StrSql + "MATERIALEFF.Y5 AS LAYER3DEPT5, "
                StrSql = StrSql + "MATERIALEFF.Y6 AS LAYER3DEPT6, "
                StrSql = StrSql + "MATERIALEFF.Y7 AS LAYER3DEPT7, "
                StrSql = StrSql + "MATERIALEFF.Y8 AS LAYER3DEPT8, "
                StrSql = StrSql + "MATERIALEFF.Y9 AS LAYER3DEPT9, "
                StrSql = StrSql + "MATERIALEFF.Y10 AS LAYER3DEPT10, "
                StrSql = StrSql + "MATERIALEFF.D1 AS LAYER4DEPT1, "
                StrSql = StrSql + "MATERIALEFF.D2 AS LAYER4DEPT2, "
                StrSql = StrSql + "MATERIALEFF.D3 AS LAYER4DEPT3, "
                StrSql = StrSql + "MATERIALEFF.D4 AS LAYER4DEPT4, "
                StrSql = StrSql + "MATERIALEFF.D5 AS LAYER4DEPT5, "
                StrSql = StrSql + "MATERIALEFF.D6 AS LAYER4DEPT6, "
                StrSql = StrSql + "MATERIALEFF.D7 AS LAYER4DEPT7, "
                StrSql = StrSql + "MATERIALEFF.D8 AS LAYER4DEPT8, "
                StrSql = StrSql + "MATERIALEFF.D9 AS LAYER4DEPT9, "
                StrSql = StrSql + "MATERIALEFF.D10 AS LAYER4DEPT10, "
                StrSql = StrSql + "MATERIALEFF.E1 AS LAYER5DEPT1, "
                StrSql = StrSql + "MATERIALEFF.E2 AS LAYER5DEPT2, "
                StrSql = StrSql + "MATERIALEFF.E3 AS LAYER5DEPT3, "
                StrSql = StrSql + "MATERIALEFF.E4 AS LAYER5DEPT4, "
                StrSql = StrSql + "MATERIALEFF.E5 AS LAYER5DEPT5, "
                StrSql = StrSql + "MATERIALEFF.E6 AS LAYER5DEPT6, "
                StrSql = StrSql + "MATERIALEFF.E7 AS LAYER5DEPT7, "
                StrSql = StrSql + "MATERIALEFF.E8 AS LAYER5DEPT8, "
                StrSql = StrSql + "MATERIALEFF.E9 AS LAYER5DEPT9, "
                StrSql = StrSql + "MATERIALEFF.E10 AS LAYER5DEPT10, "
                StrSql = StrSql + "MATERIALEFF.Z1 AS LAYER6DEPT1, "
                StrSql = StrSql + "MATERIALEFF.Z2 AS LAYER6DEPT2, "
                StrSql = StrSql + "MATERIALEFF.Z3 AS LAYER6DEPT3, "
                StrSql = StrSql + "MATERIALEFF.Z4 AS LAYER6DEPT4, "
                StrSql = StrSql + "MATERIALEFF.Z5 AS LAYER6DEPT5, "
                StrSql = StrSql + "MATERIALEFF.Z6 AS LAYER6DEPT6, "
                StrSql = StrSql + "MATERIALEFF.Z7 AS LAYER6DEPT7, "
                StrSql = StrSql + "MATERIALEFF.Z8 AS LAYER6DEPT8, "
                StrSql = StrSql + "MATERIALEFF.Z9 AS LAYER6DEPT9, "
                StrSql = StrSql + "MATERIALEFF.Z10 AS LAYER6DEPT10, "
                StrSql = StrSql + "MATERIALEFF.B1 AS LAYER7DEPT1, "
                StrSql = StrSql + "MATERIALEFF.B2 AS LAYER7DEPT2, "
                StrSql = StrSql + "MATERIALEFF.B3 AS LAYER7DEPT3, "
                StrSql = StrSql + "MATERIALEFF.B4 AS LAYER7DEPT4, "
                StrSql = StrSql + "MATERIALEFF.B5 AS LAYER7DEPT5, "
                StrSql = StrSql + "MATERIALEFF.B6 AS LAYER7DEPT6, "
                StrSql = StrSql + "MATERIALEFF.B7 AS LAYER7DEPT7, "
                StrSql = StrSql + "MATERIALEFF.B8 AS LAYER7DEPT8, "
                StrSql = StrSql + "MATERIALEFF.B9 AS LAYER7DEPT9, "
                StrSql = StrSql + "MATERIALEFF.B10 AS LAYER7DEPT10, "
                StrSql = StrSql + "MATERIALEFF.R1 AS LAYER8DEPT1, "
                StrSql = StrSql + "MATERIALEFF.R2 AS LAYER8DEPT2, "
                StrSql = StrSql + "MATERIALEFF.R3 AS LAYER8DEPT3, "
                StrSql = StrSql + "MATERIALEFF.R4 AS LAYER8DEPT4, "
                StrSql = StrSql + "MATERIALEFF.R5 AS LAYER8DEPT5, "
                StrSql = StrSql + "MATERIALEFF.R6 AS LAYER8DEPT6, "
                StrSql = StrSql + "MATERIALEFF.R7 AS LAYER8DEPT7, "
                StrSql = StrSql + "MATERIALEFF.R8 AS LAYER8DEPT8, "
                StrSql = StrSql + "MATERIALEFF.R9 AS LAYER8DEPT9, "
                StrSql = StrSql + "MATERIALEFF.R10 AS LAYER8DEPT10, "
                StrSql = StrSql + "MATERIALEFF.K1 AS LAYER9DEPT1, "
                StrSql = StrSql + "MATERIALEFF.K2 AS LAYER9DEPT2, "
                StrSql = StrSql + "MATERIALEFF.K3 AS LAYER9DEPT3, "
                StrSql = StrSql + "MATERIALEFF.K4 AS LAYER9DEPT4, "
                StrSql = StrSql + "MATERIALEFF.K5 AS LAYER9DEPT5, "
                StrSql = StrSql + "MATERIALEFF.K6 AS LAYER9DEPT6, "
                StrSql = StrSql + "MATERIALEFF.K7 AS LAYER9DEPT7, "
                StrSql = StrSql + "MATERIALEFF.K8 AS LAYER9DEPT8, "
                StrSql = StrSql + "MATERIALEFF.K9 AS LAYER9DEPT9, "
                StrSql = StrSql + "MATERIALEFF.K10 AS LAYER9DEPT10, "
                StrSql = StrSql + "MATERIALEFF.P1 AS LAYER10DEPT1, "
                StrSql = StrSql + "MATERIALEFF.P2 AS LAYER10DEPT2, "
                StrSql = StrSql + "MATERIALEFF.P3 AS LAYER10DEPT3, "
                StrSql = StrSql + "MATERIALEFF.P4 AS LAYER10DEPT4, "
                StrSql = StrSql + "MATERIALEFF.P5 AS LAYER10DEPT5, "
                StrSql = StrSql + "MATERIALEFF.P6 AS LAYER10DEPT6, "
                StrSql = StrSql + "MATERIALEFF.P7 AS LAYER10DEPT7, "
                StrSql = StrSql + "MATERIALEFF.P8 AS LAYER10DEPT8, "
                StrSql = StrSql + "MATERIALEFF.P9 AS LAYER10DEPT9, "
                StrSql = StrSql + "MATERIALEFF.P10 AS LAYER10DEPT10 "
                StrSql = StrSql + "FROM "
                StrSql = StrSql + "MATERIALEFF "
                StrSql = StrSql + "INNER JOIN  MATERIALINPUT "
                StrSql = StrSql + "ON  MATERIALINPUT.CASEID = MATERIALEFF.CASEID "
                StrSql = StrSql + "INNER JOIN  PLANTCONFIG "
                StrSql = StrSql + "ON  PLANTCONFIG.CASEID = MATERIALEFF.CASEID "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATERIALS1 "
                StrSql = StrSql + "ON MATERIALS1.MATID = MATERIALINPUT.M1 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATERIALS2 "
                StrSql = StrSql + "ON MATERIALS2.MATID = MATERIALINPUT.M2 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATERIALS3 "
                StrSql = StrSql + "ON MATERIALS3.MATID = MATERIALINPUT.M3 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATERIALS4 "
                StrSql = StrSql + "ON MATERIALS4.MATID = MATERIALINPUT.M4 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATERIALS5 "
                StrSql = StrSql + "ON MATERIALS5.MATID = MATERIALINPUT.M5 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATERIALS6 "
                StrSql = StrSql + "ON MATERIALS6.MATID = MATERIALINPUT.M6 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATERIALS7 "
                StrSql = StrSql + "ON MATERIALS7.MATID = MATERIALINPUT.M7 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATERIALS8 "
                StrSql = StrSql + "ON MATERIALS8.MATID = MATERIALINPUT.M8 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATERIALS9 "
                StrSql = StrSql + "ON MATERIALS9.MATID = MATERIALINPUT.M9 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MATERIALS10 "
                StrSql = StrSql + "ON MATERIALS10.MATID = MATERIALINPUT.M10 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS PROCESS1 "
                StrSql = StrSql + "ON PROCESS1.PROCID = PLANTCONFIG.M1 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS PROCESS2 "
                StrSql = StrSql + "ON PROCESS2.PROCID = PLANTCONFIG.M2 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS PROCESS3 "
                StrSql = StrSql + "ON PROCESS3.PROCID = PLANTCONFIG.M3 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS PROCESS4 "
                StrSql = StrSql + "ON PROCESS4.PROCID = PLANTCONFIG.M4 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS PROCESS5 "
                StrSql = StrSql + "ON PROCESS5.PROCID = PLANTCONFIG.M5 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS PROCESS6 "
                StrSql = StrSql + "ON PROCESS6.PROCID = PLANTCONFIG.M6 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS PROCESS7 "
                StrSql = StrSql + "ON PROCESS7.PROCID = PLANTCONFIG.M7 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS PROCESS8 "
                StrSql = StrSql + "ON PROCESS8.PROCID = PLANTCONFIG.M8 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS PROCESS9 "
                StrSql = StrSql + "ON PROCESS9.PROCID = PLANTCONFIG.M9 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS PROCESS10 "
                StrSql = StrSql + "ON PROCESS10.PROCID = PLANTCONFIG.M10 "
                StrSql = StrSql + "WHERE "
                StrSql = StrSql + "MATERIALEFF.CASEID IN(" + CaseIds + ") ORDER BY MATERIALEFF.CASEID "






                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function EquipmentIn(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                StrSql = "SELECT  	DISTINCT  "
                StrSql = StrSql + "EQUIPMENTTYPE.CASEID, "
                StrSql = StrSql + "( CASE WHEN EQUIPMENTTYPE.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "EQUIPMENTTYPE.M1, "
                StrSql = StrSql + "EQUIPMENTTYPE.M2, "
                StrSql = StrSql + "EQUIPMENTTYPE.M3, "
                StrSql = StrSql + "EQUIPMENTTYPE.M4, "
                StrSql = StrSql + "EQUIPMENTTYPE.M5, "
                StrSql = StrSql + "EQUIPMENTTYPE.M6, "
                StrSql = StrSql + "EQUIPMENTTYPE.M7, "
                StrSql = StrSql + "EQUIPMENTTYPE.M8, "
                StrSql = StrSql + "EQUIPMENTTYPE.M9, "
                StrSql = StrSql + "EQUIPMENTTYPE.M10, "
                StrSql = StrSql + "EQUIPMENTTYPE.M11, "
                StrSql = StrSql + "EQUIPMENTTYPE.M12, "
                StrSql = StrSql + "EQUIPMENTTYPE.M13, "
                StrSql = StrSql + "EQUIPMENTTYPE.M14, "
                StrSql = StrSql + "EQUIPMENTTYPE.M15, "
                StrSql = StrSql + "EQUIPMENTTYPE.M16, "
                StrSql = StrSql + "EQUIPMENTTYPE.M17, "
                StrSql = StrSql + "EQUIPMENTTYPE.M18, "
                StrSql = StrSql + "EQUIPMENTTYPE.M19, "
                StrSql = StrSql + "EQUIPMENTTYPE.M20, "
                StrSql = StrSql + "EQUIPMENTTYPE.M21, "
                StrSql = StrSql + "EQUIPMENTTYPE.M22, "
                StrSql = StrSql + "EQUIPMENTTYPE.M23, "
                StrSql = StrSql + "EQUIPMENTTYPE.M24, "
                StrSql = StrSql + "EQUIPMENTTYPE.M25, "
                StrSql = StrSql + "EQUIPMENTTYPE.M26, "
                StrSql = StrSql + "EQUIPMENTTYPE.M27, "
                StrSql = StrSql + "EQUIPMENTTYPE.M28, "
                StrSql = StrSql + "EQUIPMENTTYPE.M29, "
                StrSql = StrSql + "EQUIPMENTTYPE.M30, "
                StrSql = StrSql + "(AREA1.AREADE1||' '||AREA1.AREADE2) AS AREATYPE1, "
                StrSql = StrSql + "(AREA2.AREADE1||' '||AREA2.AREADE2) AS AREATYPE2, "
                StrSql = StrSql + "(AREA3.AREADE1||' '||AREA3.AREADE2) AS AREATYPE3, "
                StrSql = StrSql + "(AREA4.AREADE1||' '||AREA4.AREADE2) AS AREATYPE4, "
                StrSql = StrSql + "(AREA5.AREADE1||' '||AREA5.AREADE2) AS AREATYPE5, "
                StrSql = StrSql + "(AREA6.AREADE1||' '||AREA6.AREADE2) AS AREATYPE6, "
                StrSql = StrSql + "(AREA7.AREADE1||' '||AREA7.AREADE2) AS AREATYPE7, "
                StrSql = StrSql + "(AREA8.AREADE1||' '||AREA8.AREADE2) AS AREATYPE8, "
                StrSql = StrSql + "(AREA9.AREADE1||' '||AREA9.AREADE2) AS AREATYPE9, "
                StrSql = StrSql + "(AREA10.AREADE1||' '||AREA10.AREADE2) AS AREATYPE10, "
                StrSql = StrSql + "(AREA11.AREADE1||' '||AREA11.AREADE2) AS AREATYPE11, "
                StrSql = StrSql + "(AREA12.AREADE1||' '||AREA12.AREADE2) AS AREATYPE12, "
                StrSql = StrSql + "(AREA13.AREADE1||' '||AREA13.AREADE2) AS AREATYPE13, "
                StrSql = StrSql + "(AREA14.AREADE1||' '||AREA14.AREADE2) AS AREATYPE14, "
                StrSql = StrSql + "(AREA15.AREADE1||' '||AREA15.AREADE2) AS AREATYPE15, "
                StrSql = StrSql + "(AREA16.AREADE1||' '||AREA16.AREADE2) AS AREATYPE16, "
                StrSql = StrSql + "(AREA17.AREADE1||' '||AREA17.AREADE2) AS AREATYPE17, "
                StrSql = StrSql + "(AREA18.AREADE1||' '||AREA18.AREADE2) AS AREATYPE18, "
                StrSql = StrSql + "(AREA19.AREADE1||' '||AREA19.AREADE2) AS AREATYPE19, "
                StrSql = StrSql + "(AREA20.AREADE1||' '||AREA20.AREADE2) AS AREATYPE20, "
                StrSql = StrSql + "(AREA21.AREADE1||' '||AREA21.AREADE2) AS AREATYPE21, "
                StrSql = StrSql + "(AREA22.AREADE1||' '||AREA22.AREADE2) AS AREATYPE22, "
                StrSql = StrSql + "(AREA23.AREADE1||' '||AREA23.AREADE2) AS AREATYPE23, "
                StrSql = StrSql + "(AREA24.AREADE1||' '||AREA24.AREADE2) AS AREATYPE24, "
                StrSql = StrSql + "(AREA25.AREADE1||' '||AREA25.AREADE2) AS AREATYPE25, "
                StrSql = StrSql + "(AREA26.AREADE1||' '||AREA26.AREADE2) AS AREATYPE26, "
                StrSql = StrSql + "(AREA27.AREADE1||' '||AREA27.AREADE2) AS AREATYPE27, "
                StrSql = StrSql + "(AREA28.AREADE1||' '||AREA28.AREADE2) AS AREATYPE28, "
                StrSql = StrSql + "(AREA29.AREADE1||' '||AREA29.AREADE2) AS AREATYPE29, "
                StrSql = StrSql + "(AREA30.AREADE1||' '||AREA30.AREADE2) AS AREATYPE30, "
                StrSql = StrSql + "(ASSET1.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS1, "
                StrSql = StrSql + "(ASSET2.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS2, "
                StrSql = StrSql + "(ASSET3.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS3, "
                StrSql = StrSql + "(ASSET4.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS4, "
                StrSql = StrSql + "(ASSET5.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS5, "
                StrSql = StrSql + "(ASSET6.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS6, "
                StrSql = StrSql + "(ASSET7.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS7, "
                StrSql = StrSql + "(ASSET8.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS8, "
                StrSql = StrSql + "(ASSET9.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS9, "
                StrSql = StrSql + "(ASSET10.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS10, "
                StrSql = StrSql + "(ASSET11.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS11, "
                StrSql = StrSql + "(ASSET12.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS12, "
                StrSql = StrSql + "(ASSET13.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS13, "
                StrSql = StrSql + "(ASSET14.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS14, "
                StrSql = StrSql + "(ASSET15.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS15, "
                StrSql = StrSql + "(ASSET16.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS16, "
                StrSql = StrSql + "(ASSET17.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS17, "
                StrSql = StrSql + "(ASSET18.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS18, "
                StrSql = StrSql + "(ASSET19.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS19, "
                StrSql = StrSql + "(ASSET20.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS20, "
                StrSql = StrSql + "(ASSET21.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS21, "
                StrSql = StrSql + "(ASSET22.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS22, "
                StrSql = StrSql + "(ASSET23.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS23, "
                StrSql = StrSql + "(ASSET24.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS24, "
                StrSql = StrSql + "(ASSET25.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS25, "
                StrSql = StrSql + "(ASSET26.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS26, "
                StrSql = StrSql + "(ASSET27.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS27, "
                StrSql = StrSql + "(ASSET28.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS28, "
                StrSql = StrSql + "(ASSET29.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS29, "
                StrSql = StrSql + "(ASSET30.AREA * PREFERENCES.CONVAREA2) AS PLANTAREAS30, "
                StrSql = StrSql + "(EQUIPMENTAREA.M1 * PREFERENCES.CONVAREA2) AS PLANTAREAP1, "
                StrSql = StrSql + "(EQUIPMENTAREA.M2 * PREFERENCES.CONVAREA2) AS PLANTAREAP2, "
                StrSql = StrSql + "(EQUIPMENTAREA.M3 * PREFERENCES.CONVAREA2) AS PLANTAREAP3, "
                StrSql = StrSql + "(EQUIPMENTAREA.M4 * PREFERENCES.CONVAREA2) AS PLANTAREAP4, "
                StrSql = StrSql + "(EQUIPMENTAREA.M5 * PREFERENCES.CONVAREA2) AS PLANTAREAP5, "
                StrSql = StrSql + "(EQUIPMENTAREA.M6 * PREFERENCES.CONVAREA2) AS PLANTAREAP6, "
                StrSql = StrSql + "(EQUIPMENTAREA.M7 * PREFERENCES.CONVAREA2) AS PLANTAREAP7, "
                StrSql = StrSql + "(EQUIPMENTAREA.M8 * PREFERENCES.CONVAREA2) AS PLANTAREAP8, "
                StrSql = StrSql + "(EQUIPMENTAREA.M9 * PREFERENCES.CONVAREA2) AS PLANTAREAP9, "
                StrSql = StrSql + "(EQUIPMENTAREA.M10 * PREFERENCES.CONVAREA2) AS PLANTAREAP10, "
                StrSql = StrSql + "(EQUIPMENTAREA.M11 * PREFERENCES.CONVAREA2) AS PLANTAREAP11, "
                StrSql = StrSql + "(EQUIPMENTAREA.M12 * PREFERENCES.CONVAREA2) AS PLANTAREAP12, "
                StrSql = StrSql + "(EQUIPMENTAREA.M13 * PREFERENCES.CONVAREA2) AS PLANTAREAP13, "
                StrSql = StrSql + "(EQUIPMENTAREA.M14 * PREFERENCES.CONVAREA2) AS PLANTAREAP14, "
                StrSql = StrSql + "(EQUIPMENTAREA.M15 * PREFERENCES.CONVAREA2) AS PLANTAREAP15, "
                StrSql = StrSql + "(EQUIPMENTAREA.M16 * PREFERENCES.CONVAREA2) AS PLANTAREAP16, "
                StrSql = StrSql + "(EQUIPMENTAREA.M17 * PREFERENCES.CONVAREA2) AS PLANTAREAP17, "
                StrSql = StrSql + "(EQUIPMENTAREA.M18 * PREFERENCES.CONVAREA2) AS PLANTAREAP18, "
                StrSql = StrSql + "(EQUIPMENTAREA.M19 * PREFERENCES.CONVAREA2) AS PLANTAREAP19, "
                StrSql = StrSql + "(EQUIPMENTAREA.M20 * PREFERENCES.CONVAREA2) AS PLANTAREAP20, "
                StrSql = StrSql + "(EQUIPMENTAREA.M21 * PREFERENCES.CONVAREA2) AS PLANTAREAP21, "
                StrSql = StrSql + "(EQUIPMENTAREA.M22 * PREFERENCES.CONVAREA2) AS PLANTAREAP22, "
                StrSql = StrSql + "(EQUIPMENTAREA.M23 * PREFERENCES.CONVAREA2) AS PLANTAREAP23, "
                StrSql = StrSql + "(EQUIPMENTAREA.M24 * PREFERENCES.CONVAREA2) AS PLANTAREAP24, "
                StrSql = StrSql + "(EQUIPMENTAREA.M25 * PREFERENCES.CONVAREA2) AS PLANTAREAP25, "
                StrSql = StrSql + "(EQUIPMENTAREA.M26 * PREFERENCES.CONVAREA2) AS PLANTAREAP26, "
                StrSql = StrSql + "(EQUIPMENTAREA.M27 * PREFERENCES.CONVAREA2) AS PLANTAREAP27, "
                StrSql = StrSql + "(EQUIPMENTAREA.M28 * PREFERENCES.CONVAREA2) AS PLANTAREAP28, "
                StrSql = StrSql + "(EQUIPMENTAREA.M29 * PREFERENCES.CONVAREA2) AS PLANTAREAP29, "
                StrSql = StrSql + "(EQUIPMENTAREA.M30 * PREFERENCES.CONVAREA2) AS PLANTAREAP30, "
                StrSql = StrSql + "(ASSET1.INSTKW ) AS ERGYS1, "
                StrSql = StrSql + "(ASSET2.INSTKW ) AS ERGYS2, "
                StrSql = StrSql + "(ASSET3.INSTKW ) AS ERGYS3, "
                StrSql = StrSql + "(ASSET4.INSTKW ) AS ERGYS4, "
                StrSql = StrSql + "(ASSET5.INSTKW ) AS ERGYS5, "
                StrSql = StrSql + "(ASSET6.INSTKW ) AS ERGYS6, "
                StrSql = StrSql + "(ASSET7.INSTKW ) AS ERGYS7, "
                StrSql = StrSql + "(ASSET8.INSTKW ) AS ERGYS8, "
                StrSql = StrSql + "(ASSET9.INSTKW ) AS ERGYS9, "
                StrSql = StrSql + "(ASSET10.INSTKW ) AS ERGYS10, "
                StrSql = StrSql + "(ASSET11.INSTKW ) AS ERGYS11, "
                StrSql = StrSql + "(ASSET12.INSTKW ) AS ERGYS12, "
                StrSql = StrSql + "(ASSET13.INSTKW ) AS ERGYS13, "
                StrSql = StrSql + "(ASSET14.INSTKW ) AS ERGYS14, "
                StrSql = StrSql + "(ASSET15.INSTKW ) AS ERGYS15, "
                StrSql = StrSql + "(ASSET16.INSTKW ) AS ERGYS16, "
                StrSql = StrSql + "(ASSET17.INSTKW ) AS ERGYS17, "
                StrSql = StrSql + "(ASSET18.INSTKW ) AS ERGYS18, "
                StrSql = StrSql + "(ASSET19.INSTKW ) AS ERGYS19, "
                StrSql = StrSql + "(ASSET20.INSTKW ) AS ERGYS20, "
                StrSql = StrSql + "(ASSET21.INSTKW ) AS ERGYS21, "
                StrSql = StrSql + "(ASSET22.INSTKW ) AS ERGYS22, "
                StrSql = StrSql + "(ASSET23.INSTKW ) AS ERGYS23, "
                StrSql = StrSql + "(ASSET24.INSTKW ) AS ERGYS24, "
                StrSql = StrSql + "(ASSET25.INSTKW ) AS ERGYS25, "
                StrSql = StrSql + "(ASSET26.INSTKW ) AS ERGYS26, "
                StrSql = StrSql + "(ASSET27.INSTKW ) AS ERGYS27, "
                StrSql = StrSql + "(ASSET28.INSTKW ) AS ERGYS28, "
                StrSql = StrSql + "(ASSET29.INSTKW ) AS ERGYS29, "
                StrSql = StrSql + "(ASSET30.INSTKW ) AS ERGYS30, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M1 ) AS ERGYP1, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M2 ) AS ERGYP2, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M3 ) AS ERGYP3, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M4 ) AS ERGYP4, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M5 ) AS ERGYP5, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M6 ) AS ERGYP6, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M7 ) AS ERGYP7, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M8 ) AS ERGYP8, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M9 ) AS ERGYP9, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M10 ) AS ERGYP10, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M11 ) AS ERGYP11, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M12 ) AS ERGYP12, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M13 ) AS ERGYP13, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M14 ) AS ERGYP14, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M15 ) AS ERGYP15, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M16 ) AS ERGYP16, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M17 ) AS ERGYP17, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M18 ) AS ERGYP18, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M19 ) AS ERGYP19, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M20 ) AS ERGYP20, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M21 ) AS ERGYP21, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M22 ) AS ERGYP22, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M23 ) AS ERGYP23, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M24 ) AS ERGYP24, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M25 ) AS ERGYP25, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M26 ) AS ERGYP26, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M27 ) AS ERGYP27, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M28 ) AS ERGYP28, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M29 ) AS ERGYP29, "
                StrSql = StrSql + "(EQUIPENERGYPREF.M30 ) AS ERGYP30, "
                StrSql = StrSql + "(ASSET1.NTGKW ) AS NTGS1, "
                StrSql = StrSql + "(ASSET2.NTGKW ) AS NTGS2, "
                StrSql = StrSql + "(ASSET3.NTGKW ) AS NTGS3, "
                StrSql = StrSql + "(ASSET4.NTGKW ) AS NTGS4, "
                StrSql = StrSql + "(ASSET5.NTGKW ) AS NTGS5, "
                StrSql = StrSql + "(ASSET6.NTGKW ) AS NTGS6, "
                StrSql = StrSql + "(ASSET7.NTGKW ) AS NTGS7, "
                StrSql = StrSql + "(ASSET8.NTGKW ) AS NTGS8, "
                StrSql = StrSql + "(ASSET9.NTGKW ) AS NTGS9, "
                StrSql = StrSql + "(ASSET10.NTGKW ) AS NTGS10, "
                StrSql = StrSql + "(ASSET11.NTGKW ) AS NTGS11, "
                StrSql = StrSql + "(ASSET12.NTGKW ) AS NTGS12, "
                StrSql = StrSql + "(ASSET13.NTGKW ) AS NTGS13, "
                StrSql = StrSql + "(ASSET14.NTGKW ) AS NTGS14, "
                StrSql = StrSql + "(ASSET15.NTGKW ) AS NTGS15, "
                StrSql = StrSql + "(ASSET16.NTGKW ) AS NTGS16, "
                StrSql = StrSql + "(ASSET17.NTGKW ) AS NTGS17, "
                StrSql = StrSql + "(ASSET18.NTGKW ) AS NTGS18, "
                StrSql = StrSql + "(ASSET19.NTGKW ) AS NTGS19, "
                StrSql = StrSql + "(ASSET20.NTGKW ) AS NTGS20, "
                StrSql = StrSql + "(ASSET21.NTGKW ) AS NTGS21, "
                StrSql = StrSql + "(ASSET22.NTGKW ) AS NTGS22, "
                StrSql = StrSql + "(ASSET23.NTGKW ) AS NTGS23, "
                StrSql = StrSql + "(ASSET24.NTGKW ) AS NTGS24, "
                StrSql = StrSql + "(ASSET25.NTGKW ) AS NTGS25, "
                StrSql = StrSql + "(ASSET26.NTGKW ) AS NTGS26, "
                StrSql = StrSql + "(ASSET27.NTGKW ) AS NTGS27, "
                StrSql = StrSql + "(ASSET28.NTGKW ) AS NTGS28, "
                StrSql = StrSql + "(ASSET29.NTGKW ) AS NTGS29, "
                StrSql = StrSql + "(ASSET30.NTGKW ) AS NTGS30, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M1 ) AS NTGP1, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M2 ) AS NTGP2, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M3 ) AS NTGP3, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M4 ) AS NTGP4, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M5 ) AS NTGP5, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M6 ) AS NTGP6, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M7 ) AS NTGP7, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M8 ) AS NTGP8, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M9 ) AS NTGP9, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M10 ) AS NTGP10, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M11 ) AS NTGP11, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M12 ) AS NTGP12, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M13 ) AS NTGP13, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M14 ) AS NTGP14, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M15 ) AS NTGP15, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M16 ) AS NTGP16, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M17 ) AS NTGP17, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M18 ) AS NTGP18, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M19 ) AS NTGP19, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M20 ) AS NTGP20, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M21 ) AS NTGP21, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M22 ) AS NTGP22, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M23 ) AS NTGP23, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M24 ) AS NTGP24, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M25 ) AS NTGP25, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M26 ) AS NTGP26, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M27 ) AS NTGP27, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M28 ) AS NTGP28, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M29 ) AS NTGP29, "
                StrSql = StrSql + "(EQUIPNATURALGASPREF.M30 ) AS NTGP30, "
                StrSql = StrSql + "(EQUIPMENTDEP.M1 ) AS DEPT1, "
                StrSql = StrSql + "(EQUIPMENTDEP.M2 ) AS DEPT2, "
                StrSql = StrSql + "(EQUIPMENTDEP.M3 ) AS DEPT3, "
                StrSql = StrSql + "(EQUIPMENTDEP.M4 ) AS DEPT4, "
                StrSql = StrSql + "(EQUIPMENTDEP.M5 ) AS DEPT5, "
                StrSql = StrSql + "(EQUIPMENTDEP.M6 ) AS DEPT6, "
                StrSql = StrSql + "(EQUIPMENTDEP.M7 ) AS DEPT7, "
                StrSql = StrSql + "(EQUIPMENTDEP.M8 ) AS DEPT8, "
                StrSql = StrSql + "(EQUIPMENTDEP.M9 ) AS DEPT9, "
                StrSql = StrSql + "(EQUIPMENTDEP.M10 ) AS DEPT10, "
                StrSql = StrSql + "(EQUIPMENTDEP.M11 ) AS DEPT11, "
                StrSql = StrSql + "(EQUIPMENTDEP.M12 ) AS DEPT12, "
                StrSql = StrSql + "(EQUIPMENTDEP.M13 ) AS DEPT13, "
                StrSql = StrSql + "(EQUIPMENTDEP.M14 ) AS DEPT14, "
                StrSql = StrSql + "(EQUIPMENTDEP.M15 ) AS DEPT15, "
                StrSql = StrSql + "(EQUIPMENTDEP.M16 ) AS DEPT16, "
                StrSql = StrSql + "(EQUIPMENTDEP.M17 ) AS DEPT17, "
                StrSql = StrSql + "(EQUIPMENTDEP.M18 ) AS DEPT18, "
                StrSql = StrSql + "(EQUIPMENTDEP.M19 ) AS DEPT19, "
                StrSql = StrSql + "(EQUIPMENTDEP.M20 ) AS DEPT20, "
                StrSql = StrSql + "(EQUIPMENTDEP.M21 ) AS DEPT21, "
                StrSql = StrSql + "(EQUIPMENTDEP.M22 ) AS DEPT22, "
                StrSql = StrSql + "(EQUIPMENTDEP.M23 ) AS DEPT23, "
                StrSql = StrSql + "(EQUIPMENTDEP.M24 ) AS DEPT24, "
                StrSql = StrSql + "(EQUIPMENTDEP.M25 ) AS DEPT25, "
                StrSql = StrSql + "(EQUIPMENTDEP.M26 ) AS DEPT26, "
                StrSql = StrSql + "(EQUIPMENTDEP.M27 ) AS DEPT27, "
                StrSql = StrSql + "(EQUIPMENTDEP.M28 ) AS DEPT28, "
                StrSql = StrSql + "(EQUIPMENTDEP.M29 ) AS DEPT29, "
                StrSql = StrSql + "(EQUIPMENTDEP.M30 ) AS DEPT30, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM "
                StrSql = StrSql + "EQUIPMENTTYPE "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "EQUIPMENTCOST "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIPMENTCOST.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "PREFERENCES "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "PREFERENCES.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "EQUIPMENTAREA "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIPMENTAREA.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "EQUIPENERGYPREF "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIPENERGYPREF.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "EQUIPMENTDEP "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIPMENTDEP.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET1 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET1.EQUIPID = EQUIPMENTTYPE.M1 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET2 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET2.EQUIPID = EQUIPMENTTYPE.M2 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET3 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET3.EQUIPID = EQUIPMENTTYPE.M3 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET4 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET4.EQUIPID = EQUIPMENTTYPE.M4 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET5 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET5.EQUIPID = EQUIPMENTTYPE.M5 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET6 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET6.EQUIPID = EQUIPMENTTYPE.M6 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET7 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET7.EQUIPID = EQUIPMENTTYPE.M7 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET8 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET8.EQUIPID = EQUIPMENTTYPE.M8 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET9 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET9.EQUIPID = EQUIPMENTTYPE.M9 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET10 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET10.EQUIPID = EQUIPMENTTYPE.M10 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET11 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET11.EQUIPID = EQUIPMENTTYPE.M11 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET12 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET12.EQUIPID = EQUIPMENTTYPE.M12 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET13 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET13.EQUIPID = EQUIPMENTTYPE.M13 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET14 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET14.EQUIPID = EQUIPMENTTYPE.M14 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET15 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET15.EQUIPID = EQUIPMENTTYPE.M15 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET16 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET16.EQUIPID = EQUIPMENTTYPE.M16 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET17 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET17.EQUIPID = EQUIPMENTTYPE.M17 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET18 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET18.EQUIPID = EQUIPMENTTYPE.M18 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET19 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET19.EQUIPID = EQUIPMENTTYPE.M19 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET20 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET20.EQUIPID = EQUIPMENTTYPE.M20 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET21 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET21.EQUIPID = EQUIPMENTTYPE.M21 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET22 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET22.EQUIPID = EQUIPMENTTYPE.M22 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET23 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET23.EQUIPID = EQUIPMENTTYPE.M23 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET24 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET24.EQUIPID = EQUIPMENTTYPE.M24 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET25 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET25.EQUIPID = EQUIPMENTTYPE.M25 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET26 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET26.EQUIPID = EQUIPMENTTYPE.M26 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET27 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET27.EQUIPID = EQUIPMENTTYPE.M27 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET28 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET28.EQUIPID = EQUIPMENTTYPE.M28 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET29 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET29.EQUIPID = EQUIPMENTTYPE.M29 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT ASSET30 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET30.EQUIPID = EQUIPMENTTYPE.M30 "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA1 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET1.AREATYPE = AREA1.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA2 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET2.AREATYPE = AREA2.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA3 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET3.AREATYPE = AREA3.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA4 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET4.AREATYPE = AREA4.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA5 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET5.AREATYPE = AREA5.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA6 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET6.AREATYPE = AREA6.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA7 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET7.AREATYPE = AREA7.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA8 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET8.AREATYPE = AREA8.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA9 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET9.AREATYPE = AREA9.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA10 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET10.AREATYPE = AREA10.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA11 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET11.AREATYPE = AREA11.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA12 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET12.AREATYPE = AREA12.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA13 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET13.AREATYPE = AREA13.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA14 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET14.AREATYPE = AREA14.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA15 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET15.AREATYPE = AREA15.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA16 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET16.AREATYPE = AREA16.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA17 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET17.AREATYPE = AREA17.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA18 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET18.AREATYPE = AREA18.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA19 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET19.AREATYPE = AREA19.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA20 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET20.AREATYPE = AREA20.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA21 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET21.AREATYPE = AREA21.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA22 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET22.AREATYPE = AREA22.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA23 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET23.AREATYPE = AREA23.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA24 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET24.AREATYPE = AREA24.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA25 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET25.AREATYPE = AREA25.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA26 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET26.AREATYPE = AREA26.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA27 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET27.AREATYPE = AREA27.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA28 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET28.AREATYPE = AREA28.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA29 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET29.AREATYPE = AREA29.AREAID "
                StrSql = StrSql + "LEFT OUTER JOIN "
                StrSql = StrSql + "ECON.AREATYPE AREA30 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "ASSET30.AREATYPE = AREA30.AREAID "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN EQUIPNATURALGASPREF "
                StrSql = StrSql + "ON EQUIPNATURALGASPREF.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "WHERE "
                StrSql = StrSql + "EQUIPMENTTYPE.CASEID IN(" + CaseIds + ")  ORDER BY EQUIPMENTTYPE.CASEID "


                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function Equipment2In(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                StrSql = "SELECT  	 	DISTINCT  "
                StrSql = StrSql + "EQUIPMENT2TYPE.CASEID, "
                StrSql = StrSql + "( CASE WHEN EQUIPMENT2TYPE.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = EQUIPMENT2TYPE.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = EQUIPMENT2TYPE.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M1, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M2, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M3, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M4, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M5, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M6, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M7, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M8, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M9, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M10, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M11, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M12, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M13, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M14, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M15, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M16, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M17, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M18, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M19, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M20, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M21, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M22, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M23, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M24, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M25, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M26, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M27, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M28, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M29, "
                StrSql = StrSql + "EQUIPMENT2TYPE.M30, "
                StrSql = StrSql + "(ASSET1.INSTKW ) AS ERGYS1, "
                StrSql = StrSql + "(ASSET2.INSTKW ) AS ERGYS2, "
                StrSql = StrSql + "(ASSET3.INSTKW ) AS ERGYS3, "
                StrSql = StrSql + "(ASSET4.INSTKW ) AS ERGYS4, "
                StrSql = StrSql + "(ASSET5.INSTKW ) AS ERGYS5, "
                StrSql = StrSql + "(ASSET6.INSTKW ) AS ERGYS6, "
                StrSql = StrSql + "(ASSET7.INSTKW ) AS ERGYS7, "
                StrSql = StrSql + "(ASSET8.INSTKW ) AS ERGYS8, "
                StrSql = StrSql + "(ASSET9.INSTKW ) AS ERGYS9, "
                StrSql = StrSql + "(ASSET10.INSTKW ) AS ERGYS10, "
                StrSql = StrSql + "(ASSET11.INSTKW ) AS ERGYS11, "
                StrSql = StrSql + "(ASSET12.INSTKW ) AS ERGYS12, "
                StrSql = StrSql + "(ASSET13.INSTKW ) AS ERGYS13, "
                StrSql = StrSql + "(ASSET14.INSTKW ) AS ERGYS14, "
                StrSql = StrSql + "(ASSET15.INSTKW ) AS ERGYS15, "
                StrSql = StrSql + "(ASSET16.INSTKW ) AS ERGYS16, "
                StrSql = StrSql + "(ASSET17.INSTKW ) AS ERGYS17, "
                StrSql = StrSql + "(ASSET18.INSTKW ) AS ERGYS18, "
                StrSql = StrSql + "(ASSET19.INSTKW ) AS ERGYS19, "
                StrSql = StrSql + "(ASSET20.INSTKW ) AS ERGYS20, "
                StrSql = StrSql + "(ASSET21.INSTKW ) AS ERGYS21, "
                StrSql = StrSql + "(ASSET22.INSTKW ) AS ERGYS22, "
                StrSql = StrSql + "(ASSET23.INSTKW ) AS ERGYS23, "
                StrSql = StrSql + "(ASSET24.INSTKW ) AS ERGYS24, "
                StrSql = StrSql + "(ASSET25.INSTKW ) AS ERGYS25, "
                StrSql = StrSql + "(ASSET26.INSTKW ) AS ERGYS26, "
                StrSql = StrSql + "(ASSET27.INSTKW ) AS ERGYS27, "
                StrSql = StrSql + "(ASSET28.INSTKW ) AS ERGYS28, "
                StrSql = StrSql + "(ASSET29.INSTKW ) AS ERGYS29, "
                StrSql = StrSql + "(ASSET30.INSTKW ) AS ERGYS30, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M1 ) AS ERGYP1, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M2 ) AS ERGYP2, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M3 ) AS ERGYP3, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M4 ) AS ERGYP4, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M5 ) AS ERGYP5, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M6 ) AS ERGYP6, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M7 ) AS ERGYP7, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M8 ) AS ERGYP8, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M9 ) AS ERGYP9, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M10 ) AS ERGYP10, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M11 ) AS ERGYP11, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M12 ) AS ERGYP12, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M13 ) AS ERGYP13, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M14 ) AS ERGYP14, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M15 ) AS ERGYP15, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M16 ) AS ERGYP16, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M17 ) AS ERGYP17, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M18 ) AS ERGYP18, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M19 ) AS ERGYP19, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M20 ) AS ERGYP20, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M21 ) AS ERGYP21, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M22 ) AS ERGYP22, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M23 ) AS ERGYP23, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M24 ) AS ERGYP24, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M25 ) AS ERGYP25, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M26 ) AS ERGYP26, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M27 ) AS ERGYP27, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M28 ) AS ERGYP28, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M29 ) AS ERGYP29, "
                StrSql = StrSql + "(EQUIP2ENERGYPREF.M30 ) AS ERGYP30, "
                StrSql = StrSql + "(ASSET1.NTGKW ) AS NTGS1, "
                StrSql = StrSql + "(ASSET2.NTGKW ) AS NTGS2, "
                StrSql = StrSql + "(ASSET3.NTGKW ) AS NTGS3, "
                StrSql = StrSql + "(ASSET4.NTGKW ) AS NTGS4, "
                StrSql = StrSql + "(ASSET5.NTGKW ) AS NTGS5, "
                StrSql = StrSql + "(ASSET6.NTGKW ) AS NTGS6, "
                StrSql = StrSql + "(ASSET7.NTGKW ) AS NTGS7, "
                StrSql = StrSql + "(ASSET8.NTGKW ) AS NTGS8, "
                StrSql = StrSql + "(ASSET9.NTGKW ) AS NTGS9, "
                StrSql = StrSql + "(ASSET10.NTGKW ) AS NTGS10, "
                StrSql = StrSql + "(ASSET11.NTGKW ) AS NTGS11, "
                StrSql = StrSql + "(ASSET12.NTGKW ) AS NTGS12, "
                StrSql = StrSql + "(ASSET13.NTGKW ) AS NTGS13, "
                StrSql = StrSql + "(ASSET14.NTGKW ) AS NTGS14, "
                StrSql = StrSql + "(ASSET15.NTGKW ) AS NTGS15, "
                StrSql = StrSql + "(ASSET16.NTGKW ) AS NTGS16, "
                StrSql = StrSql + "(ASSET17.NTGKW ) AS NTGS17, "
                StrSql = StrSql + "(ASSET18.NTGKW ) AS NTGS18, "
                StrSql = StrSql + "(ASSET19.NTGKW ) AS NTGS19, "
                StrSql = StrSql + "(ASSET20.NTGKW ) AS NTGS20, "
                StrSql = StrSql + "(ASSET21.NTGKW ) AS NTGS21, "
                StrSql = StrSql + "(ASSET22.NTGKW ) AS NTGS22, "
                StrSql = StrSql + "(ASSET23.NTGKW ) AS NTGS23, "
                StrSql = StrSql + "(ASSET24.NTGKW ) AS NTGS24, "
                StrSql = StrSql + "(ASSET25.NTGKW ) AS NTGS25, "
                StrSql = StrSql + "(ASSET26.NTGKW ) AS NTGS26, "
                StrSql = StrSql + "(ASSET27.NTGKW ) AS NTGS27, "
                StrSql = StrSql + "(ASSET28.NTGKW ) AS NTGS28, "
                StrSql = StrSql + "(ASSET29.NTGKW ) AS NTGS29, "
                StrSql = StrSql + "(ASSET30.NTGKW ) AS NTGS30, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M1 ) AS NTGP1, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M2 ) AS NTGP2, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M3 ) AS NTGP3, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M4 ) AS NTGP4, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M5 ) AS NTGP5, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M6 ) AS NTGP6, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M7 ) AS NTGP7, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M8 ) AS NTGP8, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M9 ) AS NTGP9, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M10 ) AS NTGP10, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M11 ) AS NTGP11, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M12 ) AS NTGP12, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M13 ) AS NTGP13, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M14 ) AS NTGP14, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M15 ) AS NTGP15, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M16 ) AS NTGP16, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M17 ) AS NTGP17, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M18 ) AS NTGP18, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M19 ) AS NTGP19, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M20 ) AS NTGP20, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M21 ) AS NTGP21, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M22 ) AS NTGP22, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M23 ) AS NTGP23, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M24 ) AS NTGP24, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M25 ) AS NTGP25, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M26 ) AS NTGP26, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M27 ) AS NTGP27, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M28 ) AS NTGP28, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M29 ) AS NTGP29, "
                StrSql = StrSql + "(EQUIP2NATURALGASPREF.M30 ) AS NTGP30, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M1 ) AS DEPT1, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M2 ) AS DEPT2, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M3 ) AS DEPT3, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M4 ) AS DEPT4, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M5 ) AS DEPT5, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M6 ) AS DEPT6, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M7 ) AS DEPT7, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M8 ) AS DEPT8, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M9 ) AS DEPT9, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M10 ) AS DEPT10, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M11 ) AS DEPT11, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M12 ) AS DEPT12, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M13 ) AS DEPT13, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M14 ) AS DEPT14, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M15 ) AS DEPT15, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M16 ) AS DEPT16, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M17 ) AS DEPT17, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M18 ) AS DEPT18, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M19 ) AS DEPT19, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M20 ) AS DEPT20, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M21 ) AS DEPT21, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M22 ) AS DEPT22, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M23 ) AS DEPT23, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M24 ) AS DEPT24, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M25 ) AS DEPT25, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M26 ) AS DEPT26, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M27 ) AS DEPT27, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M28 ) AS DEPT28, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M29 ) AS DEPT29, "
                StrSql = StrSql + "(EQUIPMENT2DEP.M30 ) AS DEPT30, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM EQUIPMENT2TYPE "
                StrSql = StrSql + "INNER JOIN  PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=EQUIPMENT2TYPE.CASEID "
                StrSql = StrSql + "INNER JOIN EQUIP2ENERGYPREF "
                StrSql = StrSql + "ON EQUIP2ENERGYPREF.CASEID=EQUIPMENT2TYPE.CASEID "
                StrSql = StrSql + "INNER JOIN EQUIP2NATURALGASPREF "
                StrSql = StrSql + "ON EQUIP2NATURALGASPREF.CASEID=EQUIPMENT2TYPE.CASEID "
                StrSql = StrSql + "INNER JOIN EQUIPMENT2DEP "
                StrSql = StrSql + "ON EQUIPMENT2DEP.CASEID=EQUIPMENT2TYPE.CASEID "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET1 "
                StrSql = StrSql + "ON ASSET1.EQUIPID = EQUIPMENT2TYPE.M1 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET2 "
                StrSql = StrSql + "ON ASSET2.EQUIPID = EQUIPMENT2TYPE.M2 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET3 "
                StrSql = StrSql + "ON ASSET3.EQUIPID = EQUIPMENT2TYPE.M3 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET4 "
                StrSql = StrSql + "ON ASSET4.EQUIPID = EQUIPMENT2TYPE.M4 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET5 "
                StrSql = StrSql + "ON ASSET5.EQUIPID = EQUIPMENT2TYPE.M5 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET6 "
                StrSql = StrSql + "ON ASSET6.EQUIPID = EQUIPMENT2TYPE.M6 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET7 "
                StrSql = StrSql + "ON ASSET7.EQUIPID = EQUIPMENT2TYPE.M7 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET8 "
                StrSql = StrSql + "ON ASSET8.EQUIPID = EQUIPMENT2TYPE.M8 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET9 "
                StrSql = StrSql + "ON ASSET9.EQUIPID = EQUIPMENT2TYPE.M9 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET10 "
                StrSql = StrSql + "ON ASSET10.EQUIPID = EQUIPMENT2TYPE.M10 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET11 "
                StrSql = StrSql + "ON ASSET11.EQUIPID = EQUIPMENT2TYPE.M11 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET12 "
                StrSql = StrSql + "ON ASSET12.EQUIPID = EQUIPMENT2TYPE.M12 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET13 "
                StrSql = StrSql + "ON ASSET13.EQUIPID = EQUIPMENT2TYPE.M13 "
                StrSql = StrSql + "INNER JOIN  ECON.EQUIPMENT2 ASSET14 "
                StrSql = StrSql + "ON ASSET14.EQUIPID = EQUIPMENT2TYPE.M14 "
                StrSql = StrSql + "INNER JOIN  ECON.EQUIPMENT2 ASSET15 "
                StrSql = StrSql + "ON ASSET15.EQUIPID = EQUIPMENT2TYPE.M15 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET16 "
                StrSql = StrSql + "ON ASSET16.EQUIPID = EQUIPMENT2TYPE.M16 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET17 "
                StrSql = StrSql + "ON ASSET17.EQUIPID = EQUIPMENT2TYPE.M17 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET18 "
                StrSql = StrSql + "ON ASSET18.EQUIPID = EQUIPMENT2TYPE.M18 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET19 "
                StrSql = StrSql + "ON ASSET19.EQUIPID = EQUIPMENT2TYPE.M19 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET20 "
                StrSql = StrSql + "ON ASSET20.EQUIPID = EQUIPMENT2TYPE.M20 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET21 "
                StrSql = StrSql + "ON ASSET21.EQUIPID = EQUIPMENT2TYPE.M21 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET22 "
                StrSql = StrSql + "ON ASSET22.EQUIPID = EQUIPMENT2TYPE.M22 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET23 "
                StrSql = StrSql + "ON ASSET23.EQUIPID = EQUIPMENT2TYPE.M23 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET24 "
                StrSql = StrSql + "ON ASSET24.EQUIPID = EQUIPMENT2TYPE.M24 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET25 "
                StrSql = StrSql + "ON ASSET25.EQUIPID = EQUIPMENT2TYPE.M25 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET26 "
                StrSql = StrSql + "ON ASSET26.EQUIPID = EQUIPMENT2TYPE.M26 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET27 "
                StrSql = StrSql + "ON ASSET27.EQUIPID = EQUIPMENT2TYPE.M27 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET28 "
                StrSql = StrSql + "ON ASSET28.EQUIPID = EQUIPMENT2TYPE.M28 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET29 "
                StrSql = StrSql + "ON ASSET29.EQUIPID = EQUIPMENT2TYPE.M29 "
                StrSql = StrSql + "INNER JOIN ECON.EQUIPMENT2 ASSET30 "
                StrSql = StrSql + "ON ASSET30.EQUIPID = EQUIPMENT2TYPE.M30 "
                StrSql = StrSql + "WHERE EQUIPMENT2TYPE.CASEID IN(" + CaseIds + ") ORDER BY EQUIPMENT2TYPE.CASEID "



                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function OpreationsIn(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                StrSql = "SELECT DISTINCT  "
                StrSql = StrSql + "EQUIPMENTTYPE.CASEID, "
                StrSql = StrSql + "( CASE WHEN EQUIPMENTTYPE.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(EQUIDES1.EQUIPDE1||' '||EQUIDES1.EQUIPDE2) AS EQUIPDES1, "
                StrSql = StrSql + "(EQUIDES2.EQUIPDE1||' '||EQUIDES2.EQUIPDE2) AS EQUIPDES2, "
                StrSql = StrSql + "(EQUIDES3.EQUIPDE1||' '||EQUIDES3.EQUIPDE2) AS EQUIPDES3, "
                StrSql = StrSql + "(EQUIDES4.EQUIPDE1||' '||EQUIDES4.EQUIPDE2) AS EQUIPDES4, "
                StrSql = StrSql + "(EQUIDES5.EQUIPDE1||' '||EQUIDES5.EQUIPDE2) AS EQUIPDES5, "
                StrSql = StrSql + "(EQUIDES6.EQUIPDE1||' '||EQUIDES6.EQUIPDE2) AS EQUIPDES6, "
                StrSql = StrSql + "(EQUIDES7.EQUIPDE1||' '||EQUIDES7.EQUIPDE2) AS EQUIPDES7, "
                StrSql = StrSql + "(EQUIDES8.EQUIPDE1||' '||EQUIDES8.EQUIPDE2) AS EQUIPDES8, "
                StrSql = StrSql + "(EQUIDES9.EQUIPDE1||' '||EQUIDES9.EQUIPDE2) AS EQUIPDES9, "
                StrSql = StrSql + "(EQUIDES10.EQUIPDE1||' '||EQUIDES10.EQUIPDE2) AS EQUIPDES10, "
                StrSql = StrSql + "(EQUIDES11.EQUIPDE1||' '||EQUIDES11.EQUIPDE2) AS EQUIPDES11, "
                StrSql = StrSql + "(EQUIDES12.EQUIPDE1||' '||EQUIDES12.EQUIPDE2) AS EQUIPDES12, "
                StrSql = StrSql + "(EQUIDES13.EQUIPDE1||' '||EQUIDES13.EQUIPDE2) AS EQUIPDES13, "
                StrSql = StrSql + "(EQUIDES14.EQUIPDE1||' '||EQUIDES14.EQUIPDE2) AS EQUIPDES14, "
                StrSql = StrSql + "(EQUIDES15.EQUIPDE1||' '||EQUIDES15.EQUIPDE2) AS EQUIPDES15, "
                StrSql = StrSql + "(EQUIDES16.EQUIPDE1||' '||EQUIDES16.EQUIPDE2) AS EQUIPDES16, "
                StrSql = StrSql + "(EQUIDES17.EQUIPDE1||' '||EQUIDES17.EQUIPDE2) AS EQUIPDES17, "
                StrSql = StrSql + "(EQUIDES18.EQUIPDE1||' '||EQUIDES18.EQUIPDE2) AS EQUIPDES18, "
                StrSql = StrSql + "(EQUIDES19.EQUIPDE1||' '||EQUIDES19.EQUIPDE2) AS EQUIPDES19, "
                StrSql = StrSql + "(EQUIDES20.EQUIPDE1||' '||EQUIDES20.EQUIPDE2) AS EQUIPDES20, "
                StrSql = StrSql + "(EQUIDES21.EQUIPDE1||' '||EQUIDES21.EQUIPDE2) AS EQUIPDES21, "
                StrSql = StrSql + "(EQUIDES22.EQUIPDE1||' '||EQUIDES22.EQUIPDE2) AS EQUIPDES22, "
                StrSql = StrSql + "(EQUIDES23.EQUIPDE1||' '||EQUIDES23.EQUIPDE2) AS EQUIPDES23, "
                StrSql = StrSql + "(EQUIDES24.EQUIPDE1||' '||EQUIDES24.EQUIPDE2) AS EQUIPDES24, "
                StrSql = StrSql + "(EQUIDES25.EQUIPDE1||' '||EQUIDES25.EQUIPDE2) AS EQUIPDES25, "
                StrSql = StrSql + "(EQUIDES26.EQUIPDE1||' '||EQUIDES26.EQUIPDE2) AS EQUIPDES26, "
                StrSql = StrSql + "(EQUIDES27.EQUIPDE1||' '||EQUIDES27.EQUIPDE2) AS EQUIPDES27, "
                StrSql = StrSql + "(EQUIDES28.EQUIPDE1||' '||EQUIDES28.EQUIPDE2) AS EQUIPDES28, "
                StrSql = StrSql + "(EQUIDES29.EQUIPDE1||' '||EQUIDES29.EQUIPDE2) AS EQUIPDES29, "
                StrSql = StrSql + "(EQUIDES30.EQUIPDE1||' '||EQUIDES30.EQUIPDE2) AS EQUIPDES30, "
                StrSql = StrSql + "(OPWEBWIDTH.M1 * PREF.CONVTHICK) AS WEBWIDTH1, "
                StrSql = StrSql + "(OPWEBWIDTH.M2 * PREF.CONVTHICK) AS WEBWIDTH2, "
                StrSql = StrSql + "(OPWEBWIDTH.M3 * PREF.CONVTHICK) AS WEBWIDTH3, "
                StrSql = StrSql + "(OPWEBWIDTH.M4 * PREF.CONVTHICK) AS WEBWIDTH4, "
                StrSql = StrSql + "(OPWEBWIDTH.M5 * PREF.CONVTHICK) AS WEBWIDTH5, "
                StrSql = StrSql + "(OPWEBWIDTH.M6 * PREF.CONVTHICK) AS WEBWIDTH6, "
                StrSql = StrSql + "(OPWEBWIDTH.M7 * PREF.CONVTHICK) AS WEBWIDTH7, "
                StrSql = StrSql + "(OPWEBWIDTH.M8 * PREF.CONVTHICK) AS WEBWIDTH8, "
                StrSql = StrSql + "(OPWEBWIDTH.M9 * PREF.CONVTHICK) AS WEBWIDTH9, "
                StrSql = StrSql + "(OPWEBWIDTH.M10 * PREF.CONVTHICK) AS WEBWIDTH10, "
                StrSql = StrSql + "(OPWEBWIDTH.M11 * PREF.CONVTHICK) AS WEBWIDTH11, "
                StrSql = StrSql + "(OPWEBWIDTH.M12 * PREF.CONVTHICK) AS WEBWIDTH12, "
                StrSql = StrSql + "(OPWEBWIDTH.M13 * PREF.CONVTHICK) AS WEBWIDTH13, "
                StrSql = StrSql + "(OPWEBWIDTH.M14 * PREF.CONVTHICK) AS WEBWIDTH14, "
                StrSql = StrSql + "(OPWEBWIDTH.M15 * PREF.CONVTHICK) AS WEBWIDTH15, "
                StrSql = StrSql + "(OPWEBWIDTH.M16 * PREF.CONVTHICK) AS WEBWIDTH16, "
                StrSql = StrSql + "(OPWEBWIDTH.M17 * PREF.CONVTHICK) AS WEBWIDTH17, "
                StrSql = StrSql + "(OPWEBWIDTH.M18 * PREF.CONVTHICK) AS WEBWIDTH18, "
                StrSql = StrSql + "(OPWEBWIDTH.M19 * PREF.CONVTHICK) AS WEBWIDTH19, "
                StrSql = StrSql + "(OPWEBWIDTH.M20 * PREF.CONVTHICK) AS WEBWIDTH20, "
                StrSql = StrSql + "(OPWEBWIDTH.M21 * PREF.CONVTHICK) AS WEBWIDTH21, "
                StrSql = StrSql + "(OPWEBWIDTH.M22 * PREF.CONVTHICK) AS WEBWIDTH22, "
                StrSql = StrSql + "(OPWEBWIDTH.M23 * PREF.CONVTHICK) AS WEBWIDTH23, "
                StrSql = StrSql + "(OPWEBWIDTH.M24 * PREF.CONVTHICK) AS WEBWIDTH24, "
                StrSql = StrSql + "(OPWEBWIDTH.M25 * PREF.CONVTHICK) AS WEBWIDTH25, "
                StrSql = StrSql + "(OPWEBWIDTH.M26 * PREF.CONVTHICK) AS WEBWIDTH26, "
                StrSql = StrSql + "(OPWEBWIDTH.M27 * PREF.CONVTHICK) AS WEBWIDTH27, "
                StrSql = StrSql + "(OPWEBWIDTH.M28 * PREF.CONVTHICK) AS WEBWIDTH28, "
                StrSql = StrSql + "(OPWEBWIDTH.M29 * PREF.CONVTHICK) AS WEBWIDTH29, "
                StrSql = StrSql + "(OPWEBWIDTH.M30 * PREF.CONVTHICK) AS WEBWIDTH30, "
                StrSql = StrSql + "OPMAXRUNHRS.M1 AS ANNUALRUNHOURS1, "
                StrSql = StrSql + "OPMAXRUNHRS.M2 AS ANNUALRUNHOURS2, "
                StrSql = StrSql + "OPMAXRUNHRS.M3 AS ANNUALRUNHOURS3, "
                StrSql = StrSql + "OPMAXRUNHRS.M4 AS ANNUALRUNHOURS4, "
                StrSql = StrSql + "OPMAXRUNHRS.M5 AS ANNUALRUNHOURS5, "
                StrSql = StrSql + "OPMAXRUNHRS.M6 AS ANNUALRUNHOURS6, "
                StrSql = StrSql + "OPMAXRUNHRS.M7 AS ANNUALRUNHOURS7, "
                StrSql = StrSql + "OPMAXRUNHRS.M8 AS ANNUALRUNHOURS8, "
                StrSql = StrSql + "OPMAXRUNHRS.M9 AS ANNUALRUNHOURS9, "
                StrSql = StrSql + "OPMAXRUNHRS.M10 AS ANNUALRUNHOURS10, "
                StrSql = StrSql + "OPMAXRUNHRS.M11 AS ANNUALRUNHOURS11, "
                StrSql = StrSql + "OPMAXRUNHRS.M12 AS ANNUALRUNHOURS12, "
                StrSql = StrSql + "OPMAXRUNHRS.M13 AS ANNUALRUNHOURS13, "
                StrSql = StrSql + "OPMAXRUNHRS.M14 AS ANNUALRUNHOURS14, "
                StrSql = StrSql + "OPMAXRUNHRS.M15 AS ANNUALRUNHOURS15, "
                StrSql = StrSql + "OPMAXRUNHRS.M16 AS ANNUALRUNHOURS16, "
                StrSql = StrSql + "OPMAXRUNHRS.M17 AS ANNUALRUNHOURS17, "
                StrSql = StrSql + "OPMAXRUNHRS.M18 AS ANNUALRUNHOURS18, "
                StrSql = StrSql + "OPMAXRUNHRS.M19 AS ANNUALRUNHOURS19, "
                StrSql = StrSql + "OPMAXRUNHRS.M20 AS ANNUALRUNHOURS20, "
                StrSql = StrSql + "OPMAXRUNHRS.M21 AS ANNUALRUNHOURS21, "
                StrSql = StrSql + "OPMAXRUNHRS.M22 AS ANNUALRUNHOURS22, "
                StrSql = StrSql + "OPMAXRUNHRS.M23 AS ANNUALRUNHOURS23, "
                StrSql = StrSql + "OPMAXRUNHRS.M24 AS ANNUALRUNHOURS24, "
                StrSql = StrSql + "OPMAXRUNHRS.M25 AS ANNUALRUNHOURS25, "
                StrSql = StrSql + "OPMAXRUNHRS.M26 AS ANNUALRUNHOURS26, "
                StrSql = StrSql + "OPMAXRUNHRS.M27 AS ANNUALRUNHOURS27, "
                StrSql = StrSql + "OPMAXRUNHRS.M28 AS ANNUALRUNHOURS28, "
                StrSql = StrSql + "OPMAXRUNHRS.M29 AS ANNUALRUNHOURS29, "
                StrSql = StrSql + "OPMAXRUNHRS.M30 AS ANNUALRUNHOURS30, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES1.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M1 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M1,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE1, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES2.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M2 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M2,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE2, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES3.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M3 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M3,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE3, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES4.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M4 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M4,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE4, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES5.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M5 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M5,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE5, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES6.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M6 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M6,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE6, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES7.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M7 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M7,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE7, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES8.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M8 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M8,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE8, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES9.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M9 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M9,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE9, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES10.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M10 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M10,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE10, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES11.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M11 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M11,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE11, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES12.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M12 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M12,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE12, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES13.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M13 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M13,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE13, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES14.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M14 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M14,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE14, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES15.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M15 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M15,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE15, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES16.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M16 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M16,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE16, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES7.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M17 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M17,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE17, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES18.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M18 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M18,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE18, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES9.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M19 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M19,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE19, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES20.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M20 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M20,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE20, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES21.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M21 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M21,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE21, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES22.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M22 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M22,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE22, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES23.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M23 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M23,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE23, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES24.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M24 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M24,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE24, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES25.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M25 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M25,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE25, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES26.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M26 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M26,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE26, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES27.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M27 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M27,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE27, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES8.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M28 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M28,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE28, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES9.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M29 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M29,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE29, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When EQUIDES30.UNITS ='fpm' then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND((OPINSTGRSRATE.M30 * PREF.CONVTHICK2),2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "ROUND(OPINSTGRSRATE.M30,2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "AS INSTANTANEOUSRATE30, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES1.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES1.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS1, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES2.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES2.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS2, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES3.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES3.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS3, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES4.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES4.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS4, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES5.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES5.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS5, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES6.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES6.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS6, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES7.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES7.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS7, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES8.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES8.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS8, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES9.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES9.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS9, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES10.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES10.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS10, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES11.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES11.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS11, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES12.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES12.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS12, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES13.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES13.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS13, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES14.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES14.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS14, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES15.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES15.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS15, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES16.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES16.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS16, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES17.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES17.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS17, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES18.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES18.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS18, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES19.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES19.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS19, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES20.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES20.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS20, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES21.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES21.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS21, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES22.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES22.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS22, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES23.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES23.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS23, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES24.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES24.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS24, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES25.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES25.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS25, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES26.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES26.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS26, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES27.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES27.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS27, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES28.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES28.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS28, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES29.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES29.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS29, "
                StrSql = StrSql + "Case "
                StrSql = StrSql + "When PREF.UNITS =0 then "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES30.UNITS) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "Else "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(EQUIDES30.UNITS2) "
                StrSql = StrSql + ") "
                StrSql = StrSql + "End "
                StrSql = StrSql + "As EQUIPUNITS30, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M1 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE1, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M2 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE2, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M3 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE3, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M4 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE4, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M5 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE5, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M6 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE6, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M7 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE7, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M8 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE8, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M9 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE9, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M10 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE10, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M11 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE11, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M12 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE12, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M13 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE13, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M14 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE14, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M15 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE15, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M16 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE16, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M17 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE17, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M18 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE18, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M19 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE19, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M20 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE20, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M21 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE21, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M22 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE22, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M23 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE23, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M24 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE24, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M25 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE25, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M26 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE26, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M27 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE27, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M28 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE28, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M29 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE29, "
                StrSql = StrSql + "ROUND((OPLBSPERHOUR.M30 * PREF.CONVWT),2) AS INSTANTANEOUS2RATE30, "
                StrSql = StrSql + "OPDOWNTIME.M1 AS DOWNTIME1, "
                StrSql = StrSql + "OPDOWNTIME.M2 AS DOWNTIME2, "
                StrSql = StrSql + "OPDOWNTIME.M3 AS DOWNTIME3, "
                StrSql = StrSql + "OPDOWNTIME.M4 AS DOWNTIME4, "
                StrSql = StrSql + "OPDOWNTIME.M5 AS DOWNTIME5, "
                StrSql = StrSql + "OPDOWNTIME.M6 AS DOWNTIME6, "
                StrSql = StrSql + "OPDOWNTIME.M7 AS DOWNTIME7, "
                StrSql = StrSql + "OPDOWNTIME.M8 AS DOWNTIME8, "
                StrSql = StrSql + "OPDOWNTIME.M9 AS DOWNTIME9, "
                StrSql = StrSql + "OPDOWNTIME.M10 AS DOWNTIME10, "
                StrSql = StrSql + "OPDOWNTIME.M11 AS DOWNTIME11, "
                StrSql = StrSql + "OPDOWNTIME.M12 AS DOWNTIME12, "
                StrSql = StrSql + "OPDOWNTIME.M13 AS DOWNTIME13, "
                StrSql = StrSql + "OPDOWNTIME.M14 AS DOWNTIME14, "
                StrSql = StrSql + "OPDOWNTIME.M15 AS DOWNTIME15, "
                StrSql = StrSql + "OPDOWNTIME.M16 AS DOWNTIME16, "
                StrSql = StrSql + "OPDOWNTIME.M17 AS DOWNTIME17, "
                StrSql = StrSql + "OPDOWNTIME.M18 AS DOWNTIME18, "
                StrSql = StrSql + "OPDOWNTIME.M19 AS DOWNTIME19, "
                StrSql = StrSql + "OPDOWNTIME.M20 AS DOWNTIME20, "
                StrSql = StrSql + "OPDOWNTIME.M21 AS DOWNTIME21, "
                StrSql = StrSql + "OPDOWNTIME.M22 AS DOWNTIME22, "
                StrSql = StrSql + "OPDOWNTIME.M23 AS DOWNTIME23, "
                StrSql = StrSql + "OPDOWNTIME.M24 AS DOWNTIME24, "
                StrSql = StrSql + "OPDOWNTIME.M25 AS DOWNTIME25, "
                StrSql = StrSql + "OPDOWNTIME.M26 AS DOWNTIME26, "
                StrSql = StrSql + "OPDOWNTIME.M27 AS DOWNTIME27, "
                StrSql = StrSql + "OPDOWNTIME.M28 AS DOWNTIME28, "
                StrSql = StrSql + "OPDOWNTIME.M29 AS DOWNTIME29, "
                StrSql = StrSql + "OPDOWNTIME.M30 AS DOWNTIME30, "
                StrSql = StrSql + "OPWASTE.M1 AS PRODUCTIONWAST1, "
                StrSql = StrSql + "OPWASTE.M2 AS PRODUCTIONWAST2, "
                StrSql = StrSql + "OPWASTE.M3 AS PRODUCTIONWAST3, "
                StrSql = StrSql + "OPWASTE.M4 AS PRODUCTIONWAST4, "
                StrSql = StrSql + "OPWASTE.M5 AS PRODUCTIONWAST5, "
                StrSql = StrSql + "OPWASTE.M6 AS PRODUCTIONWAST6, "
                StrSql = StrSql + "OPWASTE.M7 AS PRODUCTIONWAST7, "
                StrSql = StrSql + "OPWASTE.M8 AS PRODUCTIONWAST8, "
                StrSql = StrSql + "OPWASTE.M9 AS PRODUCTIONWAST9, "
                StrSql = StrSql + "OPWASTE.M10 AS PRODUCTIONWAST10, "
                StrSql = StrSql + "OPWASTE.M11 AS PRODUCTIONWAST11, "
                StrSql = StrSql + "OPWASTE.M12 AS PRODUCTIONWAST12, "
                StrSql = StrSql + "OPWASTE.M13 AS PRODUCTIONWAST13, "
                StrSql = StrSql + "OPWASTE.M14 AS PRODUCTIONWAST14, "
                StrSql = StrSql + "OPWASTE.M15 AS PRODUCTIONWAST15, "
                StrSql = StrSql + "OPWASTE.M16 AS PRODUCTIONWAST16, "
                StrSql = StrSql + "OPWASTE.M17 AS PRODUCTIONWAST17, "
                StrSql = StrSql + "OPWASTE.M18 AS PRODUCTIONWAST18, "
                StrSql = StrSql + "OPWASTE.M19 AS PRODUCTIONWAST19, "
                StrSql = StrSql + "OPWASTE.M20 AS PRODUCTIONWAST20, "
                StrSql = StrSql + "OPWASTE.M21 AS PRODUCTIONWAST21, "
                StrSql = StrSql + "OPWASTE.M22 AS PRODUCTIONWAST22, "
                StrSql = StrSql + "OPWASTE.M23 AS PRODUCTIONWAST23, "
                StrSql = StrSql + "OPWASTE.M24 AS PRODUCTIONWAST24, "
                StrSql = StrSql + "OPWASTE.M25 AS PRODUCTIONWAST25, "
                StrSql = StrSql + "OPWASTE.M26 AS PRODUCTIONWAST26, "
                StrSql = StrSql + "OPWASTE.M27 AS PRODUCTIONWAST27, "
                StrSql = StrSql + "OPWASTE.M28 AS PRODUCTIONWAST28, "
                StrSql = StrSql + "OPWASTE.M29 AS PRODUCTIONWAST29, "
                StrSql = StrSql + "OPWASTE.M30 AS PRODUCTIONWAST30, "
                StrSql = StrSql + "OPWASTE.W1 AS DESIGNWAST1, "
                StrSql = StrSql + "OPWASTE.W2 AS DESIGNWAST2, "
                StrSql = StrSql + "OPWASTE.W3 AS DESIGNWAST3, "
                StrSql = StrSql + "OPWASTE.W4 AS DESIGNWAST4, "
                StrSql = StrSql + "OPWASTE.W5 AS DESIGNWAST5, "
                StrSql = StrSql + "OPWASTE.W6 AS DESIGNWAST6, "
                StrSql = StrSql + "OPWASTE.W7 AS DESIGNWAST7, "
                StrSql = StrSql + "OPWASTE.W8 AS DESIGNWAST8, "
                StrSql = StrSql + "OPWASTE.W9 AS DESIGNWAST9, "
                StrSql = StrSql + "OPWASTE.W10 AS DESIGNWAST10, "
                StrSql = StrSql + "OPWASTE.W11 AS DESIGNWAST11, "
                StrSql = StrSql + "OPWASTE.W12 AS DESIGNWAST12, "
                StrSql = StrSql + "OPWASTE.W13 AS DESIGNWAST13, "
                StrSql = StrSql + "OPWASTE.W14 AS DESIGNWAST14, "
                StrSql = StrSql + "OPWASTE.W15 AS DESIGNWAST15, "
                StrSql = StrSql + "OPWASTE.W16 AS DESIGNWAST16, "
                StrSql = StrSql + "OPWASTE.W17 AS DESIGNWAST17, "
                StrSql = StrSql + "OPWASTE.W18 AS DESIGNWAST18, "
                StrSql = StrSql + "OPWASTE.W19 AS DESIGNWAST19, "
                StrSql = StrSql + "OPWASTE.W20 AS DESIGNWAST20, "
                StrSql = StrSql + "OPWASTE.W21 AS DESIGNWAST21, "
                StrSql = StrSql + "OPWASTE.W22 AS DESIGNWAST22, "
                StrSql = StrSql + "OPWASTE.W23 AS DESIGNWAST23, "
                StrSql = StrSql + "OPWASTE.W24 AS DESIGNWAST24, "
                StrSql = StrSql + "OPWASTE.W25 AS DESIGNWAST25, "
                StrSql = StrSql + "OPWASTE.W26 AS DESIGNWAST26, "
                StrSql = StrSql + "OPWASTE.W27 AS DESIGNWAST27, "
                StrSql = StrSql + "OPWASTE.W28 AS DESIGNWAST28, "
                StrSql = StrSql + "OPWASTE.W29 AS DESIGNWAST29, "
                StrSql = StrSql + "OPWASTE.W30 AS DESIGNWAST30, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM "
                StrSql = StrSql + "EQUIPMENTTYPE "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES1 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES1.EQUIPID = EQUIPMENTTYPE.M1 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES2 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES2.EQUIPID = EQUIPMENTTYPE.M2 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES3 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES3.EQUIPID = EQUIPMENTTYPE.M3 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES4 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES4.EQUIPID = EQUIPMENTTYPE.M4 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES5 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES5.EQUIPID = EQUIPMENTTYPE.M5 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES6 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES6.EQUIPID = EQUIPMENTTYPE.M6 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES7 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES7.EQUIPID = EQUIPMENTTYPE.M7 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES8 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES8.EQUIPID = EQUIPMENTTYPE.M8 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES9 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES9.EQUIPID = EQUIPMENTTYPE.M9 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES10 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES10.EQUIPID = EQUIPMENTTYPE.M10 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES11 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES11.EQUIPID = EQUIPMENTTYPE.M11 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES12 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES12.EQUIPID = EQUIPMENTTYPE.M12 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES13 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES13.EQUIPID = EQUIPMENTTYPE.M13 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES14 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES14.EQUIPID = EQUIPMENTTYPE.M14 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES15 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES15.EQUIPID = EQUIPMENTTYPE.M15 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES16 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES16.EQUIPID = EQUIPMENTTYPE.M16 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES17 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES17.EQUIPID = EQUIPMENTTYPE.M17 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES18 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES18.EQUIPID = EQUIPMENTTYPE.M18 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES19 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES19.EQUIPID = EQUIPMENTTYPE.M19 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES20 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES20.EQUIPID = EQUIPMENTTYPE.M20 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES21 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES21.EQUIPID = EQUIPMENTTYPE.M21 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES22 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES22.EQUIPID = EQUIPMENTTYPE.M22 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES23 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES23.EQUIPID = EQUIPMENTTYPE.M23 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES24 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES24.EQUIPID = EQUIPMENTTYPE.M24 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES25 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES25.EQUIPID = EQUIPMENTTYPE.M25 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES26 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES26.EQUIPID = EQUIPMENTTYPE.M26 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES27 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES27.EQUIPID = EQUIPMENTTYPE.M27 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES28 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES28.EQUIPID = EQUIPMENTTYPE.M28 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES29 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES29.EQUIPID = EQUIPMENTTYPE.M29 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "ECON.EQUIPMENT EQUIDES30 "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "EQUIDES30.EQUIPID = EQUIPMENTTYPE.M30 "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "OPWEBWIDTH "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "OPWEBWIDTH.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "PREFERENCES PREF "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "PREF.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "OPLBSPERHOUR "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "OPLBSPERHOUR.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "OPMAXRUNHRS "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "OPMAXRUNHRS.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "OPINSTGRSRATE "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "OPINSTGRSRATE.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "OPDOWNTIME "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "OPDOWNTIME.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "OPWASTE "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "OPWASTE.CASEID=EQUIPMENTTYPE.CASEID "
                StrSql = StrSql + "WHERE "
                StrSql = StrSql + "EQUIPMENTTYPE.CASEID IN (" + CaseIds + ") "




                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function PersonnelIn(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                StrSql = "SELECT DISTINCT  "
                StrSql = StrSql + "PERSONNELPOS.CASEID, "
                StrSql = StrSql + "( CASE WHEN PERSONNELPOS.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = PERSONNELPOS.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = PERSONNELPOS.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "PERSONNELPOS.M1  AS ID1, "
                StrSql = StrSql + "PERSONNELPOS.M2  AS ID2, "
                StrSql = StrSql + "PERSONNELPOS.M3  AS ID3, "
                StrSql = StrSql + "PERSONNELPOS.M4  AS ID4, "
                StrSql = StrSql + "PERSONNELPOS.M5  AS ID5, "
                StrSql = StrSql + "PERSONNELPOS.M6  AS ID6, "
                StrSql = StrSql + "PERSONNELPOS.M7  AS ID7, "
                StrSql = StrSql + "PERSONNELPOS.M8  AS ID8, "
                StrSql = StrSql + "PERSONNELPOS.M9  AS ID9, "
                StrSql = StrSql + "PERSONNELPOS.M10  AS ID10, "
                StrSql = StrSql + "PERSONNELPOS.M11  AS ID11, "
                StrSql = StrSql + "PERSONNELPOS.M12  AS ID12, "
                StrSql = StrSql + "PERSONNELPOS.M13  AS ID13, "
                StrSql = StrSql + "PERSONNELPOS.M14  AS ID14, "
                StrSql = StrSql + "PERSONNELPOS.M15  AS ID15, "
                StrSql = StrSql + "PERSONNELPOS.M16  AS ID16, "
                StrSql = StrSql + "PERSONNELPOS.M17  AS ID17, "
                StrSql = StrSql + "PERSONNELPOS.M18  AS ID18, "
                StrSql = StrSql + "PERSONNELPOS.M19  AS ID19, "
                StrSql = StrSql + "PERSONNELPOS.M20  AS ID20, "
                StrSql = StrSql + "PERSONNELPOS.M21  AS ID21, "
                StrSql = StrSql + "PERSONNELPOS.M22  AS ID22, "
                StrSql = StrSql + "PERSONNELPOS.M23  AS ID23, "
                StrSql = StrSql + "PERSONNELPOS.M24  AS ID24, "
                StrSql = StrSql + "PERSONNELPOS.M25  AS ID25, "
                StrSql = StrSql + "PERSONNELPOS.M26  AS ID26, "
                StrSql = StrSql + "PERSONNELPOS.M27  AS ID27, "
                StrSql = StrSql + "PERSONNELPOS.M28  AS ID28, "
                StrSql = StrSql + "PERSONNELPOS.M29  AS ID29, "
                StrSql = StrSql + "PERSONNELPOS.M30  AS ID30, "
                StrSql = StrSql + "PERSONNELNUM.M1  AS NUMBER1, "
                StrSql = StrSql + "PERSONNELNUM.M2  AS NUMBER2, "
                StrSql = StrSql + "PERSONNELNUM.M3  AS NUMBER3, "
                StrSql = StrSql + "PERSONNELNUM.M4  AS NUMBER4, "
                StrSql = StrSql + "PERSONNELNUM.M5  AS NUMBER5, "
                StrSql = StrSql + "PERSONNELNUM.M6  AS NUMBER6, "
                StrSql = StrSql + "PERSONNELNUM.M7  AS NUMBER7, "
                StrSql = StrSql + "PERSONNELNUM.M8  AS NUMBER8, "
                StrSql = StrSql + "PERSONNELNUM.M9  AS NUMBER9, "
                StrSql = StrSql + "PERSONNELNUM.M10  AS NUMBER10, "
                StrSql = StrSql + "PERSONNELNUM.M11  AS NUMBER11, "
                StrSql = StrSql + "PERSONNELNUM.M12  AS NUMBER12, "
                StrSql = StrSql + "PERSONNELNUM.M13  AS NUMBER13, "
                StrSql = StrSql + "PERSONNELNUM.M14  AS NUMBER14, "
                StrSql = StrSql + "PERSONNELNUM.M15  AS NUMBER15, "
                StrSql = StrSql + "PERSONNELNUM.M16  AS NUMBER16, "
                StrSql = StrSql + "PERSONNELNUM.M17  AS NUMBER17, "
                StrSql = StrSql + "PERSONNELNUM.M18  AS NUMBER18, "
                StrSql = StrSql + "PERSONNELNUM.M19  AS NUMBER19, "
                StrSql = StrSql + "PERSONNELNUM.M20  AS NUMBER20, "
                StrSql = StrSql + "PERSONNELNUM.M21  AS NUMBER21, "
                StrSql = StrSql + "PERSONNELNUM.M22  AS NUMBER22, "
                StrSql = StrSql + "PERSONNELNUM.M23  AS NUMBER23, "
                StrSql = StrSql + "PERSONNELNUM.M24  AS NUMBER24, "
                StrSql = StrSql + "PERSONNELNUM.M25  AS NUMBER25, "
                StrSql = StrSql + "PERSONNELNUM.M26  AS NUMBER26, "
                StrSql = StrSql + "PERSONNELNUM.M27  AS NUMBER27, "
                StrSql = StrSql + "PERSONNELNUM.M28  AS NUMBER28, "
                StrSql = StrSql + "PERSONNELNUM.M29  AS NUMBER29, "
                StrSql = StrSql + "PERSONNELNUM.M30  AS NUMBER30, "
                StrSql = StrSql + "PERSONNELDEP.M10  AS DEPT1, "
                StrSql = StrSql + "PERSONNELDEP.M11  AS DEPARTMENT1, "
                StrSql = StrSql + "PERSONNELDEP.M12  AS DEPARTMENT2, "
                StrSql = StrSql + "PERSONNELDEP.M13  AS DEPARTMENT3, "
                StrSql = StrSql + "PERSONNELDEP.M14  AS DEPARTMENT4, "
                StrSql = StrSql + "PERSONNELDEP.M15  AS DEPARTMENT5, "
                StrSql = StrSql + "PERSONNELDEP.M16  AS DEPARTMENT6, "
                StrSql = StrSql + "PERSONNELDEP.M17  AS DEPARTMENT7, "
                StrSql = StrSql + "PERSONNELDEP.M18  AS DEPARTMENT8, "
                StrSql = StrSql + "PERSONNELDEP.M19  AS DEPARTMENT9, "
                StrSql = StrSql + "PERSONNELDEP.M19  AS DEPARTMENT10, "
                StrSql = StrSql + "PERSONNELDEP.M11  AS DEPARTMENT11, "
                StrSql = StrSql + "PERSONNELDEP.M12  AS DEPARTMENT12, "
                StrSql = StrSql + "PERSONNELDEP.M13  AS DEPARTMENT13, "
                StrSql = StrSql + "PERSONNELDEP.M14  AS DEPARTMENT14, "
                StrSql = StrSql + "PERSONNELDEP.M15  AS DEPARTMENT15, "
                StrSql = StrSql + "PERSONNELDEP.M16  AS DEPARTMENT16, "
                StrSql = StrSql + "PERSONNELDEP.M17  AS DEPARTMENT17, "
                StrSql = StrSql + "PERSONNELDEP.M18  AS DEPARTMENT18, "
                StrSql = StrSql + "PERSONNELDEP.M19  AS DEPARTMENT19, "
                StrSql = StrSql + "PERSONNELDEP.M20  AS DEPARTMENT20, "
                StrSql = StrSql + "PERSONNELDEP.M21  AS DEPARTMENT21, "
                StrSql = StrSql + "PERSONNELDEP.M22  AS DEPARTMENT22, "
                StrSql = StrSql + "PERSONNELDEP.M23  AS DEPARTMENT23, "
                StrSql = StrSql + "PERSONNELDEP.M24  AS DEPARTMENT24, "
                StrSql = StrSql + "PERSONNELDEP.M25  AS DEPARTMENT25, "
                StrSql = StrSql + "PERSONNELDEP.M26  AS DEPARTMENT26, "
                StrSql = StrSql + "PERSONNELDEP.M27  AS DEPARTMENT27, "
                StrSql = StrSql + "PERSONNELDEP.M28  AS DEPARTMENT28, "
                StrSql = StrSql + "PERSONNELDEP.M29  AS DEPARTMENT29, "
                StrSql = StrSql + "PERSONNELDEP.M30  AS DEPARTMENT30, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS, "
                StrSql = StrSql + "DECODE (PREF.OCOUNTRY ,0 , 'PERSONNEL', "
                StrSql = StrSql + "1 , 'PERSONNELCHINA', "
                StrSql = StrSql + "2 , 'PERSONNELUK', "
                StrSql = StrSql + "3 , 'PERSONNELGERMANY', "
                StrSql = StrSql + "4,  'PERSONNELSKOREA', "
                StrSql = StrSql + "'NOCOUNTRY' "
                StrSql = StrSql + ")COUNTRY "
                StrSql = StrSql + "FROM "
                StrSql = StrSql + "PERSONNELPOS "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID =PERSONNELPOS.CASEID "
                StrSql = StrSql + "INNER JOIN PERSONNELNUM "
                StrSql = StrSql + "ON 	PERSONNELNUM.CASEID = PERSONNELPOS.CASEID "
                StrSql = StrSql + "INNER JOIN PERSONNELSAL "
                StrSql = StrSql + "ON	PERSONNELSAL. CASEID = PERSONNELPOS.CASEID "
                StrSql = StrSql + "INNER JOIN PERSONNELVP "
                StrSql = StrSql + "ON PERSONNELVP.CASEID = PERSONNELPOS.CASEID "
                StrSql = StrSql + "INNER JOIN PERSONNELDEP "
                StrSql = StrSql + "ON PERSONNELDEP.CASEID = PERSONNELPOS.CASEID "
                StrSql = StrSql + "WHERE PERSONNELPOS.CASEID IN(" + CaseIds + ") ORDER BY PERSONNELPOS.CASEID "




                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function PlantConfig2(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT DISTINCT  "
                StrSql = StrSql + "PLANTSPACE.CASEID, "
                StrSql = StrSql + "( CASE WHEN PLANTSPACE.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = PLANTSPACE.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = PLANTSPACE.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(PLANTSPACE.M1*PREF.CONVAREA2) AS PRODUCTIONAREA, "
                StrSql = StrSql + "(PLANTSPACE.M2*PREF.CONVAREA2) AS WAREHOUSEAREA, "
                StrSql = StrSql + "(PLANTSPACE.M3*PREF.CONVAREA2) AS OFFICEAREA, "
                StrSql = StrSql + "(PLANTSPACE.M4*PREF.CONVAREA2) AS SUPPORTAREA, "
                StrSql = StrSql + "(PLANTSPACE.M5*PREF.CONVAREA2) AS TOTALAREA, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM "
                StrSql = StrSql + "PLANTSPACE "
                StrSql = StrSql + "INNER JOIN "
                StrSql = StrSql + "PREFERENCES PREF "
                StrSql = StrSql + "ON "
                StrSql = StrSql + "PREF.CASEID = PLANTSPACE. CASEID "
                StrSql = StrSql + "WHERE "
                StrSql = StrSql + "PLANTSPACE.CASEID IN(" + CaseIds + ") ORDER BY CASEID "




                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function EnergyIn(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT DISTINCT  "
                StrSql = StrSql + "PLANTENERGY.CASEID, "
                StrSql = StrSql + "( CASE WHEN PLANTENERGY.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = PLANTENERGY.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = PLANTENERGY.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(SELECT PRICE FROM ENERGY WHERE ENERGYID =1) AS  ELECS, "
                StrSql = StrSql + "(SELECT PRICE FROM ENERGY WHERE ENERGYID =2) AS  NATGASS, "
                StrSql = StrSql + "PLANTENERGY.ELECPRICE AS ELECP, "
                StrSql = StrSql + "PLANTENERGY.NGASPRICE AS NATGASP, "
                StrSql = StrSql + "PLANTENERGY.M1 , "
                StrSql = StrSql + "PLANTENERGY.M6 , "
                StrSql = StrSql + "PLANTENERGY.D1 , "
                StrSql = StrSql + "PLANTENERGY.D6 , "
                StrSql = StrSql + "PLANTENERGY.D11, "
                StrSql = StrSql + "PLANTENERGY.M2 , "
                StrSql = StrSql + "PLANTENERGY.M7 , "
                StrSql = StrSql + "PLANTENERGY.D2 , "
                StrSql = StrSql + "PLANTENERGY.D7 , "
                StrSql = StrSql + "PLANTENERGY.D12 , "
                StrSql = StrSql + "PLANTENERGY.M3 , "
                StrSql = StrSql + "PLANTENERGY.M8 , "
                StrSql = StrSql + "PLANTENERGY.D3 , "
                StrSql = StrSql + "PLANTENERGY.D8 , "
                StrSql = StrSql + "PLANTENERGY.D13 , "
                StrSql = StrSql + "PLANTENERGY.M4 , "
                StrSql = StrSql + "PLANTENERGY.M9 , "
                StrSql = StrSql + "PLANTENERGY.D4 , "
                StrSql = StrSql + "PLANTENERGY.D9 , "
                StrSql = StrSql + "PLANTENERGY.D14 , "
                StrSql = StrSql + "PLANTENERGY.M5 , "
                StrSql = StrSql + "PLANTENERGY.M10 , "
                StrSql = StrSql + "PLANTENERGY.D5 , "
                StrSql = StrSql + "PLANTENERGY.D10 , "
                StrSql = StrSql + "PLANTENERGY.D15, "
                StrSql = StrSql + "(PLANTCO2.D1*PREF.CONVWT) AS GHG1 , "
                StrSql = StrSql + "(PLANTCO2.D6*PREF.CONVWT) AS GHG6, "
                StrSql = StrSql + "(PLANTCO2.D11*PREF.CONVWT) AS GHG11, "
                StrSql = StrSql + "(PLANTCO2.D2*PREF.CONVWT) AS GHG2, "
                StrSql = StrSql + "(PLANTCO2.D7*PREF.CONVWT) AS GHG7, "
                StrSql = StrSql + "(PLANTCO2.D12*PREF.CONVWT) AS GHG12, "
                StrSql = StrSql + "(PLANTCO2.D3*PREF.CONVWT) AS GHG3, "
                StrSql = StrSql + "(PLANTCO2.D8*PREF.CONVWT) AS GHG8, "
                StrSql = StrSql + "(PLANTCO2.D13*PREF.CONVWT) AS GHG13, "
                StrSql = StrSql + "(PLANTCO2.D4*PREF.CONVWT) AS GHG4, "
                StrSql = StrSql + "(PLANTCO2.D9*PREF.CONVWT) AS GHG9, "
                StrSql = StrSql + "(PLANTCO2.D14*PREF.CONVWT) AS GHG14, "
                StrSql = StrSql + "(PLANTCO2.D5*PREF.CONVWT) AS GHG5, "
                StrSql = StrSql + "(PLANTCO2.D10*PREF.CONVWT) AS GHG10, "
                StrSql = StrSql + "(PLANTCO2.D15*PREF.CONVWT) AS GHG15, "
                StrSql = StrSql + "PLANTENERGY.REN, "
                StrSql = StrSql + "PLANTENERGY.INO, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM PLANTENERGY "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = PLANTENERGY.CASEID "
                StrSql = StrSql + "INNER JOIN PLANTCO2 "
                StrSql = StrSql + "ON PLANTCO2.CASEID = PLANTENERGY.CASEID "
                StrSql = StrSql + "WHERE PLANTENERGY.CASEID IN (" + CaseIds + ") ORDER BY PLANTENERGY.CASEID "





                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function CustomerIn(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "CUSTOMERIN.CASEID, "
                StrSql = StrSql + "( CASE WHEN CUSTOMERIN.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = CUSTOMERIN.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = CUSTOMERIN.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(CUSTOMERIN.M2*PREF.CONVTHICK3)SDTOCUST, "
                StrSql = StrSql + "((CNVF.TFUELEFF*PREF.CONVTHICK3)/PREF.CONVGALLON)TFUELEFFS, "
                StrSql = StrSql + "((CUSTOMERIN.M3*PREF.CONVTHICK3)/PREF.CONVGALLON)TFUELEFFP, "
                StrSql = StrSql + "((CNVF.RFUELEFF*PREF.CONVTHICK3)/PREF.CONVGALLON)RFUELEFFS, "
                StrSql = StrSql + "((CUSTOMERIN.M3*PREF.CONVTHICK3)/PREF.CONVGALLON)RFUELEFFP, "
                StrSql = StrSql + "CNVF.ERGY, "
                StrSql = StrSql + "CNVF.CO2, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM CUSTOMERIN "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = CUSTOMERIN.CASEID "
                StrSql = StrSql + "INNER JOIN ECON.CONVFACTORS2 CNVF "
                StrSql = StrSql + "ON 1 = 1 "
                StrSql = StrSql + "WHERE CUSTOMERIN.CASEID IN(" + CaseIds + ") ORDER BY CASEID "





                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function ExtraProcess(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "FIXEDCOSTSUG.CASEID, "
                StrSql = StrSql + "( CASE WHEN FIXEDCOSTSUG.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = FIXEDCOSTSUG.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = FIXEDCOSTSUG.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(FIXEDCOSTPCT.M1*PREF.CONVWT)EP1, "
                StrSql = StrSql + "(FIXEDCOSTPCT.M2*PREF.CONVWT)EP2, "
                StrSql = StrSql + "(FIXEDCOSTSUG.M1*PREF.CONVWT)SUG1, "
                StrSql = StrSql + "(FIXEDCOSTSUG.M2*PREF.CONVWT)SUG2, "
                StrSql = StrSql + "(FIXEDCOSTPRE.M1*PREF.CONVWT)PREF1, "
                StrSql = StrSql + "(FIXEDCOSTPRE.M2*PREF.CONVWT)PREF2, "
                StrSql = StrSql + "FIXEDCOSTDEP.M1 DEP1, "
                StrSql = StrSql + "FIXEDCOSTDEP.M2 DEP2, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM FIXEDCOSTSUG "
                StrSql = StrSql + "INNER JOIN FIXEDCOSTPCT "
                StrSql = StrSql + "ON FIXEDCOSTPCT.CASEID  = FIXEDCOSTSUG.CASEID "
                StrSql = StrSql + "INNER JOIN FIXEDCOSTPRE "
                StrSql = StrSql + "ON FIXEDCOSTPRE.CASEID  = FIXEDCOSTSUG.CASEID "
                StrSql = StrSql + "INNER JOIN FIXEDCOSTDEP "
                StrSql = StrSql + "ON FIXEDCOSTDEP.CASEID  = FIXEDCOSTSUG.CASEID "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = FIXEDCOSTSUG.CASEID "
                StrSql = StrSql + "WHERE FIXEDCOSTSUG.CASEID IN (" + CaseIds + ") ORDER BY FIXEDCOSTSUG.CASEID "






                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

#End Region

#Region "Intermediate Results"
        Public Function ExtrusionOut(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "MAT.CASEID, "
                StrSql = StrSql + "( CASE WHEN MAT.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = MAT.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = MAT.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(MAT1.MATDE1||' '||MAT1.MATDE2) AS MATDE1, "
                StrSql = StrSql + "(MAT2.MATDE1||' '||MAT2.MATDE2) AS MATDE2, "
                StrSql = StrSql + "(MAT3.MATDE1||' '||MAT3.MATDE2) AS MATDE3, "
                StrSql = StrSql + "(MAT4.MATDE1||' '||MAT4.MATDE2) AS MATDE4, "
                StrSql = StrSql + "(MAT5.MATDE1||' '||MAT5.MATDE2) AS MATDE5, "
                StrSql = StrSql + "(MAT6.MATDE1||' '||MAT6.MATDE2) AS MATDE6, "
                StrSql = StrSql + "(MAT7.MATDE1||' '||MAT7.MATDE2) AS MATDE7, "
                StrSql = StrSql + "(MAT8.MATDE1||' '||MAT8.MATDE2) AS MATDE8, "
                StrSql = StrSql + "(MAT9.MATDE1||' '||MAT9.MATDE2) AS MATDE9, "
                StrSql = StrSql + "(MAT10.MATDE1||' '||MAT10.MATDE2) AS MATDE10, "
                StrSql = StrSql + "(CASE WHEN MAT.SG1 <> 0 THEN "
                StrSql = StrSql + "MAT.SG1 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "MAT1.SG "
                StrSql = StrSql + "END)SG1, "
                StrSql = StrSql + "(CASE WHEN MAT.SG2 <> 0 THEN "
                StrSql = StrSql + "MAT.SG2 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "MAT2.SG "
                StrSql = StrSql + "END)SG2, "
                StrSql = StrSql + "(CASE WHEN MAT.SG3 <> 0 THEN "
                StrSql = StrSql + "MAT.SG3 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "MAT3.SG "
                StrSql = StrSql + "END)SG3, "
                StrSql = StrSql + "(CASE WHEN MAT.SG4 <> 0 THEN "
                StrSql = StrSql + "MAT.SG4 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "MAT4.SG "
                StrSql = StrSql + "END)SG4, "
                StrSql = StrSql + "(CASE WHEN MAT.SG5 <> 0 THEN "
                StrSql = StrSql + "MAT.SG5 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "MAT5.SG "
                StrSql = StrSql + "END)SG5, "
                StrSql = StrSql + "(CASE WHEN MAT.SG6 <> 0 THEN "
                StrSql = StrSql + "MAT.SG6 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "MAT6.SG "
                StrSql = StrSql + "END)SG6, "
                StrSql = StrSql + "(CASE WHEN MAT.SG7 <> 0 THEN "
                StrSql = StrSql + "MAT.SG7 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "MAT7.SG "
                StrSql = StrSql + "END)SG7, "
                StrSql = StrSql + "(CASE WHEN MAT.SG8 <> 0 THEN "
                StrSql = StrSql + "MAT.SG8 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "MAT8.SG "
                StrSql = StrSql + "END)SG8, "
                StrSql = StrSql + "(CASE WHEN MAT.SG9 <> 0 THEN "
                StrSql = StrSql + "MAT.SG9 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "MAT9.SG "
                StrSql = StrSql + "END)SG9, "
                StrSql = StrSql + "(CASE WHEN MAT.SG10 <> 0 THEN "
                StrSql = StrSql + "MAT.SG10 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "MAT10.SG "
                StrSql = StrSql + "END)SG10, "
                StrSql = StrSql + "(MATOUT.M1*PREF.CONVWT/PREF.CONVAREA) AS WT1, "
                StrSql = StrSql + "(MATOUT.M2*PREF.CONVWT/PREF.CONVAREA) AS WT2, "
                StrSql = StrSql + "(MATOUT.M3*PREF.CONVWT/PREF.CONVAREA) AS WT3, "
                StrSql = StrSql + "(MATOUT.M4*PREF.CONVWT/PREF.CONVAREA) AS WT4, "
                StrSql = StrSql + "(MATOUT.M5*PREF.CONVWT/PREF.CONVAREA) AS WT5, "
                StrSql = StrSql + "(MATOUT.M6*PREF.CONVWT/PREF.CONVAREA) AS WT6, "
                StrSql = StrSql + "(MATOUT.M7*PREF.CONVWT/PREF.CONVAREA) AS WT7, "
                StrSql = StrSql + "(MATOUT.M8*PREF.CONVWT/PREF.CONVAREA) AS WT8, "
                StrSql = StrSql + "(MATOUT.M9*PREF.CONVWT/PREF.CONVAREA) AS WT9, "
                StrSql = StrSql + "(MATOUT.M10*PREF.CONVWT/PREF.CONVAREA) AS WT10, "
                StrSql = StrSql + "MATOUT.P1, "
                StrSql = StrSql + "MATOUT.P2, "
                StrSql = StrSql + "MATOUT.P3, "
                StrSql = StrSql + "MATOUT.P4, "
                StrSql = StrSql + "MATOUT.P5, "
                StrSql = StrSql + "MATOUT.P6, "
                StrSql = StrSql + "MATOUT.P7, "
                StrSql = StrSql + "MATOUT.P8, "
                StrSql = StrSql + "MATOUT.P9, "
                StrSql = StrSql + "MATOUT.P10, "
                StrSql = StrSql + "(MATOUT.PUR1*PREF.CONVWT)AS PUR1, "
                StrSql = StrSql + "(MATOUT.PUR2*PREF.CONVWT)AS PUR2, "
                StrSql = StrSql + "(MATOUT.PUR3*PREF.CONVWT)AS PUR3, "
                StrSql = StrSql + "(MATOUT.PUR4*PREF.CONVWT)AS PUR4, "
                StrSql = StrSql + "(MATOUT.PUR5*PREF.CONVWT)AS PUR5, "
                StrSql = StrSql + "(MATOUT.PUR6*PREF.CONVWT)AS PUR6, "
                StrSql = StrSql + "(MATOUT.PUR7*PREF.CONVWT)AS PUR7, "
                StrSql = StrSql + "(MATOUT.PUR8*PREF.CONVWT)AS PUR8, "
                StrSql = StrSql + "(MATOUT.PUR9*PREF.CONVWT)AS PUR9, "
                StrSql = StrSql + "(MATOUT.PUR10*PREF.CONVWT)AS PUR10, "
                StrSql = StrSql + "MATOUT.EN1, "
                StrSql = StrSql + "MATOUT.EN2, "
                StrSql = StrSql + "MATOUT.EN3, "
                StrSql = StrSql + "MATOUT.EN4, "
                StrSql = StrSql + "MATOUT.EN5, "
                StrSql = StrSql + "MATOUT.EN6, "
                StrSql = StrSql + "MATOUT.EN7, "
                StrSql = StrSql + "MATOUT.EN8, "
                StrSql = StrSql + "MATOUT.EN9, "
                StrSql = StrSql + "MATOUT.EN10, "
                StrSql = StrSql + "(MATOUT.PURZ1*PREF.CONVWT)AS PURZ1, "
                StrSql = StrSql + "(MATOUT.PURZ2*PREF.CONVWT)AS PURZ2, "
                StrSql = StrSql + "(MATOUT.PURZ3*PREF.CONVWT)AS PURZ3, "
                StrSql = StrSql + "(MATOUT.PURZ4*PREF.CONVWT)AS PURZ4, "
                StrSql = StrSql + "(MATOUT.PURZ5*PREF.CONVWT)AS PURZ5, "
                StrSql = StrSql + "(MATOUT.PURZ6*PREF.CONVWT)AS PURZ6, "
                StrSql = StrSql + "(MATOUT.PURZ7*PREF.CONVWT)AS PURZ7, "
                StrSql = StrSql + "(MATOUT.PURZ8*PREF.CONVWT)AS PURZ8, "
                StrSql = StrSql + "(MATOUT.PURZ9*PREF.CONVWT)AS PURZ9, "
                StrSql = StrSql + "(MATOUT.PURZ10*PREF.CONVWT)AS PURZ10, "
                StrSql = StrSql + "MATOUT.INEN1, "
                StrSql = StrSql + "MATOUT.INEN2, "
                StrSql = StrSql + "MATOUT.INEN3, "
                StrSql = StrSql + "MATOUT.INEN4, "
                StrSql = StrSql + "MATOUT.INEN5, "
                StrSql = StrSql + "MATOUT.INEN6, "
                StrSql = StrSql + "MATOUT.INEN7, "
                StrSql = StrSql + "MATOUT.INEN8, "
                StrSql = StrSql + "MATOUT.INEN9, "
                StrSql = StrSql + "MATOUT.INEN10, "
                StrSql = StrSql + "(MATOUT.INGHG1*PREF.CONVWT)AS INGHG1, "
                StrSql = StrSql + "(MATOUT.INGHG2*PREF.CONVWT)AS INGHG2, "
                StrSql = StrSql + "(MATOUT.INGHG3*PREF.CONVWT)AS INGHG3, "
                StrSql = StrSql + "(MATOUT.INGHG4*PREF.CONVWT)AS INGHG4, "
                StrSql = StrSql + "(MATOUT.INGHG5*PREF.CONVWT)AS INGHG5, "
                StrSql = StrSql + "(MATOUT.INGHG6*PREF.CONVWT)AS INGHG6, "
                StrSql = StrSql + "(MATOUT.INGHG7*PREF.CONVWT)AS INGHG7, "
                StrSql = StrSql + "(MATOUT.INGHG8*PREF.CONVWT)AS INGHG8, "
                StrSql = StrSql + "(MATOUT.INGHG9*PREF.CONVWT)AS INGHG9, "
                StrSql = StrSql + "(MATOUT.INGHG10*PREF.CONVWT)AS INGHG10, "
                StrSql = StrSql + "(MATOUT.CMGHG1*PREF.CONVWT)AS CMGHG1, "
                StrSql = StrSql + "(MATOUT.CMGHG2*PREF.CONVWT)AS CMGHG2, "
                StrSql = StrSql + "(MATOUT.CMGHG3*PREF.CONVWT)AS CMGHG3, "
                StrSql = StrSql + "(MATOUT.CMGHG4*PREF.CONVWT)AS CMGHG4, "
                StrSql = StrSql + "(MATOUT.CMGHG5*PREF.CONVWT)AS CMGHG5, "
                StrSql = StrSql + "(MATOUT.CMGHG6*PREF.CONVWT)AS CMGHG6, "
                StrSql = StrSql + "(MATOUT.CMGHG7*PREF.CONVWT)AS CMGHG7, "
                StrSql = StrSql + "(MATOUT.CMGHG8*PREF.CONVWT)AS CMGHG8, "
                StrSql = StrSql + "(MATOUT.CMGHG9*PREF.CONVWT)AS CMGHG9, "
                StrSql = StrSql + "(MATOUT.CMGHG10*PREF.CONVWT)AS CMGHG10, "
                StrSql = StrSql + "TOTAL.TOTALMATINCINERGY, "
                StrSql = StrSql + "TOTAL.TOTALMATINCINGHG, "
                StrSql = StrSql + "TOTAL.TOTALMATCMPSTGHG, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM MATERIALINPUT MAT "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT1 "
                StrSql = StrSql + "ON MAT1.MATID = MAT.M1 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT2 "
                StrSql = StrSql + "ON MAT2.MATID = MAT.M2 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT3 "
                StrSql = StrSql + "ON MAT3.MATID = MAT.M3 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT4 "
                StrSql = StrSql + "ON MAT4.MATID = MAT.M4 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT5 "
                StrSql = StrSql + "ON MAT5.MATID = MAT.M5 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT6 "
                StrSql = StrSql + "ON MAT6.MATID = MAT.M6 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT7 "
                StrSql = StrSql + "ON MAT7.MATID = MAT.M7 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT8 "
                StrSql = StrSql + "ON MAT8.MATID = MAT.M8 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT9 "
                StrSql = StrSql + "ON MAT9.MATID = MAT.M9 "
                StrSql = StrSql + "INNER JOIN ECON.MATERIALS MAT10 "
                StrSql = StrSql + "ON MAT10.MATID = MAT.M10 "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=MAT.CASEID "
                StrSql = StrSql + "INNER JOIN MATERIALOUTPUT MATOUT "
                StrSql = StrSql + "ON MATOUT.CASEID = MAT.CASEID "
                StrSql = StrSql + "INNER JOIN TOTAL "
                StrSql = StrSql + "ON TOTAL.CASEID = MAT.CASEID "
                StrSql = StrSql + "WHERE MAT.CASEID IN(" + CaseIds + ") ORDER BY MAT.CASEID "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function PalletOut(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "POUT.CASEID, "
                StrSql = StrSql + "( CASE WHEN POUT.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = POUT.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = POUT.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(POUT.M1*PREF.CONVWT)M1, "
                StrSql = StrSql + "(POUT.M2*PREF.CONVWT)M2, "
                StrSql = StrSql + "(POUT.M3*PREF.CONVWT)M3, "
                StrSql = StrSql + "POUT.M4, "
                StrSql = StrSql + "(POUT.M5*PREF.CONVWT)M5, "
                StrSql = StrSql + "(POUT.M6*PREF.CONVWT)M6, "
                StrSql = StrSql + "(POUT.M7*PREF.CONVWT)M7, "
                StrSql = StrSql + "POUT.M8, "
                StrSql = StrSql + "(TOTAL.TOTALOLDPALLETENERGY/PREF.CONVWT)M9, "
                StrSql = StrSql + "(TOTAL.TOTPALLETOLDCO2)M10, "
                StrSql = StrSql + "(TOTAL.TOTALOLDPALLETINCINERGY/PREF.CONVWT)M11, "
                StrSql = StrSql + "(TOTAL.TOTALOLDPALLETINCINGHG)M12, "
                StrSql = StrSql + "(TOTAL.TOTALOLDPALLETCMPSTGHG)M13, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM PALLETINOUT POUT "
                StrSql = StrSql + "INNER JOIN TOTAL "
                StrSql = StrSql + "ON TOTAL.CASEID = POUT.CASEID "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=POUT.CASEID "
                StrSql = StrSql + "WHERE POUT.CASEID IN(" + CaseIds + ") ORDER BY POUT.CASEID "
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function EndOfLifeIn(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "MATB.CASEID, "
                StrSql = StrSql + "( CASE WHEN MATB.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = MATB.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = MATB.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "MATB.M1 AS MATB1, "
                StrSql = StrSql + "MATB.M2 AS MATB2, "
                StrSql = StrSql + "MATB.M3 AS MATB3, "
                StrSql = StrSql + "MATB.M4 AS MATB4, "
                StrSql = StrSql + "MATB.M5 AS MATB5, "
                StrSql = StrSql + "MATB.M6 AS MATB6, "
                StrSql = StrSql + "MATB.M7 AS MATB7, "
                StrSql = StrSql + "MATB.M8 AS MATB8, "
                StrSql = StrSql + "MATB.M9 AS MATB9, "
                StrSql = StrSql + "MALIN.MR1 AS MALRE1, "
                StrSql = StrSql + "MALIN.MR2 AS MALRE2, "
                StrSql = StrSql + "MALIN.MR3 AS MALRE3, "
                StrSql = StrSql + "MALIN.MR4 AS MALRE4, "
                StrSql = StrSql + "MALIN.MR5 AS MALRE5, "
                StrSql = StrSql + "MALIN.MR6 AS MALRE6, "
                StrSql = StrSql + "MALIN.MR7 AS MALRE7, "
                StrSql = StrSql + "MALIN.MR8 AS MALRE8, "
                StrSql = StrSql + "MALIN.MR9 AS MALRE9, "
                StrSql = StrSql + "MALIN.MI1 AS MALIN1, "
                StrSql = StrSql + "MALIN.MI2 AS MALIN2, "
                StrSql = StrSql + "MALIN.MI3 AS MALIN3, "
                StrSql = StrSql + "MALIN.MI4 AS MALIN4, "
                StrSql = StrSql + "MALIN.MI5 AS MALIN5, "
                StrSql = StrSql + "MALIN.MI6 AS MALIN6, "
                StrSql = StrSql + "MALIN.MI7 AS MALIN7, "
                StrSql = StrSql + "MALIN.MI8 AS MALIN8, "
                StrSql = StrSql + "MALIN.MI9 AS MALIN9, "
                StrSql = StrSql + "MALIN.MC1 AS MALCM1, "
                StrSql = StrSql + "MALIN.MC2 AS MALCM2, "
                StrSql = StrSql + "MALIN.MC3 AS MALCM3, "
                StrSql = StrSql + "MALIN.MC4 AS MALCM4, "
                StrSql = StrSql + "MALIN.MC5 AS MALCM5, "
                StrSql = StrSql + "MALIN.MC6 AS MALCM6, "
                StrSql = StrSql + "MALIN.MC7 AS MALCM7, "
                StrSql = StrSql + "MALIN.MC8 AS MALCM8, "
                StrSql = StrSql + "MALIN.MC9 AS MALCM9, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM MATERIALBALANCE MATB "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = MATB.CASEID "
                StrSql = StrSql + "INNER JOIN MATENDOFLIFEIN MALIN "
                StrSql = StrSql + "ON MALIN.CASEID = MATB.CASEID "
                StrSql = StrSql + "WHERE MATB.CASEID IN(" + CaseIds + ") ORDER BY MATB.CASEID "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function PalletNewOut(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "PNEWOUT.CASEID, "
                StrSql = StrSql + "( CASE WHEN PNEWOUT.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = PNEWOUT.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = PNEWOUT.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "PNEWOUT.A1, "
                StrSql = StrSql + "PNEWOUT.A2, "
                StrSql = StrSql + "PNEWOUT.A3, "
                StrSql = StrSql + "PNEWOUT.A4, "
                StrSql = StrSql + "PNEWOUT.A5, "
                StrSql = StrSql + "PNEWOUT.A6, "
                StrSql = StrSql + "PNEWOUT.A7, "
                StrSql = StrSql + "PNEWOUT.A8, "
                StrSql = StrSql + "PNEWOUT.A9, "
                StrSql = StrSql + "PNEWOUT.A10, "
                StrSql = StrSql + "PNEWOUT.B1, "
                StrSql = StrSql + "PNEWOUT.B2, "
                StrSql = StrSql + "PNEWOUT.B3, "
                StrSql = StrSql + "PNEWOUT.B4, "
                StrSql = StrSql + "PNEWOUT.B5, "
                StrSql = StrSql + "PNEWOUT.B6, "
                StrSql = StrSql + "PNEWOUT.B7, "
                StrSql = StrSql + "PNEWOUT.B8, "
                StrSql = StrSql + "PNEWOUT.B9, "
                StrSql = StrSql + "PNEWOUT.B10, "
                StrSql = StrSql + "PNEWOUT.C1, "
                StrSql = StrSql + "PNEWOUT.C2, "
                StrSql = StrSql + "PNEWOUT.C3, "
                StrSql = StrSql + "PNEWOUT.C4, "
                StrSql = StrSql + "PNEWOUT.C5, "
                StrSql = StrSql + "PNEWOUT.C6, "
                StrSql = StrSql + "PNEWOUT.C7, "
                StrSql = StrSql + "PNEWOUT.C8, "
                StrSql = StrSql + "PNEWOUT.C9, "
                StrSql = StrSql + "PNEWOUT.C10, "
                StrSql = StrSql + "PNEWOUT.D1, "
                StrSql = StrSql + "PNEWOUT.D2, "
                StrSql = StrSql + "PNEWOUT.D3, "
                StrSql = StrSql + "PNEWOUT.D4, "
                StrSql = StrSql + "PNEWOUT.D5, "
                StrSql = StrSql + "PNEWOUT.D6, "
                StrSql = StrSql + "PNEWOUT.D7, "
                StrSql = StrSql + "PNEWOUT.D8, "
                StrSql = StrSql + "PNEWOUT.D9, "
                StrSql = StrSql + "PNEWOUT.D10, "
                StrSql = StrSql + "PNEWOUT.E1, "
                StrSql = StrSql + "PNEWOUT.E2, "
                StrSql = StrSql + "PNEWOUT.E3, "
                StrSql = StrSql + "PNEWOUT.E4, "
                StrSql = StrSql + "PNEWOUT.E5, "
                StrSql = StrSql + "PNEWOUT.E6, "
                StrSql = StrSql + "PNEWOUT.E7, "
                StrSql = StrSql + "PNEWOUT.E8, "
                StrSql = StrSql + "PNEWOUT.E9, "
                StrSql = StrSql + "PNEWOUT.E10, "
                StrSql = StrSql + "PNEWOUT.F1, "
                StrSql = StrSql + "PNEWOUT.F2, "
                StrSql = StrSql + "PNEWOUT.F3, "
                StrSql = StrSql + "PNEWOUT.F4, "
                StrSql = StrSql + "PNEWOUT.F5, "
                StrSql = StrSql + "PNEWOUT.F6, "
                StrSql = StrSql + "PNEWOUT.F7, "
                StrSql = StrSql + "PNEWOUT.F8, "
                StrSql = StrSql + "PNEWOUT.F9, "
                StrSql = StrSql + "PNEWOUT.F10, "
                StrSql = StrSql + "PNEWOUT.G1, "
                StrSql = StrSql + "PNEWOUT.G2, "
                StrSql = StrSql + "PNEWOUT.G3, "
                StrSql = StrSql + "PNEWOUT.G4, "
                StrSql = StrSql + "PNEWOUT.G5, "
                StrSql = StrSql + "PNEWOUT.G6, "
                StrSql = StrSql + "PNEWOUT.G7, "
                StrSql = StrSql + "PNEWOUT.G8, "
                StrSql = StrSql + "PNEWOUT.G9, "
                StrSql = StrSql + "PNEWOUT.G10, "
                StrSql = StrSql + "PNEWOUT.H1, "
                StrSql = StrSql + "PNEWOUT.H2, "
                StrSql = StrSql + "PNEWOUT.H3, "
                StrSql = StrSql + "PNEWOUT.H4, "
                StrSql = StrSql + "PNEWOUT.H5, "
                StrSql = StrSql + "PNEWOUT.H6, "
                StrSql = StrSql + "PNEWOUT.H7, "
                StrSql = StrSql + "PNEWOUT.H8, "
                StrSql = StrSql + "PNEWOUT.H9, "
                StrSql = StrSql + "PNEWOUT.H10, "
                StrSql = StrSql + "PNEWOUT.I1, "
                StrSql = StrSql + "PNEWOUT.I2, "
                StrSql = StrSql + "PNEWOUT.I3, "
                StrSql = StrSql + "PNEWOUT.I4, "
                StrSql = StrSql + "PNEWOUT.I5, "
                StrSql = StrSql + "PNEWOUT.I6, "
                StrSql = StrSql + "PNEWOUT.I7, "
                StrSql = StrSql + "PNEWOUT.I8, "
                StrSql = StrSql + "PNEWOUT.I9, "
                StrSql = StrSql + "PNEWOUT.I10, "
                StrSql = StrSql + "PNEWOUT.J1, "
                StrSql = StrSql + "PNEWOUT.J2, "
                StrSql = StrSql + "PNEWOUT.J3, "
                StrSql = StrSql + "PNEWOUT.J4, "
                StrSql = StrSql + "PNEWOUT.J5, "
                StrSql = StrSql + "PNEWOUT.J6, "
                StrSql = StrSql + "PNEWOUT.J7, "
                StrSql = StrSql + "PNEWOUT.J8, "
                StrSql = StrSql + "PNEWOUT.J9, "
                StrSql = StrSql + "PNEWOUT.J10, "
                StrSql = StrSql + "PNEWOUT.K1, "
                StrSql = StrSql + "PNEWOUT.K2, "
                StrSql = StrSql + "PNEWOUT.K3, "
                StrSql = StrSql + "PNEWOUT.K4, "
                StrSql = StrSql + "PNEWOUT.K5, "
                StrSql = StrSql + "PNEWOUT.K6, "
                StrSql = StrSql + "PNEWOUT.K7, "
                StrSql = StrSql + "PNEWOUT.K8, "
                StrSql = StrSql + "PNEWOUT.K9, "
                StrSql = StrSql + "PNEWOUT.K10, "
                StrSql = StrSql + "PNEWOUT.L1, "
                StrSql = StrSql + "PNEWOUT.L2, "
                StrSql = StrSql + "PNEWOUT.L3, "
                StrSql = StrSql + "PNEWOUT.L4, "
                StrSql = StrSql + "PNEWOUT.L5, "
                StrSql = StrSql + "PNEWOUT.L6, "
                StrSql = StrSql + "PNEWOUT.L7, "
                StrSql = StrSql + "PNEWOUT.L8, "
                StrSql = StrSql + "PNEWOUT.L9, "
                StrSql = StrSql + "PNEWOUT.L10, "
                StrSql = StrSql + "PNEWOUT.M1, "
                StrSql = StrSql + "PNEWOUT.M2, "
                StrSql = StrSql + "PNEWOUT.M3, "
                StrSql = StrSql + "PNEWOUT.M4, "
                StrSql = StrSql + "PNEWOUT.M5, "
                StrSql = StrSql + "PNEWOUT.M6, "
                StrSql = StrSql + "PNEWOUT.M7, "
                StrSql = StrSql + "PNEWOUT.M8, "
                StrSql = StrSql + "PNEWOUT.M9, "
                StrSql = StrSql + "PNEWOUT.M10, "
                StrSql = StrSql + "PNEWOUT.N1, "
                StrSql = StrSql + "PNEWOUT.N2, "
                StrSql = StrSql + "PNEWOUT.N3, "
                StrSql = StrSql + "PNEWOUT.N4, "
                StrSql = StrSql + "PNEWOUT.N5, "
                StrSql = StrSql + "PNEWOUT.N6, "
                StrSql = StrSql + "PNEWOUT.N7, "
                StrSql = StrSql + "PNEWOUT.N8, "
                StrSql = StrSql + "PNEWOUT.N9, "
                StrSql = StrSql + "PNEWOUT.N10, "
                StrSql = StrSql + "PNEWOUT.O1, "
                StrSql = StrSql + "PNEWOUT.O2, "
                StrSql = StrSql + "PNEWOUT.O3, "
                StrSql = StrSql + "PNEWOUT.O4, "
                StrSql = StrSql + "PNEWOUT.O5, "
                StrSql = StrSql + "PNEWOUT.O6, "
                StrSql = StrSql + "PNEWOUT.O7, "
                StrSql = StrSql + "PNEWOUT.O8, "
                StrSql = StrSql + "PNEWOUT.O9, "
                StrSql = StrSql + "PNEWOUT.O10, "
                StrSql = StrSql + "PNEWOUT.P1, "
                StrSql = StrSql + "PNEWOUT.P2, "
                StrSql = StrSql + "PNEWOUT.P3, "
                StrSql = StrSql + "PNEWOUT.P4, "
                StrSql = StrSql + "PNEWOUT.P5, "
                StrSql = StrSql + "PNEWOUT.P6, "
                StrSql = StrSql + "PNEWOUT.P7, "
                StrSql = StrSql + "PNEWOUT.P8, "
                StrSql = StrSql + "PNEWOUT.P9, "
                StrSql = StrSql + "PNEWOUT.P10, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM PALLETINNEWOUT PNEWOUT "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=PNEWOUT.CASEID "
                StrSql = StrSql + "WHERE PNEWOUT.CASEID IN(" + CaseIds + ") ORDER BY PNEWOUT.CASEID "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function ScorecardIntm(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT SCREIN.CASEID,  "
                StrSql = StrSql + "( CASE WHEN SCREIN.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = SCREIN.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = SCREIN.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "M1, "
                StrSql = StrSql + "M2, "
                StrSql = StrSql + "M3, "
                StrSql = StrSql + "M4, "
                StrSql = StrSql + "M5, "
                StrSql = StrSql + "M6, "
                StrSql = StrSql + "M7, "
                StrSql = StrSql + "M8, "
                StrSql = StrSql + "M9, "
                StrSql = StrSql + "M10, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM SCORECARDINTM SCREIN "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=SCREIN.CASEID "
                StrSql = StrSql + "WHERE SCREIN.CASEID IN(" + CaseIds + ") ORDER BY SCREIN.CASEID "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function OperationsOut(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "OPOUT.CASEID, "
                StrSql = StrSql + "( CASE WHEN OPOUT.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = OPOUT.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = OPOUT.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(OPOUT1.PROCDE1||' '||OPOUT1.PROCDE2) AS PROCDE1, "
                StrSql = StrSql + "(OPOUT2.PROCDE1||' '||OPOUT2.PROCDE2) AS PROCDE2, "
                StrSql = StrSql + "(OPOUT3.PROCDE1||' '||OPOUT3.PROCDE2) AS PROCDE3, "
                StrSql = StrSql + "(OPOUT4.PROCDE1||' '||OPOUT4.PROCDE2) AS PROCDE4, "
                StrSql = StrSql + "(OPOUT5.PROCDE1||' '||OPOUT5.PROCDE2) AS PROCDE5, "
                StrSql = StrSql + "(OPOUT6.PROCDE1||' '||OPOUT6.PROCDE2) AS PROCDE6, "
                StrSql = StrSql + "(OPOUT7.PROCDE1||' '||OPOUT7.PROCDE2) AS PROCDE7, "
                StrSql = StrSql + "(OPOUT8.PROCDE1||' '||OPOUT8.PROCDE2) AS PROCDE8, "
                StrSql = StrSql + "(OPOUT9.PROCDE1||' '||OPOUT9.PROCDE2) AS PROCDE9, "
                StrSql = StrSql + "(OPOUT10.PROCDE1||' '||OPOUT10.PROCDE2) AS PROCDE10, "
                StrSql = StrSql + "(OPDEPVOL.M1*PREF.CONVWT) AS PV1, "
                StrSql = StrSql + "(OPDEPVOL.M2*PREF.CONVWT) AS PV2, "
                StrSql = StrSql + "(OPDEPVOL.M3*PREF.CONVWT) AS PV3, "
                StrSql = StrSql + "(OPDEPVOL.M4*PREF.CONVWT) AS PV4, "
                StrSql = StrSql + "(OPDEPVOL.M5*PREF.CONVWT) AS PV5, "
                StrSql = StrSql + "(OPDEPVOL.M6*PREF.CONVWT) AS PV6, "
                StrSql = StrSql + "(OPDEPVOL.M7*PREF.CONVWT) AS PV7, "
                StrSql = StrSql + "(OPDEPVOL.M8*PREF.CONVWT) AS PV8, "
                StrSql = StrSql + "(OPDEPVOL.M9*PREF.CONVWT) AS PV9, "
                StrSql = StrSql + "(OPDEPVOL.M10*PREF.CONVWT) AS PV10, "
                StrSql = StrSql + "(OPDEPVOL.T1*PREF.CONVWT) AS FEV1, "
                StrSql = StrSql + "(OPDEPVOL.T2*PREF.CONVWT) AS FEV2, "
                StrSql = StrSql + "(OPDEPVOL.T3*PREF.CONVWT) AS FEV3, "
                StrSql = StrSql + "(OPDEPVOL.T4*PREF.CONVWT) AS FEV4, "
                StrSql = StrSql + "(OPDEPVOL.T5*PREF.CONVWT) AS FEV5, "
                StrSql = StrSql + "(OPDEPVOL.T6*PREF.CONVWT) AS FEV6, "
                StrSql = StrSql + "(OPDEPVOL.T7*PREF.CONVWT) AS FEV7, "
                StrSql = StrSql + "(OPDEPVOL.T8*PREF.CONVWT) AS FEV8, "
                StrSql = StrSql + "(OPDEPVOL.T9*PREF.CONVWT) AS FEV9, "
                StrSql = StrSql + "(OPDEPVOL.T10*PREF.CONVWT) AS FEV10, "
                StrSql = StrSql + "(OPDEPVOL.G1*PREF.CONVWT) AS FPV1, "
                StrSql = StrSql + "(OPDEPVOL.G2*PREF.CONVWT) AS FPV2, "
                StrSql = StrSql + "(OPDEPVOL.G3*PREF.CONVWT) AS FPV3, "
                StrSql = StrSql + "(OPDEPVOL.G4*PREF.CONVWT) AS FPV4, "
                StrSql = StrSql + "(OPDEPVOL.G5*PREF.CONVWT) AS FPV5, "
                StrSql = StrSql + "(OPDEPVOL.G6*PREF.CONVWT) AS FPV6, "
                StrSql = StrSql + "(OPDEPVOL.G7*PREF.CONVWT) AS FPV7, "
                StrSql = StrSql + "(OPDEPVOL.G8*PREF.CONVWT) AS FPV8, "
                StrSql = StrSql + "(OPDEPVOL.G9*PREF.CONVWT) AS FPV9, "
                StrSql = StrSql + "(OPDEPVOL.G10*PREF.CONVWT) AS FPV10, "
                StrSql = StrSql + "(OPDEPVOL.D1) AS DW1, "
                StrSql = StrSql + "(OPDEPVOL.D2) AS DW2, "
                StrSql = StrSql + "(OPDEPVOL.D3) AS DW3, "
                StrSql = StrSql + "(OPDEPVOL.D4) AS DW4, "
                StrSql = StrSql + "(OPDEPVOL.D5) AS DW5, "
                StrSql = StrSql + "(OPDEPVOL.D6) AS DW6, "
                StrSql = StrSql + "(OPDEPVOL.D7) AS DW7, "
                StrSql = StrSql + "(OPDEPVOL.D8) AS DW8, "
                StrSql = StrSql + "(OPDEPVOL.D9) AS DW9, "
                StrSql = StrSql + "(OPDEPVOL.D10) AS DW10, "
                StrSql = StrSql + "(OPDEPVOL.W1) AS AW1, "
                StrSql = StrSql + "(OPDEPVOL.W2) AS AW2, "
                StrSql = StrSql + "(OPDEPVOL.W3) AS AW3, "
                StrSql = StrSql + "(OPDEPVOL.W4) AS AW4, "
                StrSql = StrSql + "(OPDEPVOL.W5) AS AW5, "
                StrSql = StrSql + "(OPDEPVOL.W6) AS AW6, "
                StrSql = StrSql + "(OPDEPVOL.W7) AS AW7, "
                StrSql = StrSql + "(OPDEPVOL.W8) AS AW8, "
                StrSql = StrSql + "(OPDEPVOL.W9) AS AW9, "
                StrSql = StrSql + "(OPDEPVOL.W10) AS AW10, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM PLANTCONFIG OPOUT "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS OPOUT1 "
                StrSql = StrSql + "ON OPOUT1.PROCID = OPOUT.M1 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS OPOUT2 "
                StrSql = StrSql + "ON OPOUT2.PROCID = OPOUT.M2 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS OPOUT3 "
                StrSql = StrSql + "ON OPOUT3.PROCID = OPOUT.M3 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS OPOUT4 "
                StrSql = StrSql + "ON OPOUT4.PROCID = OPOUT.M4 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS OPOUT5 "
                StrSql = StrSql + "ON OPOUT5.PROCID = OPOUT.M5 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS OPOUT6 "
                StrSql = StrSql + "ON OPOUT6.PROCID = OPOUT.M6 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS OPOUT7 "
                StrSql = StrSql + "ON OPOUT7.PROCID = OPOUT.M7 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS OPOUT8 "
                StrSql = StrSql + "ON OPOUT8.PROCID = OPOUT.M8 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS OPOUT9 "
                StrSql = StrSql + "ON OPOUT9.PROCID = OPOUT.M9 "
                StrSql = StrSql + "INNER JOIN ECON.PROCESS OPOUT10 "
                StrSql = StrSql + "ON OPOUT10.PROCID = OPOUT.M10 "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=OPOUT.CASEID "
                StrSql = StrSql + "INNER JOIN OPDEPVOL "
                StrSql = StrSql + "ON OPDEPVOL.CASEID = OPOUT.CASEID "
                StrSql = StrSql + "WHERE OPOUT.CASEID IN(" + CaseIds + ") ORDER BY OPOUT.CASEID "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function


#End Region

#Region "Results"
        Public Function ErgyResults(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  TOT.CASEID,  "
                StrSql = StrSql + "( CASE WHEN TOT.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = TOT.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = TOT.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "TOT.RMERGY, "
                StrSql = StrSql + "TOT.RMPACKERGY, "
                StrSql = StrSql + "TOT.RMANDPACKTRNSPTERGY, "
                StrSql = StrSql + "TOT.PROCERGY, "
                StrSql = StrSql + "TOT.DPPACKERGY, "
                StrSql = StrSql + "TOT.DPTRNSPTERGY, "
                StrSql = StrSql + "TOT.TRSPTTOCUS, "
                StrSql = StrSql + "(TOT.RMERGY+TOT.RMPACKERGY+TOT.RMANDPACKTRNSPTERGY+TOT.PROCERGY+TOT.DPPACKERGY+TOT.DPTRNSPTERGY+TOT.TRSPTTOCUS)TOTALENERGY, "
                StrSql = StrSql + "(TOT.RMERGY+TOT.RMPACKERGY+TOT.DPPACKERGY)AS PURMATERIALERGY, "
                StrSql = StrSql + "(TOT.PROCERGY)AS PROCESSERGY, "
                StrSql = StrSql + "(TOT.RMANDPACKTRNSPTERGY+TOT.DPTRNSPTERGY+TOT.TRSPTTOCUS) AS TRNSPTERGY, "
                StrSql = StrSql + "(RSPL.VOLUME*PREF.CONVWT)SALESVOLUMELB, "
                StrSql = StrSql + "(CASE WHEN RSPL.FINVOLMSI > 0 THEN "
                StrSql = StrSql + "(RSPL.FINVOLMSI*PREF.CONVAREA) "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "RSPL.FINVOLMUNITS "
                StrSql = StrSql + "END)SALESVOLUMEUNIT, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM TOTAL TOT "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = TOT.CASEID "
                StrSql = StrSql + "INNER JOIN RESULTSPL RSPL "
                StrSql = StrSql + "ON RSPL.CASEID = TOT.CASEID "
                StrSql = StrSql + "WHERE TOT.CASEID IN(" + CaseIds + ") ORDER BY TOT.CASEID "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function GhgResults(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  TOT.CASEID,  "
                StrSql = StrSql + "( CASE WHEN TOT.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = TOT.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = TOT.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "(TOT.RMGRNHUSGAS*PREF.CONVWT) AS RMGRNHUSGAS, "
                StrSql = StrSql + "(TOT.RMPACKGRNHUSGAS*PREF.CONVWT) AS RMPACKGRNHUSGAS, "
                StrSql = StrSql + "(TOT.RMANDPACKTRNSPTGRNHUSGAS*PREF.CONVWT) AS RMANDPACKTRNSPTGRNHUSGAS, "
                StrSql = StrSql + "(TOT.PROCGRNHUSGAS*PREF.CONVWT) AS PROCGRNHUSGAS, "
                StrSql = StrSql + "(TOT.DPPACKGRNHUSGAS*PREF.CONVWT) AS DPPACKGRNHUSGAS, "
                StrSql = StrSql + "(TOT.DPTRNSPTGRNHUSGAS*PREF.CONVWT) AS DPTRNSPTGRNHUSGAS, "
                StrSql = StrSql + "(TOT.TRSPTTOCUSGRNHUSGAS*PREF.CONVWT)AS TRSPTTOCUSGRNHUSGAS, "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(TOT.RMGRNHUSGAS*PREF.CONVWT)+ "
                StrSql = StrSql + "(TOT.RMPACKGRNHUSGAS*PREF.CONVWT)+ "
                StrSql = StrSql + "(TOT.RMANDPACKTRNSPTGRNHUSGAS*PREF.CONVWT)+ "
                StrSql = StrSql + "(TOT.PROCGRNHUSGAS*PREF.CONVWT)+ "
                StrSql = StrSql + "(TOT.DPPACKGRNHUSGAS*PREF.CONVWT)+ "
                StrSql = StrSql + "(TOT.DPTRNSPTGRNHUSGAS*PREF.CONVWT)+ "
                StrSql = StrSql + "(TOT.TRSPTTOCUSGRNHUSGAS*PREF.CONVWT) "
                StrSql = StrSql + ")TOTALENGRNHUSGAS, "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(TOT.RMGRNHUSGAS*PREF.CONVWT)+ "
                StrSql = StrSql + "(TOT.RMPACKGRNHUSGAS*PREF.CONVWT)+ "
                StrSql = StrSql + "(TOT.DPPACKGRNHUSGAS*PREF.CONVWT) "
                StrSql = StrSql + ")PURMATERIALGRNHUSGAS, "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(TOT.PROCGRNHUSGAS*PREF.CONVWT) "
                StrSql = StrSql + ")PROCESSGRNHUSGAS, "
                StrSql = StrSql + "( "
                StrSql = StrSql + "(TOT.RMANDPACKTRNSPTGRNHUSGAS*PREF.CONVWT)+ "
                StrSql = StrSql + "(TOT.DPTRNSPTGRNHUSGAS*PREF.CONVWT)+ "
                StrSql = StrSql + "(TOT.TRSPTTOCUSGRNHUSGAS*PREF.CONVWT) "
                StrSql = StrSql + ")TRNSPTGRNHUSGAS, "
                StrSql = StrSql + "(RSPL.VOLUME*PREF.CONVWT)SALESVOLUMELB, "
                StrSql = StrSql + "(CASE WHEN RSPL.FINVOLMSI > 0 THEN "
                StrSql = StrSql + "(RSPL.FINVOLMSI*PREF.CONVAREA) "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "RSPL.FINVOLMUNITS "
                StrSql = StrSql + "END)SALESVOLUMEUNIT, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM TOTAL TOT "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = TOT.CASEID "
                StrSql = StrSql + "INNER JOIN RESULTSPL RSPL "
                StrSql = StrSql + "ON RSPL.CASEID = TOT.CASEID "
                StrSql = StrSql + "WHERE TOT.CASEID IN(" + CaseIds + ") ORDER BY TOT.CASEID "


                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function ScorecardRes(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                StrSql = "SELECT RSCRE.CASEID,  "
                StrSql = StrSql + "( CASE WHEN RSCRE.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = RSCRE.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = RSCRE.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "RSCRE.M1 AS RW1, "
                StrSql = StrSql + "RSCRE.M2 AS RW2, "
                StrSql = StrSql + "RSCRE.M3 AS RW3, "
                StrSql = StrSql + "RSCRE.M4 AS RW4, "
                StrSql = StrSql + "RSCRE.M5 AS RW5, "
                StrSql = StrSql + "RSCRE.M6 AS RW6, "
                StrSql = StrSql + "RSCRE.M7 AS RW7, "
                StrSql = StrSql + "RSCRE.M8 AS RW8, "
                StrSql = StrSql + "RSCRE.M9 AS RW9, "
                StrSql = StrSql + "RSCRE.M10 AS RW10, "
                StrSql = StrSql + "(M1+M2+M3+M4+M5+M6+M7+M8+M9+M10)RWT, "
                StrSql = StrSql + "MSCRE.M1 AS MX1, "
                StrSql = StrSql + "MSCRE.M2 AS MX2, "
                StrSql = StrSql + "MSCRE.M3 AS MX3, "
                StrSql = StrSql + "MSCRE.M4 AS MX4, "
                StrSql = StrSql + "MSCRE.M5 AS MX5, "
                StrSql = StrSql + "MSCRE.M6 AS MX6, "
                StrSql = StrSql + "MSCRE.M7 AS MX7, "
                StrSql = StrSql + "MSCRE.M8 AS MX8, "
                StrSql = StrSql + "MSCRE.M9 AS MX9, "
                StrSql = StrSql + "MSCRE.M10 AS MX10, "
                StrSql = StrSql + "(MSCRE.M1+MSCRE.M2+MSCRE.M3+MSCRE.M4+MSCRE.M5+MSCRE.M6+MSCRE.M7+MSCRE.M8+MSCRE.M9+MSCRE.M10)MXT, "
                StrSql = StrSql + "TSCRE.M1 AS TOT1, "
                StrSql = StrSql + "TSCRE.M2 AS TOT2, "
                StrSql = StrSql + "TSCRE.M3 AS TOT3, "
                StrSql = StrSql + "TSCRE.M4 AS TOT4, "
                StrSql = StrSql + "TSCRE.M5 AS TOT5, "
                StrSql = StrSql + "TSCRE.M6 AS TOT6, "
                StrSql = StrSql + "TSCRE.M7 AS TOT7, "
                StrSql = StrSql + "TSCRE.M8 AS TOT8, "
                StrSql = StrSql + "TSCRE.M9 AS TOT9, "
                StrSql = StrSql + "TSCRE.M10 AS TOT10, "
                StrSql = StrSql + "(TSCRE.M1+TSCRE.M2+TSCRE.M3+TSCRE.M4+TSCRE.M5+TSCRE.M6+TSCRE.M7+TSCRE.M8+TSCRE.M9+TSCRE.M10)TOTT, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM RAWSCORE RSCRE "
                StrSql = StrSql + "INNER JOIN MAXSCORE MSCRE "
                StrSql = StrSql + "ON MSCRE.CASEID = RSCRE.CASEID "
                StrSql = StrSql + "INNER JOIN TOTALSCORE TSCRE "
                StrSql = StrSql + "ON TSCRE.CASEID = RSCRE.CASEID "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID=RSCRE.CASEID "
                StrSql = StrSql + "WHERE RSCRE.CASEID IN(" + CaseIds + ") ORDER BY RSCRE.CASEID "


                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function EndOfLifeRes(ByVal CaseIds As String, ByVal Username As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  "
                StrSql = StrSql + "MATB.CASEID, "
                StrSql = StrSql + "( CASE WHEN MATB.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = MATB.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT ( PERMISSIONSCASES.CASEDE1|| ' ' ||PERMISSIONSCASES.CASEDE2) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = MATB.CASEID "
                StrSql = StrSql + "AND PERMISSIONSCASES.USERNAME ='" + Username + "' "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDES, "
                StrSql = StrSql + "MATB.M1 AS MATB1, "
                StrSql = StrSql + "MATB.M2 AS MATB2, "
                StrSql = StrSql + "MATB.M3 AS MATB3, "
                StrSql = StrSql + "MATB.M4 AS MATB4, "
                StrSql = StrSql + "MATB.M5 AS MATB5, "
                StrSql = StrSql + "MATB.M6 AS MATB6, "
                StrSql = StrSql + "MATB.M7 AS MATB7, "
                StrSql = StrSql + "MATB.M8 AS MATB8, "
                StrSql = StrSql + "MATB.M9 AS MATB9, "
                StrSql = StrSql + "MALOUT.MR1 AS MALRE1, "
                StrSql = StrSql + "MALOUT.MR2 AS MALRE2, "
                StrSql = StrSql + "MALOUT.MR3 AS MALRE3, "
                StrSql = StrSql + "MALOUT.MR4 AS MALRE4, "
                StrSql = StrSql + "MALOUT.MR5 AS MALRE5, "
                StrSql = StrSql + "MALOUT.MR6 AS MALRE6, "
                StrSql = StrSql + "MALOUT.MR7 AS MALRE7, "
                StrSql = StrSql + "MALOUT.MR8 AS MALRE8, "
                StrSql = StrSql + "MALOUT.MR9 AS MALRE9, "
                StrSql = StrSql + "MALOUT.MI1 AS MALIN1, "
                StrSql = StrSql + "MALOUT.MI2 AS MALIN2, "
                StrSql = StrSql + "MALOUT.MI3 AS MALIN3, "
                StrSql = StrSql + "MALOUT.MI4 AS MALIN4, "
                StrSql = StrSql + "MALOUT.MI5 AS MALIN5, "
                StrSql = StrSql + "MALOUT.MI6 AS MALIN6, "
                StrSql = StrSql + "MALOUT.MI7 AS MALIN7, "
                StrSql = StrSql + "MALOUT.MI8 AS MALIN8, "
                StrSql = StrSql + "MALOUT.MI9 AS MALIN9, "
                StrSql = StrSql + "MALOUT.MC1 AS MALCM1, "
                StrSql = StrSql + "MALOUT.MC2 AS MALCM2, "
                StrSql = StrSql + "MALOUT.MC3 AS MALCM3, "
                StrSql = StrSql + "MALOUT.MC4 AS MALCM4, "
                StrSql = StrSql + "MALOUT.MC5 AS MALCM5, "
                StrSql = StrSql + "MALOUT.MC6 AS MALCM6, "
                StrSql = StrSql + "MALOUT.MC7 AS MALCM7, "
                StrSql = StrSql + "MALOUT.MC8 AS MALCM8, "
                StrSql = StrSql + "MALOUT.MC9 AS MALCM9, "
                StrSql = StrSql + "MALOUT.ML1 AS MALLF1, "
                StrSql = StrSql + "MALOUT.ML2 AS MALLF2, "
                StrSql = StrSql + "MALOUT.ML3 AS MALLF3, "
                StrSql = StrSql + "MALOUT.ML4 AS MALLF4, "
                StrSql = StrSql + "MALOUT.ML5 AS MALLF5, "
                StrSql = StrSql + "MALOUT.ML6 AS MALLF6, "
                StrSql = StrSql + "MALOUT.ML7 AS MALLF7, "
                StrSql = StrSql + "MALOUT.ML8 AS MALLF8, "
                StrSql = StrSql + "MALOUT.ML9 AS MALLF9, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM MATERIALBALANCE MATB "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = MATB.CASEID "
                StrSql = StrSql + "INNER JOIN MATENDOFLIFEOUT MALOUT "
                StrSql = StrSql + "ON MALOUT.CASEID = MATB.CASEID "
                StrSql = StrSql + "WHERE MATB.CASEID IN(" + CaseIds + ") ORDER BY MATB.CASEID "


                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function
#End Region

#Region "Graphical Results"

        Public Function GetChartErgyRes(ByVal CaseIds() As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim strCaseId As String = String.Empty
            Dim i As Integer
            Try
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                For i = 0 To CaseIds.Length - 1
                    If i = 0 Then
                        strCaseId = CaseIds(i)
                    Else
                        strCaseId = strCaseId + "," + CaseIds(i)
                    End If

                Next
                StrSql = "SELECT  DISTINCT  "
                StrSql = StrSql + "TOTAL.CASEID, "
                StrSql = StrSql + "( CASE WHEN TOTAL.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEID||':'||REPLACE(REPLACE((REPLACE(NVL(BASECASES.CASEDE1,''),')','}')),'(','{')||' '||REPLACE((REPLACE(NVL(BASECASES.CASEDE2,''),')','}')),'(','{'),';',':') )  "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT (PERMISSIONSCASES.CASEID||':'||REPLACE(REPLACE((REPLACE(NVL(PERMISSIONSCASES.CASEDE1,''),')','}')),'(','{') || ' ' || REPLACE((REPLACE(NVL(PERMISSIONSCASES.CASEDE2,''),')','}')),'(','{'),';',':') )  "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDE, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "RESULTSPL.FINVOLMSI,"
                StrSql = StrSql + "RESULTSPL.FINVOLMUNITS,"
                StrSql = StrSql + "RESULTSPL.VOLUME, "
                StrSql = StrSql + "RMERGY, "
                StrSql = StrSql + "RMPACKERGY, "
                StrSql = StrSql + "RMANDPACKTRNSPTERGY, "
                StrSql = StrSql + "PROCERGY, "
                StrSql = StrSql + "DPPACKERGY, "
                StrSql = StrSql + "DPTRNSPTERGY, "
                StrSql = StrSql + "TRSPTTOCUS, "
                StrSql = StrSql + "(RMERGY+RMPACKERGY+DPPACKERGY)PURMATERIALERGY, "
                StrSql = StrSql + "(RMANDPACKTRNSPTERGY+DPTRNSPTERGY+TRSPTTOCUS)TRNSPTERGY, "
                StrSql = StrSql + "(RMERGY+RMPACKERGY+RMANDPACKTRNSPTERGY+PROCERGY+DPPACKERGY+DPTRNSPTERGY+TRSPTTOCUS)TOTALENERGY "
                StrSql = StrSql + "FROM TOTAL "
                StrSql = StrSql + "INNER JOIN RESULTSPL "
                StrSql = StrSql + "ON RESULTSPL.CASEID = TOTAL.CASEID "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = TOTAL.CASEID "
                StrSql = StrSql + "WHERE TOTAL.CASEID IN (" + strCaseId + ") "
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
                Return Dts
            Catch ex As Exception
                Throw New Exception("S1GetData:GetChartErgyRes:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function

        Public Function GetChartGhgRes(ByVal CaseIds() As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim strCaseId As String = String.Empty
            Dim i As Integer
            Try
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                For i = 0 To CaseIds.Length - 1
                    If i = 0 Then
                        strCaseId = CaseIds(i)
                    Else
                        strCaseId = strCaseId + "," + CaseIds(i)
                    End If

                Next
                StrSql = "SELECT  DISTINCT  "
                StrSql = StrSql + "TOTAL.CASEID, "
                StrSql = StrSql + "( CASE WHEN TOTAL.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEID||':'||REPLACE(REPLACE((REPLACE(NVL(BASECASES.CASEDE1,''),')','}')),'(','{')||' '||REPLACE((REPLACE(NVL(BASECASES.CASEDE2,''),')','}')),'(','{'),';',':') )  "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT (PERMISSIONSCASES.CASEID||':'||REPLACE(REPLACE((REPLACE(NVL(PERMISSIONSCASES.CASEDE1,''),')','}')),'(','{') || ' ' || REPLACE((REPLACE(NVL(PERMISSIONSCASES.CASEDE2,''),')','}')),'(','{'),';',':') )  "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDE, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "RESULTSPL.FINVOLMSI,"
                StrSql = StrSql + "RESULTSPL.FINVOLMUNITS,"
                StrSql = StrSql + "RESULTSPL.VOLUME, "
                StrSql = StrSql + "RMGRNHUSGAS, "
                StrSql = StrSql + "RMPACKGRNHUSGAS, "
                StrSql = StrSql + "RMANDPACKTRNSPTGRNHUSGAS, "
                StrSql = StrSql + "PROCGRNHUSGAS, "
                StrSql = StrSql + "DPPACKGRNHUSGAS, "
                StrSql = StrSql + "DPTRNSPTGRNHUSGAS, "
                StrSql = StrSql + "TRSPTTOCUSGRNHUSGAS, "
                StrSql = StrSql + "(RMGRNHUSGAS+RMPACKGRNHUSGAS+DPPACKGRNHUSGAS)PURMATERIALGRNHUSGAS, "
                StrSql = StrSql + "(RMANDPACKTRNSPTGRNHUSGAS+DPTRNSPTGRNHUSGAS+TRSPTTOCUSGRNHUSGAS)TRNSPTGRNHUSGAS, "
                StrSql = StrSql + "(RMGRNHUSGAS+RMPACKGRNHUSGAS+RMANDPACKTRNSPTGRNHUSGAS+PROCGRNHUSGAS+DPPACKGRNHUSGAS+DPTRNSPTGRNHUSGAS+TRSPTTOCUSGRNHUSGAS)TOTALENGRNHUSGAS "
                StrSql = StrSql + "FROM TOTAL "
                StrSql = StrSql + "INNER JOIN RESULTSPL "
                StrSql = StrSql + "ON RESULTSPL.CASEID = TOTAL.CASEID "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = TOTAL.CASEID "
                StrSql = StrSql + "WHERE TOTAL.CASEID IN (" + strCaseId + ") "
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
                Return Dts
            Catch ex As Exception
                Throw New Exception("S1GetData:GetChartGhgRes:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function

        Public Function GetChartWaterRes(ByVal CaseIds() As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim strCaseId As String = String.Empty
            Dim i As Integer
            Try
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                For i = 0 To CaseIds.Length - 1
                    If i = 0 Then
                        strCaseId = CaseIds(i)
                    Else
                        strCaseId = strCaseId + "," + CaseIds(i)
                    End If

                Next
                StrSql = "SELECT  DISTINCT  "
                StrSql = StrSql + "TOTAL.CASEID, "
                StrSql = StrSql + "( CASE WHEN TOTAL.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEID||':'||REPLACE(REPLACE((REPLACE(NVL(BASECASES.CASEDE1,''),')','}')),'(','{')||' '||REPLACE((REPLACE(NVL(BASECASES.CASEDE2,''),')','}')),'(','{'),';',':') )  "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT (PERMISSIONSCASES.CASEID||':'||REPLACE(REPLACE((REPLACE(NVL(PERMISSIONSCASES.CASEDE1,''),')','}')),'(','{') || ' ' || REPLACE((REPLACE(NVL(PERMISSIONSCASES.CASEDE2,''),')','}')),'(','{'),';',':') )  "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDE, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "RESULTSPL.FINVOLMSI,"
                StrSql = StrSql + "RESULTSPL.FINVOLMUNITS,"
                StrSql = StrSql + "RESULTSPL.VOLUME, "
                StrSql = StrSql + "RMWATER, "
                StrSql = StrSql + "RMPACKWATER, "
                StrSql = StrSql + "RMANDPACKTRNSPTWATER, "
                StrSql = StrSql + "PROCWATER, "
                StrSql = StrSql + "DPPACKWATER, "
                StrSql = StrSql + "DPTRNSPTWATER, "
                StrSql = StrSql + "TRSPTTOCUSWATER, "
                StrSql = StrSql + "(RMWATER+RMPACKWATER+DPPACKWATER)PURMATERIALWATER, "
                StrSql = StrSql + "(RMANDPACKTRNSPTWATER+DPTRNSPTWATER+TRSPTTOCUSWATER)TRNSPTWATER, "
                StrSql = StrSql + "(RMWATER+RMPACKWATER+RMANDPACKTRNSPTWATER+PROCWATER+DPPACKWATER+DPTRNSPTWATER+TRSPTTOCUSWATER)TOTALENWATER "
                StrSql = StrSql + "FROM TOTAL "
                StrSql = StrSql + "INNER JOIN RESULTSPL "
                StrSql = StrSql + "ON RESULTSPL.CASEID = TOTAL.CASEID "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = TOTAL.CASEID "
                StrSql = StrSql + "WHERE TOTAL.CASEID IN (" + strCaseId + ") "
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
                Return Dts
            Catch ex As Exception
                Throw New Exception("S1GetData:GetChartWaterRes:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function



        Public Function ErgyCharts(ByVal CaseIds As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()

                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  DISTINCT  "
                StrSql = StrSql + "TOTAL.CASEID, "
                StrSql = StrSql + "( CASE WHEN TOTAL.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEID||':'||BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT (PERMISSIONSCASES.CASEID||':'||NVL(PERMISSIONSCASES.CASEDE1,'') || ' ' || NVL(PERMISSIONSCASES.CASEDE2,'') ) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDE, "
                StrSql = StrSql + "RESULTSPL.FINVOLMSI,"
                StrSql = StrSql + "RESULTSPL.FINVOLMUNITS,"
                StrSql = StrSql + "RESULTSPL.VOLUME, "
                StrSql = StrSql + "RMERGY, "
                StrSql = StrSql + "RMPACKERGY, "
                StrSql = StrSql + "RMANDPACKTRNSPTERGY, "
                StrSql = StrSql + "PROCERGY, "
                StrSql = StrSql + "DPPACKERGY, "
                StrSql = StrSql + "DPTRNSPTERGY, "
                StrSql = StrSql + "TRSPTTOCUS, "
                StrSql = StrSql + "(RMERGY+RMPACKERGY+DPPACKERGY)PURMATERIALERGY, "
                StrSql = StrSql + "(RMANDPACKTRNSPTERGY+DPTRNSPTERGY+TRSPTTOCUS)TRNSPTERGY, "
                StrSql = StrSql + "(RMERGY+RMPACKERGY+RMANDPACKTRNSPTERGY+PROCERGY+DPPACKERGY+DPTRNSPTERGY+TRSPTTOCUS)TOTALENERGY "
                StrSql = StrSql + "FROM TOTAL "
                StrSql = StrSql + "INNER JOIN RESULTSPL "
                StrSql = StrSql + "ON RESULTSPL.CASEID = TOTAL.CASEID "
                StrSql = StrSql + "WHERE TOTAL.CASEID IN (" + CaseIds + ") "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function GhgCharts(ByVal CaseIds As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()

                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  DISTINCT  "
                StrSql = StrSql + "TOTAL.CASEID, "
                StrSql = StrSql + "( CASE WHEN TOTAL.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEID||':'||BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT (PERMISSIONSCASES.CASEID||':'||NVL(PERMISSIONSCASES.CASEDE1,'') || ' ' || NVL(PERMISSIONSCASES.CASEDE2,'') ) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDE, "
                StrSql = StrSql + "RESULTSPL.FINVOLMSI,"
                StrSql = StrSql + "RESULTSPL.FINVOLMUNITS,"
                StrSql = StrSql + "RESULTSPL.VOLUME, "
                StrSql = StrSql + "RMGRNHUSGAS, "
                StrSql = StrSql + "RMPACKGRNHUSGAS, "
                StrSql = StrSql + "RMANDPACKTRNSPTGRNHUSGAS, "
                StrSql = StrSql + "PROCGRNHUSGAS, "
                StrSql = StrSql + "DPPACKGRNHUSGAS, "
                StrSql = StrSql + "DPTRNSPTGRNHUSGAS, "
                StrSql = StrSql + "TRSPTTOCUSGRNHUSGAS, "
                StrSql = StrSql + "(RMGRNHUSGAS+RMPACKGRNHUSGAS+DPPACKGRNHUSGAS)PURMATERIALGRNHUSGAS, "
                StrSql = StrSql + "(RMANDPACKTRNSPTGRNHUSGAS+DPTRNSPTGRNHUSGAS+TRSPTTOCUSGRNHUSGAS)TRNSPTGRNHUSGAS, "
                StrSql = StrSql + "(RMGRNHUSGAS+RMPACKGRNHUSGAS+RMANDPACKTRNSPTGRNHUSGAS+PROCGRNHUSGAS+DPPACKGRNHUSGAS+DPTRNSPTGRNHUSGAS+TRSPTTOCUSGRNHUSGAS)TOTALENGRNHUSGAS "
                StrSql = StrSql + "FROM TOTAL "
                StrSql = StrSql + "INNER JOIN RESULTSPL "
                StrSql = StrSql + "ON RESULTSPL.CASEID = TOTAL.CASEID "
                StrSql = StrSql + "WHERE TOTAL.CASEID IN (" + CaseIds + ") "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function WaterCharts(ByVal CaseIds As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()

                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
                StrSql = "SELECT  DISTINCT  "
                StrSql = StrSql + "TOTAL.CASEID, "
                StrSql = StrSql + "( CASE WHEN TOTAL.CASEID <= 1000 THEN "
                StrSql = StrSql + "( SELECT (BASECASES.CASEID||':'||BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSql = StrSql + "FROM BASECASES "
                StrSql = StrSql + "WHERE  BASECASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") ELSE "
                StrSql = StrSql + "( SELECT DISTINCT (PERMISSIONSCASES.CASEID||':'||NVL(PERMISSIONSCASES.CASEDE1,'') || ' ' || NVL(PERMISSIONSCASES.CASEDE2,'') ) "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + "WHERE  PERMISSIONSCASES.CASEID = TOTAL.CASEID "
                StrSql = StrSql + ") "
                StrSql = StrSql + "END  ) AS CASEDE, "
                StrSql = StrSql + "RESULTSPL.FINVOLMSI,"
                StrSql = StrSql + "RESULTSPL.FINVOLMUNITS,"
                StrSql = StrSql + "RESULTSPL.VOLUME, "
                StrSql = StrSql + "RMWATER, "
                StrSql = StrSql + "RMPACKWATER, "
                StrSql = StrSql + "RMANDPACKTRNSPTWATER, "
                StrSql = StrSql + "PROCWATER, "
                StrSql = StrSql + "DPPACKWATER, "
                StrSql = StrSql + "DPTRNSPTWATER, "
                StrSql = StrSql + "TRSPTTOCUSWATER, "
                StrSql = StrSql + "(RMWATER+RMPACKWATER+DPPACKWATER)PURMATERIALWATER, "
                StrSql = StrSql + "(RMANDPACKTRNSPTWATER+DPTRNSPTWATER+TRSPTTOCUSWATER)TRNSPTWATER, "
                StrSql = StrSql + "(RMWATER+RMPACKWATER+RMANDPACKTRNSPTWATER+PROCWATER+DPPACKWATER+DPTRNSPTWATER+TRSPTTOCUSWATER)TOTALENWATER "
                StrSql = StrSql + "FROM TOTAL "
                StrSql = StrSql + "INNER JOIN RESULTSPL "
                StrSql = StrSql + "ON RESULTSPL.CASEID = TOTAL.CASEID "
                StrSql = StrSql + "WHERE TOTAL.CASEID IN (" + CaseIds + ") "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function ChartPref(ByVal UserName As String) As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()

                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")

                StrSql = "SELECT  USERNAME,  "
                StrSql = StrSql + "UNITS, "
                StrSql = StrSql + "CURRENCY, "
                StrSql = StrSql + "CURR, "
                StrSql = StrSql + "CONVERSIONFACTOR, "
                StrSql = StrSql + "TITLE1, "
                StrSql = StrSql + "TITLE2, "
                StrSql = StrSql + "TITLE3, "
                StrSql = StrSql + "TITLE4, "
                StrSql = StrSql + "TITLE5, "
                StrSql = StrSql + "TITLE6, "
                StrSql = StrSql + "CONVAREA, "
                StrSql = StrSql + "TITLE7, "
                StrSql = StrSql + "TITLE8, "
                StrSql = StrSql + "TITLE9, "
                StrSql = StrSql + "TITLE10, "
                StrSql = StrSql + "TITLE11, "
                StrSql = StrSql + "TITLE12, "
                StrSql = StrSql + "CONVWT, "
                StrSql = StrSql + "CONVAREA2, "
                StrSql = StrSql + "CONVTHICK, "
                StrSql = StrSql + "CONVTHICK2, "
                StrSql = StrSql + "CONVTHICK3 "
                StrSql = StrSql + "FROM CHARTPREFERENCES "
                StrSql = StrSql + "WHERE USERNAME='" + UserName + "' "


                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function

        Public Function ChartSetting() As DataSet
            Dim Dts As New DataSet
            Try

                Dim StrSql As String = ""
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString1 As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
                StrSql = "SELECT EXTSERVERADD, INTCOMPORTADD FROM CHARTSETTING "
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString1)
            Catch ex As Exception
                Throw
            End Try
            Return Dts
        End Function


#End Region

#Region "Global Manager"
        Public Function GetAllPermissionCases(ByVal AssumId As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim strCaseId As String = String.Empty
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            Try
                StrSql = "SELECT DISTINCT(P.CASEID) FROM PERMISSIONSCASES P  "
                StrSql = StrSql + "WHERE P.CASEID IN "
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM BASECASES WHERE CASEID=CASE1)>0 THEN 0 ELSE NVL(CASE1,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM BASECASES WHERE CASEID=CASE2)>0 THEN 0 ELSE NVL(CASE2,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM BASECASES WHERE CASEID=CASE3)>0 THEN 0 ELSE NVL(CASE3,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM BASECASES WHERE CASEID=CASE4)>0 THEN 0 ELSE NVL(CASE4,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT "
                StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM BASECASES WHERE CASEID=CASE5)>0 THEN 0 ELSE NVL(CASE5,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT   (CASE WHEN(SELECT CASEID FROM BASECASES WHERE CASEID=CASE6)>0 THEN 0 ELSE NVL(CASE6,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT   (CASE WHEN(SELECT CASEID FROM BASECASES WHERE CASEID=CASE7)>0 THEN 0 ELSE NVL(CASE7,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT   (CASE WHEN(SELECT CASEID FROM BASECASES WHERE CASEID=CASE8)>0 THEN 0 ELSE NVL(CASE8,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT  (CASE WHEN(SELECT CASEID FROM BASECASES WHERE CASEID=CASE9)>0 THEN 0 ELSE NVL(CASE9,0) END ) "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT  (CASE WHEN(SELECT CASEID FROM BASECASES WHERE CASEID=CASE10)>0 THEN 0 ELSE NVL(CASE10,0) END )  AS C "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                StrSql = StrSql + ")"
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw New Exception("E3GetCases:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetAllPermissionCasesS3(ByVal AssumId As String, ByVal licAdmin As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim strCaseId As String = String.Empty
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            Try
                If licAdmin = "Y" Then
                    StrSql = "SELECT DISTINCT(P.CASEID) FROM PERMISSIONSCASES P  "
                    StrSql = StrSql + "WHERE P.CASEID IN "
                    StrSql = StrSql + "( "
                    StrSql = StrSql + "SELECT NVL(CASE1,0) FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT NVL(CASE2,0) FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT NVL(CASE3,0) FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT NVL(CASE4,0) FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT NVL(CASE5,0) FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT NVL(CASE6,0) FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT NVL(CASE7,0) FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT NVL(CASE8,0) FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT NVL(CASE9,0) FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT NVL(CASE10,0) FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + ")"
                Else
                    StrSql = "SELECT DISTINCT(P.CASEID) FROM PERMISSIONSCASES P  "
                    StrSql = StrSql + "WHERE P.CASEID IN "
                    StrSql = StrSql + "( "
                    StrSql = StrSql + "SELECT "
                    StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND CASEID=CASE1)>0 THEN 0 ELSE NVL(CASE1,0) END ) "
                    StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT "
                    StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE2)>0 THEN 0 ELSE NVL(CASE2,0) END ) "
                    StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT "
                    StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE3)>0 THEN 0 ELSE NVL(CASE3,0) END ) "
                    StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT "
                    StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE4)>0 THEN 0 ELSE NVL(CASE4,0) END ) "
                    StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT "
                    StrSql = StrSql + "(CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE5)>0 THEN 0 ELSE NVL(CASE5,0) END ) "
                    StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT   (CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE6)>0 THEN 0 ELSE NVL(CASE6,0) END ) "
                    StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT   (CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE7)>0 THEN 0 ELSE NVL(CASE7,0) END ) "
                    StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID=" + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT   (CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE8)>0 THEN 0 ELSE NVL(CASE8,0) END ) "
                    StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT  (CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE9)>0 THEN 0 ELSE NVL(CASE9,0) END ) "
                    StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                    StrSql = StrSql + "UNION "
                    StrSql = StrSql + "SELECT  (CASE WHEN(SELECT CASEID FROM PERMISSIONSCASES INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID  WHERE PERMISSIONSCASES.STATUSID=3 AND  CASEID=CASE10)>0 THEN 0 ELSE NVL(CASE10,0) END )  AS C "
                    StrSql = StrSql + "FROM ECON3.ASSUMPTIONS WHERE ASSUMPTIONID= " + AssumId
                    StrSql = StrSql + ")"
                End If
                
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw New Exception("E3GetAllPermissionCasesE3:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function CheckUser(ByVal CaseId As String, ByVal UserName As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim strCaseId As String = String.Empty
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            Try
                StrSql = "SELECT  "
                StrSql = StrSql + "USERNAME "
                StrSql = StrSql + "FROM PERMISSIONSCASES "
                StrSql = StrSql + " WHERE CASEID= " + CaseId
                StrSql = StrSql + " AND USERNAME='" + UserName + "'"
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw New Exception("E3CheckUser:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetDelCases(ByVal CaseID As String, ByVal UserName As String) As String
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            Try
                StrSql = "SELECT CASEID FROM PERMISSIONSCASES WHERE CASEID= " + CaseID + " AND UPPER(USERNAME)='" + UserName.ToUpper() + "' "
                StrSql = StrSql + "UNION "
                StrSql = StrSql + "SELECT CASEID FROM BASECASES WHERE CASEID= " + CaseID

                Dim Cs As New DataTable()
                Cs = odbUtil.FillDataTable(StrSql, MyConnectionString)

                If Cs.Rows.Count = 0 Then
                    Return CaseID
                End If
            Catch ex As Exception
                Throw New Exception("E3CheckUser:" + ex.Message.ToString())
            End Try
            Return ""
        End Function

        Public Function GetSisterCases(ByVal CaseID As String) As Boolean
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            Try
                StrSql = "SELECT CASEID FROM PERMISSIONSCASES WHERE CASEID= " + CaseID + " AND STATUSID=5 "
                Dim Cs As New DataTable()
                Cs = odbUtil.FillDataTable(StrSql, MyConnectionString)

                If Cs.Rows.Count = 0 Then
                    Return False
                Else
                    Return True
                End If
            Catch ex As Exception
                Throw New Exception("GetSisterCases:" + ex.Message.ToString())
            End Try
            Return ""
        End Function

        Public Function GetDelCasesS3(ByVal CaseID As String, ByVal UserName As String, ByVal LiceAdmin As String) As String
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            Try
                If LiceAdmin = "Y" Then
                    StrSql = "SELECT CASEID FROM PERMISSIONSCASES WHERE CASEID= " + CaseID + " AND upper(username)='" + UserName.ToUpper() + "'"
                Else
                    StrSql = "SELECT CASEID FROM ("
                    StrSql = StrSql + "(SELECT CASEID,CASEDE1,('CASE:'||CASEID||' - '|| CASEDE1||' ' || CASEDE2) AS CASEDE FROM PERMISSIONSCASES WHERE username='" + UserName + "' ) "
                    StrSql = StrSql + "UNION (SELECT CASEID,CASEDE1,('CASE:'||CASEID||' - '|| CASEDE1||' ' || CASEDE2) AS CASEDE  FROM PERMISSIONSCASES  INNER JOIN ECON.USERS ON UPPER(USERS.USERNAME)=UPPER(PERMISSIONSCASES.USERNAME) "
                    StrSql = StrSql + "INNER JOIN ECON.MODSTATUS MS ON MS.STATUSID=PERMISSIONSCASES.STATUSID "
                    StrSql = StrSql + "WHERE USERS.LICENSEID IN (SELECT USERS.LICENSEID FROM ECON.USERS WHERE UPPER(USERNAME)='" + UserName.ToUpper() + "') "
                    StrSql = StrSql + "AND PERMISSIONSCASES.STATUSID=3) "
                    StrSql = StrSql + ")  WHERE CASEID= " + CaseID + " "
                End If
                Dim Cs As New DataTable()
                Cs = odbUtil.FillDataTable(StrSql, MyConnectionString)

                If Cs.Rows.Count = 0 Then
                    Return CaseID
                End If
            Catch ex As Exception
                Throw New Exception("E3CheckUser:" + ex.Message.ToString())
            End Try
            Return ""
        End Function
        Public Function GetAssumptionCaseId(ByVal AssumptionId As String) As String
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim strCaseid As String = String.Empty
            Dim Dts As New DataSet()
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
            Try
                StrSql = "SELECT (CASE1 || ','|| CASE2 || ','|| CASE3 || ','|| CASE4  "
                StrSql = StrSql + "|| ','|| CASE5 || ','|| CASE6 || ','|| CASE7 || ','|| CASE8 "
                StrSql = StrSql + "|| ','|| CASE9 || ','|| CASE10) CASEID "
                StrSql = StrSql + "FROM ECON3.ASSUMPTIONS "
                StrSql = StrSql + "WHERE ASSUMPTIONID= " + AssumptionId.ToString()
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString)
                strCaseid = Dts.Tables(0).Rows(0).Item("CASEID").ToString()
            Catch ex As Exception
                Throw New Exception("GetAssumptionCaseId:" + ex.Message.ToString())
            End Try
            Return strCaseid
        End Function
        Public Function GetCasesByCaseID(ByVal CaseId As String) As DataSet
            Dim Dts As New DataSet
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")

                Dim StrSql As String = "SELECT CASEID FROM PERMISSIONSCASES WHERE CASEID=" + CaseId + " "
                StrSql = StrSql + "UNION SELECT CASEID FROM BASECASES WHERE CASEID=" + CaseId
                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function
#End Region

#Region "User Category"
        Public Function GetCategorySet(ByVal CatSetName As String, ByVal UserId As String, ByVal Pagename As String) As DataTable
            Dim Dts As New DataTable()
            Dim strsql As String = String.Empty
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                strsql = "SELECT CATEGORYSETID, CATEGORYSETNAME,PAGENAME FROM  "
                strsql = strsql + "CATEGORYSET "
                strsql = strsql + "WHERE USERID= " + UserId + " "
                If CatSetName <> "" Then
                    strsql = strsql + "AND UPPER(CATEGORYSETNAME)='" + CatSetName.ToUpper() + "' "
                End If
                If Pagename <> "" Then
                    strsql = strsql + "AND UPPER(PAGENAME)='" + Pagename.ToUpper() + "' "
                End If
                strsql = strsql + "ORDER BY UPPER(CATEGORYSETNAME)"
                Dts = odbUtil.FillDataTable(strsql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function
        Public Function GetCategoryBySet(ByVal CatSetId As String, ByVal CatName As String) As DataTable
            Dim Dts As New DataTable()
            Dim strsql As String = String.Empty
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                strsql = "SELECT * FROM  "
                strsql = strsql + "CATEGORY "
                strsql = strsql + "WHERE CATEGORYSETID=" + CatSetId + " "
                If CatName <> "" Then
                    strsql = strsql + "AND UPPER(CATEGORYNAME)= '" + CatName.ToUpper() + "' "
                End If
                strsql = strsql + "ORDER BY CATEGORYNAME ASC"
                Dts = odbUtil.FillDataTable(strsql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function
        Public Function GetCategoryItemBycategory(ByVal category As String) As DataSet
            Dim Dts As New DataSet()
            Dim strsql As String = String.Empty
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                strsql = "SELECT ITEMNAME  "
                strsql = strsql + "FROM CATEGORYITEM "
                strsql = strsql + "WHERE CATEGORYID=" + category
                Dts = odbUtil.FillDataSet(strsql, MyConnectionString)
                Return Dts

            Catch ex As Exception
                Throw
                Return Dts
            End Try

        End Function
        Public Function GetCategoryItems(ByVal PageName As String) As DataSet
            Dim Dts As New DataSet()
            Dim strsql As String = String.Empty
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                If PageName = "ERGY" Then
                    strsql = "SELECT  'Raw Materials' DES,'RMERGY' CODE  FROM DUAL  "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Raw Materials Packaging' DES,'RMPACKERGY' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'RM & Pack Transport' DES,'RMANDPACKTRNSPTERGY' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Process' DES,'PROCERGY' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Distribution Packaging' DES,'DPPACKERGY' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'DP Transport' DES,'DPTRNSPTERGY' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Transport to Customer' DES,'TRSPTTOCUS' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Purchased Materials' DES,'PURMATERIALERGY' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Transportation' DES,'TRNSPTERGY' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Total Energy' DES,'TOTALENERGY' CODE  FROM DUAL "
                ElseIf PageName = "GHG" Then
                    strsql = "SELECT  'Raw Materials' DES,'RMGRNHUSGAS' CODE  FROM DUAL  "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Raw Materials Packaging' DES,'RMPACKGRNHUSGAS' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'RM & Pack Transport' DES,'RMANDPACKTRNSPTGRNHUSGAS' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Process' DES,'PROCGRNHUSGAS' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Distribution Packaging' DES,'DPPACKGRNHUSGAS' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'DP Transport' DES,'DPTRNSPTGRNHUSGAS' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Transport to Customer' DES,'TRSPTTOCUSGRNHUSGAS' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Purchased Materials' DES,'PURMATERIALGRNHUSGAS' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Transportation' DES,'TRNSPTGRNHUSGAS' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Total GHG' DES,'TOTALENGRNHUSGAS' CODE  FROM DUAL "
                ElseIf PageName = "WATER" Then
                    strsql = "SELECT  'Raw Materials' DES,'RMWATER' CODE  FROM DUAL  "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Raw Materials Packaging' DES,'RMPACKWATER' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'RM & Pack Transport' DES,'RMANDPACKTRNSPTWATER' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Process' DES,'PROCWATER' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Distribution Packaging' DES,'DPPACKWATER' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'DP Transport' DES,'DPTRNSPTWATER' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Transport to Customer' DES,'TRSPTTOCUSWATER' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Purchased Materials' DES,'PURMATERIALWATER' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Transportation' DES,'TRNSPTWATER' CODE  FROM DUAL "
                    strsql = strsql + "UNION ALL "
                    strsql = strsql + "SELECT 'Total Water' DES,'TOTALENWATER' CODE  FROM DUAL "
                End If


                Dts = odbUtil.FillDataSet(strsql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function
        Public Function GetItemsByCat(ByVal CategoryId As String) As DataSet
            Dim Dts As New DataSet()
            Dim strsql As String = String.Empty
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                strsql = "SELECT CAT.CATEGORYID,  "
                strsql = strsql + "ITEMNAME "
                strsql = strsql + "FROM CATEGORYITEM "
                strsql = strsql + "INNER JOIN CATEGORY CAT "
                strsql = strsql + "ON CAT.CATEGORYID=CATEGORYITEM.CATEGORYID "
                strsql = strsql + "INNER JOIN CATEGORYSET "
                strsql = strsql + "ON CATEGORYSET.CATEGORYSETID=CAT.CATEGORYSETID "
                strsql = strsql + "WHERE CAT.CATEGORYID=" + CategoryId
                Dts = odbUtil.FillDataSet(strsql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function
        Public Function GetCategorySetByID(ByVal CatSetID As String) As DataTable
            Dim Dts As New DataTable()
            Dim strsql As String = String.Empty
            Try
                Dim odbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                strsql = "SELECT CATEGORYSETID, CATEGORYSETNAME,PAGENAME FROM  "
                strsql = strsql + "CATEGORYSET "
                strsql = strsql + "WHERE CATEGORYSETID= " + CatSetID + " "
                Dts = odbUtil.FillDataTable(strsql, MyConnectionString)
                Return Dts
            Catch ex As Exception
                Throw
                Return Dts
            End Try
        End Function
#End Region
#Region "2D Report"
        Public Function GetCasesBYUserName(ByVal userName As String, ByVal CASEDE1 As String, ByVal CASEDE2 As String) As DataSet
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet
            'RETURNS ALL THE BASECASES WITH PERMISSIONSCASES
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            Try
                strsql = "SELECT * FROM  "
                strsql = strsql + "( "
                strsql = strsql + "SELECT CASEID, (CASEDE1||'  '||CASEDE2)CASEDES,CASEDE1,CASEDE2,(CASEID||'. PACKAGE FORMAT= '||CASEDE1||' UNIQUE FEATURES= '||CASEDE2)CASEDE,CASEID ||':'|| CaseDE1  AS CASEDES1 "
                strsql = strsql + "FROM PERMISSIONSCASES  WHERE UPPER(USERNAME) ='" + userName.ToUpper() + "' "
                strsql = strsql + "UNION ALL "
                strsql = strsql + "SELECT CASEID, (CASEDE1||'  '||CASEDE2)CASEDES,CASEDE1,CASEDE2,(CASEID||'. PACKAGE FORMAT= '||CASEDE1||' UNIQUE FEATURES= '||CASEDE2)CASEDE,CASEID ||':'|| CaseDE1  AS CASEDES1 "
                strsql = strsql + "FROM BASECASES "
                strsql = strsql + ")A "
                strsql = strsql + "WHERE  NVL(UPPER(CASEDE1),'#') LIKE '%" + CASEDE1.ToUpper + "%'  AND NVL(UPPER(CASEDE2),'#') LIKE '%" + CASEDE2.ToUpper() + "%' "
                strsql = strsql + "ORDER BY  CASEID,CASEDE1 "

                ds = objdbUtil.FillDataSet(strsql, MyConnectionString)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function GetSeqReportId() As Integer
            Dim strsql As String
            Dim reportId As Integer
            Dim objdbUtil As New DBUtil()
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
            Try
                strsql = "SELECT SEQREPORTID.NEXTVAL  FROM DUAL  "
                reportId = objdbUtil.FillData(strsql, MyConnectionString)
                Return reportId
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function getPageCategory(ByVal parentId As String) As DataSet
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet
            Try
                strsql = "SELECT REPORTCATEGORYID,PARENTID,CATNAME  "
                strsql = strsql + " FROM REPORTCATEGORY "
                strsql = strsql + " WHERE NVL(PARENTID,-1)=" + parentId
                ds = objdbUtil.FillDataSet(strsql, Sustain3Connection)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function getColumnsByPageId(ByVal pageId As String) As DataSet
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet
            Try
                strsql = "SELECT REPORTCOLUMNSID,  "
                strsql = strsql + "COLNAME, "
                strsql = strsql + "COLDETAILS "
                strsql = strsql + "FROM REPORTCOLUMNS "
                strsql = strsql + "WHERE REPORTCATEGORYID LIKE '%" + pageId + "%'"
                ds = objdbUtil.FillDataSet(strsql, Sustain3Connection)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function getRowssByPageId(ByVal pageId As String) As DataSet
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet
            Try
                strsql = "SELECT REPORTROWSID,  "
                strsql = strsql + "ROWNAME, "
                strsql = strsql + "ROWSEQ "
                strsql = strsql + "FROM REPORTROWS "
                strsql = strsql + "WHERE REPORTCATEGORYID LIKE '%" + pageId + "%'"
                strsql = strsql + " ORDER BY ROWSEQ "
                ds = objdbUtil.FillDataSet(strsql, Sustain3Connection)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function GetReportsDetail(ByVal ReportId As String, ByVal UserId As String) As DataSet
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet
            Try
                strsql = "SELECT  "
                strsql = strsql + "UR.REPORTID,UR.REPORTNAME,RCAT.CATNAME,RC.COLNAME,RR.ROWNAME, "
                strsql = strsql + " CASE WHEN RCAT.CATNAME IS NULL THEN ' ' ELSE "
                strsql = strsql + "'PAGE :'||RCAT.CATNAME ||' ROW :'||RR.ROWNAME||' COLUMN :'|| RC.COLNAME END AS FILTERDES "
                strsql = strsql + "FROM USERREPORTS UR "
                strsql = strsql + "INNER JOIN USERREPORTFILTER URF "
                strsql = strsql + "ON UR.REPORTID=URF.REPORTID "
                strsql = strsql + "LEFT OUTER JOIN REPORTCATEGORY RCAT "
                strsql = strsql + "ON RCAT.REPORTCATEGORYID=URF.REPORTCATEGORYID "
                strsql = strsql + "LEFT OUTER JOIN REPORTCOLUMNS RC "
                strsql = strsql + "ON RC.REPORTCOLUMNSID=URF.REPORTCOLUMNSID "
                strsql = strsql + "LEFT OUTER JOIN REPORTROWS RR "
                strsql = strsql + "ON RR.REPORTROWSID=URF.REPORTROWSID "
                strsql = strsql + "WHERE UR.USERID=" + UserId
                strsql = strsql + "AND UR.REPORTID=CASE WHEN " + ReportId + "=-1 THEN UR.REPORTID ELSE " + ReportId + " END "

                ds = objdbUtil.FillDataSet(strsql, Sustain3Connection)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function GetReportsRowCount(ByVal ReportId As String) As Integer
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet
            Dim count As Integer
            Try
                strsql = "SELECT COUNT( DISTINCT (ROWNO))  "
                strsql = strsql + "FROM USERREPORTDETAILS "
                strsql = strsql + "WHERE REPORTID= " + ReportId
                count = objdbUtil.FillData(strsql, Sustain3Connection)
                Return count
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function GetReportsColCount(ByVal ReportId As String) As Integer
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet
            Dim count As Integer
            Try
                strsql = "SELECT COUNT( DISTINCT (COLNO))  "
                strsql = strsql + "FROM USERREPORTDETAILS "
                strsql = strsql + "WHERE REPORTID= " + ReportId
                count = objdbUtil.FillData(strsql, Sustain3Connection)
                Return count
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function GetReportsColNames(ByVal ReportId As String, ByVal ColNo As String) As DataSet
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet

            Try
                strsql = "SELECT USERREPORTCOLUMNSID,COLNAME,COLNO   "
                strsql = strsql + "FROM USERREPORTCOLUMNS "
                strsql = strsql + "WHERE REPORTID= " + ReportId
                strsql = strsql + "AND COLNO=CASE WHEN " + ColNo + "=-1 THEN COLNO ELSE " + ColNo + " END "

                ds = objdbUtil.FillDataSet(strsql, Sustain3Connection)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function GetReportsRowNames(ByVal ReportId As String, ByVal RowNo As String) As DataSet
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet

            Try
                strsql = "SELECT USERREPORTROWSID,ROWNAME,ROWNO   "
                strsql = strsql + "FROM USERREPORTROWS "
                strsql = strsql + "WHERE REPORTID= " + ReportId
                strsql = strsql + "AND ROWNO=CASE WHEN " + RowNo + "=-1 THEN ROWNO ELSE " + RowNo + " END "

                ds = objdbUtil.FillDataSet(strsql, Sustain3Connection)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try

        End Function
        Public Function GetReportsCases(ByVal ReportId As String) As DataSet
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet

            Try
                strsql = "SELECT REPORTDETAILSID,REPORTID,ROWNO,COLNO,CASEID   "
                strsql = strsql + "FROM USERREPORTDETAILS "
                strsql = strsql + "WHERE REPORTID= " + ReportId

                ds = objdbUtil.FillDataSet(strsql, Sustain3Connection)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try

        End Function
        Public Function CheckFirstCaseId(ByVal ReportId As String) As DataSet
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet

            Try
                StrSql = "SELECT CASEID  "
                strsql = strsql + "FROM "
                strsql = strsql + "USERREPORTDETAILS "
                strsql = strsql + "WHERE REPORTID=" + ReportId + " "
                strsql = strsql + "AND ROWNO=1 AND COLNO=1 "

                ds = objdbUtil.FillDataSet(strsql, Sustain3Connection)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try

        End Function
        Public Function GetReportFilter(ByVal ReportId As String) As DataSet
            Dim strsql As String
            Dim objdbUtil As New DBUtil()
            Dim ds As New DataSet

            Try
                strsql = "SELECT USERREPORTFILTERID,  "
                strsql = strsql + "URF.REPORTID, "
                strsql = strsql + "URF.REPORTCATEGORYID, "
                strsql = strsql + "RR.REPORTROWSID, "
                strsql = strsql + "RR.ROWNAME, "
                strsql = strsql + "RR.ROWSEQ, "
                strsql = strsql + "RC.COLSEQ,"
                strsql = strsql + "RC.REPORTCOLUMNSID , "
                strsql = strsql + "RC.COLNAME, "
                strsql = strsql + "RC.COLDETAILS, "
                strsql = strsql + "RC.COLDETAILS ||''||RR.ROWSEQ as SQLCOlNAME "
                strsql = strsql + "FROM USERREPORTFILTER URF "
                strsql = strsql + "INNER JOIN REPORTROWS RR ON RR.REPORTROWSID=URF.REPORTROWSID "
                strsql = strsql + "INNER JOIN REPORTCOLUMNS RC ON RC.REPORTCOLUMNSID=URF.REPORTCOLUMNSID "
                strsql = strsql + "WHERE REPORTID=" + ReportId

                ds = objdbUtil.FillDataSet(strsql, Sustain3Connection)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try

        End Function

        Public Function GetEnergyResults(ByVal CaseId As String, ByVal Rowseq As String) As DataTable
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            Try
                StrSql = "SELECT  "
                StrSql = StrSql + "TOT.CASEID, "
                StrSql = StrSql + "'Raw Materials' As A1, "
                StrSql = StrSql + "'Raw Materials Packaging' AS A2, "
                StrSql = StrSql + "'RM & Pack Transport' AS A3, "
                StrSql = StrSql + "'Process' AS A4, "
                StrSql = StrSql + "'Distribution Packaging' AS A5, "
                StrSql = StrSql + "'DP Transport' AS A6, "
                StrSql = StrSql + "'Transport to Customer' AS A7, "
                StrSql = StrSql + "'Total Energy' AS A8, "
                StrSql = StrSql + "'Purchased Materials' AS A9, "
                StrSql = StrSql + "'Process' AS A10, "
                StrSql = StrSql + "'Transportation' AS A11, "
                StrSql = StrSql + "'Total Energy' AS A12, "
                StrSql = StrSql + "TOT.RMERGY AS T1, "
                StrSql = StrSql + "TOT.RMPACKERGY AS T2, "
                StrSql = StrSql + "TOT.RMANDPACKTRNSPTERGY AS T3, "
                StrSql = StrSql + "TOT.PROCERGY AS T4, "
                StrSql = StrSql + "TOT.DPPACKERGY AS T5, "
                StrSql = StrSql + "TOT.DPTRNSPTERGY AS T6, "
                StrSql = StrSql + "TOT.TRSPTTOCUS AS T7, "
                StrSql = StrSql + "(TOT.RMERGY+TOT.RMPACKERGY+TOT.RMANDPACKTRNSPTERGY+TOT.PROCERGY+TOT.DPPACKERGY+TOT.DPTRNSPTERGY+TOT.TRSPTTOCUS) T8, "
                StrSql = StrSql + "(TOT.RMERGY+TOT.RMPACKERGY+TOT.DPPACKERGY) AS T9, "
                StrSql = StrSql + "TOT.PROCERGY AS T10, "
                StrSql = StrSql + "(TOT.RMANDPACKTRNSPTERGY+TOT.DPTRNSPTERGY+TOT.TRSPTTOCUS) AS  T11, "
                StrSql = StrSql + "(TOT.RMERGY+TOT.RMPACKERGY+TOT.RMANDPACKTRNSPTERGY+TOT.PROCERGY+TOT.DPPACKERGY+TOT.DPTRNSPTERGY+TOT.TRSPTTOCUS) T12, "
                StrSql = StrSql + "(RSPL.VOLUME*PREF.CONVWT)SVOLUME, "
                StrSql = StrSql + "(CASE WHEN RSPL.FINVOLMSI > 0 THEN "
                StrSql = StrSql + "(RSPL.FINVOLMSI*PREF.CONVAREA) "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "RSPL.FINVOLMUNITS "
                StrSql = StrSql + "END)SUNITVAL, "
                StrSql = StrSql + "(CASE WHEN RSPL.FINVOLMSI > 0 THEN "
                StrSql = StrSql + "'MJ/'||PREF.TITLE3 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "'MJ/unit' "
                StrSql = StrSql + "END)SUNIT, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM TOTAL TOT "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = TOT.CASEID "
                StrSql = StrSql + "INNER JOIN RESULTSPL RSPL "
                StrSql = StrSql + "ON RSPL.CASEID = TOT.CASEID "
                StrSql = StrSql + "WHERE TOT.CASEID in (" + CaseId.ToString() + ") "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString)
                Dim dt As New DataTable
                Dim dr As DataRow
                Dim j As Integer
                Dim i As Integer
                j = CInt(Rowseq) - 1
                If Dts.Tables(0).Rows.Count > 0 Then

                    For i = 0 To Dts.Tables(0).Rows.Count - 1
                        dr = dt.NewRow()
                        ' For j = 0 To 24
                        If i = 0 Then
                            dt.Columns.Add("CASEID")
                            dt.Columns.Add("UNITS")
                            dt.Columns.Add("UNIT1")
                            dt.Columns.Add("UNIT2")
                            dt.Columns.Add("UNIT3")
                            dt.Columns.Add("UNIT4")
                            dt.Columns.Add("TOTAL" + (j + 1).ToString() + "")
                            dt.Columns.Add("TOTALPER" + (j + 1).ToString() + "")
                            dt.Columns.Add("TOTALWT" + (j + 1).ToString() + "")
                            dt.Columns.Add("TOTALVOl" + (j + 1).ToString() + "")
                        End If

                        dr("CASEID") = Dts.Tables(0).Rows(i)("CASEID").ToString()
                        dr("UNITS") = Dts.Tables(0).Rows(i)("UNITS").ToString()
                        dr("UNIT1") = "MJ"
                        dr("UNIT2") = "(% of Total)"
                        dr("UNIT4") = Dts.Tables(0).Rows(i)("SUNIT").ToString()
                        dr("UNIT3") = "MJ/" + Dts.Tables(0).Rows(i).Item("TITLE8").ToString()

                        dr("TOTAL" + (j + 1).ToString() + "") = FormatNumber(CDbl(Dts.Tables(0).Rows(i)("T" + (j + 1).ToString()).ToString()), 0)
                        If Dts.Tables(0).Rows(i)("T8").ToString() > 0 Then
                            dr("TOTALPER" + (j + 1).ToString() + "") = FormatNumber(CDbl(Dts.Tables(0).Rows(i)("T" + (j + 1).ToString()).ToString()) / CDbl(Dts.Tables(0).Rows(i)("T8").ToString()) * 100, 3)
                        Else
                            dr("TOTALPER" + (j + 1).ToString() + "") = "na"
                        End If
                        If Dts.Tables(0).Rows(i)("SVOLUME").ToString() > 0 Then
                            dr("TOTALWT" + (j + 1).ToString() + "") = FormatNumber(CDbl((Dts.Tables(0).Rows(i)("T" + (j + 1).ToString()).ToString())) / CDbl(Dts.Tables(0).Rows(i)("SVOLUME").ToString()), 3)
                        Else
                            dr("TOTALWT" + (j + 1).ToString() + "") = "na"
                        End If
                        If Dts.Tables(0).Rows(i)("SUNITVAL").ToString() > 0 Then
                            dr("TOTALVOl" + (j + 1).ToString() + "") = FormatNumber(CDbl((Dts.Tables(0).Rows(i)("T" + (j + 1).ToString()).ToString()) / CDbl(Dts.Tables(0).Rows(i)("SUNITVAL").ToString())), 3)
                        Else
                            dr("TOTALVOl" + (j + 1).ToString() + "") = "na"
                        End If
                        'Next
                        dt.Rows.Add(dr)
                    Next
                End If

                Return dt
            Catch ex As Exception
                Throw New Exception("S3GetData:GetEnergyResults:" + ex.Message.ToString())
                'Return dt
            End Try
        End Function

        Public Function GetGhgResults(ByVal CaseId As String, ByVal Rowseq As String) As DataTable
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            Try
                StrSql = "SELECT  "
                StrSql = StrSql + "TOT.CASEID, "
                StrSql = StrSql + "'Raw Materials' As A1, "
                StrSql = StrSql + "'Raw Materials Packaging' AS A2, "
                StrSql = StrSql + "'RM & Pack Transport' AS A3, "
                StrSql = StrSql + "'Process' AS A4, "
                StrSql = StrSql + "'Distribution Packaging' AS A5, "
                StrSql = StrSql + "'DP Transport' AS A6, "
                StrSql = StrSql + "'Transport to Customer' AS A7, "
                StrSql = StrSql + "'Total Greenhouse Gas' AS A8, "
                StrSql = StrSql + "'Purchased Materials' AS A9, "
                StrSql = StrSql + "'Process' AS A10, "
                StrSql = StrSql + "'Transportation' AS A11, "
                StrSql = StrSql + "'Total Greenhouse Gas' AS A12, "
                StrSql = StrSql + "(TOT.RMGRNHUSGAS*PREF.CONVWT) AS T1, "
                StrSql = StrSql + "(TOT.RMPACKGRNHUSGAS*PREF.CONVWT) AS T2, "
                StrSql = StrSql + "(TOT.RMANDPACKTRNSPTGRNHUSGAS*PREF.CONVWT) AS T3, "
                StrSql = StrSql + "(TOT.PROCGRNHUSGAS*PREF.CONVWT) AS T4, "
                StrSql = StrSql + "(TOT.DPPACKGRNHUSGAS*PREF.CONVWT) AS T5, "
                StrSql = StrSql + "(TOT.DPTRNSPTGRNHUSGAS*PREF.CONVWT) AS T6, "
                StrSql = StrSql + "(TOT.TRSPTTOCUSGRNHUSGAS*PREF.CONVWT) AS T7, "
                StrSql = StrSql + "((TOT.RMGRNHUSGAS+TOT.RMPACKGRNHUSGAS+TOT.RMANDPACKTRNSPTGRNHUSGAS+TOT.PROCGRNHUSGAS+TOT.DPPACKGRNHUSGAS+TOT.DPTRNSPTGRNHUSGAS+TOT.TRSPTTOCUSGRNHUSGAS)*PREF.CONVWT) T8, "
                StrSql = StrSql + "((TOT.RMGRNHUSGAS+TOT.RMPACKGRNHUSGAS+TOT.DPPACKGRNHUSGAS)*PREF.CONVWT) AS T9, "
                StrSql = StrSql + "(TOT.PROCGRNHUSGAS*PREF.CONVWT) AS T10, "
                StrSql = StrSql + "((TOT.RMANDPACKTRNSPTGRNHUSGAS+TOT.DPTRNSPTGRNHUSGAS+TOT.TRSPTTOCUSGRNHUSGAS)*PREF.CONVWT) AS  T11, "
                StrSql = StrSql + "((TOT.RMGRNHUSGAS+TOT.RMPACKGRNHUSGAS+TOT.RMANDPACKTRNSPTGRNHUSGAS+TOT.PROCGRNHUSGAS+TOT.DPPACKGRNHUSGAS+TOT.DPTRNSPTGRNHUSGAS+TOT.TRSPTTOCUSGRNHUSGAS)*PREF.CONVWT) T12, "
                StrSql = StrSql + "(RSPL.VOLUME*PREF.CONVWT)SVOLUME, "
                StrSql = StrSql + "(CASE WHEN RSPL.FINVOLMSI > 0 THEN "
                StrSql = StrSql + "(RSPL.FINVOLMSI*PREF.CONVAREA) "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "RSPL.FINVOLMUNITS "
                StrSql = StrSql + "END)SUNITVAL, "
                StrSql = StrSql + "(CASE WHEN RSPL.FINVOLMSI > 0 THEN "
                StrSql = StrSql + "PREF.TITLE8||' gr gas /'||PREF.TITLE3 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "PREF.TITLE8||' gr gas /unit' "
                StrSql = StrSql + "END)SUNIT, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM TOTAL TOT "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = TOT.CASEID "
                StrSql = StrSql + "INNER JOIN RESULTSPL RSPL "
                StrSql = StrSql + "ON RSPL.CASEID = TOT.CASEID "
                StrSql = StrSql + "WHERE TOT.CASEID in (" + CaseId + " )"

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString)

                Dim dt As New DataTable
                Dim dr As DataRow
                Dim j As Integer
                Dim i As Integer
                j = CInt(Rowseq) - 1
                If Dts.Tables(0).Rows.Count > 0 Then

                    For i = 0 To Dts.Tables(0).Rows.Count - 1
                        dr = dt.NewRow()
                        ' For j = 0 To 24
                        If i = 0 Then
                            dt.Columns.Add("CASEID")
                            dt.Columns.Add("UNITS")
                            dt.Columns.Add("UNIT1")
                            dt.Columns.Add("UNIT2")
                            dt.Columns.Add("UNIT3")
                            dt.Columns.Add("UNIT4")
                            dt.Columns.Add("TOTAL" + (j + 1).ToString() + "")
                            dt.Columns.Add("TOTALPER" + (j + 1).ToString() + "")
                            dt.Columns.Add("TOTALWT" + (j + 1).ToString() + "")
                            dt.Columns.Add("TOTALVOl" + (j + 1).ToString() + "")
                        End If

                        dr("CASEID") = Dts.Tables(0).Rows(i)("CASEID").ToString()
                        dr("UNITS") = Dts.Tables(0).Rows(i)("UNITS").ToString()
                        dr("UNIT1") = Dts.Tables(0).Rows(i)("TITLE8").ToString()
                        dr("UNIT2") = "(% of Total)"
                        dr("UNIT4") = Dts.Tables(0).Rows(i)("SUNIT").ToString()                        
                        dr("UNIT3") = Dts.Tables(0).Rows(i).Item("TITLE8").ToString() + " gr gas/" + Dts.Tables(0).Rows(i).Item("TITLE8").ToString()
                        dr("TOTAL" + (j + 1).ToString() + "") = FormatNumber(CDbl(Dts.Tables(0).Rows(i)("T" + (j + 1).ToString()).ToString()), 0)
                        If Dts.Tables(0).Rows(i)("T8").ToString() > 0 Then
                            dr("TOTALPER" + (j + 1).ToString() + "") = FormatNumber(CDbl(Dts.Tables(0).Rows(i)("T" + (j + 1).ToString()).ToString()) / CDbl(Dts.Tables(0).Rows(i)("T8").ToString()) * 100, 2)
                        Else
                            dr("TOTALPER" + (j + 1).ToString() + "") = "na"
                        End If
                        If Dts.Tables(0).Rows(i)("SVOLUME").ToString() > 0 Then
                            dr("TOTALWT" + (j + 1).ToString() + "") = FormatNumber(CDbl((Dts.Tables(0).Rows(i)("T" + (j + 1).ToString()).ToString())) / CDbl(Dts.Tables(0).Rows(i)("SVOLUME").ToString()), 3)
                        Else
                            dr("TOTALWT" + (j + 1).ToString() + "") = "na"
                        End If
                        If Dts.Tables(0).Rows(i)("SUNITVAL").ToString() > 0 Then
                            dr("TOTALVOl" + (j + 1).ToString() + "") = FormatNumber(CDbl((Dts.Tables(0).Rows(i)("T" + (j + 1).ToString()).ToString()) / CDbl(Dts.Tables(0).Rows(i)("SUNITVAL").ToString())), 3)
                        Else
                            dr("TOTALVOl" + (j + 1).ToString() + "") = "na"
                        End If
                        'Next
                        dt.Rows.Add(dr)
                    Next
                End If

                Return dt
            Catch ex As Exception
                Throw New Exception("S3GetData:GetGhgResults:" + ex.Message.ToString())
            End Try
        End Function

        Public Function GetWaterResults(ByVal CaseId As String, ByVal Rowseq As String) As DataTable
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            Try
                StrSql = "SELECT  "
                StrSql = StrSql + "TOT.CASEID, "
                StrSql = StrSql + "'Raw Materials' As A1, "
                StrSql = StrSql + "'Raw Materials Packaging' AS A2, "
                StrSql = StrSql + "'RM & Pack Transport' AS A3, "
                StrSql = StrSql + "'Process' AS A4, "
                StrSql = StrSql + "'Distribution Packaging' AS A5, "
                StrSql = StrSql + "'DP Transport' AS A6, "
                StrSql = StrSql + "'Transport to Customer' AS A7, "
                StrSql = StrSql + "'Total Water' AS A8, "
                StrSql = StrSql + "'Purchased Materials' AS A9, "
                StrSql = StrSql + "'Process' AS A10, "
                StrSql = StrSql + "'Transportation' AS A11, "
                StrSql = StrSql + "'Total Water' AS A12, "
                StrSql = StrSql + "(TOT.RMWATER*PREF.CONVGALLON) AS T1, "
                StrSql = StrSql + "(TOT.RMPACKWATER*PREF.CONVGALLON) AS T2, "
                StrSql = StrSql + "(TOT.RMANDPACKTRNSPTWATER*PREF.CONVGALLON) AS T3, "
                StrSql = StrSql + "(TOT.PROCWATER*PREF.CONVGALLON) AS T4, "
                StrSql = StrSql + "(TOT.DPPACKWATER*PREF.CONVGALLON) AS T5, "
                StrSql = StrSql + "(TOT.DPTRNSPTWATER*PREF.CONVGALLON) AS T6, "
                StrSql = StrSql + "(TOT.TRSPTTOCUSWATER*PREF.CONVGALLON) AS T7, "
                StrSql = StrSql + "((TOT.RMWATER+TOT.RMPACKWATER+TOT.RMANDPACKTRNSPTWATER+TOT.PROCWATER+TOT.DPPACKWATER+TOT.DPTRNSPTWATER+TOT.TRSPTTOCUSWATER)*PREF.CONVGALLON) T8, "
                StrSql = StrSql + "((TOT.RMWATER+TOT.RMPACKWATER+TOT.DPPACKWATER)*PREF.CONVGALLON) AS T9, "
                StrSql = StrSql + "(TOT.PROCWATER*PREF.CONVGALLON) AS T10, "
                StrSql = StrSql + "((TOT.RMANDPACKTRNSPTWATER+TOT.DPTRNSPTWATER+TOT.TRSPTTOCUSWATER)*PREF.CONVGALLON) AS  T11, "
                StrSql = StrSql + "((TOT.RMWATER+TOT.RMPACKWATER+TOT.RMANDPACKTRNSPTWATER+TOT.PROCWATER+TOT.DPPACKWATER+TOT.DPTRNSPTWATER+TOT.TRSPTTOCUSWATER)*PREF.CONVGALLON) T12, "
                StrSql = StrSql + "(RSPL.VOLUME*PREF.CONVWT)SVOLUME, "
                StrSql = StrSql + "(CASE WHEN RSPL.FINVOLMSI > 0 THEN "
                StrSql = StrSql + "(RSPL.FINVOLMSI*PREF.CONVAREA) "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "RSPL.FINVOLMUNITS "
                StrSql = StrSql + "END)SUNITVAL, "
                StrSql = StrSql + "(CASE WHEN RSPL.FINVOLMSI > 0 THEN "
                StrSql = StrSql + "PREF.TITLE10||' water /'||PREF.TITLE3 "
                StrSql = StrSql + "ELSE "
                StrSql = StrSql + "PREF.TITLE10||' water /unit' "
                StrSql = StrSql + "END)SUNIT, "
                StrSql = StrSql + "PREF.TITLE1, "
                StrSql = StrSql + "PREF.TITLE3, "
                StrSql = StrSql + "PREF.TITLE2, "
                StrSql = StrSql + "PREF.TITLE4, "
                StrSql = StrSql + "PREF.TITLE5, "
                StrSql = StrSql + "PREF.TITLE6, "
                StrSql = StrSql + "PREF.TITLE7, "
                StrSql = StrSql + "PREF.TITLE8, "
                StrSql = StrSql + "PREF.TITLE9, "
                StrSql = StrSql + "PREF.TITLE10, "
                StrSql = StrSql + "PREF.TITLE11, "
                StrSql = StrSql + "PREF.TITLE12, "
                StrSql = StrSql + "PREF.CONVGALLON, "
                StrSql = StrSql + "PREF.UNITS "
                StrSql = StrSql + "FROM TOTAL TOT "
                StrSql = StrSql + "INNER JOIN PREFERENCES PREF "
                StrSql = StrSql + "ON PREF.CASEID = TOT.CASEID "
                StrSql = StrSql + "INNER JOIN RESULTSPL RSPL "
                StrSql = StrSql + "ON RSPL.CASEID = TOT.CASEID "
                StrSql = StrSql + "WHERE TOT.CASEID in (" + CaseId.ToString() + ") "

                Dts = odbUtil.FillDataSet(StrSql, MyConnectionString)
                Dim dt As New DataTable
                Dim dr As DataRow
                Dim j As Integer
                Dim i As Integer
                j = CInt(Rowseq)
                If Dts.Tables(0).Rows.Count > 0 Then

                    For i = 0 To Dts.Tables(0).Rows.Count - 1
                        dr = dt.NewRow()
                        ' For j = 0 To 24
                        If i = 0 Then
                            dt.Columns.Add("CASEID")
                            dt.Columns.Add("UNITS")
                            dt.Columns.Add("UNIT1")
                            dt.Columns.Add("UNIT2")
                            dt.Columns.Add("UNIT3")
                            dt.Columns.Add("UNIT4")
                            dt.Columns.Add("TOTAL" + (j).ToString() + "")
                            dt.Columns.Add("TOTALPER" + (j).ToString() + "")
                            dt.Columns.Add("TOTALWT" + (j).ToString() + "")
                            dt.Columns.Add("TOTALVOl" + (j).ToString() + "")
                        End If

                        dr("CASEID") = Dts.Tables(0).Rows(i)("CASEID").ToString()
                        dr("UNITS") = Dts.Tables(0).Rows(i)("UNITS").ToString()
                        dr("UNIT1") = Dts.Tables(0).Rows(i)("TITLE10").ToString()
                        dr("UNIT2") = "(% of Total)"
                        dr("UNIT4") = Dts.Tables(0).Rows(i)("SUNIT").ToString()
                        dr("UNIT3") = Dts.Tables(0).Rows(i).Item("TITLE10").ToString() + " water/" + Dts.Tables(0).Rows(i).Item("TITLE8").ToString()

                        dr("TOTAL" + (j).ToString() + "") = FormatNumber(CDbl(Dts.Tables(0).Rows(i)("T" + (j).ToString()).ToString()), 0)
                        If Dts.Tables(0).Rows(i)("T8").ToString() > 0 Then
                            dr("TOTALPER" + (j).ToString() + "") = FormatNumber(CDbl(Dts.Tables(0).Rows(i)("T" + (j).ToString()).ToString()) / CDbl(Dts.Tables(0).Rows(i)("T8").ToString()) * 100, 2)
                        Else
                            dr("TOTALPER" + (j).ToString() + "") = "na"
                        End If
                        If Dts.Tables(0).Rows(i)("SVOLUME").ToString() > 0 Then
                            dr("TOTALWT" + (j).ToString() + "") = FormatNumber(CDbl((Dts.Tables(0).Rows(i)("T" + (j).ToString()).ToString())) / CDbl(Dts.Tables(0).Rows(i)("SVOLUME").ToString()), 3)
                        Else
                            dr("TOTALWT" + (j).ToString() + "") = "na"
                        End If
                        If Dts.Tables(0).Rows(i)("SUNITVAL").ToString() > 0 Then
                            dr("TOTALVOl" + (j).ToString() + "") = FormatNumber(CDbl((Dts.Tables(0).Rows(i)("T" + (j).ToString()).ToString()) / CDbl(Dts.Tables(0).Rows(i)("SUNITVAL").ToString())), 3)
                        Else
                            dr("TOTALVOl" + (j).ToString() + "") = "na"
                        End If
                        'Next
                        dt.Rows.Add(dr)
                    Next
                End If

                Return dt

            Catch ex As Exception
                Throw New Exception("S3GetData:GetWaterResults:" + ex.Message.ToString())
            End Try
        End Function

        

#End Region
    End Class
End Class
