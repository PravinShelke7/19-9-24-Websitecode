﻿Imports Microsoft.VisualBasic
Imports System.Web.SessionState
Imports System.Data
Imports System.Data.OleDb
Imports System
Public Class S3UpInsData
    Public Class UpdateInsert
        Dim Sustain3Connection As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
        Public Function AssumptionUpdate(ByVal Caseid As String) As Integer
            If Caseid <> "" Then
                'Converting The Comma Separetd CaseID String to an Array
                Dim CaseArray(9) As String
                Dim NewCaseArray(9) As String
                Dim Cases As Integer

                CaseArray = Caseid.Split(",")
                Dim I As Integer

                For I = 0 To 9
                    If I <= UBound(CaseArray) Then
                        NewCaseArray(I) = CaseArray(I)
                    Else
                        NewCaseArray(I) = "NULL"
                    End If
                Next

                Cases = (UBound(CaseArray) + 1)



                'Creating Database Connection
                Dim oDbUtil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")


                If (NewCaseArray.Length <= 10) Then

                    'SQL
                    Dim SqlId As String = "SELECT SEQASSUMPTIONID.nextval NewAssumptionId FROM dual"
                    Dim AssumptionID As Integer = oDbUtil.FillData(SqlId, MyConnectionString)




                    Dim StrSqlInsert As String = "Insert into Assumptions (AssumptionId, Description, Module, Saved, Case1, Case2, Case3,"
                    StrSqlInsert = StrSqlInsert + "case4, case5, case6, case7, case8, case9, case10 ) "
                    StrSqlInsert = StrSqlInsert + "values (" + AssumptionID.ToString() + ",'New Comparision',1,0," + NewCaseArray(0) + "," + NewCaseArray(1) + "," + NewCaseArray(2) + "," + NewCaseArray(3) + "," + NewCaseArray(4) + ","
                    StrSqlInsert = StrSqlInsert + "" + NewCaseArray(5) + "," + NewCaseArray(6) + "," + NewCaseArray(7) + "," + NewCaseArray(8) + "," + NewCaseArray(9) + "  "
                    StrSqlInsert = StrSqlInsert + ")"
                    oDbUtil.UpIns(StrSqlInsert, MyConnectionString)
                    Return AssumptionID

                End If

            End If
        End Function
        Public Sub EditComparisonName(ByVal AID As String, ByVal CaseDes As String)
            Try
                Dim odButil As New DBUtil()
                Dim val As Integer
                val = 1
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
                Dim StrSqlUpadate As String = ""
                Dim StrSqlIUpadate As String = ""
                StrSqlUpadate = "UPDATE ASSUMPTIONS SET "
                StrSqlUpadate = StrSqlUpadate + " DESCRIPTION='" + CaseDes + " ' "
                StrSqlUpadate = StrSqlUpadate + " WHERE ASSUMPTIONID= " + AID.ToString()
                odButil.UpIns(StrSqlUpadate, MyConnectionString)

            Catch ex As Exception

            End Try
        End Sub
        Public Sub EditComparison(ByVal AID As String, ByVal caseIds() As String, ByVal count As Integer)
            Try
                Dim odButil As New DBUtil()
                Dim i, val As Integer
                val = 1
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
                Dim StrSqlUpadate As String = ""
                Dim StrSqlIUpadate As String = ""
                StrSqlUpadate = "UPDATE ASSUMPTIONS SET "
                For i = count To 10
                    If (caseIds(val) <> Nothing) Then
                        StrSqlUpadate = StrSqlUpadate + "CASE" + i.ToString() + " =" + caseIds(val) + " ,"
                    Else
                        StrSqlUpadate = StrSqlUpadate + "CASE" + i.ToString() + " =NULL ,"
                    End If
                    val += 1
                Next
                StrSqlIUpadate = StrSqlUpadate.Remove(StrSqlUpadate.Length - 1)
                StrSqlIUpadate = StrSqlIUpadate + " WHERE ASSUMPTIONID= " + AID.ToString()

                odButil.UpIns(StrSqlIUpadate, MyConnectionString)

            Catch ex As Exception

            End Try
        End Sub

        Public Sub SharedCase(ByVal shareusername As String, ByVal ID As String)

            'Creating Database Connection
            Dim oDbUtil As New DBUtil()

            'SQL
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
            Dim StrsqlInsert As String = "INSERT INTO PERMASSUMPTIONS (USERNAME, ASSUMPTIONID)"
            StrsqlInsert = StrsqlInsert + " SELECT '" + shareusername + "'," + ID + " FROM DUAL "
            StrsqlInsert = StrsqlInsert + "WHERE NOT EXISTS (SELECT 1 FROM PERMASSUMPTIONS WHERE UPPER(USERNAME)='" + shareusername.ToUpper() + "' AND ASSUMPTIONID=" + ID + ")"

            oDbUtil.UpIns(StrsqlInsert, MyConnectionString)



        End Sub

        Public Sub AlterComparison(ByVal Name As String, ByVal ID As String, ByVal AssID As String, ByVal Username As String, ByVal Password As String)

            'Creating Database Connection
            Dim odButil As New DBUtil()
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
            'SQL
            If ID = "1" Or ID = "2" Then
                Dim StrSqlSave As String = "UPDATE ASSUMPTIONS SET SAVED = 1 ,"
                StrSqlSave = StrSqlSave + " DESCRIPTION='" + Name + " '  "
                StrSqlSave = StrSqlSave + "WHERE ASSUMPTIONID =" + AssID.ToString() + ""
                odButil.UpIns(StrSqlSave, MyConnectionString)

                Dim StrSqlSaved As String = "Insert into PERMASSUMPTIONS (USERNAME , ASSUMPTIONID  ) select"
                StrSqlSaved = StrSqlSaved + "'" + Username.ToString() + "'," + AssID.ToString() + " From Dual where not exists ( select 1 from PERMASSUMPTIONS "
                StrSqlSaved = StrSqlSaved + "Where PERMASSUMPTIONS.ASSUMPTIONID =" + AssID.ToString() + ")"
                odButil.UpIns(StrSqlSaved, MyConnectionString)

            End If

            If ID = "3" Then

                Dim StrSqlDelete As String = "DELETE FROM PERMASSUMPTIONS WHERE ASSUMPTIONID=" + AssID.ToString() + " AND UPPER(USERNAME)='" + Username.ToUpper() + "' "
                odButil.UpIns(StrSqlDelete, MyConnectionString)

                Dim StrSqlDelete2 As String = "DELETE FROM ASSUMPTIONS WHERE ASSUMPTIONID=" + AssID.ToString() + " "
                StrSqlDelete2 = StrSqlDelete2 + "AND NOT EXISTS  "
                StrSqlDelete2 = StrSqlDelete2 + "( "
                StrSqlDelete2 = StrSqlDelete2 + "SELECT 1 FROM PERMASSUMPTIONS "
                StrSqlDelete2 = StrSqlDelete2 + "WHERE ASSUMPTIONID= " + AssID.ToString() + " "
                StrSqlDelete2 = StrSqlDelete2 + ") "

                odButil.UpIns(StrSqlDelete2, MyConnectionString)

            End If

            If ID = "4" Then
                Dim StrSqlSave As String = "UPDATE ASSUMPTIONS SET "
                StrSqlSave = StrSqlSave + " DESCRIPTION='" + Name + " '  "
                StrSqlSave = StrSqlSave + "WHERE ASSUMPTIONID =" + AssID.ToString() + ""
                odButil.UpIns(StrSqlSave, MyConnectionString)
            End If
        End Sub

#Region "User Category Update"
        Public Sub AddCategorySet(ByVal CatSetName As String, ByVal UserId As String, ByVal PageName As String)
            Try
                Dim odButil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                Dim strsql As String = ""
                strsql = "INSERT INTO CATEGORYSET  "
                strsql = strsql + "( "
                strsql = strsql + "CATEGORYSETID, CATEGORYSETNAME,USERID,PAGENAME "
                strsql = strsql + ") "
                strsql = strsql + "SELECT SEQCATEGORYSETID.NEXTVAL, "
                strsql = strsql + "'" + CatSetName + "', "
                strsql = strsql + UserId + ","
                strsql = strsql + "'" + PageName + "' "
                strsql = strsql + "FROM DUAL "
                odButil.UpIns(strsql, MyConnectionString)
            Catch ex As Exception

            End Try
        End Sub
        Public Sub AddCategory(ByVal CatSetName() As String, ByVal CatSetId As String)
            Try
                Dim odButil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                Dim strsql As String = ""
                Dim i As Integer = 0

                For i = 0 To CatSetName.Length
                    strsql = "INSERT INTO CATEGORY  "
                    strsql = strsql + "( "
                    strsql = strsql + "CATEGORYID, CATEGORYSETID, CATEGORYNAME "
                    strsql = strsql + ") "
                    strsql = strsql + "SELECT SEQCATEGORYID.NEXTVAL, "
                    strsql = strsql + CatSetId + ", "
                    strsql = strsql + "'" + CatSetName(i) + "' "
                    strsql = strsql + "FROM DUAL "
                    odButil.UpIns(strsql, MyConnectionString)
                Next


            Catch ex As Exception

            End Try
        End Sub
        Public Sub AddEditCatItem(ByVal CatId As String, ByVal CatVal() As String)
            Try
                Dim odButil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                Dim strsql As String = ""
                Dim i As Integer = 0


                'Inserting Data
                For i = 0 To CatVal.Length - 1
                    strsql = "INSERT INTO  CATEGORYITEM  "
                    strsql = strsql + "(CATEGORYITEMID, CATEGORYID, ITEMNAME) "
                    strsql = strsql + "SELECT SEQCATEGORYITEMID.NEXTVAL, "
                    strsql = strsql + CatId + ", "
                    strsql = strsql + "'" + CatVal(i) + "' "
                    strsql = strsql + "FROM DUAL "
                    odButil.UpIns(strsql, MyConnectionString)
                Next


            Catch ex As Exception

            End Try
        End Sub
        Public Sub DeleteCatItem(ByVal CatId As String, ByVal itemName As String)
            Try
                Dim odButil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                Dim strsql As String = ""
                strsql = "DELETE FROM  "
                strsql = strsql + "CATEGORYITEM "
                strsql = strsql + "WHERE CATEGORYID=" + CatId + " "
                strsql = strsql + "AND ITEMNAME IN (" + itemName + " ) "
                odButil.UpIns(strsql, MyConnectionString)
            Catch ex As Exception

            End Try
        End Sub
        Public Sub RenameCategory(ByVal CatId As String, ByVal CatName As String, ByVal CatSetid As String)
            Try
                Dim odButil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                Dim strsql As String = ""
                strsql = "UPDATE CATEGORY  "
                strsql = strsql + "SET CATEGORYNAME='" + CatName + "' "
                strsql = strsql + "WHERE CATEGORYID= " + CatId + " "
                strsql = strsql + "AND CATEGORYSETID= " + CatSetid + " "
                odButil.UpIns(strsql, MyConnectionString)
            Catch ex As Exception

            End Try
        End Sub
        Public Sub DeleteCategory(ByVal CatId As String, ByVal CatSetid As String)
            Try
                Dim odButil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                Dim strsql As String = ""

                'Delete Category
                strsql = "DELETE CATEGORY  "
                strsql = strsql + "WHERE CATEGORYID= " + CatId + " "
                strsql = strsql + "AND CATEGORYSETID= " + CatSetid + " "
                odButil.UpIns(strsql, MyConnectionString)

                'Delete Category Items
                strsql = "DELETE CATEGORYITEM  "
                strsql = strsql + "WHERE CATEGORYID= " + CatId + " "
                odButil.UpIns(strsql, MyConnectionString)
            Catch ex As Exception

            End Try
        End Sub
        Public Sub DeleteCategorySet(ByVal CatSetid As String)
            Try
                Dim odButil As New DBUtil()
                Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
                Dim strsql As String = ""

                'Delete Category Items
                strsql = "DELETE FROM  "
                strsql = strsql + "CATEGORYITEM "
                strsql = strsql + "WHERE "
                strsql = strsql + "CATEGORYITEMID IN "
                strsql = strsql + "( "
                strsql = strsql + "SELECT CATEGORYITEMID FROM CATEGORYITEM "
                strsql = strsql + "INNER JOIN CATEGORY "
                strsql = strsql + "ON CATEGORY.CATEGORYID=CATEGORYITEM.CATEGORYID "
                strsql = strsql + "INNER JOIN CATEGORYSET "
                strsql = strsql + "ON CATEGORYSET.CATEGORYSETID=CATEGORY.CATEGORYSETID "
                strsql = strsql + "WHERE CATEGORYSET.CATEGORYSETID= " + CatSetid
                strsql = strsql + ") "
                odButil.UpIns(strsql, MyConnectionString)

                'Delete Category
                strsql = "DELETE FROM CATEGORY  "
                strsql = strsql + "WHERE "
                strsql = strsql + "CATEGORYSETID= " + CatSetid + " "
                odButil.UpIns(strsql, MyConnectionString)

                'Delete Category Set
                strsql = "DELETE CATEGORYSET  "
                strsql = strsql + "WHERE "
                strsql = strsql + "CATEGORYSETID= " + CatSetid + " "
                odButil.UpIns(strsql, MyConnectionString)



                odButil.UpIns(strsql, MyConnectionString)
            Catch ex As Exception

            End Try
        End Sub
#End Region
#Region "2DReports"
        Public Function AddReport(ByVal UserId As String, ByVal ReportName As String, ByVal RowCnt As Integer, ByVal ColCnt As Integer) As Integer
            Dim odbUtil As New DBUtil()
            Dim ObjGetData As New E3GetData.Selectdata
            Dim StrSql As String = String.Empty
            Dim ReportId As Integer
            Dim i As New Integer
            Dim J As Integer
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
            Try
                'Create report
                ReportId = ObjGetData.GetSeqReportId()
                StrSql = String.Empty
                StrSql = "INSERT INTO USERREPORTS  "
                StrSql = StrSql + "(REPORTID,REPORTNAME,  USERID ) "
                StrSql = StrSql + "SELECT  " + ReportId.ToString() + ", "
                StrSql = StrSql + " 'Blank Report'," + UserId.ToString() + " FROM DUAL "
                odbUtil.UpIns(StrSql, MyConnectionString)

                StrSql = String.Empty
                StrSql = "INSERT INTO USERREPORTS  "
                StrSql = StrSql + "(REPORTID,REPORTNAME,  USERID ) "
                StrSql = StrSql + "SELECT  " + ReportId.ToString() + ", "
                StrSql = StrSql + " '" + ReportName + "'," + UserId.ToString() + " FROM DUAL "
                odbUtil.UpIns(StrSql, Sustain3Connection)

                'insert Rows & cols
                For i = 1 To RowCnt
                    For J = 1 To ColCnt
                        StrSql = String.Empty
                        StrSql = "INSERT INTO USERREPORTDETAILS  "
                        StrSql = StrSql + "(REPORTDETAILSID,REPORTID,ROWNO,COLNO,CASEID) "
                        StrSql = StrSql + "SELECT "
                        StrSql = StrSql + "SEQREPORTDETAILID.NEXTVAL, "
                        StrSql = StrSql + "" + ReportId.ToString() + "," + i.ToString + "," + J.ToString + ",null"
                        StrSql = StrSql + " FROM DUAL "
                        odbUtil.UpIns(StrSql, Sustain3Connection)
                        odbUtil.UpIns(StrSql, MyConnectionString)
                    Next
                Next
                'Insert Filter
                StrSql = String.Empty
                StrSql = "INSERT INTO USERREPORTFILTER  "
                StrSql = StrSql + "(USERREPORTFILTERID,REPORTID) "
                StrSql = StrSql + "SELECT SEQREPORTFILTERID.NEXTVAL," + ReportId.ToString() + " FROM DUAL "
                odbUtil.UpIns(StrSql, Sustain3Connection)
                odbUtil.UpIns(StrSql, MyConnectionString)
                Return (ReportId)
            Catch ex As Exception
                Throw ex
            End Try

        End Function
        Public Sub DeleteReport(ByVal reportId As String)
            Dim strsql As String = String.Empty
            Dim odbUtil As New DBUtil()
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
            Try
                strsql = "DELETE FROM USERREPORTS  "
                strsql = strsql + "WHERE REPORTID= " + reportId
                odbUtil.UpIns(strsql, Sustain3Connection)
                odbUtil.UpIns(strsql, MyConnectionString)
                strsql = String.Empty
                strsql = "DELETE FROM USERREPORTDETAILS  "
                strsql = strsql + "WHERE REPORTID= " + reportId
                odbUtil.UpIns(strsql, Sustain3Connection)
                odbUtil.UpIns(strsql, MyConnectionString)
                strsql = String.Empty
                strsql = "DELETE FROM USERREPORTFILTER  "
                strsql = strsql + "WHERE REPORTID= " + reportId
                odbUtil.UpIns(strsql, Sustain3Connection)
                odbUtil.UpIns(strsql, MyConnectionString)
                strsql = String.Empty
                strsql = "DELETE FROM USERREPORTCOLUMNS  "
                strsql = strsql + "WHERE REPORTID= " + reportId
                odbUtil.UpIns(strsql, Sustain3Connection)
                odbUtil.UpIns(strsql, MyConnectionString)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        Public Sub EditReport(ByVal reportId As String, ByVal Reportname As String, ByVal RowCount As String, ByVal ColCount As String, ByVal prevRowCount As String, ByVal prevColCount As String)
            Dim strsql As String = String.Empty
            Dim odbUtil As New DBUtil()
            Dim i As Integer
            Try
                strsql = "UPDATE USERREPORTS  "
                strsql = strsql + "SET USERREPORTS.REPORTNAME = '" + Reportname + "' "
                strsql = strsql + "WHERE REPORTID= " + reportId
                odbUtil.UpIns(strsql, Sustain3Connection)

                If CInt(RowCount) > CInt(prevRowCount) Then
                    For i = CInt(prevRowCount) + 1 To CInt(RowCount)
                        For j = 1 To CInt(prevColCount)
                            strsql = String.Empty
                            strsql = "INSERT INTO USERREPORTDETAILS  "
                            strsql = strsql + "(REPORTDETAILSID,REPORTID,ROWNO,COLNO,CASEID) "
                            strsql = strsql + "SELECT "
                            strsql = strsql + "SEQREPORTDETAILID.NEXTVAL, "
                            strsql = strsql + "" + reportId.ToString() + "," + i.ToString() + "," + j.ToString() + ",null"
                            strsql = strsql + " FROM DUAL "
                            odbUtil.UpIns(strsql, Sustain3Connection)
                        Next
                    Next
                ElseIf CInt(RowCount) < CInt(prevRowCount) Then
                    ' i = CInt(prevRowCount) - CInt(RowCount)
                    strsql = String.Empty
                    strsql = "DELETE FROM USERREPORTDETAILS  "
                    strsql = strsql + "WHERE REPORTID= " + reportId
                    strsql = strsql + " AND  ROWNO>" + RowCount 'i.ToString()
                    odbUtil.UpIns(strsql, Sustain3Connection)

                    strsql = String.Empty
                    strsql = "DELETE FROM USERREPORTROWS  "
                    strsql = strsql + "WHERE REPORTID= " + reportId
                    strsql = strsql + " AND  ROWNO>" + RowCount 'i.ToString()
                    odbUtil.UpIns(strsql, Sustain3Connection)
                ElseIf CInt(RowCount) = CInt(prevRowCount) Then

                End If

                If CInt(ColCount) > CInt(prevColCount) Then
                    For i = 1 To CInt(RowCount)
                        For j = CInt(prevColCount) + 1 To CInt(ColCount)
                            strsql = String.Empty
                            strsql = "INSERT INTO USERREPORTDETAILS  "
                            strsql = strsql + "(REPORTDETAILSID,REPORTID,ROWNO,COLNO,CASEID) "
                            strsql = strsql + "SELECT "
                            strsql = strsql + "SEQREPORTDETAILID.NEXTVAL, "
                            strsql = strsql + "" + reportId.ToString() + "," + i.ToString() + "," + j.ToString() + ",null"
                            strsql = strsql + " FROM DUAL "
                            odbUtil.UpIns(strsql, Sustain3Connection)
                        Next
                    Next
                ElseIf CInt(ColCount) < CInt(prevColCount) Then
                    'i = CInt(prevColCount) - CInt(ColCount)
                    strsql = String.Empty
                    strsql = "DELETE FROM USERREPORTDETAILS  "
                    strsql = strsql + "WHERE REPORTID= " + reportId
                    strsql = strsql + " AND  COLNO>" + ColCount 'i.ToString()
                    odbUtil.UpIns(strsql, Sustain3Connection)

                    strsql = String.Empty
                    strsql = "DELETE FROM USERREPORTCOLUMNS  "
                    strsql = strsql + "WHERE REPORTID= " + reportId
                    strsql = strsql + " AND  COLNO>" + ColCount 'i.ToString()
                    odbUtil.UpIns(strsql, Sustain3Connection)

                ElseIf CInt(RowCount) = CInt(prevRowCount) Then

                End If

            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        Public Function CopyReport(ByVal reportId As String) As Integer
            Dim strsql As String = String.Empty
            Dim odbUtil As New DBUtil()
            Dim objGetData As New E3GetData.Selectdata
            Dim newReportId As Integer
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
            Try
                newReportId = objGetData.GetSeqReportId()
                strsql = "INSERT INTO USERREPORTS  "
                strsql = strsql + "(REPORTID,REPORTNAME,  USERID ) "
                strsql = strsql + "SELECT " + newReportId.ToString() + ", UR.REPORTNAME, UR.USERID "
                strsql = strsql + "FROM USERREPORTS UR WHERE UR.REPORTID=" + reportId + " "
                odbUtil.UpIns(strsql, Sustain3Connection)
                odbUtil.UpIns(strsql, MyConnectionString)

                strsql = String.Empty
                strsql = "INSERT INTO USERREPORTDETAILS  "
                strsql = strsql + "(REPORTDETAILSID,REPORTID,ROWNO,COLNO,CASEID) "
                strsql = strsql + "SELECT SEQREPORTDETAILID.NEXTVAL," + newReportId.ToString() + ",URD.ROWNO,URD.COLNO,URD.CASEID "
                strsql = strsql + "FROM  USERREPORTDETAILS URD "
                strsql = strsql + "WHERE URD.REPORTID=" + reportId + " "
                odbUtil.UpIns(strsql, Sustain3Connection)
                odbUtil.UpIns(strsql, MyConnectionString)

                strsql = String.Empty
                strsql = "INSERT INTO USERREPORTFILTER  "
                strsql = strsql + "(USERREPORTFILTERID,REPORTID,REPORTCATEGORYID,REPORTROWSID,REPORTCOLUMNSID) "
                strsql = strsql + "SELECT SEQREPORTFILTERID.NEXTVAL," + newReportId.ToString() + ",UF.REPORTCATEGORYID,UF.REPORTROWSID,UF.REPORTCOLUMNSID "
                strsql = strsql + "FROM USERREPORTFILTER UF "
                strsql = strsql + "WHERE UF.REPORTID=" + reportId + " "
                odbUtil.UpIns(strsql, Sustain3Connection)
                odbUtil.UpIns(strsql, MyConnectionString)

                strsql = String.Empty
                strsql = "INSERT INTO USERREPORTCOLUMNS  "
                strsql = strsql + "(USERREPORTCOLUMNSID,REPORTID,COLNO,COLNAME) "
                strsql = strsql + "SELECT SEQUSERREPORTCOLUMNSID.NEXTVAL," + newReportId.ToString() + ",UC.COLNO,UC.COLNAME "
                strsql = strsql + "FROM USERREPORTCOLUMNS UC "
                strsql = strsql + "WHERE UC.REPORTID= " + reportId + " "
                odbUtil.UpIns(strsql, Sustain3Connection)
                odbUtil.UpIns(strsql, MyConnectionString)

                strsql = String.Empty
                strsql = "INSERT INTO USERREPORTROWS  "
                strsql = strsql + "(USERREPORTROWSID,REPORTID,ROWNO,ROWNAME) "
                strsql = strsql + "SELECT SEQUSERREPORTROWSID.NEXTVAL," + newReportId.ToString() + ",UR.ROWNO,UR.ROWNAME "
                strsql = strsql + "FROM USERREPORTROWS UR "
                strsql = strsql + "WHERE UR.REPORTID= " + reportId + " "
                odbUtil.UpIns(strsql, Sustain3Connection)
                odbUtil.UpIns(strsql, MyConnectionString)

                Return newReportId
            Catch ex As Exception
                Throw ex
            End Try
        End Function

        Public Sub SyncReport(ByVal reportId As String, ByVal UserId As String)
            Dim strsql As String = String.Empty
            Dim odbUtil As New DBUtil()
            Dim objGetData As New E3GetData.Selectdata
            Dim dsE3Report As New DataSet
            Dim rowCount As Integer
            Dim colCount As Integer
            Dim i As Integer
            Dim j As Integer
            Dim MyConnectionString As String = System.Configuration.ConfigurationManager.AppSettings("SystemConnectionString")
            Try
                strsql = "UPDATE SUSTAIN3.USERREPORTS  "
                strsql = strsql + "SET (REPORTNAME)=( "
                strsql = strsql + "SELECT REPORTNAME "
                strsql = strsql + "FROM ECON3.USERREPORTS "
                strsql = strsql + "WHERE REPORTID=" + reportId + ") "
                strsql = strsql + "WHERE REPORTID=" + reportId + " "
                odbUtil.UpIns(strsql, MyConnectionString)
                ' odbUtil.UpIns(strsql, MyConnectionString)

                'UPDATE THE CASEIDS
                ' dsE3Report = objGetData.GetReportsDetail(reportId, UserId)
                rowCount = objGetData.GetReportsRowCount(reportId)
                colCount = objGetData.GetReportsColCount(reportId)
                For i = 1 To rowCount
                    For j = 1 To colCount
                        strsql = String.Empty
                        strsql = "UPDATE SUSTAIN3.USERREPORTDETAILS  "
                        strsql = strsql + "SET (CASEID)=( "
                        strsql = strsql + "SELECT CASEID "
                        strsql = strsql + "FROM ECON3.USERREPORTDETAILS "
                        strsql = strsql + "WHERE REPORTID=" + reportId + " AND ROWNO=" + i.ToString() + " AND COLNO=" + j.ToString() + ") "
                        strsql = strsql + "WHERE REPORTID=" + reportId + " AND ROWNO=" + i.ToString() + " AND COLNO=" + j.ToString() + " "
                        odbUtil.UpIns(strsql, MyConnectionString)
                    Next
                Next

                strsql = String.Empty
                strsql = " DELETE FROM USERREPORTCOLUMNS WHERE REPORTID=" + reportId + ""
                odbUtil.UpIns(strsql, Sustain3Connection)

                strsql = String.Empty
                strsql = "INSERT INTO SUSTAIN3.USERREPORTCOLUMNS(USERREPORTCOLUMNSID,REPORTID,COLNO,COLNAME)  "
                strsql = strsql + "SELECT  SUSTAIN3.SEQUSERREPORTCOLUMNSID.NEXTVAL,REPORTID,COLNO,COLNAME FROM ECON3.USERREPORTCOLUMNS WHERE REPORTID=" + reportId + " "
                odbUtil.UpIns(strsql, MyConnectionString)

                strsql = String.Empty
                strsql = " DELETE FROM USERREPORTROWS WHERE REPORTID=" + reportId + ""
                odbUtil.UpIns(strsql, Sustain3Connection)

                strsql = String.Empty
                strsql = "INSERT INTO SUSTAIN3.USERREPORTROWS(USERREPORTROWSID,REPORTID,ROWNO,ROWNAME)  "
                strsql = strsql + "SELECT  SUSTAIN3.SEQUSERREPORTROWSID.NEXTVAL,REPORTID,ROWNO,ROWNAME FROM ECON3.USERREPORTROWS WHERE REPORTID=" + reportId + " "
                odbUtil.UpIns(strsql, MyConnectionString)


            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        Public Sub RenameReport(ByVal ReportId As String, ByVal ReportName As String)

            'Creating Database Connection
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                'Report Details
                StrSql = String.Empty
                StrSql = "UPDATE USERREPORTS  "
                StrSql = StrSql + "SET USERREPORTS.REPORTNAME = '" + ReportName + "' "
                StrSql = StrSql + "WHERE USERREPORTS.REPORTID=" + ReportId + " "
                odbUtil.UpIns(StrSql, Sustain3Connection)

            Catch ex As Exception
                Throw New Exception("Error:RenameReport:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub UpdateRows(ByVal reportId As String, ByVal RowNo As Integer, ByVal ColNo As Integer, ByVal caseid As String)
            Dim strsql As String = String.Empty
            Dim odbUtil As New DBUtil()
            Try
                strsql = "UPDATE USERREPORTDETAILS  "
                strsql = strsql + "SET CASEID=" + caseid + " "
                strsql = strsql + "WHERE ROWNO=" + RowNo.ToString + " AND COLNO=" + ColNo.ToString() + " AND REPORTID=" + reportId.ToString + " "
                odbUtil.UpIns(strsql, Sustain3Connection)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        Public Sub UpdateFilter(ByVal reportId As String, ByVal reportcategoryId As String, ByVal RowId As String, ByVal ColId As String)
            Dim strsql As String = String.Empty
            Dim odbUtil As New DBUtil()
            Try
                strsql = "UPDATE USERREPORTFILTER  "
                strsql = strsql + "SET REPORTCATEGORYID=" + reportcategoryId + " , "
                strsql = strsql + "REPORTROWSID=" + RowId + " , "
                strsql = strsql + "REPORTCOLUMNSID=" + ColId + " "
                strsql = strsql + "WHERE REPORTID=" + reportId + " "

                odbUtil.UpIns(strsql, Sustain3Connection)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Sub AddColumnName(ByVal reportId As String, ByVal ColId As String, ByVal ColName As String)
            Dim strsql As String = String.Empty
            Dim odbUtil As New DBUtil()
            Try
                strsql = "INSERT INTO USERREPORTCOLUMNS  "
                strsql = strsql + "(USERREPORTCOLUMNSID,REPORTID,COLNO,COLNAME) "
                strsql = strsql + "SELECT SEQUSERREPORTCOLUMNSID.NEXTVAL," + reportId + " ," + ColId + " ,'" + ColName + "' FROM DUAL "
                strsql = strsql + " WHERE NOT EXISTS (SELECT 1 FROM USERREPORTCOLUMNS WHERE REPORTID=" + reportId + " AND COLNO=" + ColId + ")"
                odbUtil.UpIns(strsql, Sustain3Connection)

                strsql = "UPDATE USERREPORTCOLUMNS  "
                strsql = strsql + "SET COLNAME='" + ColName + "'"
                strsql = strsql + " WHERE REPORTID=" + reportId + " AND COLNO=" + ColId
                odbUtil.UpIns(strsql, Sustain3Connection)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        Public Sub AddRowName(ByVal reportId As String, ByVal rowId As String, ByVal rowName As String)
            Dim strsql As String = String.Empty
            Dim odbUtil As New DBUtil()
            Try
                strsql = "INSERT INTO USERREPORTROWS  "
                strsql = strsql + "(USERREPORTROWSID,REPORTID,ROWNO,ROWNAME) "
                strsql = strsql + "SELECT SEQUSERREPORTROWSID.NEXTVAL," + reportId + " ," + rowId + " ,'" + rowName + "' FROM DUAL "
                strsql = strsql + " WHERE NOT EXISTS (SELECT 1 FROM USERREPORTROWS WHERE REPORTID=" + reportId + " AND ROWNO=" + rowId + ")"
                odbUtil.UpIns(strsql, Sustain3Connection)

                strsql = "UPDATE USERREPORTROWS  "
                strsql = strsql + "SET ROWNAME='" + rowName + "'"
                strsql = strsql + " WHERE REPORTID=" + reportId + " AND ROWNO=" + rowId
                odbUtil.UpIns(strsql, Sustain3Connection)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub
#End Region
    End Class
End Class
