Imports Microsoft.VisualBasic
Imports System.Web.SessionState
Imports System.Data
Imports System.Data.OleDb
Imports System

Public Class UsersGetData
    Public Class Selectdata
        Dim EconConnection As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
        Dim ConfigurationConnection As String = System.Configuration.ConfigurationManager.AppSettings("ConfigurationConnectionString")

#Region "Login Details"
        Public Function ValidateUser(ByVal UserName As String, ByVal Password As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim obj As New CryptoHelper
            Try
                StrSql = "select USERID,  "
                StrSql = StrSql + "USERNAME, "
                StrSql = StrSql + "PASSWORD, "
                StrSql = StrSql + "LICENSEID, "
                StrSql = StrSql + "COMPANY, "
                StrSql = StrSql + "ISVALIDEMAIL,"
                StrSql = StrSql + "VERFCODE,"
                StrSql = StrSql + "TO_CHAR(VCREATIONDATE,'MON DD, YYYY')CDATE, "
                'Bug#389
                StrSql = StrSql + "VUPDATEDATE "
                'Bug389
                StrSql = StrSql + "from users "
                StrSql = StrSql + "WHERE Upper(username)='" + UserName.ToUpper() + "'"
                StrSql = StrSql + " AND password='" + obj.Encrypt(Password) + "' "

                'StrSql = StrSql + " AND NVL(USERS.ISVALIDEMAIL,'N')<>'N'"
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)

                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:ValidateUser:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function ValidateUserWithCode(ByVal UserName As String, ByVal Password As String, ByVal VerfCode As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim obj As New CryptoHelper
            Try
                StrSql = "select USERS.USERID,  "
                StrSql = StrSql + "USERNAME, "
                StrSql = StrSql + "PASSWORD, "
                StrSql = StrSql + "LICENSEID, "
                StrSql = StrSql + "COMPANY, "
                StrSql = StrSql + "ISVALIDEMAIL,"
                StrSql = StrSql + "VERFCODE,"
                StrSql = StrSql + "TO_CHAR(VCREATIONDATE,'MON DD, YYYY')CDATE, "
                StrSql = StrSql + "EMAILADDRESS, "
                StrSql = StrSql + "USERCONTACTID, "
                StrSql = StrSql + "(PREFIX||' '||FIRSTNAME||' '||LASTNAME)NAME "

                StrSql = StrSql + "from USERS "
                StrSql = StrSql + "INNER JOIN USERCONTACTS "
                StrSql = StrSql + "ON USERS.USERID=USERCONTACTS.USERID "
                StrSql = StrSql + "WHERE Upper(username)='" + UserName.ToUpper() + "'"
                StrSql = StrSql + " AND password='" + obj.Encrypt(Password) + "' "
                StrSql = StrSql + " AND VERFCODE='" + VerfCode + "' "

                Dts = odbUtil.FillDataSet(StrSql, EconConnection)

                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:ValidateUser:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        'Public Function GetUserDetails(ByVal userId As String) As DataSet
        '    Dim Dts As New DataSet()
        '    Dim odbUtil As New DBUtil()
        '    Dim StrSql As String = String.Empty
        '    Try
        '        StrSql = "SELECT  "
        '        StrSql = StrSql + "USERS.ISPROMOMAIL, "
        '        StrSql = StrSql + "USERCONTACTID, "
        '        StrSql = StrSql + "USERCONTACTS.USERID, "
        '        StrSql = StrSql + "PREFIX, "
        '        StrSql = StrSql + "FIRSTNAME, "
        '        StrSql = StrSql + "LASTNAME,(PREFIX||' '||FIRSTNAME||' '||LASTNAME)NAME,nvl(USERS.IsValidEmail,'N')IsValidEmail, "
        '        StrSql = StrSql + "JOBTITLE, "
        '        StrSql = StrSql + "EMAILADDRESS, "
        '        StrSql = StrSql + "PHONENUMBER, "
        '        StrSql = StrSql + "FAXNUMBER, "
        '        StrSql = StrSql + "COMPANYNAME, "
        '        StrSql = StrSql + "STREETADDRESS1, "
        '        StrSql = StrSql + "STREETADDRESS2, "
        '        StrSql = StrSql + "CITY, "
        '        StrSql = StrSql + "STATE, "
        '        StrSql = StrSql + "ZIPCODE, "
        '        StrSql = StrSql + "COUNTRY "
        '        StrSql = StrSql + "FROM USERCONTACTS "
        '        StrSql = StrSql + "INNER JOIN USERS "
        '        StrSql = StrSql + "ON USERS.USERID=USERCONTACTS.USERID "
        '        StrSql = StrSql + "WHERE USERCONTACTS.USERID  = '" + userId + "'"
        '        Dts = odbUtil.FillDataSet(StrSql, EconConnection)

        '        Return Dts
        '    Catch ex As Exception
        '        Throw New Exception("UsersGetData:GetUserDetails:" + ex.Message.ToString())
        '        Return Dts
        '    End Try
        'End Function

        Public Function GetUserDetails(ByVal userId As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT  "
                StrSql = StrSql + "USERS.USERNAME, "
                StrSql = StrSql + "USERS.ISPROMOMAIL, "
                StrSql = StrSql + "USERCONTACTID, "
                StrSql = StrSql + "USERCONTACTS.USERID, "
                StrSql = StrSql + "PREFIX, "
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME,(PREFIX||' '||FIRSTNAME||' '||LASTNAME)NAME,nvl(USERS.IsValidEmail,'N')IsValidEmail, "
                StrSql = StrSql + "JOBTITLE, "
                StrSql = StrSql + "EMAILADDRESS, "
                StrSql = StrSql + "PHONENUMBER, "
                StrSql = StrSql + "FAXNUMBER, "
                StrSql = StrSql + "COMPANYNAME, "
                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "STREETADDRESS2, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "COUNTRY COUNTRYID, "
                StrSql = StrSql + "(CASE WHEN COUNTRY=0 THEN  '' ELSE COUNTRIES.COUNTRYDES END) COUNTRY "
                StrSql = StrSql + "FROM USERCONTACTS "
                StrSql = StrSql + "INNER JOIN USERS "
                StrSql = StrSql + "ON USERS.USERID=USERCONTACTS.USERID "

                StrSql = StrSql + "INNER JOIN COUNTRIES "
                StrSql = StrSql + "ON COUNTRIES.COUNTRYID=USERCONTACTS.COUNTRY "

                StrSql = StrSql + "WHERE USERCONTACTS.USERID  = '" + userId + "'"
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)

                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:ValidateUser:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function

        Public Function GetUserSubscriptionDetails(ByVal ID As String, ByVal IsLic As Boolean) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT USERS.COMPANY,  "
                StrSql = StrSql + "USERCONTACTS.COMPANYNAME, "
                StrSql = StrSql + "(PREFIX||' '||FIRSTNAME||' '||LASTNAME)NAME, "
                StrSql = StrSql + "TO_CHAR(LICENSEMASTER.SUBSCRPBDATE,'MON DD, YYYY')SBDATE, "
                StrSql = StrSql + "TO_CHAR(LICENSEMASTER.SUBSCRPEDATE,'MON DD, YYYY')SEDATE "
                StrSql = StrSql + "FROM USERS "
                StrSql = StrSql + "LEFT OUTER JOIN USERCONTACTS "
                StrSql = StrSql + "ON USERCONTACTS.USERID  = USERS.USERID "
                StrSql = StrSql + "INNER JOIN LICENSEMASTER "
                StrSql = StrSql + "ON USERS.LICENSEID = LICENSEMASTER.LICENSEID "
                If IsLic Then
                    StrSql = StrSql + "WHERE LICENSEMASTER.LICENSENAME = '" + ID + "' "
                Else
                    StrSql = StrSql + "WHERE USERS.USERID = " + ID + " "
                End If


                Dts = odbUtil.FillDataSet(StrSql, EconConnection)

                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserSubscriptionDetails:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetUserCount(ByVal userName As String) As Integer
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim count As Integer
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT Count(1) As Cnt FROM USERS WHERE upper(USERS.USERNAME)= '" + userName.ToUpper() + "'"
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                count = CInt(Dts.Tables(0).Rows(0).Item("Cnt"))
                Return count
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserCount:" + ex.Message.ToString())
                Return count
            End Try
        End Function
        Public Function GetEmailConfigDetails(ByVal IsPrimary As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT SMTP,  "
                StrSql = StrSql + "URL, "
                StrSql = StrSql + "SMTPUNAME, "
                StrSql = StrSql + "SMTPPWD, "
                StrSql = StrSql + "ISAUNTH, "
                StrSql = StrSql + "HTTPSURL, "
                StrSql = StrSql + "SITE, "
                StrSql = StrSql + "SMTPPORT, "
                StrSql = StrSql + "SMTPISSSL "
                StrSql = StrSql + "FROM EMAILCONFIG "
                StrSql = StrSql + "WHERE ISPRIMARY='" + IsPrimary + "' "
                Dts = odbUtil.FillDataSet(StrSql, ConfigurationConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetEmailConfigDetails:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetUserId(ByVal userName As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT USERS.USERID,  "
                StrSql = StrSql + "USERS.USERNAME, "
                StrSql = StrSql + "USERS.PASSWORD, "
                StrSql = StrSql + "USERCONTACTS.EMAILADDRESS EMAILADD, "
                StrSql = StrSql + "USERCONTACTS.FIRSTNAME FNAME "
                StrSql = StrSql + "FROM USERS "
                StrSql = StrSql + "INNER JOIN USERCONTACTS "
                StrSql = StrSql + "ON USERCONTACTS.USERID=USERS.USERID "
                StrSql = StrSql + "WHERE Upper(USERS.USERNAME)=  '" + userName.ToUpper() + "'"
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserId:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetUserAddressByUserID(ByVal LogInUserID As String, ByVal isWebC As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT USERADDRESSID,  "
                StrSql = StrSql + "USERNAME, "
                StrSql = StrSql + "ADDHEADER,"
                StrSql = StrSql + "PREFIX, "
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "PREFIX ||' '||FIRSTNAME||' '||LASTNAME AS FULLNAME, "
                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "STREETADDRESS2, "
                StrSql = StrSql + "STREETADDRESS1 ||' '|| STREETADDRESS2 ADDRESS, "
                StrSql = StrSql + "PHONENUMBER, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "CO.COUNTRYDES, "
                StrSql = StrSql + "EMAILADDRESS, "
                StrSql = StrSql + "FAXNUMBER, "
                StrSql = StrSql + "COMPANYNAME, "
                StrSql = StrSql + "JOBTITLE "
                StrSql = StrSql + "FROM USERADDRESS UA "
                StrSql = StrSql + "LEFT JOIN  COUNTRIES CO ON UA.COUNTRY=CO.COUNTRYID "
                StrSql = StrSql + "WHERE LOGINUSERID=" + LogInUserID
                If isWebC = "Y" Then
                    StrSql = StrSql + "UNION  "
                    StrSql = StrSql + "SELECT 0 AS USERADDRESSID, "
                    StrSql = StrSql + "'No One Selected' as USERNAME, "
                    StrSql = StrSql + "'NA' ADDHEADER, "
                    StrSql = StrSql + "'NA' PREFIX, "
                    StrSql = StrSql + "'NA' FIRSTNAME, "
                    StrSql = StrSql + "'NA' LASTNAME, "
                    StrSql = StrSql + "'NA' AS FULLNAME, "
                    StrSql = StrSql + "'NA' STREETADDRESS1, "
                    StrSql = StrSql + "'NA' STREETADDRESS2, "
                    StrSql = StrSql + "'NA' ADDRESS, "
                    StrSql = StrSql + "'NA' PHONENUMBER, "
                    StrSql = StrSql + "'NA' CITY, "
                    StrSql = StrSql + "'NA' STATE, "
                    StrSql = StrSql + "'NA' ZIPCODE, "
                    StrSql = StrSql + "'NA' COUNTRYDES, "
                    StrSql = StrSql + "'NA' EMAILADDRESS, "
                    StrSql = StrSql + "'NA' FAXNUMBER, "
                    StrSql = StrSql + "'NA' COMPANYNAME, "
                    StrSql = StrSql + "'NA' JOBTITLE "
                    StrSql = StrSql + "FROM DUAL "
                End If
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserAddressByNameAndUserID:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetUserAddresDetailByID(ByVal UserID As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty

            Try
                StrSql = "SELECT USERADDRESSID,  "
                StrSql = StrSql + "USERNAME, "
                StrSql = StrSql + "ADDHEADER,"
                StrSql = StrSql + "PREFIX, "
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "PREFIX ||' '||FIRSTNAME||' '||LASTNAME AS FULLNAME, "
                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "STREETADDRESS2, "
                StrSql = StrSql + "STREETADDRESS1 ||' '|| STREETADDRESS2 ADDRESS, "
                StrSql = StrSql + "PHONENUMBER, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "CO.COUNTRYDES, "
                StrSql = StrSql + "EMAILADDRESS, "
                StrSql = StrSql + "FAXNUMBER, "
                StrSql = StrSql + "COMPANYNAME, "
                StrSql = StrSql + "JOBTITLE "
                StrSql = StrSql + "FROM USERADDRESS UA "
                StrSql = StrSql + "LEFT JOIN  COUNTRIES CO ON UA.COUNTRY=CO.COUNTRYID "
                StrSql = StrSql + "WHERE USERADDRESSID=" + UserID
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
              
                Return Dts

            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserAddresDetailByID:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetAddresNameByID(ByVal UserID As String) As String
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim strName As String = ""
            Try
                StrSql = "SELECT USERADDRESSID,  "
                StrSql = StrSql + "USERNAME, "
                StrSql = StrSql + "ADDHEADER,"
                StrSql = StrSql + "PREFIX, "
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "PREFIX ||' '||FIRSTNAME||' '||LASTNAME AS FULLNAME, "
                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "STREETADDRESS2, "
                StrSql = StrSql + "STREETADDRESS1 ||' '|| STREETADDRESS2 ADDRESS, "
                StrSql = StrSql + "PHONENUMBER, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "CO.COUNTRYDES, "
                StrSql = StrSql + "EMAILADDRESS, "
                StrSql = StrSql + "FAXNUMBER, "
                StrSql = StrSql + "COMPANYNAME, "
                StrSql = StrSql + "JOBTITLE "
                StrSql = StrSql + "FROM USERADDRESS UA "
                StrSql = StrSql + "LEFT JOIN  COUNTRIES CO ON UA.COUNTRY=CO.COUNTRYID "
                StrSql = StrSql + "WHERE USERADDRESSID=" + UserID
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                If Dts.Tables(0).Rows.Count > 0 Then
                    strName = Dts.Tables(0).Rows(0).Item("UserName").ToString()
                    Return strName
                End If
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserAddressByNameAndUserID:" + ex.Message.ToString())
                Return strName
            End Try
        End Function
        Public Function GetUserAddressByNameID(ByVal userName As String, ByVal LogInUserID As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT USERADDRESSID,  "
                StrSql = StrSql + "USERNAME, "
                StrSql = StrSql + "ADDHEADER,"
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "CO.COUNTRYDES, "
                StrSql = StrSql + "EMAILADDRESS "
                StrSql = StrSql + "FROM USERADDRESS UA "
                StrSql = StrSql + "LEFT JOIN  COUNTRIES CO ON UA.COUNTRY=CO.COUNTRYID "
                StrSql = StrSql + "WHERE LOGINUSERID=" + LogInUserID + " "
                StrSql = StrSql + "AND  UPPER(USERNAME)='" + userName.ToUpper() + "' "
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserAddressByNameAndUserID:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetUserAddressByNameHeadID(ByVal userName As String, ByVal headerText As String, ByVal logInUserID As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT * FROM USERADDRESS  "
                StrSql = StrSql + "WHERE Upper(USERNAME)=  '" + userName.ToUpper() + "' AND UPPER(ADDHEADER)='" + headerText.ToUpper() + "' AND LOGINUSERID=" + logInUserID
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserAddressByName:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetUserAddressIDByHeadID(ByVal headerText As String, ByVal logInUserID As String) As Integer
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim id As Integer
            Try
                StrSql = "SELECT USERADDRESSID FROM USERADDRESS  "
                StrSql = StrSql + "WHERE  UPPER(ADDHEADER)='" + headerText.ToUpper() + "' AND LOGINUSERID=" + logInUserID
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                If Dts.Tables(0).Rows.Count > 0 Then
                    id = Dts.Tables(0).Rows(0)("USERADDRESSID").ToString()
                End If
                Return id
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserAddressByName:" + ex.Message.ToString())
                Return 0
            End Try
        End Function
        Public Function GetAlliedMemberMail(ByVal code As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "select * from ALLIEDADMINMAIL  "
                StrSql = StrSql + "WHERE CODE='" + code.Trim() + "' "
                Dts = odbUtil.FillDataSet(StrSql, ConfigurationConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserId:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetAddressHeaderByUser(ByVal userId As String, ByVal header As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                If header <> "" Then
                    'StrSql = "SELECT * FROM USERADDRESS  "
                    'StrSql = StrSql + "WHERE  NVL(UPPER(ADDRESSHEADER),'#') LIKE '" + header.ToUpper() + "' "
                    'StrSql = StrSql + "AND USERID=" + userId + " "

                    StrSql = "SELECT USERADDRESSID,  "
                    StrSql = StrSql + "USERID, "
                    StrSql = StrSql + "ADDRESSHEADER, "
                    StrSql = StrSql + "PREFIX, "
                    StrSql = StrSql + "PREFIX||' '||FIRSTNAME ||' '||LASTNAME USERNAME,  "
                    StrSql = StrSql + "FIRSTNAME, "
                    StrSql = StrSql + "LASTNAME, "
                    StrSql = StrSql + "JOBTITLE, "
                    StrSql = StrSql + "EMAILADDRESS, "
                    StrSql = StrSql + "PHONENUMBER, "
                    StrSql = StrSql + "FAXNUMBER, "
                    StrSql = StrSql + "COMPANYNAME, "
                    StrSql = StrSql + "STREETADDRESS1, "
                    StrSql = StrSql + "STREETADDRESS2, "
                    StrSql = StrSql + "CITY, "
                    StrSql = StrSql + "STATE, "
                    StrSql = StrSql + "ZIPCODE, "
                    StrSql = StrSql + "COUNTRY "
                    StrSql = StrSql + "FROM USERADDRESS "
                    StrSql = StrSql + "WHERE  NVL(UPPER(ADDRESSHEADER),'#') LIKE '" + header.ToUpper() + "' "
                    StrSql = StrSql + "AND USERID=" + userId + " "
                    StrSql = StrSql + " ORDER BY USERADDRESSID "
                Else
                    'StrSql = "SELECT * FROM USERADDRESS  "
                    'StrSql = StrSql + "WHERE  NVL(UPPER(ADDRESSHEADER),'#') LIKE '" + header.ToUpper() + "%' "
                    'StrSql = StrSql + "AND USERID=" + userId + " "


                    StrSql = "SELECT USERADDRESSID,  "
                    StrSql = StrSql + "USERID, "
                    StrSql = StrSql + "ADDRESSHEADER, "
                    StrSql = StrSql + "PREFIX, "
                    StrSql = StrSql + "PREFIX||' '||FIRSTNAME ||' '||LASTNAME USERNAME,  "
                    StrSql = StrSql + "FIRSTNAME, "
                    StrSql = StrSql + "LASTNAME, "
                    StrSql = StrSql + "JOBTITLE, "
                    StrSql = StrSql + "EMAILADDRESS, "
                    StrSql = StrSql + "PHONENUMBER, "
                    StrSql = StrSql + "FAXNUMBER, "
                    StrSql = StrSql + "COMPANYNAME, "
                    StrSql = StrSql + "STREETADDRESS1, "
                    StrSql = StrSql + "STREETADDRESS2, "
                    StrSql = StrSql + "CITY, "
                    StrSql = StrSql + "STATE, "
                    StrSql = StrSql + "ZIPCODE, "
                    StrSql = StrSql + "COUNTRY "
                    StrSql = StrSql + "FROM USERADDRESS "
                    StrSql = StrSql + "WHERE  NVL(UPPER(ADDRESSHEADER),'#') LIKE '" + header.ToUpper() + "%' "
                    StrSql = StrSql + "AND USERID=" + userId + " "
                    StrSql = StrSql + " ORDER BY USERADDRESSID "
                End If

                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserId:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetUserAddById(ByVal userAddId As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
               

                StrSql = "SELECT  "
                StrSql = StrSql + "U.USERID, "
                StrSql = StrSql + "PREFIX, "
                StrSql = StrSql + "PREFIX||' '||FIRSTNAME ||' '||LASTNAME USERNAME, "
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "JOBTITLE, "
                StrSql = StrSql + "EMAILADDRESS, "
                StrSql = StrSql + "PHONENUMBER, "
                StrSql = StrSql + "FAXNUMBER, "
                StrSql = StrSql + "COMPANYNAME, "
                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "STREETADDRESS2, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "COUNTRY, "
                StrSql = StrSql + "COUNTRYDES, "
                StrSql = StrSql + "U.USERNAME LOGINNAME "
                StrSql = StrSql + "FROM USERCONTACTS UC "
                StrSql = StrSql + "INNER JOIN USERS U ON U.USERID=UC.USERID "
                StrSql = StrSql + "INNER JOIN COUNTRIES CO "
                StrSql = StrSql + "ON UC.COUNTRY=CO.COUNTRYID "
                StrSql = StrSql + "WHERE UC.USERID= " + userAddId


                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserAddById:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetCountry() As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT COUNTRYID,  "
                StrSql = StrSql + "COUNTRYDES "
                StrSql = StrSql + "FROM COUNTRIES "
                StrSql = StrSql + " ORDER BY UPPER(COUNTRYDES)"
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function GetState() As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT STATEID, "
                StrSql = StrSql + "COUNTRYID, "
                StrSql = StrSql + "NAME "
                StrSql = StrSql + "FROM STATE "
                StrSql = StrSql + " ORDER BY UPPER(NAME)"
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function GetStateByDes(ByVal stateDes As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT STATEID, "
                StrSql = StrSql + "COUNTRYID, "
                StrSql = StrSql + "NAME "
                StrSql = StrSql + "FROM STATE "
                StrSql = StrSql + "WHERE UPPER(NAME)='" + stateDes.ToUpper() + "' "
                StrSql = StrSql + " ORDER BY UPPER(NAME)"
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function ValidateUserPWD(ByVal UserID As String, ByVal Password As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Dim obj As New CryptoHelper
            Try
                StrSql = "SELECT USERS.USERID,  "
                StrSql = StrSql + "USERS.USERNAME, "
                StrSql = StrSql + "USERS.PASSWORD, "
                StrSql = StrSql + "USERCONTACTS.EMAILADDRESS EMAILADD, "
                StrSql = StrSql + "USERCONTACTS.FIRSTNAME FNAME "
                StrSql = StrSql + " FROM USERS "
                StrSql = StrSql + "INNER JOIN USERCONTACTS "
                StrSql = StrSql + "ON USERCONTACTS.USERID=USERS.USERID "
                StrSql = StrSql + "WHERE Upper(USERS.USERID)=" + UserID.ToString() + " "
                StrSql = StrSql + " AND USERS.password='" + obj.Encrypt(Password) + "' "

                Dts = odbUtil.FillDataSet(StrSql, EconConnection)

                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:ValidateUserPWD:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        'Public Function GetBillToShipToUserCount(ByVal userid As String, ByVal BilltoShipToId As String) As Integer
        '    Dim Dts As New DataSet()
        '    Dim odbUtil As New DBUtil()
        '    Dim count As Integer
        '    Dim StrSql As String = String.Empty
        '    Try

        '        StrSql = "SELECT COUNT(1) CNT  "
        '        StrSql = StrSql + "FROM BILLTOSHIPTOADDRESS BS "
        '        StrSql = StrSql + "INNER JOIN USERS "
        '        StrSql = StrSql + "ON USERS.USERID=BS.USERID "
        '        StrSql = StrSql + "WHERE "
        '        StrSql = StrSql + "BS.ADDRESSID=" + BilltoShipToId.ToString()
        '        StrSql = StrSql + " AND BS.USERID=" + userid.ToString()

        '        Dts = odbUtil.FillDataSet(StrSql, EconConnection)
        '        count = CInt(Dts.Tables(0).Rows(0).Item("CNT"))
        '        Return count
        '    Catch ex As Exception
        '        Throw New Exception("UsersGetData:GetBillToShipToUserCount:" + ex.Message.ToString())
        '        Return count
        '    End Try
        'End Function

        'Public Function GetBillToShipToByUserId(ByVal UserId As String) As DataSet
        '    Dim Dts As New DataSet()
        '    Dim odbUtil As New DBUtil()
        '    Dim StrSql As String = String.Empty
        '    Try
        '        'StrSql = "SELECT BSA.ADDRESSID,  "
        '        'StrSql = StrSql + "UC.PREFIX||' '||UC.FIRSTNAME ||' '||UC.LASTNAME USERNAME, "
        '        'StrSql = StrSql + "UC.STREETADDRESS1, "
        '        'StrSql = StrSql + "(UC.FIRSTNAME ||' '||UC.LASTNAME ||','||UC.STATE||','||CO.COUNTRYDES) AS ADDRESS, "
        '        'StrSql = StrSql + "UC.CITY, "
        '        'StrSql = StrSql + "UC.STATE, "
        '        'StrSql = StrSql + "CO.COUNTRYDES , "
        '        'StrSql = StrSql + "UC.ZIPCODE "
        '        'StrSql = StrSql + "FROM BILLTOSHIPTOADDRESS BSA "
        '        'StrSql = StrSql + "INNER JOIN  USERCONTACTS UC "
        '        'StrSql = StrSql + "ON UC.USERID=BSA.ADDRESSID "
        '        'StrSql = StrSql + "INNER JOIN  COUNTRIES CO ON UC.COUNTRY=CO.COUNTRYID "
        '        'StrSql = StrSql + "WHERE BSA.USERID= " + UserId.ToString()

        '        StrSql = "SELECT BSA.ADDRESSID,  "
        '        StrSql = StrSql + "UC.PREFIX||' '||UC.FIRSTNAME ||' '||UC.LASTNAME AS USERNAME, "
        '        StrSql = StrSql + "UC.STREETADDRESS1, "
        '        StrSql = StrSql + "U.USERNAME||','|| UC.STATE||','||CO.COUNTRYDES  AS ADDRESS, "
        '        StrSql = StrSql + "UC.CITY, "
        '        StrSql = StrSql + "UC.STATE, "
        '        StrSql = StrSql + "CO.COUNTRYDES , "
        '        StrSql = StrSql + "UC.ZIPCODE "
        '        StrSql = StrSql + "FROM BILLTOSHIPTOADDRESS BSA "
        '        StrSql = StrSql + "INNER JOIN  USERCONTACTS UC "
        '        StrSql = StrSql + "ON UC.USERID=BSA.ADDRESSID "
        '        StrSql = StrSql + "INNER JOIN USERS U "
        '        StrSql = StrSql + "ON U.USERID=UC.USERID "
        '        StrSql = StrSql + "LEFT JOIN  COUNTRIES CO ON UC.COUNTRY=CO.COUNTRYID "
        '        StrSql = StrSql + "WHERE BSA.USERID= " + UserId.ToString()

        '        Dts = odbUtil.FillDataSet(StrSql, EconConnection)

        '        Return Dts
        '    Catch ex As Exception
        '        Throw ex
        '    End Try
        'End Function
        Public Function GetBillToShipToUserDetails(ByVal LogInUserID As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT USERADDRESSID,  "
                StrSql = StrSql + "USERNAME, "
                StrSql = StrSql + "ADDHEADER,"
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "CO.COUNTRYDES, "
                StrSql = StrSql + "EMAILADDRESS "
                StrSql = StrSql + "FROM USERADDRESS UA "
                StrSql = StrSql + "LEFT JOIN  COUNTRIES CO ON UA.COUNTRY=CO.COUNTRYID "
                StrSql = StrSql + "WHERE LOGINUSERID=" + LogInUserID
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetBillToShipToUserDetails:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
      
        Public Function GetBillToShipToUserDetailsByAddID(ByVal UID As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT USERADDRESSID,  "
                StrSql = StrSql + "USERNAME, "
                StrSql = StrSql + "ADDHEADER,"
                StrSql = StrSql + "PREFIX, "
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "PREFIX ||' '||FIRSTNAME||' '||LASTNAME AS FULLNAME, "
                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "STREETADDRESS2, "
                StrSql = StrSql + "JOBTITLE, "
                StrSql = StrSql + "COMPANYNAME, "
                StrSql = StrSql + "FAXNUMBER, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "PHONENUMBER, "
                StrSql = StrSql + "COUNTRY, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "CO.COUNTRYID, "
                StrSql = StrSql + "CO.COUNTRYDES, "
                StrSql = StrSql + "EMAILADDRESS "
                StrSql = StrSql + "FROM USERADDRESS UA "
                StrSql = StrSql + "LEFT JOIN  COUNTRIES CO ON UA.COUNTRY=CO.COUNTRYID "
                StrSql = StrSql + "WHERE USERADDRESSID=" + UID
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetBillToShipToUserDetails:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        'Public Function GetBillToShipToUsers(ByVal userId As String) As DataSet
        '    Dim Dts As New DataSet()
        '    Dim odbUtil As New DBUtil()
        '    Dim StrSql As String = String.Empty
        '    Try
        '        StrSql = "SELECT BSA.ADDRESSID,  "
        '        StrSql = StrSql + "U.USERNAME, "
        '        StrSql = StrSql + "UC.FIRSTNAME , "
        '        StrSql = StrSql + "UC.LASTNAME , "
        '        StrSql = StrSql + "UC.STREETADDRESS1||' '||UC.STREETADDRESS2 ADDRESS, "
        '        StrSql = StrSql + "UC.CITY, "
        '        StrSql = StrSql + "UC.STATE, "
        '        StrSql = StrSql + "CO.COUNTRYDES "

        '        StrSql = StrSql + "FROM BILLTOSHIPTOADDRESS BSA "
        '        StrSql = StrSql + "INNER JOIN  USERCONTACTS UC "
        '        StrSql = StrSql + "ON UC.USERID=BSA.ADDRESSID "
        '        StrSql = StrSql + "INNER JOIN USERS U "
        '        StrSql = StrSql + "ON U.USERID=UC.USERID "
        '        StrSql = StrSql + "LEFT JOIN  COUNTRIES CO ON UC.COUNTRY=CO.COUNTRYID "
        '        StrSql = StrSql + "WHERE BSA.USERID= " + userId.ToString()

        '        Dts = odbUtil.FillDataSet(StrSql, EconConnection)

        '        Return Dts
        '    Catch ex As Exception
        '        Throw ex
        '    End Try
        'End Function

#End Region
#Region "New User Creation August3-2017"
        Public Function CheckUserExist(ByVal userName As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim count As Integer
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT ISSTATUSCOMP STATUS FROM USERS WHERE upper(USERS.USERNAME)= '" + userName.ToUpper() + "' "
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:CheckUserExist:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
        Public Function GetUserIdData(ByVal userName As String) As DataSet
            Dim Dts As New DataSet()
            Dim odbUtil As New DBUtil()
            Dim StrSql As String = String.Empty
            Try
                StrSql = "SELECT USERS.USERID,  "
                StrSql = StrSql + "USERS.USERNAME, "
                StrSql = StrSql + "USERS.PASSWORD, "
                StrSql = StrSql + "USERCONTACTS.EMAILADDRESS EMAILADD, "
                StrSql = StrSql + "USERCONTACTS.FIRSTNAME FNAME,USERS.ISSTATUSCOMP STATUS "
                StrSql = StrSql + "FROM USERS "
                StrSql = StrSql + "INNER JOIN USERCONTACTS "
                StrSql = StrSql + "ON USERCONTACTS.USERID=USERS.USERID "
                StrSql = StrSql + "WHERE Upper(USERS.USERNAME)=  '" + userName.ToUpper() + "'"
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                Return Dts
            Catch ex As Exception
                Throw New Exception("UsersGetData:GetUserId:" + ex.Message.ToString())
                Return Dts
            End Try
        End Function
#End Region
        
    End Class
End Class
