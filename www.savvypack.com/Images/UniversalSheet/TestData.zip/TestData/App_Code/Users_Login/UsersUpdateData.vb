Imports Microsoft.VisualBasic
Imports System.Web.SessionState
Imports System.Data
Imports System.Data.OleDb
Imports System
Public Class UsersUpdateData
    Public Class UpdateInsert
        Dim EconConnection As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
        Public Sub LoginLogOutLogInsert(ByVal UserName As String, ByVal SessionId As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String

            Try
                StrSql = "Insert into LOGINLOGOUTLOG (USERNAME,LOGIN,SESSIONID)  "
                StrSql = StrSql + "VALUES('" + UserName + "',SYSDATE,'" + SessionId + "')"
                odbUtil.UpIns(StrSql, EconConnection)

            Catch ex As Exception
                Throw New Exception("UsersUpdateData:LoginLogOutLogInsert:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub InsertUserDetails(ByVal UserName As String, ByVal password As String, ByVal CompanyName As String, ByVal Prefix As String, ByVal FirstName As String, ByVal LastName As String, ByVal Position As String, ByVal PhoneNumber As String, ByVal FaxNumber As String, ByVal StreetAddress1 As String, ByVal StreetAddress2 As String, ByVal City As String, ByVal State As String, ByVal ZipCode As String, ByVal Country As String, ByVal VerfCode As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String

            Try
                Dim obj As New CryptoHelper
                'Inserting Into User Table
                StrSql = "INSERT INTO USERS  "
                StrSql = StrSql + "(USERID,USERNAME,PASSWORD,COMPANY,VERFCODE,VCREATIONDATE) "
                StrSql = StrSql + "SELECT SEQUSERID.NEXTVAL, "
                StrSql = StrSql + "'" + UserName + "', "
                StrSql = StrSql + "'" + obj.Encrypt(password) + "', "
                StrSql = StrSql + "'" + CompanyName + "', "
                StrSql = StrSql + "'" + VerfCode + "', "
                StrSql = StrSql + "SYSDATE "
                StrSql = StrSql + "FROM DUAL "
                StrSql = StrSql + "WHERE NOT EXISTS "
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT 1 FROM "
                StrSql = StrSql + "USERS "
                StrSql = StrSql + "WHERE Upper(USERS.USERNAME) = '" + UserName.ToUpper() + "' "
                StrSql = StrSql + ") "
                odbUtil.UpIns(StrSql, EconConnection)

                'Inserting Into UserContacts Table
                StrSql = "INSERT INTO USERCONTACTS  "
                StrSql = StrSql + "(USERCONTACTID, "
                StrSql = StrSql + "USERID, "
                StrSql = StrSql + "PREFIX, "
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "JOBTITLE, "
                StrSql = StrSql + "EMAILADDRESS, "
                StrSql = StrSql + "PHONENUMBER, "
                StrSql = StrSql + "FAXNUMBER, "
                StrSql = StrSql + "COMPANYNAME, "
                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "STREETADDRESS2, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "COUNTRY) "
                StrSql = StrSql + "SELECT SEQUSERCONTACTID.NEXTVAL, "
                StrSql = StrSql + "(SELECT USERS.USERID FROM USERS WHERE Upper(USERS.USERNAME)='" + UserName.ToUpper() + "'), "
                StrSql = StrSql + "'" + Prefix + "', "
                StrSql = StrSql + "'" + FirstName + "', "
                StrSql = StrSql + "'" + LastName + "', "
                StrSql = StrSql + "'" + Position + "', "
                StrSql = StrSql + "'" + UserName + "', "
                StrSql = StrSql + "'" + PhoneNumber + "', "
                StrSql = StrSql + "'" + FaxNumber + "', "
                StrSql = StrSql + "'" + CompanyName + "', "
                StrSql = StrSql + "'" + StreetAddress1 + "', "
                StrSql = StrSql + "'" + StreetAddress2 + "', "
                StrSql = StrSql + "'" + City + "', "
                StrSql = StrSql + "'" + State + "', "
                StrSql = StrSql + "'" + ZipCode + "', "
                StrSql = StrSql + "'" + Country + "' "
                StrSql = StrSql + "FROM DUAL "
                StrSql = StrSql + "WHERE NOT EXISTS "
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT 1 FROM "
                StrSql = StrSql + "USERCONTACTS "
                StrSql = StrSql + "WHERE USERCONTACTS.USERID = (SELECT USERS.USERID FROM USERS WHERE  Upper(USERS.USERNAME)='" + UserName.ToUpper() + "') "
                StrSql = StrSql + ") "
                odbUtil.UpIns(StrSql, EconConnection)

                ' Inserting In to UserAddress table

                'StrSql = "INSERT INTO UserAddress  "
                'StrSql = StrSql + "(USERADDRESSID,USERID, ADDRESSHEADER, STREETADDRESS1, STREETADDRESS2, CITY, STATE, ZIPCODE, COUNTRY, PHONENUMBER, FAXNUMBER) "
                'StrSql = StrSql + "SELECT SEQUSERADDID.Nextval,(SELECT USERS.USERID FROM USERS WHERE Upper(USERS.USERNAME)='" + UserName.ToUpper() + "'),'Primary Address','" + StreetAddress1.ToString().Replace("'", "''") + "','" + StreetAddress2.ToString().Replace("'", "''") + "','" + City.ToString().Replace("'", "''") + "','" + State.ToString().Replace("'", "''") + "','" + ZipCode.ToString().Replace("'", "''") + "','" + Country.ToString().Replace("'", "''") + "','" + PhoneNumber.ToString().Replace("'", "''") + "','" + FaxNumber.ToString().Replace("'", "''") + "' FROM DUAL"
                'odbUtil.UpIns(StrSql, EconConnection)

                'StrSql = "INSERT INTO UserAddress  "
                'StrSql = StrSql + "(USERADDRESSID,USERID, ADDRESSHEADER, STREETADDRESS1, STREETADDRESS2, CITY, STATE, ZIPCODE, COUNTRY, PHONENUMBER, FAXNUMBER,EMAILADDRESS,PREFIX,FIRSTNAME,LASTNAME,JOBTITLE,COMPANYNAME) "
                'StrSql = StrSql + "SELECT SEQUSERADDID.Nextval,(SELECT USERS.USERID FROM USERS WHERE Upper(USERS.USERNAME)='" + UserName.ToUpper() + "'),'Primary Address','" + StreetAddress1.ToString().Replace("'", "''") + "','" + StreetAddress2.ToString().Replace("'", "''") + "','" + City.ToString().Replace("'", "''") + "','" + State.ToString().Replace("'", "''") + "','" + ZipCode.ToString().Replace("'", "''") + "','" + Country.ToString().Replace("'", "''") + "','" + PhoneNumber.ToString().Replace("'", "''") + "','" + FaxNumber.ToString().Replace("'", "''") + "', "
                'StrSql = StrSql + "'" + UserName + "', '" + Prefix + "','" + FirstName + "','" + LastName + "','" + Position + "','" + CompanyName + "' FROM DUAL "
                'odbUtil.UpIns(StrSql, EconConnection)

                'insert into Password log
                StrSql = "INSERT INTO  PASSWORDLOG(USERID,PASSWORD,SEQUENCE) "
                StrSql = StrSql + " VALUES((select userid from users where upper(USERNAME)='" + UserName.ToUpper() + "' AND PASSWORD='" + password + "'),'" + password + "',1)"
                odbUtil.UpIns(StrSql, EconConnection)



            Catch ex As Exception
                Throw New Exception("UsersUpdateData:InsertUserDetails:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub InsertUserAddressDetails(ByVal UserName As String, ByVal AddHeader As String, ByVal CompanyName As String, ByVal Prefix As String, ByVal FirstName As String, ByVal LastName As String, ByVal Position As String, ByVal PhoneNumber As String, ByVal FaxNumber As String, ByVal StreetAddress1 As String, ByVal StreetAddress2 As String, ByVal City As String, ByVal State As String, ByVal ZipCode As String, ByVal Country As String, ByVal LoginUserID As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String

            Try

                'Inserting Into USERADDRESS Table
                StrSql = "INSERT INTO USERADDRESS  "
                StrSql = StrSql + "(USERADDRESSID, "
                StrSql = StrSql + "COMPANYNAME, "
                StrSql = StrSql + "LOGINUSERID, "
                StrSql = StrSql + "USERNAME, "
                StrSql = StrSql + "ADDHEADER, "
                StrSql = StrSql + "PREFIX, "
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "JOBTITLE, "
                StrSql = StrSql + "EMAILADDRESS, "
                StrSql = StrSql + "PHONENUMBER, "
                StrSql = StrSql + "FAXNUMBER, "

                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "STREETADDRESS2, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "COUNTRY) "
                StrSql = StrSql + "SELECT SEQUSERADDID.NEXTVAL, "
                StrSql = StrSql + "'" + CompanyName + "', "
                StrSql = StrSql + LoginUserID + ","
                StrSql = StrSql + "'" + UserName + "',"
                StrSql = StrSql + "'" + AddHeader + "',"
                StrSql = StrSql + "'" + Prefix + "', "
                StrSql = StrSql + "'" + FirstName + "', "
                StrSql = StrSql + "'" + LastName + "', "
                StrSql = StrSql + "'" + Position + "', "
                StrSql = StrSql + "'" + UserName + "', "
                StrSql = StrSql + "'" + PhoneNumber + "', "
                StrSql = StrSql + "'" + FaxNumber + "', "
                StrSql = StrSql + "'" + StreetAddress1 + "', "
                StrSql = StrSql + "'" + StreetAddress2 + "', "
                StrSql = StrSql + "'" + City + "', "
                StrSql = StrSql + "'" + State + "', "
                StrSql = StrSql + "'" + ZipCode + "', "
                StrSql = StrSql + "'" + Country + "' "
                StrSql = StrSql + "FROM DUAL "
                StrSql = StrSql + "WHERE NOT EXISTS "
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT 1 FROM "
                StrSql = StrSql + "USERADDRESS "
                StrSql = StrSql + "WHERE UPPER(USERNAME)='" + UserName.ToUpper() + "' AND ADDHEADER='" + AddHeader + "' AND LOGINUSERID=" + LoginUserID + ") "
                odbUtil.UpIns(StrSql, EconConnection)




            Catch ex As Exception
                Throw New Exception("UsersUpdateData:InsertUserDetails:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub InsShoppingCartAddDetails(ByVal UserId As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Dim objGetData As New UsersGetData.Selectdata()
            Dim ds As New DataSet()

            Dim CompanyName As String = ""
            Dim AddHeader As String = ""
            Dim Prefix As String = ""
            Dim FirstName As String = ""
            Dim LastName As String = ""
            Dim Position As String = ""
            Dim PhoneNumber As String = ""
            Dim FaxNumber As String = ""
            Dim StreetAddress1 As String = ""
            Dim StreetAddress2 As String = ""
            Dim City As String = ""
            Dim State As String = ""
            Dim ZipCode As String = ""
            Dim Country As String = ""
            Dim UserName As String = ""

            Try
                'Getting Logged In Users Details by UserId
                ds = objGetData.GetUserAddById(UserId)
                If ds.Tables(0).Rows.Count > 0 Then
                    CompanyName = ds.Tables(0).Rows(0).Item("COMPANYNAME").ToString()
                    AddHeader = "Login User"
                    Prefix = ds.Tables(0).Rows(0).Item("PREFIX").ToString()
                    FirstName = ds.Tables(0).Rows(0).Item("FIRSTNAME").ToString()
                    LastName = ds.Tables(0).Rows(0).Item("LASTNAME").ToString()
                    Position = ds.Tables(0).Rows(0).Item("JOBTITLE").ToString()
                    PhoneNumber = ds.Tables(0).Rows(0).Item("PHONENUMBER").ToString()
                    FaxNumber = ds.Tables(0).Rows(0).Item("FAXNUMBER").ToString()
                    StreetAddress1 = ds.Tables(0).Rows(0).Item("STREETADDRESS1").ToString()
                    StreetAddress2 = ds.Tables(0).Rows(0).Item("STREETADDRESS2").ToString()
                    City = ds.Tables(0).Rows(0).Item("CITY").ToString()
                    State = ds.Tables(0).Rows(0).Item("STATE").ToString()
                    ZipCode = ds.Tables(0).Rows(0).Item("ZIPCODE").ToString()
                    Country = ds.Tables(0).Rows(0).Item("COUNTRY").ToString()
                    UserName = ds.Tables(0).Rows(0).Item("LOGINNAME").ToString()
                End If

                'Inserting Into USERADDRESS Table
                StrSql = "INSERT INTO USERADDRESS  "
                StrSql = StrSql + "(USERADDRESSID, "
                StrSql = StrSql + "COMPANYNAME, "
                StrSql = StrSql + "LOGINUSERID, "
                StrSql = StrSql + "USERNAME, "
                StrSql = StrSql + "ADDHEADER, "
                StrSql = StrSql + "PREFIX, "
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "JOBTITLE, "
                StrSql = StrSql + "EMAILADDRESS, "
                StrSql = StrSql + "PHONENUMBER, "
                StrSql = StrSql + "FAXNUMBER, "

                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "STREETADDRESS2, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "COUNTRY) "
                StrSql = StrSql + "SELECT SEQUSERADDID.NEXTVAL, "
                StrSql = StrSql + "'" + CompanyName + "', "
                StrSql = StrSql + UserId + ","
                StrSql = StrSql + "'" + UserName + "',"
                StrSql = StrSql + "'" + AddHeader + "',"
                StrSql = StrSql + "'" + Prefix + "', "
                StrSql = StrSql + "'" + FirstName + "', "
                StrSql = StrSql + "'" + LastName + "', "
                StrSql = StrSql + "'" + Position + "', "
                StrSql = StrSql + "'" + UserName + "', "
                StrSql = StrSql + "'" + PhoneNumber + "', "
                StrSql = StrSql + "'" + FaxNumber + "', "
                StrSql = StrSql + "'" + StreetAddress1 + "', "
                StrSql = StrSql + "'" + StreetAddress2 + "', "
                StrSql = StrSql + "'" + City + "', "
                StrSql = StrSql + "'" + State + "', "
                StrSql = StrSql + "'" + ZipCode + "', "
                StrSql = StrSql + Country + " "
                StrSql = StrSql + "FROM DUAL "
                StrSql = StrSql + "WHERE NOT EXISTS "
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT 1 FROM "
                StrSql = StrSql + "USERADDRESS "
                StrSql = StrSql + "WHERE LOGINUSERID=" + UserId + ") "
                odbUtil.UpIns(StrSql, EconConnection)


            Catch ex As Exception
                Throw New Exception("UsersUpdateData:InsertUserDetails:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub UpdateUserAddressDetails(ByVal UserIAddId As String, ByVal CompanyName As String, ByVal Prefix As String, ByVal FirstName As String, ByVal LastName As String, ByVal Position As String, ByVal PhoneNumber As String, ByVal FaxNumber As String, ByVal StreetAddress1 As String, ByVal StreetAddress2 As String, ByVal City As String, ByVal State As String, ByVal ZipCode As String, ByVal Country As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Try
                'Update USERCONTACTS
                StrSql = "UPDATE USERADDRESS  "
                StrSql = StrSql + "SET "
                StrSql = StrSql + "PREFIX='" + Prefix + "', "
                StrSql = StrSql + "FIRSTNAME='" + FirstName + "', "
                StrSql = StrSql + "LASTNAME='" + LastName + "', "
                StrSql = StrSql + "JOBTITLE='" + Position + "', "
                StrSql = StrSql + "PHONENUMBER='" + PhoneNumber + "', "
                StrSql = StrSql + "FAXNUMBER='" + FaxNumber + "', "
                StrSql = StrSql + "COMPANYNAME='" + CompanyName + "', "
                StrSql = StrSql + "STREETADDRESS1='" + StreetAddress1 + "', "
                StrSql = StrSql + "STREETADDRESS2='" + StreetAddress2 + "', "
                StrSql = StrSql + "CITY='" + City + "', "
                StrSql = StrSql + "STATE='" + State + "', "
                StrSql = StrSql + "ZIPCODE = '" + ZipCode + "', "
                StrSql = StrSql + "COUNTRY = '" + Country + "' "
                StrSql = StrSql + "WHERE USERADDRESSID=" + UserIAddId + " "
                odbUtil.UpIns(StrSql, EconConnection)

            Catch ex As Exception
                Throw New Exception("UsersUpdateData:UpdateUserDetails:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub UpdateUserDetails(ByVal UserId As String, ByVal UserName As String, ByVal CompanyName As String, ByVal Prefix As String, ByVal FirstName As String, ByVal LastName As String, ByVal Position As String, ByVal PhoneNumber As String, ByVal FaxNumber As String, ByVal StreetAddress1 As String, ByVal StreetAddress2 As String, ByVal City As String, ByVal State As String, ByVal ZipCode As String, ByVal Country As String, ByVal PromoMail As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Try
                'Update USERCONTACTS
                StrSql = "UPDATE USERCONTACTS  "
                StrSql = StrSql + "SET "
                StrSql = StrSql + "USERCONTACTS.PREFIX='" + Prefix + "', "
                StrSql = StrSql + "USERCONTACTS.FIRSTNAME='" + FirstName + "', "
                StrSql = StrSql + "USERCONTACTS.LASTNAME='" + LastName + "', "
                StrSql = StrSql + "USERCONTACTS.JOBTITLE='" + Position + "', "
                StrSql = StrSql + "USERCONTACTS.PHONENUMBER='" + PhoneNumber + "', "
                StrSql = StrSql + "USERCONTACTS.FAXNUMBER='" + FaxNumber + "', "
                StrSql = StrSql + "USERCONTACTS.COMPANYNAME='" + CompanyName + "', "
                StrSql = StrSql + "USERCONTACTS.STREETADDRESS1='" + StreetAddress1 + "', "
                StrSql = StrSql + "USERCONTACTS.STREETADDRESS2='" + StreetAddress2 + "', "
                StrSql = StrSql + "USERCONTACTS.CITY='" + City + "', "
                StrSql = StrSql + "USERCONTACTS.STATE='" + State + "', "
                StrSql = StrSql + "USERCONTACTS.ZIPCODE = '" + ZipCode + "', "
                StrSql = StrSql + "USERCONTACTS.COUNTRY = '" + Country + "' "
                StrSql = StrSql + "WHERE USERCONTACTS.USERID=" + UserId + " "
                odbUtil.UpIns(StrSql, EconConnection)

                'Inserting Into UserContacts Table
                StrSql = String.Empty
                StrSql = "INSERT INTO USERCONTACTS  "
                StrSql = StrSql + "(USERCONTACTID, "
                StrSql = StrSql + "USERID, "
                StrSql = StrSql + "PREFIX, "
                StrSql = StrSql + "FIRSTNAME, "
                StrSql = StrSql + "LASTNAME, "
                StrSql = StrSql + "JOBTITLE, "
                StrSql = StrSql + "EMAILADDRESS, "
                StrSql = StrSql + "PHONENUMBER, "
                StrSql = StrSql + "FAXNUMBER, "
                StrSql = StrSql + "COMPANYNAME, "
                StrSql = StrSql + "STREETADDRESS1, "
                StrSql = StrSql + "STREETADDRESS2, "
                StrSql = StrSql + "CITY, "
                StrSql = StrSql + "STATE, "
                StrSql = StrSql + "ZIPCODE, "
                StrSql = StrSql + "COUNTRY) "
                StrSql = StrSql + "SELECT SEQUSERCONTACTID.NEXTVAL, "
                StrSql = StrSql + UserId + ", "
                StrSql = StrSql + "'" + Prefix + "', "
                StrSql = StrSql + "'" + FirstName + "', "
                StrSql = StrSql + "'" + LastName + "', "
                StrSql = StrSql + "'" + Position + "', "
                StrSql = StrSql + "'" + UserName + "', "
                StrSql = StrSql + "'" + PhoneNumber + "', "
                StrSql = StrSql + "'" + FaxNumber + "', "
                StrSql = StrSql + "'" + CompanyName + "', "
                StrSql = StrSql + "'" + StreetAddress1 + "', "
                StrSql = StrSql + "'" + StreetAddress2 + "', "
                StrSql = StrSql + "'" + City + "', "
                StrSql = StrSql + "'" + State + "', "
                StrSql = StrSql + "'" + ZipCode + "', "
                StrSql = StrSql + "'" + Country + "' "
                StrSql = StrSql + "FROM DUAL "
                StrSql = StrSql + "WHERE NOT EXISTS "
                StrSql = StrSql + "( "
                StrSql = StrSql + "SELECT 1 FROM "
                StrSql = StrSql + "USERCONTACTS "
                StrSql = StrSql + "WHERE USERCONTACTS.USERID =" + UserId + ""
                StrSql = StrSql + ") "
                odbUtil.UpIns(StrSql, EconConnection)

                'Updating User Table
                StrSql = String.Empty
                StrSql = "UPDATE USERS SET ISPROMOMAIL = '" + PromoMail + "' WHERE  USERID=" + UserId + ""
                odbUtil.UpIns(StrSql, EconConnection)

                'Update UserAddress table

                'StrSql = "UPDATE UserAddress  "
                'StrSql = StrSql + "SET STREETADDRESS1='" + StreetAddress1.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + "STREETADDRESS2='" + StreetAddress2.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + " CITY='" + City.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + " STATE='" + State.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + " ZIPCODE='" + ZipCode.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + " COUNTRY='" + Country.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + " PHONENUMBER='" + PhoneNumber.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + " FAXNUMBER='" + FaxNumber.ToString().Replace("'", "''") + "' "
                'StrSql = StrSql + " WHERE ADDRESSHEADER='Primary Address'"



                'StrSql = "Update UserAddress  "
                'StrSql = StrSql + "Set "                
                'StrSql = StrSql + "PREFIX='" + Prefix + "', "
                'StrSql = StrSql + "FIRSTNAME='" + FirstName + "', "
                'StrSql = StrSql + "LASTNAME='" + LastName + "', "
                'StrSql = StrSql + "JOBTITLE='" + Position + "', "
                'StrSql = StrSql + "COMPANYNAME='" + CompanyName + "', "
                'StrSql = StrSql + "STREETADDRESS1='" + StreetAddress1.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + "STREETADDRESS2='" + StreetAddress2.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + "CITY='" + City.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + "ZIPCODE='" + ZipCode.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + "STATE='" + State.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + "COUNTRY='" + Country.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + "PHONENUMBER='" + PhoneNumber.ToString().Replace("'", "''") + "',"
                'StrSql = StrSql + "FAXNUMBER='" + FaxNumber.ToString().Replace("'", "''") + "' "
                'StrSql = StrSql + " WHERE ADDRESSHEADER='Primary Address'"
                'StrSql = StrSql + " AND USERID=" + UserId + ""
                'odbUtil.UpIns(StrSql, EconConnection)

            Catch ex As Exception
                Throw New Exception("UsersUpdateData:UpdateUserDetails:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub UpdateEmailValidationFlag(ByVal UserId As String, ByVal UserName As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Try
                'Updating User detail
                StrSql = String.Empty
                StrSql = "Update Users Set Users.IsValidEmail= 'Y' Where Upper(UserName)= '" + UserName.ToUpper() + "' and  USERID=" + UserId + ""
                odbUtil.UpIns(StrSql, EconConnection)

            Catch ex As Exception
                Throw New Exception("UsersUpdateData:UpdateUserDetails:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub AddUserAddress(ByVal UserId As String, ByVal Header As String, ByVal PhNo As String, ByVal FaxNo As String, ByVal StrAdd1 As String, ByVal StrAdd2 As String, ByVal City As String, ByVal State As String, ByVal Zip As String, ByVal Cntry As String, ByVal email As String, ByVal prefix As String, ByVal FirstNAme As String, ByVal Lastname As String, ByVal CompName As String, ByVal JobTitle As String)
            Dim Ds As New DataSet()
            Dim odbUtil As New DBUtil()
            Try
                Dim StrSql As String = String.Empty
                If UserId <> 0 And Header <> "" Then
                    StrSql = "INSERT INTO UserAddress  "
                    StrSql = StrSql + "(USERADDRESSID,USERID, ADDRESSHEADER, STREETADDRESS1, STREETADDRESS2, CITY, STATE, ZIPCODE, COUNTRY, PHONENUMBER, FAXNUMBER,EMAILADDRESS,PREFIX,FIRSTNAME,LASTNAME,JOBTITLE,COMPANYNAME) "
                    StrSql = StrSql + "SELECT SEQUSERADDID.Nextval," + UserId.ToString() + ",'" + Header.ToString() + "','" + StrAdd1.ToString().Replace("'", "''") + "','" + StrAdd2.ToString().Replace("'", "''") + "','" + City.ToString().Replace("'", "''") + "','" + State.ToString().Replace("'", "''") + "','" + Zip.ToString().Replace("'", "''") + "','" + Cntry.ToString().Replace("'", "''") + "','" + PhNo.ToString().Replace("'", "''") + "','" + FaxNo.ToString().Replace("'", "''") + "', "
                    StrSql = StrSql + "'" + email + "', '" + prefix + "','" + FirstNAme + "','" + Lastname + "','" + JobTitle + "','" + CompName + "' FROM DUAL "
                    StrSql = StrSql + "WHERE NOT EXISTS "
                    StrSql = StrSql + "( "
                    StrSql = StrSql + "SELECT 1 FROM "
                    StrSql = StrSql + "UserAddress "
                    StrSql = StrSql + "WHERE UserAddress.USERID =" + UserId + " And Upper(UserAddress.ADDRESSHEADER)='" + Header.ToUpper() + "' "
                    StrSql = StrSql + ") "


                    odbUtil.UpIns(StrSql, EconConnection)
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        Public Sub UpdateUserAddress(ByVal UserAddressId As String, ByVal Header As String, ByVal PhNo As String, ByVal FaxNo As String, ByVal StrAdd1 As String, ByVal StrAdd2 As String, ByVal City As String, ByVal State As String, ByVal Zip As String, ByVal Cntry As String, ByVal UserId As String, ByVal email As String, ByVal prefix As String, ByVal FirstNAme As String, ByVal Lastname As String, ByVal CompName As String, ByVal JobTitle As String)
            Dim Ds As New DataSet()
            Dim odbUtil As New DBUtil()
            Try
                Dim StrSql As String = String.Empty
                If UserAddressId <> 0 And Header <> "" Then
                    StrSql = "Update UserAddress  "
                    StrSql = StrSql + "Set ADDRESSHEADER='" + Header.ToString().Replace("'", "''") + "', "
                    StrSql = StrSql + "EMAILADDRESS='" + email + "', "
                    StrSql = StrSql + "PREFIX='" + prefix + "', "
                    StrSql = StrSql + "FIRSTNAME='" + FirstNAme + "', "
                    StrSql = StrSql + "LASTNAME='" + Lastname + "', "
                    StrSql = StrSql + "JOBTITLE='" + JobTitle + "', "
                    StrSql = StrSql + "COMPANYNAME='" + CompName + "', "
                    StrSql = StrSql + "STREETADDRESS1='" + StrAdd1.ToString().Replace("'", "''") + "',"
                    StrSql = StrSql + "STREETADDRESS2='" + StrAdd2.ToString().Replace("'", "''") + "',"
                    StrSql = StrSql + "CITY='" + City.ToString().Replace("'", "''") + "',"
                    StrSql = StrSql + "ZIPCODE='" + Zip.ToString().Replace("'", "''") + "',"
                    StrSql = StrSql + "STATE='" + State.ToString().Replace("'", "''") + "',"
                    StrSql = StrSql + "COUNTRY='" + Cntry.ToString().Replace("'", "''") + "',"
                    StrSql = StrSql + "PHONENUMBER='" + PhNo.ToString().Replace("'", "''") + "',"
                    StrSql = StrSql + "FAXNUMBER='" + FaxNo.ToString().Replace("'", "''") + "' "
                    StrSql = StrSql + "Where UserAddressId=" + UserAddressId.ToString().Replace("'", "''") + ""
                    odbUtil.UpIns(StrSql, EconConnection)

                    'Update USERCONTACTS
                    StrSql = "UPDATE USERCONTACTS  "
                    StrSql = StrSql + "SET "
                    StrSql = StrSql + " USERCONTACTS.EMAILADDRESS='" + email + "', "
                    StrSql = StrSql + "  USERCONTACTS.PREFIX='" + prefix + "', "
                    StrSql = StrSql + " USERCONTACTS.FIRSTNAME='" + FirstNAme + "', "
                    StrSql = StrSql + "USERCONTACTS.LASTNAME='" + Lastname + "', "
                    StrSql = StrSql + "USERCONTACTS.JOBTITLE='" + JobTitle + "', "
                    StrSql = StrSql + "USERCONTACTS.COMPANYNAME='" + CompName + "', "
                    StrSql = StrSql + "USERCONTACTS.PHONENUMBER='" + PhNo.ToString().Replace("'", "''") + "', "
                    StrSql = StrSql + "USERCONTACTS.FAXNUMBER='" + FaxNo.ToString().Replace("'", "''") + "', "
                    StrSql = StrSql + "USERCONTACTS.STREETADDRESS1='" + StrAdd1.ToString().Replace("'", "''") + "', "
                    StrSql = StrSql + "USERCONTACTS.STREETADDRESS2='" + StrAdd2.ToString().Replace("'", "''") + "', "
                    StrSql = StrSql + "USERCONTACTS.CITY='" + City.ToString().Replace("'", "''") + "', "
                    StrSql = StrSql + "USERCONTACTS.STATE='" + State.ToString().Replace("'", "''") + "', "
                    StrSql = StrSql + "USERCONTACTS.ZIPCODE = '" + Zip.ToString().Replace("'", "''") + "', "
                    StrSql = StrSql + "USERCONTACTS.COUNTRY = '" + Cntry.ToString().Replace("'", "''") + "' "
                    StrSql = StrSql + "WHERE USERCONTACTS.USERID=" + UserId + " "
                    odbUtil.UpIns(StrSql, EconConnection)
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        Public Sub ChangePWD(ByVal UserID As String, ByVal pwd As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Dim obj As New CryptoHelper
            Try

                StrSql = "UPDATE USERS "
                StrSql = StrSql + " SET PASSWORD='" + obj.Encrypt(pwd.ToString()) + "' "
                StrSql = StrSql + " WHERE UserID = " + UserID
                odbUtil.UpIns(StrSql, EconConnection)

            Catch ex As Exception
                Throw New Exception("UsersUpdateData:ChangePWD:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub UpdatePWDLog(ByVal UserID As String, ByVal pwd As String, ByVal count As Integer)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Dim Dts As New DataSet()


            Try
                StrSql = "SELECT * "
                StrSql = StrSql + " FROM PASSWORDLOG "
                StrSql = StrSql + "WHERE Upper(USERID)=" + UserID.ToString() + ""
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                count = Dts.Tables(0).Rows.Count
                If count < 5 Then
                    StrSql = "INSERT INTO PASSWORDLOG(USERID,PASSWORD,SEQUENCE) "
                    count = count + 1
                    StrSql = StrSql + "VALUES(" + UserID.ToString() + ",'" + pwd.ToString() + "'," + count.ToString() + ") "
                    odbUtil.UpIns(StrSql, EconConnection)
                Else
                    StrSql = "DELETE FROM PASSWORDLOG WHERE USERID=" + UserID + " AND SEQUENCE=1"
                    odbUtil.UpIns(StrSql, EconConnection)
                    StrSql = "UPDATE PASSWORDLOG "
                    StrSql = StrSql + " SET SEQUENCE=1 WHERE SEQUENCE=2 AND USERID=" + UserID
                    odbUtil.UpIns(StrSql, EconConnection)

                    StrSql = "UPDATE PASSWORDLOG "
                    StrSql = StrSql + " SET SEQUENCE=2 WHERE SEQUENCE=3 AND USERID=" + UserID
                    odbUtil.UpIns(StrSql, EconConnection)

                    StrSql = "UPDATE PASSWORDLOG "
                    StrSql = StrSql + " SET SEQUENCE=3 WHERE SEQUENCE=4 AND USERID=" + UserID
                    odbUtil.UpIns(StrSql, EconConnection)

                    StrSql = "UPDATE PASSWORDLOG "
                    StrSql = StrSql + " SET SEQUENCE=4 WHERE SEQUENCE=5 AND USERID=" + UserID
                    odbUtil.UpIns(StrSql, EconConnection)

                    StrSql = "INSERT INTO PASSWORDLOG(USERID,PASSWORD,SEQUENCE) "
                    StrSql = StrSql + "VALUES(" + UserID + ",'" + pwd + "',5) "
                    odbUtil.UpIns(StrSql, EconConnection)

                End If

            Catch ex As Exception
                Throw New Exception("UsersUpdateData:ChangePWD:" + ex.Message.ToString())
            End Try

        End Sub
#Region "New User Creation August3-2017"
        Public Sub UpdateINCOMPUserDetails(ByVal UserName As String, ByVal password As String, ByVal CompanyName As String, ByVal Prefix As String, ByVal FirstName As String, ByVal LastName As String, ByVal Position As String, ByVal PhoneNumber As String, ByVal FaxNumber As String, ByVal StreetAddress1 As String, ByVal StreetAddress2 As String, ByVal City As String, ByVal State As String, ByVal ZipCode As String, ByVal Country As String, ByVal VerfCode As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String

            Try
                'Bug#389
                'Inserting Into User Table
                StrSql = "UPDATE USERS  "
                StrSql = StrSql + "SET USERNAME='" + UserName + "', "
                StrSql = StrSql + "PASSWORD='" + password + "', "
                StrSql = StrSql + "COMPANY='" + CompanyName + "', "
                StrSql = StrSql + "VERFCODE='" + VerfCode + "', "
                StrSql = StrSql + "ISSTATUSCOMP='Y',ISVALIDEMAIL='Y', "
                StrSql = StrSql + "VCREATIONDATE=SYSDATE,VUPDATEDATE=SYSDATE,LOCKDATE=CURRENT_Timestamp-interval '17' minute "
                StrSql = StrSql + "WHERE Upper(USERS.USERNAME) = '" + UserName.ToUpper() + "' "
                'Bug#389
                odbUtil.UpIns(StrSql, EconConnection)

                'Inserting Into UserContacts Table
                StrSql = "UPDATE USERCONTACTS  "
                StrSql = StrSql + "SET PREFIX='" + Prefix + "', "
                StrSql = StrSql + "FIRSTNAME='" + FirstName + "', "
                StrSql = StrSql + "LASTNAME='" + LastName + "', "
                StrSql = StrSql + "JOBTITLE='" + Position + "', "
                StrSql = StrSql + "EMAILADDRESS='" + UserName + "', "
                StrSql = StrSql + "PHONENUMBER='" + PhoneNumber + "', "
                StrSql = StrSql + "FAXNUMBER='" + FaxNumber + "', "
                StrSql = StrSql + "COMPANYNAME='" + CompanyName + "', "
                StrSql = StrSql + "STREETADDRESS1='" + StreetAddress1 + "', "
                StrSql = StrSql + "STREETADDRESS2='" + StreetAddress2 + "', "
                StrSql = StrSql + "CITY='" + City + "', "
                StrSql = StrSql + "STATE='" + State + "', "
                StrSql = StrSql + "ZIPCODE='" + ZipCode + "', "
                StrSql = StrSql + "COUNTRY='" + Country + "' "
                StrSql = StrSql + "WHERE USERCONTACTS.USERID = (SELECT USERS.USERID FROM USERS WHERE Upper(USERS.USERNAME)='" + UserName.ToUpper() + "') "

                odbUtil.UpIns(StrSql, EconConnection)

                'Bug#389
                StrSql = "INSERT INTO  PASSWORDLOG(USERID,PASSWORD,SEQUENCE) "
                StrSql = StrSql + " VALUES((select userid from users where upper(USERNAME)='" + UserName.ToUpper() + "' AND PASSWORD='" + password + "'),'" + password + "',1)"
                odbUtil.UpIns(StrSql, EconConnection)
                'Bug#389

                'Bug#379
                StrSql = "INSERT INTO INKPREFERENCES  "
                StrSql = StrSql + "(USERNAME) "
                StrSql = StrSql + "VALUES('" + UserName.Trim() + "')"
                odbUtil.UpIns(StrSql, EconConnection)
                'Bug#379

            Catch ex As Exception
                Throw New Exception("UsersUpdateData:UpdateUserDetails:" + ex.Message.ToString())
            End Try

        End Sub
#End Region
        'Public Sub InsertBillToShipToUser(ByVal UserID As String, ByVal BiilToShipToId As String)
        '    Dim odbUtil As New DBUtil()
        '    Dim StrSql As String

        '    Try

        '        StrSql = "INSERT INTO BILLTOSHIPTOADDRESS(USERID,ADDRESSID)  "
        '        StrSql = StrSql + "SELECT " + UserID.ToString() + " ," + BiilToShipToId.ToString() + "  FROM DUAL "
        '        StrSql = StrSql + "WHERE NOT EXISTS (SELECT * FROM BILLTOSHIPTOADDRESS WHERE USERID=" + UserID.ToString() + " AND ADDRESSID=" + BiilToShipToId.ToString() + ") "

        '        odbUtil.UpIns(StrSql, EconConnection)

        '    Catch ex As Exception
        '        Throw New Exception("UsersUpdateData:ChangePWD:" + ex.Message.ToString())
        '    End Try

        'End Sub
    End Class
End Class
