Imports Microsoft.VisualBasic
Imports System.Web.SessionState
Imports System.Data
Imports System.Data.OleDb
Imports System

Public Class LoginUpdateData
    Public Class Selectdata
        Dim EconConnection As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
        Dim Econ2Connection As String = System.Configuration.ConfigurationManager.AppSettings("Econ2ConnectionString")
        Dim Econ3Connection As String = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
        Dim Econ4Connection As String = System.Configuration.ConfigurationManager.AppSettings("Econ4ConnectionString")
        Dim Sustain1Connection As String = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
        Dim Sustain2Connection As String = System.Configuration.ConfigurationManager.AppSettings("Sustain2ConnectionString")
        Dim Sustain3Connection As String = System.Configuration.ConfigurationManager.AppSettings("Sustain3ConnectionString")
        Dim Sustain4Connection As String = System.Configuration.ConfigurationManager.AppSettings("Sustain4ConnectionString")
        Dim SpecConnection As String = System.Configuration.ConfigurationManager.AppSettings("SpecConnectionString")
        Dim Schem1Connection As String = System.Configuration.ConfigurationManager.AppSettings("Schem1ConnectionString")
        Dim Echem1Connection As String = System.Configuration.ConfigurationManager.AppSettings("Echem1ConnectionString")
        Dim Market1Connection As String = System.Configuration.ConfigurationManager.AppSettings("Market1ConnectionString")
        Dim ContractConnection As String = System.Configuration.ConfigurationManager.AppSettings("ContractConnectionString")
        Dim ReportConnection As String = System.Configuration.ConfigurationManager.AppSettings("ReportConnectionString")
        Dim DistributionConnection As String = System.Configuration.ConfigurationManager.AppSettings("DistributionConnectionString")
        Dim RetailConnection As String = System.Configuration.ConfigurationManager.AppSettings("RetailConnectionString")
        Dim PackProdConnection As String = System.Configuration.ConfigurationManager.AppSettings("PackProdConnectionString")
        Dim SDistributionConnection As String = System.Configuration.ConfigurationManager.AppSettings("SDistributionConnectionString")
        Dim VChainConnection As String = System.Configuration.ConfigurationManager.AppSettings("VChainConnectionString")
        Dim SBAConnection As String = System.Configuration.ConfigurationManager.AppSettings("SBAConnectionString")

#Region "Bug#Security"
        Public Sub UUnlockAccount(ByVal UserName As String, ByVal Status As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Try
                'Update AccountLocked
                StrSql = "UPDATE USERS "
                StrSql = StrSql + " SET ISLOCK='" + Status + "'"
                StrSql = StrSql + " where UPPER(USERNAME)='" + UserName.ToUpper() + "'"
                odbUtil.UpIns(StrSql, EconConnection)

            Catch ex As Exception
                Throw New Exception("LoginUpdateData:UUnlockAccount:" + ex.Message.ToString())
            End Try
        End Sub
        Public Sub UAccountLocked(ByVal UserName As String, ByVal Status As String, ByVal LockDate As Date)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Try
                'Update AccountLocked
                StrSql = "UPDATE USERS "
                StrSql = StrSql + " SET ISLOCK='" + Status + "'"
                StrSql = StrSql + ",LOCKDATE=sysdate"
                StrSql = StrSql + " where UPPER(USERNAME)='" + UserName.ToUpper() + "'"
                odbUtil.UpIns(StrSql, EconConnection)

            Catch ex As Exception
                Throw New Exception("LoginUpdateData:UAccountLocked:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub UpdatePWDLog(ByVal UserID As String, ByVal pwd As String, ByVal count As Integer)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Dim Dts As New DataSet()
            Try
                StrSql = "SELECT * "
                StrSql = StrSql + " FROM PASSWORDLOG "
                StrSql = StrSql + "WHERE Upper(USERID)=" + UserID.ToString() + ""
                Dts = odbUtil.FillDataSet(StrSql, EconConnection)
                count = Dts.Tables(0).Rows.Count
                If count < 5 Then
                    StrSql = "INSERT INTO PASSWORDLOG(USERID,PASSWORD,SEQUENCE) "
                    count = count + 1
                    StrSql = StrSql + "VALUES(" + UserID.ToString() + ",'" + pwd.ToString() + "'," + count.ToString() + ") "
                    odbUtil.UpIns(StrSql, EconConnection)
                Else
                    StrSql = "DELETE FROM PASSWORDLOG WHERE USERID=" + UserID + " AND SEQUENCE=1"
                    odbUtil.UpIns(StrSql, EconConnection)
                    StrSql = "UPDATE PASSWORDLOG "
                    StrSql = StrSql + " SET SEQUENCE=1 WHERE SEQUENCE=2 AND USERID=" + UserID
                    odbUtil.UpIns(StrSql, EconConnection)

                    StrSql = "UPDATE PASSWORDLOG "
                    StrSql = StrSql + " SET SEQUENCE=2 WHERE SEQUENCE=3 AND USERID=" + UserID
                    odbUtil.UpIns(StrSql, EconConnection)

                    StrSql = "UPDATE PASSWORDLOG "
                    StrSql = StrSql + " SET SEQUENCE=3 WHERE SEQUENCE=4 AND USERID=" + UserID
                    odbUtil.UpIns(StrSql, EconConnection)

                    StrSql = "UPDATE PASSWORDLOG "
                    StrSql = StrSql + " SET SEQUENCE=4 WHERE SEQUENCE=5 AND USERID=" + UserID
                    odbUtil.UpIns(StrSql, EconConnection)

                    StrSql = "INSERT INTO PASSWORDLOG(USERID,PASSWORD,SEQUENCE) "
                    StrSql = StrSql + "VALUES(" + UserID + ",'" + pwd + "',5) "
                    odbUtil.UpIns(StrSql, EconConnection)

                End If

            Catch ex As Exception
                Throw New Exception("UsersUpdateData:ChangePWD:" + ex.Message.ToString())
            End Try

        End Sub
#End Region

        Public Sub InuseLoginInsert(ByVal sessionID As String, ByVal username As String, ByVal licenseID As String, ByVal schema As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.AppSettings(schema)
            Try
                'Insert into Inuse table
                StrSql = "Insert into inuse (sessionID,username,licenseID) "
                StrSql = StrSql + "VALUES('" + sessionID + "','" + username + "','" + licenseID + "')"
                odbUtil.UpIns(StrSql, ConnectionString)

                'Insert into loginlog table
                StrSql = "Insert into loginlog (serverdate,username,sessionID) "
                StrSql = StrSql + "VALUES(sysdate,'" + username + "','" + sessionID + "')"
                odbUtil.UpIns(StrSql, ConnectionString)

            Catch ex As Exception
                Throw New Exception("LoginUpdateData:InuseLoginInsert:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub InuseLoginInsertReport(ByVal sessionID As String, ByVal username As String, ByVal licenseID As String, ByVal schema As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.AppSettings(schema)
            Try
                'Insert into Inuse table
                StrSql = "Insert into inuse (sessionID,username,licenseID) "
                StrSql = StrSql + "VALUES('" + sessionID + "','" + username + "','" + licenseID + "')"
                odbUtil.UpIns(StrSql, ConnectionString)

                'Insert into loginlog table
                StrSql = "Insert into loginlog (serverdate,username ) "
                StrSql = StrSql + "VALUES(sysdate,'" + username + "')"
                odbUtil.UpIns(StrSql, ConnectionString)

            Catch ex As Exception
                Throw New Exception("LoginUpdateData:InuseLoginInsert:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub InuseLoginInsertContract(ByVal sessionID As String, ByVal username As String, ByVal licenseID As String, ByVal clientIP As String, ByVal clientCO As String, ByVal clientBROWSER As String, ByVal schema As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.AppSettings(schema)
            Try
                'Insert into Inuse table
                StrSql = "Insert into inuse (sessionID,username,licenseID) "
                StrSql = StrSql + "VALUES('" + sessionID + "','" + username + "','" + licenseID + "')"
                odbUtil.UpIns(StrSql, ConnectionString)

                'Insert into loginlog table
                StrSql = "Insert into loginlog (serverdate,username,sessionID,clientIP,clientCO,clientBROWSER) "
                StrSql = StrSql + "VALUES(sysdate,'" + username + "','" + sessionID + "','" + clientIP + "','" + clientCO + "','" + clientBROWSER + "')"
                odbUtil.UpIns(StrSql, ConnectionString)

            Catch ex As Exception
                Throw New Exception("LoginUpdateData:InuseLoginInsertContract:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub InuseLoginInsertPackProd(ByVal sessionID As String, ByVal username As String, ByVal licenseID As String, ByVal clientIP As String, ByVal clientCO As String, ByVal clientBROWSER As String, ByVal schema As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.AppSettings(schema)
            Try
                'Insert into Inuse table
                StrSql = "Insert into inuse (sessionID,username,licenseID) "
                StrSql = StrSql + "VALUES('" + sessionID + "','" + username + "','" + licenseID + "')"
                odbUtil.UpIns(StrSql, ConnectionString)

                'Insert into loginlog table
                StrSql = "Insert into loginlog (serverdate,username,sessionID,clientIP,clientCO,clientBROWSER) "
                StrSql = StrSql + "VALUES(sysdate,'" + username + "','" + sessionID + "','" + clientIP + "','" + clientCO + "','" + clientBROWSER + "')"
                odbUtil.UpIns(StrSql, ConnectionString)

            Catch ex As Exception
                Throw New Exception("LoginUpdateData:InuseLoginInsertPackProd:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub InsertSelection(ByVal username As String, ByVal schema As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.AppSettings(schema)
            Try
                'Insert into Selection table
                StrSql = "INSERT INTO SELECTION (SERVERDATE,USERNAME, COMPANY, PRODUCT, COMPANY2, STATE, SERVICE, DESIGN, MACHINE, PROCESS, CUSTOMER) "
                StrSql = StrSql + "VALUES (sysdate,'" + username + "',0,0,0,0,0,0,0,0,0)"
                odbUtil.UpIns(StrSql, ConnectionString)

            Catch ex As Exception
                Throw New Exception("LoginUpdateData:InsertSelection:" + ex.Message.ToString())
            End Try

        End Sub

        Public Sub ULoginInsert(ByVal UID As String, ByVal UserName As String, ByVal UserPassword As String)
            Dim odbUtil As New DBUtil()
            Dim StrSql As String

            Try
                'Delete the existing UID from Ulogin table
                StrSql = "delete ulogin where id= " + UID
                odbUtil.UpIns(StrSql, EconConnection)

                'Insert into Ulogin table
                StrSql = "Insert into Ulogin (ID,uname,upwd,logindate) "
                StrSql = StrSql + "VALUES('" + UID + "','" + UserName + "','" + UserPassword + "',sysdate)"
                odbUtil.UpIns(StrSql, EconConnection)


            Catch ex As Exception
                Throw New Exception("LoginUpdateData:ULoginInsert:" + ex.Message.ToString())
            End Try

        End Sub
        Public Sub UpdateInuseLogoutLog(ByVal username As String, ByVal password As String)
            Dim odbutil As New DBUtil()
            Dim objGetData As New LoginGetData.Selectdata()
            Dim ds As New DataSet()
            Try
                'Getting and deleting Inuse detail for ECon1
                DeleteInuseDetails(username, EconConnection, "EconConnectionString", "")
                'Getting and deleting Inuse detail for ECon2
                DeleteInuseDetails(username, Econ2Connection, "Econ2ConnectionString", "")
                'Getting and deleting Inuse detail for ECon3
                DeleteInuseDetails(username, Econ3Connection, "Econ3ConnectionString", "")
                'Getting and deleting Inuse detail for ECon4
                DeleteInuseDetails(username, Econ4Connection, "Econ4ConnectionString", "")
                'Getting and deleting Inuse detail for Sustain1
                DeleteInuseDetails(username, Sustain1Connection, "Sustain1ConnectionString", "")
                'Getting and deleting Inuse detail for Sustain2
                DeleteInuseDetails(username, Sustain2Connection, "Sustain2ConnectionString", "")
                'Getting and deleting Inuse detail for Sustain3
                DeleteInuseDetails(username, Sustain3Connection, "Sustain3ConnectionString", "")
                'Getting and deleting Inuse detail for Sustain4
                DeleteInuseDetails(username, Sustain4Connection, "Sustain4ConnectionString", "")
                'Getting and deleting Inuse detail for Spec
                DeleteInuseDetails(username, SpecConnection, "SpecConnectionString", "")
                'Getting and deleting Inuse detail for SChem1
                DeleteInuseDetails(username, Schem1Connection, "Schem1ConnectionString", "")
                'Getting and deleting Inuse detail for EChem1
                DeleteInuseDetails(username, Echem1Connection, "Echem1ConnectionString", "")
                'Getting and deleting Inuse detail for Market1
                DeleteInuseDetails(username, Market1Connection, "Market1ConnectionString", "")
                'Getting and deleting Inuse detail for Contract
                DeleteInuseDetails(username, ContractConnection, "ContractConnectionString", "contract")
                'Getting and deleting Inuse detail for Reports
                DeleteInuseDetails(username, ReportConnection, "ReportConnectionString", "report")
                'Getting and deleting Inuse detail for Distribution
                DeleteInuseDetails(username, DistributionConnection, "DistributionConnectionString", "")
                'Getting and deleting Inuse detail for Retail
                DeleteInuseDetails(username, RetailConnection, "RetailConnectionString", "")
                'Getting and deleting Inuse detail for Packaging Producer
                DeleteInuseDetails(username, PackProdConnection, "PackProdConnectionString", "PackProd")
                'Getting and deleting Inuse detail for SDistribution
                DeleteInuseDetails(username, SDistributionConnection, "SDistributionConnectionString", "SDist")
                'Getting and deleting Inuse detail for Value Chain
                DeleteInuseDetails(username, VChainConnection, "VChainConnectionString", "VChain")
                'Getting and deleting Inuse detail for SBA
                DeleteInuseDetails(username, SBAConnection, "SBAConnectionString", "Sassist")


            Catch ex As Exception
                Throw New Exception("LoginUpdateData:UpdateInuseLogoutLog:" + ex.Message.ToString())
            End Try
        End Sub
        Public Sub DeleteInuseDetails(ByVal username As String, ByVal strCon As String, ByVal schema As String, ByVal flag As String)
            Dim odbutil As New DBUtil()
            Dim StrSql As String
            Dim objGetData As New LoginGetData.Selectdata()
            Dim ds As New DataSet()
            Try

                ds = objGetData.GetInUseTableInfo(username, schema)
                If ds.Tables(0).Rows.Count > 0 Then
                    'Delete from inuse table
                   
                    StrSql = "delete from inuse where Upper(username)='" + username.ToUpper() + "'"
                    odbutil.UpIns(StrSql, strCon)


                    'Insert into Logoutlog table
                    StrSql = "insert into Logoutlog(serverdate,username,path) "
                    StrSql = StrSql + "values(sysdate,'" + Trim(username) + "','LR')"
                    odbutil.UpIns(StrSql, strCon)


                End If


            Catch ex As Exception
                Throw New Exception("LoginUpdateData:DeleteInuseDetails:" + ex.Message.ToString())
            End Try


        End Sub
        Public Sub UpdateLogOffDetails(ByVal username As String, ByVal type As String, ByVal sessionId As String)

            If type = "E1" Then
                LogOffUpdate(username, sessionId, EconConnection)
            ElseIf type = "E2" Then
                LogOffUpdate(username, sessionId, Econ2Connection)
            ElseIf type = "E3" Then
                LogOffUpdate(username, sessionId, Econ3Connection)
            ElseIf type = "E4" Then
                LogOffUpdate(username, sessionId, Econ4Connection)
            ElseIf type = "S1" Then
                LogOffUpdate(username, sessionId, Sustain1Connection)
            ElseIf type = "S2" Then
                LogOffUpdate(username, sessionId, Sustain2Connection)
            ElseIf type = "S3" Then
                LogOffUpdate(username, sessionId, Sustain3Connection)
            ElseIf type = "S4" Then
                LogOffUpdate(username, sessionId, Sustain4Connection)
            ElseIf type = "SCH1" Then
                LogOffUpdate(username, sessionId, Schem1Connection)
            ElseIf type = "ECH1" Then
                LogOffUpdate(username, sessionId, Echem1Connection)
            ElseIf type = "M1" Then
                LogOffUpdate(username, sessionId, Market1Connection)
            ElseIf type = "SPEC" Then
                LogOffUpdate(username, sessionId, SpecConnection)
            ElseIf type = "Contract" Then
                LogOffContractUpdate(username, sessionId, ContractConnection)
            ElseIf type = "DIST" Then
                LogOffUpdate(username, sessionId, DistributionConnection)
            ElseIf type = "Retl" Then
                LogOffUpdate(username, sessionId, RetailConnection)
            ElseIf type = "PackProd" Then
                LogOffContractUpdate(username, sessionId, PackProdConnection)
            ElseIf type = "SDist" Then
                LogOffUpdate(username, sessionId, SDistributionConnection)
            ElseIf type = "VChain" Then
                LogOffUpdate(username, sessionId, VChainConnection)
            ElseIf type = "StandAssist" Then
                LogOffUpdate(username, sessionId, SBAConnection)

            End If
        End Sub
        Public Sub LogOffUpdate(ByVal username As String, ByVal sessionId As String, ByVal schema As String)
            'Deleting from Inuse table
            Dim odbutil As New DBUtil()
            Dim StrSql As String
            Dim ds As New DataSet()
            StrSql = "delete from inuse where sessionid='" + sessionId + "'"
            odbutil.UpIns(StrSql, schema)
            'Inserting in LogoutLog table
            StrSql = ""
            StrSql = "insert into Logoutlog(serverdate,username,sessionid,path) "
            StrSql = StrSql + "values(sysdate,'" + Trim(username) + "','" + sessionId + "','L')"
            odbutil.UpIns(StrSql, schema)
        End Sub
        Public Sub LogOffContractUpdate(ByVal username As String, ByVal sessionId As String, ByVal schema As String)
            'Deleting from Inuse table
            Dim odbutil As New DBUtil()
            Dim StrSql As String
            Dim ds As New DataSet()
            StrSql = "delete from inuse where sessionid='" + sessionId + "'"
            odbutil.UpIns(StrSql, schema)
            'Inserting in LogoutLog table
            StrSql = ""
            StrSql = "insert into Logoutlog(serverdate,username,sessionid,path) "
            StrSql = StrSql + "values(sysdate,'" + Trim(username) + "','" + sessionId + "','L')"
            odbutil.UpIns(StrSql, schema)
        End Sub
        Public Sub UpdatePassword(ByVal userId As String, ByVal password As String)
            Dim odbutil As New DBUtil()
            Dim StrSql As String
            StrSql = "Update USERS SET USERS.PASSWORD ='" + password + "'"
            StrSql = StrSql + " WHERE USERS.USERID=" + userId
            odbutil.UpIns(StrSql, EconConnection)
        End Sub
        Public Sub InsertUserDetails(ByVal userName As String, ByVal password As String, ByVal CorpUserName As String, ByVal CorpPassword As String)
            Dim odbutil As New DBUtil()
            Dim StrSql As String
            StrSql = "INSERT INTO USERS  "
            StrSql = StrSql + "(USERNAME,PASSWORD,USERID,COMPANY,LICENSENO,ISVALIDEMAIL) "
            StrSql = StrSql + "SELECT '" + userName.Trim() + "', '"
            StrSql = StrSql + password.Trim() + "', "
            StrSql = StrSql + "SEQUSERID.NEXTVAL, "
            StrSql = StrSql + "CORPORATEUSERS.COMPANY, "
            StrSql = StrSql + "CORPORATEUSERS.COMPANY||SEQUSERID.NEXTVAL,'Y' FROM CORPORATEUSERS WHERE Upper(CORPORATEUSERS.USERNAME)='" + CorpUserName.ToUpper() + "' "
            StrSql = StrSql + "AND Upper(CORPORATEUSERS.PASSWORD)='" + CorpPassword.ToUpper() + "' "
            odbutil.UpIns(StrSql, EconConnection)

        End Sub
        Public Sub UpdateUser(ByVal userId As String)
            Dim odbutil As New DBUtil
            Dim StrSql As String
            'Dim connStr As String
            'connStr = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
            StrSql = " UPDATE USERS "
            StrSql = StrSql + "SET USERS.ISCORPORATEUSER = '' "
            StrSql = StrSql + "WHERE USERID=" + userId + ""
            odbutil.UpIns(StrSql, EconConnection)

            StrSql = " DELETE FROM USERPERMISSIONS "
            StrSql = StrSql & "WHERE USERID=" & userId & ""
            StrSql = StrSql & "AND NVL(ISCORPORATEPERMISSION,'A') = 'C' "
            odbutil.UpIns(StrSql, EconConnection)



        End Sub
        Public Sub InsertUserPermissions(ByVal userId As String, ByVal CUserId As String)
            Dim odbutil As New DBUtil
            Dim StrSql As String
            'Dim connStr As String
            'connStr = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
            'Update The User table
            StrSql = " UPDATE USERS "
            StrSql = StrSql & "SET USERS.ISCORPORATEUSER = 'C' "
            StrSql = StrSql & "WHERE USERID=" & userId & ""
            odbutil.UpIns(StrSql, EconConnection)

            'Adding The Permissions
            StrSql = " INSERT INTO USERPERMISSIONS (USERID,SERVICEID,USERROLE,ISCORPORATEPERMISSION)  "
            StrSql = StrSql & "SELECT " & userId & ", "
            StrSql = StrSql & "CORPORATEUSERPERMISSIONS.SERVICEID, "
            StrSql = StrSql & "CORPORATEUSERPERMISSIONS.USERROLE, "
            StrSql = StrSql & "'C' "
            StrSql = StrSql & "FROM CORPORATEUSERPERMISSIONS  "
            StrSql = StrSql & "INNER JOIN CORPORATEUSERS A  "
            StrSql = StrSql & "ON A.CORPORATEUSERID=CORPORATEUSERPERMISSIONS.CORPORATEUSERID  "
            'StrSql = StrSql & "INNER JOIN SERVICES "
            'StrSql = StrSql & "ON  SERVICES.SERVICEID  = CORPORATEUSERPERMISSIONS.SERVICEID "
            'StrSql = StrSql & "AND SERVICES.SERVICEDE IN('ECON1','ECON2','SUSTAIN1','SUSTAIN2')"
            StrSql = StrSql & "AND A.CORPORATEUSERID =" & CUserId & " "
            StrSql = StrSql & "WHERE NOT EXISTS "
            StrSql = StrSql & "( "
            StrSql = StrSql & "SELECT 1  "
            StrSql = StrSql & "FROM USERPERMISSIONS "
            StrSql = StrSql & "WHERE USERPERMISSIONS.USERID=" & userId & " "
            StrSql = StrSql & "AND USERPERMISSIONS.SERVICEID=CORPORATEUSERPERMISSIONS.SERVICEID "
            StrSql = StrSql & ") "

            odbutil.UpIns(StrSql, EconConnection)





        End Sub
        Public Sub UpdateLogOffDetails2(ByVal username As String, ByVal Tid As String, ByVal sessionId As String)

            'If Tid = "1" Or Tid = "4" Then 
            LogOffUpdate2(username, sessionId, EconConnection)
            'ElseIf Tid = "2" Then
            LogOffUpdate2(username, sessionId, Econ2Connection)
            'ElseIf Tid = "3" Then
            LogOffUpdate2(username, sessionId, Econ3Connection)
            'ElseIf Tid = "5" Then
            LogOffUpdate2(username, sessionId, Sustain1Connection)
            'ElseIf Tid = "6" Then
            LogOffUpdate2(username, sessionId, Sustain2Connection)
            'ElseIf Tid = "8" Then
            LogOffUpdate2(username, sessionId, Schem1Connection)
            'ElseIf Tid = "9" Then
            LogOffUpdate2(username, sessionId, Sustain3Connection)
            'ElseIf Tid = "10" Then
            LogOffUpdate2(username, sessionId, Sustain4Connection)
            'ElseIf Tid = "11" Then
            LogOffUpdate2(username, sessionId, Econ4Connection)
            'ElseIf Tid = "7" Then
            LogOffUpdate2(username, sessionId, Echem1Connection)
            'ElseIf Tid = "12" Then
            LogOffUpdate2(username, sessionId, Market1Connection)
            'ElseIf Tid = "13" Then
            LogOffUpdate2(username, sessionId, SpecConnection)
            'ElseIf Tid = "18" Then
            LogOffUpdate2(username, sessionId, DistributionConnection)
            'ElseIf Tid = "19" Then
            LogOffUpdate2(username, sessionId, RetailConnection)
            'ElseIf Tid = "20" Then
            LogOffUpdate2(username, sessionId, PackProdConnection)
            'ElseIf Tid = "21" Then
            LogOffUpdate2(username, sessionId, ContractConnection)
            'ElseIf Tid = "22" Then
            LogOffUpdate2(username, sessionId, SDistributionConnection)
            'ElseIf Tid = "23" Then
            LogOffUpdate2(username, sessionId, VChainConnection)
            'ElseIf Tid = "28" Then
            LogOffUpdate2(username, sessionId, SBAConnection)
            'End If
        End Sub
        Public Sub LogOffUpdate2(ByVal username As String, ByVal sessionId As String, ByVal schema As String)
            'Deleting from Inuse table
            Dim odbutil As New DBUtil()
            Dim StrSql As String
            Dim objGetData As New LoginGetData.Selectdata()
            Dim ds As New DataSet()
            Try
                'Getting inuse detail
                StrSql = "select * from inuse  WHERE Upper(username)= '" + username.ToUpper() + "'"
                ds = odbutil.FillDataSet(StrSql, schema)

                If ds.Tables(0).Rows.Count > 0 Then

                    'Deleting Inuse Detail
                    StrSql = "delete from inuse where sessionid='" + sessionId + "'"
                    odbutil.UpIns(StrSql, schema)
                    'Inserting in LogoutLog table
                    StrSql = ""
                    StrSql = "insert into Logoutlog(serverdate,username,path) "
                    StrSql = StrSql + "values(sysdate,'" + Trim(username) + "','G')"
                    odbutil.UpIns(StrSql, schema)
                End If

            Catch ex As Exception
                Throw New Exception("LoginUpdateData:DeleteInuseDetails:" + ex.Message.ToString())
            End Try
           
        End Sub
        Public Sub InsertLicense(ByVal userName As String, ByVal password As String, ByVal modName As String)
            'Inserting in License table
            Dim odbutil As New DBUtil()
            Dim StrSql As String
            Dim License1 As String
            License1 = "License1"
            If modName <> "CONTR" And modName <> "PACKPROD" And modName <> "REPORT" Then
                StrSql = "INSERT INTO license (username, license, serverdate) "
                StrSql = StrSql + "values('" & userName & "','" & License1 & "',TO_DATE('" & Now & "','mm/dd/yyyy hh:mi:ss pm'))"
                odbutil.UpIns(StrSql, EconConnection)
            ElseIf modName = "CONTR" Then
                StrSql = "INSERT INTO license (username, license, serverdate) "
                StrSql = StrSql + "values('" & userName & "','" & License1 & "',TO_DATE('" & Now & "','mm/dd/yyyy hh:mi:ss pm'))"
                odbutil.UpIns(StrSql, ContractConnection)
            ElseIf modName = "PACKPROD" Then
                StrSql = "INSERT INTO license (username, license, serverdate) "
                StrSql = StrSql + "values('" & userName & "','" & License1 & "',TO_DATE('" & Now & "','mm/dd/yyyy hh:mi:ss pm'))"
                odbutil.UpIns(StrSql, PackProdConnection)
            ElseIf modName = "REPORT" Then
                StrSql = "INSERT INTO license (username, license, serverdate) "
                StrSql = StrSql + "values('" & userName & "','" & License1 & "',TO_DATE('" & Now & "','mm/dd/yyyy hh:mi:ss pm'))"
                odbutil.UpIns(StrSql, ReportConnection)

            End If

        End Sub
    End Class

End Class
