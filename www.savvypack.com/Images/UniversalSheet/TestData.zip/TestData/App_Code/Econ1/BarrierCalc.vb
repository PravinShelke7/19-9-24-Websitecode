﻿Imports Microsoft.VisualBasic
Imports System.Web.SessionState
Imports System.Data
Imports System.Data.OleDb
Imports System.Collections
Imports System
Imports E1GetData
Imports System.Math
Imports System.Web.UI.HtmlTextWriter

Public Class BarrierCalc
    Public Class Calculations
        Dim EconConnection As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
        Public OTR(10) As String
        Public TotalOTR As String
        Public TotalWVTR As String
        Public WVTR(10) As String
        Public OTRds As DataSet
        Public WVTRds As DataSet
        Public MidTemp1 As String
        Public MidTemp2 As String
        Public Msg As String
        Dim objGetData As New E1GetData.Selectdata
        Dim Tempds As DataSet
        Dim RHds As DataSet
        Dim Ds As DataSet
        Dim OTRMsg, WVTRmsg As String
        Dim Templow, Temphigh, RHlow, RHhigh As String


        Dim path As String = "C:\Sudhanshu\Raxa_Code\AlliedProject\Log\TimeLog.txt"
        Dim objLog As New LogFiles.CreateLogFiles

        Public Sub BarrierPropCalculate(ByVal CaseID As Integer, ByVal OTRFlag As Integer, ByVal WVTRFlag As Integer, ByVal Temp As String, ByVal Temp2 As String, ByVal RH As String, ByVal RH2 As String)

            TotalOTR = "0"
            TotalWVTR = "0"
            Ds = objGetData.GetBarrierInput(CaseID)
            OTRMsg = ""
            WVTRmsg = ""
            Msg = ""

            objLog.WriteTimeLog1(path)
            objLog.WriteTimeLog(path, "GetOTRValues Start at :              ")
            OTRds = objGetData.GetOTRValues(CaseID, OTRFlag)
            objLog.WriteTimeLog(path, "GetOTRValues End at :              ")

            objLog.WriteTimeLog1(path)
            objLog.WriteTimeLog(path, "GetWVTRValues Start at :              ")
            WVTRds = objGetData.GetWVTRValues(CaseID, WVTRFlag)
            objLog.WriteTimeLog(path, "GetWVTRValues End at :              ")

            For i = 1 To 10
                If OTRds.Tables(0).Rows(0).Item("GRADE" + (i).ToString()).ToString() <> 0 Then
                    If OTRFlag = 1 Then
                        If OTRds.Tables(0).Rows(0).Item("OTR" + i.ToString() + "M").ToString() = "" Then
                            If Not OTRMsg.Contains(OTRds.Tables(0).Rows(0).Item("M" + i.ToString()).ToString()) Then
                                OTRMsg = OTRMsg + "" + OTRds.Tables(0).Rows(0).Item("MATS" + i.ToString()).ToString() + " (OTR)\n"
                            End If

                        End If

                    ElseIf OTRFlag = 2 Or OTRFlag = 3 Or OTRFlag = 4 Then
                        If OTRds.Tables(0).Rows(0).Item("OTR1" + (i - 1).ToString() + "M").ToString() = "" Then
                            If Not OTRMsg.Contains(OTRds.Tables(0).Rows(0).Item("M" + i.ToString()).ToString()) Then
                                OTRMsg = OTRMsg + "" + OTRds.Tables(0).Rows(0).Item("MATS" + i.ToString()).ToString() + " (OTR)\n"
                            End If
                        End If

                    End If
                    If WVTRFlag = 1 Then
                        If WVTRds.Tables(0).Rows(0).Item("WVTR" + i.ToString() + "M").ToString() = "" Then
                            If Not WVTRmsg.Contains(WVTRds.Tables(0).Rows(0).Item("M" + i.ToString()).ToString()) Then
                                WVTRmsg = WVTRmsg + "" + WVTRds.Tables(0).Rows(0).Item("MATS" + i.ToString()).ToString() + " (WVTR)\n"
                            End If
                        End If
                    ElseIf WVTRFlag = 2 Or WVTRFlag = 3 Or WVTRFlag = 4 Then

                        If WVTRds.Tables(0).Rows(0).Item("WVTR1" + (i - 1).ToString() + "M").ToString() = "" Then
                            If Not WVTRmsg.Contains(WVTRds.Tables(0).Rows(0).Item("M" + i.ToString()).ToString()) Then
                                WVTRmsg = WVTRmsg + "" + WVTRds.Tables(0).Rows(0).Item("MATS" + i.ToString()).ToString() + " (WVTR)\n"
                            End If
                        End If
                    End If

                End If
            Next

            If OTRMsg <> "" Or WVTRmsg <> "" Then
                Msg = "Data is not present for following materials for Date " + CDate(Ds.Tables(0).Rows(0).Item("EFFDATE").ToString()).Date + "\n"
                If OTRMsg <> "" Then
                    Msg = Msg + OTRMsg + ""
                End If
                If WVTRmsg <> "" Then
                    Msg = Msg + WVTRmsg + ""
                End If
            End If


            If OTRFlag = 1 Then
                For i = 0 To 9
                    If OTRds.Tables(0).Rows(0).Item("GRADE" + (i + 1).ToString()) <> 0 Then
                        If OTRds.Tables(0).Rows(0).Item("ISTHICK" + (i + 1).ToString()) <> "N" Then
                            OTR(i) = CDbl(OTRds.Tables(0).Rows(0).Item("OTR" + (i + 1).ToString())) / CDbl(OTRds.Tables(0).Rows(0).Item("THICK" + (i + 1).ToString()))
                        Else
                            OTR(i) = CDbl(OTRds.Tables(0).Rows(0).Item("OTR" + (i + 1).ToString()))
                        End If

                    Else
                        OTR(i) = "0"
                    End If

                Next
            ElseIf OTRFlag = 2 Then
                Tempds = objGetData.GetBasrrierHighLowTemp(Temp)
                RHds = objGetData.GetBasrrierHighLowHumidity(RH)
                Templow = Tempds.Tables(0).Rows(0).Item("TEMPVAL").ToString()
                Temphigh = Tempds.Tables(0).Rows(1).Item("TEMPVAL").ToString()
                RHlow = RHds.Tables(0).Rows(0).Item("RHVALUE").ToString()
                RHhigh = RHds.Tables(0).Rows(1).Item("RHVALUE").ToString()
                For i = 0 To 9
                    If OTRds.Tables(0).Rows(0).Item("GRADE" + (i + 1).ToString()) <> 0 Then
                        MidTemp1 = CDbl(OTRds.Tables(0).Rows(0).Item("OTR1" + i.ToString())) + (CDbl(Temp - Templow) / CDbl(Temphigh - Templow) * (CDbl(CDbl(OTRds.Tables(0).Rows(0).Item("OTR3" + i.ToString())) - CDbl(CDbl(OTRds.Tables(0).Rows(0).Item("OTR1" + i.ToString()))))))
                        MidTemp2 = CDbl(OTRds.Tables(0).Rows(0).Item("OTR2" + i.ToString())) + (CDbl(Temp - Templow) / CDbl(Temphigh - Templow) * (CDbl(CDbl(OTRds.Tables(0).Rows(0).Item("OTR4" + i.ToString())) - CDbl(CDbl(OTRds.Tables(0).Rows(0).Item("OTR2" + i.ToString()))))))
                        OTR(i) = MidTemp1 + ((RH - RHlow) / (RHhigh - RHlow) * (MidTemp2 - MidTemp1))
                        If OTRds.Tables(0).Rows(0).Item("ISTHICK" + (i + 1).ToString()) <> "N" Then
                            OTR(i) = CDbl(OTR(i)) / CDbl(OTRds.Tables(0).Rows(0).Item("THICK" + (i + 1).ToString()))
                        End If
                    Else
                        OTR(i) = "0"
                    End If

                Next

            ElseIf OTRFlag = 3 Then

                RHds = objGetData.GetBasrrierHighLowHumidity(RH)

                RHlow = RHds.Tables(0).Rows(0).Item("RHVALUE").ToString()
                RHhigh = RHds.Tables(0).Rows(1).Item("RHVALUE").ToString()
                For i = 0 To 9
                    If OTRds.Tables(0).Rows(0).Item("GRADE" + (i + 1).ToString()) <> 0 Then
                        OTR(i) = CDbl(OTRds.Tables(0).Rows(0).Item("OTR1" + i.ToString())) + ((RH - RHlow) / (RHhigh - RHlow) * (CDbl(OTRds.Tables(0).Rows(0).Item("OTR2" + i.ToString())) - CDbl(OTRds.Tables(0).Rows(0).Item("OTR1" + i.ToString()))))

                        If OTRds.Tables(0).Rows(0).Item("ISTHICK" + (i + 1).ToString()) <> "N" Then
                            OTR(i) = CDbl(OTR(i)) / CDbl(OTRds.Tables(0).Rows(0).Item("THICK" + (i + 1).ToString()))
                        End If
                    Else
                        OTR(i) = "0"
                    End If
                Next

            ElseIf OTRFlag = 4 Then
                Tempds = objGetData.GetBasrrierHighLowTemp(Temp)

                Templow = Tempds.Tables(0).Rows(0).Item("TEMPVAL").ToString()
                Temphigh = Tempds.Tables(0).Rows(1).Item("TEMPVAL").ToString()

                For i = 0 To 9
                    If OTRds.Tables(0).Rows(0).Item("GRADE" + (i + 1).ToString()) <> 0 Then
                        OTR(i) = CDbl(OTRds.Tables(0).Rows(0).Item("OTR1" + i.ToString())) + (CDbl(Temp - Templow) / CDbl(Temphigh - Templow) * (CDbl(CDbl(OTRds.Tables(0).Rows(0).Item("OTR2" + i.ToString())) - CDbl(CDbl(OTRds.Tables(0).Rows(0).Item("OTR1" + i.ToString()))))))
                        If OTRds.Tables(0).Rows(0).Item("ISTHICK" + (i + 1).ToString()) <> "N" Then
                            OTR(i) = CDbl(OTR(i)) / CDbl(OTRds.Tables(0).Rows(0).Item("THICK" + (i + 1).ToString()))
                        End If
                    Else
                        OTR(i) = "0"
                    End If
                Next
            End If

            'WVTR calculations

            If WVTRFlag = 1 Then
                For i = 0 To 9
                    If WVTRds.Tables(0).Rows(0).Item("GRADE" + (i + 1).ToString()) <> 0 Then
                        If WVTRds.Tables(0).Rows(0).Item("ISTHICK" + (i + 1).ToString()) <> "N" Then
                            WVTR(i) = CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR" + (i + 1).ToString())) / CDbl(WVTRds.Tables(0).Rows(0).Item("THICK" + (i + 1).ToString()))
                        Else
                            WVTR(i) = CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR" + (i + 1).ToString()))
                        End If
                    Else
                        WVTR(i) = "0"
                    End If

                Next
            ElseIf WVTRFlag = 2 Then
                Tempds = objGetData.GetBasrrierHighLowTemp(Temp2)
                RHds = objGetData.GetBasrrierHighLowHumidity(RH2)
                Templow = Tempds.Tables(0).Rows(0).Item("TEMPVAL").ToString()
                Temphigh = Tempds.Tables(0).Rows(1).Item("TEMPVAL").ToString()
                RHlow = RHds.Tables(0).Rows(0).Item("RHVALUE").ToString()
                RHhigh = RHds.Tables(0).Rows(1).Item("RHVALUE").ToString()
                For i = 0 To 9
                    If WVTRds.Tables(0).Rows(0).Item("GRADE" + (i + 1).ToString()) <> 0 Then
                        MidTemp1 = CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR1" + i.ToString())) + (CDbl(Temp2 - Templow) / CDbl(Temphigh - Templow) * (CDbl(CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR3" + i.ToString())) - CDbl(CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR1" + i.ToString()))))))
                        MidTemp2 = CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR2" + i.ToString())) + (CDbl(Temp2 - Templow) / CDbl(Temphigh - Templow) * (CDbl(CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR4" + i.ToString())) - CDbl(CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR2" + i.ToString()))))))
                        WVTR(i) = MidTemp1 + ((RH2 - RHlow) / (RHhigh - RHlow) * (MidTemp2 - MidTemp1))
                        If WVTRds.Tables(0).Rows(0).Item("ISTHICK" + (i + 1).ToString()) <> "N" Then
                            WVTR(i) = CDbl(WVTR(i)) / CDbl(WVTRds.Tables(0).Rows(0).Item("THICK" + (i + 1).ToString()))
                        End If
                    Else
                        WVTR(i) = "0"
                    End If

                Next

            ElseIf WVTRFlag = 3 Then

                RHds = objGetData.GetBasrrierHighLowHumidity(RH2)

                RHlow = RHds.Tables(0).Rows(0).Item("RHVALUE").ToString()
                RHhigh = RHds.Tables(0).Rows(1).Item("RHVALUE").ToString()
                For i = 0 To 9
                    If WVTRds.Tables(0).Rows(0).Item("GRADE" + (i + 1).ToString()) <> 0 Then
                        WVTR(i) = CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR1" + i.ToString())) + ((RH2 - RHlow) / (RHhigh - RHlow) * (CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR2" + i.ToString())) - CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR1" + i.ToString()))))
                        If WVTRds.Tables(0).Rows(0).Item("ISTHICK" + (i + 1).ToString()) <> "N" Then
                            WVTR(i) = CDbl(WVTR(i)) / CDbl(WVTRds.Tables(0).Rows(0).Item("THICK" + (i + 1).ToString()))
                        End If
                    Else
                        WVTR(i) = "0"
                    End If
                Next

            ElseIf WVTRFlag = 4 Then
                Tempds = objGetData.GetBasrrierHighLowTemp(Temp2)

                Templow = Tempds.Tables(0).Rows(0).Item("TEMPVAL").ToString()
                Temphigh = Tempds.Tables(0).Rows(1).Item("TEMPVAL").ToString()

                For i = 0 To 9
                    If WVTRds.Tables(0).Rows(0).Item("GRADE" + (i + 1).ToString()) <> 0 Then
                        WVTR(i) = CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR1" + i.ToString())) + (CDbl(Temp2 - Templow) / CDbl(Temphigh - Templow) * (CDbl(CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR2" + i.ToString())) - CDbl(CDbl(WVTRds.Tables(0).Rows(0).Item("WVTR1" + i.ToString()))))))

                        If WVTRds.Tables(0).Rows(0).Item("ISTHICK" + (i + 1).ToString()) <> "N" Then
                            WVTR(i) = CDbl(WVTR(i)) / CDbl(WVTRds.Tables(0).Rows(0).Item("THICK" + (i + 1).ToString()))
                        End If
                    Else
                        WVTR(i) = "0"
                    End If
                Next
            End If

            'TotalOTR = "0"
            For i = 0 To 9
                If OTRds.Tables(0).Rows(0).Item("GRADE" + (i + 1).ToString()).ToString() <> 0 Then
                    If OTR(i) <> 0 Then
                        If Not IsNumeric(Ds.Tables(0).Rows(0).Item("OTR" + (i + 1).ToString())) Then
                            TotalOTR = CDbl(TotalOTR) + (1 / CDbl(OTR(i)))
                        Else
                            'If (Ds.Tables(0).Rows(0).Item("OTR" + (i + 1).ToString())) <> 0 Then
                            TotalOTR = CDbl(TotalOTR) + (1 / CDbl(Ds.Tables(0).Rows(0).Item("OTR" + (i + 1).ToString())))
                            'End If


                        End If
                    Else
                        If IsNumeric(Ds.Tables(0).Rows(0).Item("OTR" + (i + 1).ToString())) Then
                            'If (Ds.Tables(0).Rows(0).Item("OTR" + (i + 1).ToString())) <> 0 Then
                            '    TotalOTR = CDbl(TotalOTR) + (1 / CDbl(Ds.Tables(0).Rows(0).Item("OTR" + (i + 1).ToString())))
                            'End If
                            TotalOTR = CDbl(TotalOTR) + (1 / CDbl(Ds.Tables(0).Rows(0).Item("OTR" + (i + 1).ToString())))
                        Else
                            TotalOTR = CDbl(TotalOTR) + (1 / CDbl(OTR(i)))
                        End If

                    End If
                End If


            Next
            If TotalOTR <> "0" Then
                TotalOTR = 1 / CDbl(TotalOTR)
            End If

            'TotalWVTR = "0"
            For i = 0 To 9
                If OTRds.Tables(0).Rows(0).Item("GRADE" + (i + 1).ToString()).ToString() <> 0 Then
                    If WVTR(i) <> 0 Then
                        If Not IsNumeric(Ds.Tables(0).Rows(0).Item("WVTR" + (i + 1).ToString())) Then
                            TotalWVTR = CDbl(TotalWVTR) + (1 / CDbl(WVTR(i)))
                        Else
                            'If (Ds.Tables(0).Rows(0).Item("WVTR" + (i + 1).ToString())) <> 0 Then
                            TotalWVTR = CDbl(TotalWVTR) + (1 / CDbl(Ds.Tables(0).Rows(0).Item("WVTR" + (i + 1).ToString())))
                            'End If

                        End If
                    Else
                        If IsNumeric(Ds.Tables(0).Rows(0).Item("WVTR" + (i + 1).ToString())) Then
                            'If (Ds.Tables(0).Rows(0).Item("WVTR" + (i + 1).ToString())) <> 0 Then
                            TotalWVTR = CDbl(TotalWVTR) + (1 / CDbl(Ds.Tables(0).Rows(0).Item("WVTR" + (i + 1).ToString())))
                        Else
                            TotalWVTR = CDbl(TotalWVTR) + (1 / CDbl(WVTR(i)))
                            'End If
                        End If
                    End If
                End If


            Next
            If TotalWVTR <> "0" Then
                TotalWVTR = 1 / CDbl(TotalWVTR)
            End If

        End Sub
    End Class
End Class
