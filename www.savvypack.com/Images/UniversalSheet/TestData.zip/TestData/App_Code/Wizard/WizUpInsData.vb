﻿Imports Microsoft.VisualBasic
Imports System.Web.SessionState
Imports System.Data
Imports System.Data.OleDb
Imports System
Imports WizGetData
Imports System.Math
Imports System.Web.UI.HtmlTextWriter

Public Class WizUpInsData
    Public Class UpdateInsert
        Dim connectionStringS1 As String = System.Configuration.ConfigurationManager.ConnectionStrings("SustainConn").ConnectionString.ToString()
        Dim connectionStringS2 As String = System.Configuration.ConfigurationManager.ConnectionStrings("Sustain2Conn").ConnectionString.ToString()
        Dim connectionStringE1 As String = System.Configuration.ConfigurationManager.ConnectionStrings("EconConn").ConnectionString.ToString()
        Dim connectionStringE2 As String = System.Configuration.ConfigurationManager.ConnectionStrings("EconConn").ConnectionString.ToString()
        Dim odbutil As New DBUtil()
#Region "Messages"


        Public Sub DeleteUserMessages(ByVal UserId As Integer, ByVal MessageId As String)
            Try
                Dim StrSql As String = String.Empty
                StrSql = "INSERT INTO USEERDELETDMSG  "
                StrSql = StrSql + "(USERID,MESSAGEID,SERVERDATE) "
                StrSql = StrSql + "VALUES "
                StrSql = StrSql + "(" + UserId.ToString() + "," + MessageId.ToString() + ",SYSDATE) "
                odbutil.UpIns(StrSql, connectionStringE1)
            Catch ex As Exception
                Throw New Exception("UpInsData:DeleteUserMessages:" + ex.Message.ToString())
            End Try
        End Sub

#End Region

    End Class
End Class
