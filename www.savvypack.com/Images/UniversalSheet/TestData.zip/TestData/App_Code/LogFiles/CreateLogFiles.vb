﻿Imports System.IO
Imports System.Text
Imports System.Data

Namespace LogFiles
    Public Class CreateLogFiles
        Private sLogFormat As String
        Private sErrorTime As String

        Public Sub New()
            'sLogFormat used to create log files format :
            ' dd/mm/yyyy hh:mm:ss AM/PM ==> Log Message
            sLogFormat = DateTime.Now.ToShortDateString().ToString() & " " & DateTime.Now.ToLongTimeString().ToString() & " "
            'this variable used to create log filename format "
            'for example filename : ErrorLogYYYYMMDD
            Dim sYear As String = DateTime.Now.Year.ToString()
            Dim sMonth As String = DateTime.Now.Month.ToString()
            Dim sDay As String = DateTime.Now.Day.ToString()
            sErrorTime = sMonth + "_" + sDay + "_" + sYear
        End Sub

        Public Sub LoginConflictLog(ByVal sPathName As String, ByVal userName As String, ByVal license As String, ByVal modName As String)
            Dim sw As New StreamWriter(sPathName, True)
            ' sw.WriteLine("***************************************************************************************************")
            Try
                sw.WriteLine("***************************************************************************************************")
                sw.WriteLine("Login conflict on " + sLogFormat + " for:")
                sw.WriteLine("    User: " + userName)
                sw.WriteLine("    License: " + license)
                sw.WriteLine("    Module: " + modName)
                sw.Flush()
                sw.Close()
            Catch ex As Exception
            End Try
        End Sub

        Public Sub WriteData(ByVal sPathName As String, ByVal sErrMsg As String, ByVal ds As DataSet)
            Dim sw As New StreamWriter(sPathName, True)
            Dim i As Integer
            Try
                sw.WriteLine(sErrMsg)
                sw.WriteLine("User Name ,Date")
                For i = 0 To ds.Tables(0).Rows.Count - 1
                    sw.WriteLine(ds.Tables(0).Rows(i).Item("PERSDES").ToString() + ", " + ds.Tables(0).Rows(i).Item("ARCHSALARY").ToString())
                Next              
                sw.Flush()
                sw.Close()
            Catch ex As Exception
            End Try
        End Sub
        Public Sub WriteTimeLog(ByVal sPathName As String, ByVal funName As String)
            Dim sw As New StreamWriter(sPathName, True)

            Try
                'sw.WriteLine("***************************************************************************************************")
                'sw.WriteLine(sPathName)
                sw.WriteLine(funName + "        Date:" + DateTime.Now.Date.ToString() + "        Time Hour:" + DateTime.Now.Hour.ToString() + " Min:" + Now.Minute.ToString() + " Sec:" + Now.Second.ToString() + " mSec:" + Now.Millisecond.ToString())
                sw.Flush()
                sw.Close()
            Catch ex As Exception
            End Try
        End Sub
        Public Sub WriteTimeLog1(ByVal sPathName As String)
            Dim sw As New StreamWriter(sPathName, True)
            Try
                sw.WriteLine("----------------------------------------------------------------------------------------------------")
                sw.Flush()
                sw.Close()
            Catch ex As Exception
            End Try
        End Sub
        Public Sub WriteTimeLog2(ByVal sPathName As String)
            Dim sw As New StreamWriter(sPathName, True)
            Try
                sw.WriteLine("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
                sw.Flush()
                sw.Close()
            Catch ex As Exception
            End Try
        End Sub
    End Class
End Namespace

