Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Partial Class ProductFormat
    Inherits System.Web.UI.Page

    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try
            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetProductFormatSql(Cases, UserName, Password)

            Count = Dts.Rows.Count


            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='140px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CaseDes").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)

            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)


            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                td4.Text = "Weight :-" + Dts.Rows(J).Item("Title8").ToString()
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)


            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)


            Dim row As New Integer

            For row = 1 To 1





                'Main Feilds

                'Production Combo
                Dim PTR1 As New TableRow
                Dim PTC1 As New TableCell
                PTR1.ID = "P_1"
                PTR1.CssClass = "ColorTR"
                PTC1.Text = "Product Format"
                PTC1.BorderWidth = 1
                PTC1.CssClass = "Displaynametd"
                PTR1.Controls.Add(PTC1)
                Dim P As New Integer
                For P = 0 To Count - 1
                    Dim Unit As String = ""
                    Unit = Dts.Rows(P).Item("Units").ToString()
                    Dim GetCombo As New Selectdata()
                    Dim DT As New DataTable()
                    DT = GetCombo.GetProdCombo(Unit)
                    Dim ProdComo As New DropDownList

                    ProdComo.DataSource = DT
                    ProdComo.DataValueField = "FormatID"
                    ProdComo.DataTextField = "Des"
                    ProdComo.DataBind()
                    ProdComo.SelectedValue = Dts.Rows(P).Item("M1").ToString()
                    ProdComo.ID = "P" + row.ToString() + "_" + P.ToString()

                    If Dts.Rows(P).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        ProdComo.Enabled = False
                    Else
                        ProdComo.Enabled = True
                    End If

                    Dim PTC2 As New TableCell
                    PTC2.Controls.Add(ProdComo)
                    PTC2.CssClass = "CaseTD"
                    PTC2.BorderWidth = 1
                    PTR1.Controls.Add(PTC2)


                Next
                tblComparision.Controls.Add(PTR1)

                'Product Input1
                Dim PTR2 As New TableRow
                Dim PTC3 As New TableCell
                PTR2.ID = "I1_1"
                PTR2.CssClass = "ColorTR"
                PTC3.Text = "Input 1"
                PTC3.CssClass = "Displaynametd"
                PTC3.BorderWidth = 1
                PTR2.Controls.Add(PTC3)
                Dim IP1 As New Integer
                For IP1 = 0 To Count - 1
                    Dim PTC4 As New TableCell
                    Dim IPF1 As Double
                    Dim IPT1 As New TextBox
                    Dim IPL1 As New Label


                    Dim Convthick As String = Dts.Rows(IP1).Item("convthick")
                    Dim IV1 As String = Dts.Rows(IP1).Item("M2")
                    IPF1 = Convert.ToDouble(IV1 * Convthick)
                    IPT1.Text = IPF1.ToString("0.000")
                    IPT1.ID = "I1" + row.ToString() + "_" + IP1.ToString()
                    IPT1.CssClass = "textBox"
                    IPL1.Text = Dts.Rows(IP1).Item("Format_M1") + "<br />"

                    If Dts.Rows(IP1).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        IPT1.Enabled = False
                    Else
                        IPT1.Enabled = True
                    End If

                    PTC4.Controls.Add(IPL1)
                    PTC4.Controls.Add(IPT1)
                    PTC4.BorderWidth = 1
                    PTC4.CssClass = "CaseTD"
                    PTR2.Controls.Add(PTC4)

                Next
                tblComparision.Controls.Add(PTR2)

                'Product Input2
                Dim PTR3 As New TableRow
                Dim PTC5 As New TableCell
                PTR3.ID = "I2_1"
                PTR3.CssClass = "ColorTR"
                PTC5.Text = "Input 2"
                PTC5.CssClass = "Displaynametd"
                PTC5.BorderWidth = 1
                PTR3.Controls.Add(PTC5)
                Dim IP2 As New Integer
                For IP2 = 0 To Count - 1
                    Dim PTC6 As New TableCell
                    Dim IPF2 As Double
                    Dim IPT2 As New TextBox
                    Dim IPL2 As New Label
                    Dim Convthick As String = Dts.Rows(IP2).Item("convthick")
                    Dim IV2 As String = Dts.Rows(IP2).Item("M3")
                    Dim Roll As String = 1
                    Dim UN As String = Dts.Rows(IP2).Item("Units").ToString()
                    If UN = 1 Then
                        Roll = 0.01204
                    End If
                    IPF2 = Convert.ToDouble(IV2 * Convthick * Roll)
                    IPT2.Text = IPF2.ToString("0.000")
                    IPT2.ID = "I2" + row.ToString() + "_" + IP2.ToString()
                    IPT2.CssClass = "textBox"
                    IPL2.Text = Dts.Rows(IP2).Item("Format_M2") + "<br />"

                    If Dts.Rows(IP2).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        IPT2.Enabled = False
                    Else
                        IPT2.Enabled = True
                    End If

                    PTC6.CssClass = "CaseTD"
                    PTC6.BorderWidth = 1
                    PTC6.Controls.Add(IPL2)
                    PTC6.Controls.Add(IPT2)
                    PTR3.Controls.Add(PTC6)
                Next
                tblComparision.Controls.Add(PTR3)




                'Product Input3
                Dim PTR4 As New TableRow
                Dim PTC7 As New TableCell
                PTR4.ID = "I3_1"
                PTR4.CssClass = "ColorTR"
                PTC7.Text = "Input 3"
                PTC7.CssClass = "Displaynametd"
                PTC7.BorderWidth = 1
                PTR4.Controls.Add(PTC7)
                Dim IP3 As New Integer
                For IP3 = 0 To Count - 1
                    Dim PTC8 As New TableCell
                    Dim IPF3 As Double
                    Dim IPT3 As New TextBox
                    Dim IPL3 As New Label
                    Dim Convthick As String = Dts.Rows(IP3).Item("convthick")
                    Dim IV3 As String = Dts.Rows(IP3).Item("M4")
                    IPF3 = Convert.ToDouble(IV3 * Convthick)
                    IPT3.Text = IPF3.ToString("0.000")
                    IPT3.ID = "I3" + row.ToString() + "_" + IP3.ToString()
                    IPT3.CssClass = "textBox"
                    IPL3.Text = Dts.Rows(IP3).Item("Format_M3") + "<br />"

                    If Dts.Rows(IP3).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        IPT3.Enabled = False
                    Else
                        IPT3.Enabled = True
                    End If

                    PTC8.CssClass = "CaseTD"
                    PTC8.BorderWidth = 1
                    PTC8.Controls.Add(IPL3)
                    PTC8.Controls.Add(IPT3)
                    PTR4.Controls.Add(PTC8)
                Next
                tblComparision.Controls.Add(PTR4)



                'Product Input4
                Dim PTR5 As New TableRow
                Dim PTC9 As New TableCell
                PTR5.ID = "I4_1"
                PTR5.CssClass = "ColorTR"
                PTC9.Text = "Input 4"
                PTC9.CssClass = "Displaynametd"
                PTC9.BorderWidth = 1
                PTR5.Controls.Add(PTC9)
                Dim IP4 As New Integer
                For IP4 = 0 To Count - 1
                    Dim PTC10 As New TableCell
                    Dim IPF4 As Double
                    Dim IPT4 As New TextBox
                    Dim IPL4 As New Label
                    Dim IV4 As String = Dts.Rows(IP4).Item("M5")
                    IPF4 = Convert.ToDouble(IV4)
                    IPT4.Text = IPF4.ToString("0.000")
                    IPT4.ID = "I4" + row.ToString() + "_" + IP4.ToString()
                    IPT4.CssClass = "textBox"
                    IPL4.Text = Dts.Rows(IP4).Item("Format_M4") + "<br />"

                    If Dts.Rows(IP4).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        IPT4.Enabled = False
                    Else
                        IPT4.Enabled = True
                    End If

                    PTC10.CssClass = "CaseTD"
                    PTC10.BorderWidth = 1
                    PTC10.Controls.Add(IPL4)
                    PTC10.Controls.Add(IPT4)
                    PTR5.Controls.Add(PTC10)
                Next
                tblComparision.Controls.Add(PTR5)


                'Product Input5
                Dim PTR6 As New TableRow
                Dim PTC11 As New TableCell
                PTR6.ID = "I5_1"
                PTR6.CssClass = "ColorTR"
                PTC11.Text = "Input 5"
                PTC11.CssClass = "Displaynametd"
                PTC11.BorderWidth = 1
                PTR6.Controls.Add(PTC11)
                Dim IP5 As New Integer
                For IP5 = 0 To Count - 1
                    Dim PTC12 As New TableCell
                    Dim IPF5 As Double
                    Dim IPT5 As New TextBox
                    Dim IPL5 As New Label
                    Dim IV5 As String = Dts.Rows(IP5).Item("M6")
                    IPF5 = Convert.ToDouble(IV5)
                    IPT5.Text = IPF5.ToString("0.000")
                    IPT5.ID = "I5" + row.ToString() + "_" + IP5.ToString()
                    IPT5.CssClass = "textBox"
                    IPL5.Text = Dts.Rows(IP5).Item("Format_M5") + "<br />"

                    If Dts.Rows(IP5).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        IPT5.Enabled = False
                    Else
                        IPT5.Enabled = True
                    End If

                    PTC12.CssClass = "CaseTD"
                    PTC12.BorderWidth = 1
                    PTC12.Controls.Add(IPL5)
                    PTC12.Controls.Add(IPT5)
                    PTR6.Controls.Add(PTC12)
                Next
                tblComparision.Controls.Add(PTR6)
            Next

            'Dim tr4 As New TableRow
            'Dim td7 As New TableCell
            'tr4.CssClass = "Layer"
            'td7.ColumnSpan = Count + 1
            'tr4.Controls.Add(td7)
            'tblComparision.Controls.Add(tr4)


            Dim PTR7 As New TableRow
            Dim PTC13 As New TableCell
            PTR7.ID = "PF1_1"
            PTR7.CssClass = "ColorTR"
            PTC13.Text = "Product Wegiht"
            PTC13.CssClass = "Displaynametd"
            PTC13.BorderWidth = 1
            PTR7.Controls.Add(PTC13)
            Dim ProductWeight As New Integer
            For ProductWeight = 0 To Count - 1
                Dim PTC14 As New TableCell
                Dim PW As Double
                Dim PWLable As New Label
                Dim PWTLable As New Label
                Dim convwt As String = Dts.Rows(ProductWeight).Item("convwt").ToString()
                Dim Unit1 As String = Dts.Rows(ProductWeight).Item("Units").ToString()
                If Unit1 = 0 Then
                    PWLable.Text = "Product Weight  (lb)<br/>"
                Else
                    PWLable.Text = "Product Weight  (kg)<br/>"
                End If
                PW = Convert.ToDouble(Dts.Rows(ProductWeight).Item("prodwt").ToString() * convwt)
                PWTLable.Text = PW.ToString("0.0000")
                PWTLable.ForeColor = Drawing.Color.Red
                PTC14.Controls.Add(PWLable)
                PTC14.Controls.Add(PWTLable)
                PTC14.BorderWidth = 1
                PTC14.CssClass = "CaseTD"
                PTR7.Controls.Add(PTC14)
            Next
            tblComparision.Controls.Add(PTR7)

            Dim PTR8 As New TableRow
            Dim PTC15 As New TableCell
            PTR8.CssClass = "ColorTR"
            PTR8.ID = "PF2_1"
            PTC15.Text = "Roll Diameter"
            PTC15.BorderWidth = 1
            PTC15.CssClass = "Displaynametd"
            PTR8.Controls.Add(PTC15)
            Dim RollDiameter As New Integer
            For RollDiameter = 0 To Count - 1
                Dim PTC16 As New TableCell
                Dim PR As Double
                Dim PRLV As New Label
                Dim PRLT As New Label
                Dim unit2 As String = Dts.Rows(RollDiameter).Item("Units")
                Dim Convthick As String = Dts.Rows(RollDiameter).Item("convthick")
                Dim RollDia As String = Dts.Rows(RollDiameter).Item("rolldia").ToString()
                PR = Convert.ToDouble(RollDia * Convthick)
                If RollDia > 0 Then
                    If unit2 = 0 Then
                        PRLT.Text = "Roll Diameter (in)<br>"
                    Else
                        PRLT.Text = "Roll Diameter (mm)<br>"

                    End If
                    PRLV.ForeColor = Drawing.Color.Red
                    PRLV.Text = PR.ToString("0.000")
                    PTC16.Controls.Add(PRLT)
                    PTC16.Controls.Add(PRLV)
                Else
                    PTC16.Text = "NA"
                End If
                PTC16.CssClass = "CaseTD"
                PTC16.BorderWidth = 1
                PTR8.Controls.Add(PTC16)
            Next
            tblComparision.Controls.Add(PTR8)










        Catch ex As Exception
            Response.Write("Error:--" + ex.Message.ToString())

        End Try
    End Sub



    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click
        Dim Update As New Update()

        Dim J As New Integer
        For J = 0 To Count - 1
            Dim I As New Integer
            Dim CaseID As String = ""
            Dim ProductFormat As String = ""
            Dim Input1 As String = ""
            Dim Input2 As String = ""
            Dim Input3 As String = ""
            Dim Input4 As String = ""
            Dim Input5 As String = ""
            For I = 1 To 1
                Dim P As String = Request.Form("ctl00$ContentPlaceHolder1$P" + I.ToString() + "_" + J.ToString() + "")
                Dim I1 As String = Request.Form("ctl00$ContentPlaceHolder1$I1" + I.ToString() + "_" + J.ToString() + "")
                Dim I2 As String = Request.Form("ctl00$ContentPlaceHolder1$I2" + I.ToString() + "_" + J.ToString() + "")
                Dim I3 As String = Request.Form("ctl00$ContentPlaceHolder1$I3" + I.ToString() + "_" + J.ToString() + "")
                Dim I4 As String = Request.Form("ctl00$ContentPlaceHolder1$I4" + I.ToString() + "_" + J.ToString() + "")
                Dim I5 As String = Request.Form("ctl00$ContentPlaceHolder1$I5" + I.ToString() + "_" + J.ToString() + "")
                CaseID = Request.Form("Case" + J.ToString() + "")
                ProductFormat = ProductFormat + P + ","
                Input1 = Input1 + I1 + ","
                Input2 = Input2 + I2 + ","
                Input3 = Input3 + I3 + ","
                Input4 = Input4 + I4 + ","
                Input5 = Input5 + I5 + ","
            Next
            ProductFormat = ProductFormat.Remove(ProductFormat.Length - 1, 1)
            Input1 = Input1.Remove(Input1.Length - 1, 1)
            Input2 = Input2.Remove(Input2.Length - 1, 1)
            Input3 = Input3.Remove(Input3.Length - 1, 1)
            Input4 = Input4.Remove(Input4.Length - 1, 1)
            Input5 = Input5.Remove(Input5.Length - 1, 1)
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                Update.ProductUpdate(CaseID, ProductFormat, Input1, Input2, Input3, Input4, Input5)
            End If
        Next
        Response.Redirect("ProductFormat.aspx")
    End Sub



    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click
        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))
            CI = CI + CaseID + ","

        Next
        CI = CI.Remove(CI.Length - 1, 1)
        If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
        Else
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=ProductFormat.aspx")
        End If





    End Sub
End Class
