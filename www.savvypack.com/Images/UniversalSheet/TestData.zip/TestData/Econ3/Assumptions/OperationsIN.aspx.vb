Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class OperationsIn
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetOperationSql(Cases, UserName, Password)
            Count = Dts.Rows.Count


            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='160px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)

            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)
            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                td4.Text = "Web Width : (" + Dts.Rows(J).Item("Title9") + ")<br />Instantaneous Rate 2 : (" + Dts.Rows(J).Item("Title5") + ")" + "<br><img alt='' src='../../Images/spacer.gif' width='300px'height='0px'  />"
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)


            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)



            Dim row As New Integer
            For row = 1 To 30

                'Break
                Dim tr5 As New TableRow
                Dim td7 As New TableCell
                td7.Text = "<b>Position" + row.ToString + "</b>"
                tr5.CssClass = "Layer"
                tr5.Controls.Add(td7)
                Dim Break As New Integer
                For Break = 0 To Count - 1
                    Dim td8 As New TableCell
                    td8.Text = "&nbsp;"
                    tr5.Controls.Add(td8)
                Next
                tblComparision.Controls.Add(tr5)



                'Equipment Description
                Dim OPR1 As New TableRow
                Dim OPC1 As New TableCell
                OPR1.ID = "OP1_" + row.ToString()
                OPR1.CssClass = "ColorTR"
                OPR1.Height = 25
                OPC1.Text = "Equipment Description"
                OPC1.BorderWidth = 1
                OPC1.CssClass = "Displaynametd"
                OPR1.Controls.Add(OPC1)

                Dim EquipDes As New Integer
                For EquipDes = 0 To Count - 1
                    Dim OPC2 As New TableCell
                    Dim Des As String = "EQUIPDES" + row.ToString()
                    OPC2.Text = Dts.Rows(EquipDes).Item(Des).ToString()
                    OPC2.BorderWidth = 1
                    OPC2.Style.Add("text-align", "Center")
                    OPR1.Controls.Add(OPC2)
                Next
                tblComparision.Controls.Add(OPR1)


                'Web Width 
                Dim OPR2 As New TableRow
                Dim OPC3 As New TableCell
                OPR2.ID = "OP2_" + row.ToString()
                OPR2.CssClass = "ColorTR"
                OPC3.Text = "Web Width"
                OPC3.BorderWidth = 1
                OPC3.CssClass = "Displaynametd"
                OPR2.Controls.Add(OPC3)
                Dim WebWidh As New Integer
                For WebWidh = 0 To Count - 1
                    Dim OPC4 As New TableCell
                    Dim WebWidthTextbox As New TextBox
                    Dim EquipWidth As String = "EQUIPWIDTH" + row.ToString()
                    Dim Equip As String = Dts.Rows(WebWidh).Item(EquipWidth).ToString()
                    Dim Web As String = "WEBWIDTH" + row.ToString()
                    If Equip = 0 Then
                    Else
                        WebWidthTextbox.Text = FormatNumber(Dts.Rows(WebWidh).Item(Web).ToString(), 3)
                        WebWidthTextbox.CssClass = "textBox"
                        OPC4.Controls.Add(WebWidthTextbox)
                        WebWidthTextbox.ID = "Web" + row.ToString() + "_" + WebWidh.ToString()

                        If Dts.Rows(WebWidh).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                            WebWidthTextbox.Enabled = False
                        Else
                            WebWidthTextbox.Enabled = True
                        End If

                    End If
                    OPC4.CssClass = "CaseTD"
                    OPC4.BorderWidth = 1
                    OPR2.Controls.Add(OPC4)
                Next
                tblComparision.Controls.Add(OPR2)



                'Maximum Annual Run Hours
                Dim OPR3 As New TableRow
                Dim OPC5 As New TableCell
                OPR3.ID = "OP3_" + row.ToString()
                OPR3.CssClass = "ColorTR"
                OPC5.Text = "Maximum Annual Run Hours"
                OPC5.BorderWidth = 1
                OPC5.CssClass = "Displaynametd"
                OPR3.Controls.Add(OPC5)
                Dim MaxAnnualRun As New Integer
                For MaxAnnualRun = 0 To Count - 1
                    Dim OPC6 As New TableCell
                    Dim MaxAnnualTextBox As New TextBox
                    Dim RunHours As String = "ANNUALRUNHOURS" + row.ToString()
                    MaxAnnualTextBox.Text = FormatNumber(Dts.Rows(MaxAnnualRun).Item(RunHours).ToString(), 0)
                    MaxAnnualTextBox.ID = "MAR" + row.ToString() + "_" + MaxAnnualRun.ToString()
                    MaxAnnualTextBox.CssClass = "textBox"

                    If Dts.Rows(MaxAnnualRun).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        MaxAnnualTextBox.Enabled = False
                    Else
                        MaxAnnualTextBox.Enabled = True
                    End If

                    OPC6.Controls.Add(MaxAnnualTextBox)
                    OPC6.CssClass = "CaseTD"
                    OPC6.BorderWidth = 1
                    OPR3.Controls.Add(OPC6)
                Next
                tblComparision.Controls.Add(OPR3)


                'Instantaneous Rate
                Dim OPR4 As New TableRow
                Dim OPC7 As New TableCell
                OPR4.ID = "OP4_" + row.ToString()
                OPR4.CssClass = "ColorTR"
                OPC7.Text = "Instantaneous Rate1"
                OPC7.BorderWidth = 1
                OPC7.CssClass = "Displaynametd"
                OPR4.Controls.Add(OPC7)
                Dim Irate As New Integer
                For Irate = 0 To Count - 1
                    Dim OPC8 As New TableCell
                    Dim IrateTextBox As New TextBox
                    Dim Rate As String = "INSTANTANEOUSRATE" + row.ToString()
                    IrateTextBox.Text = FormatNumber(Dts.Rows(Irate).Item(Rate).ToString(), 2)
                    IrateTextBox.CssClass = "textBox"

                    If Dts.Rows(Irate).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        IrateTextBox.Enabled = False
                    Else
                        IrateTextBox.Enabled = True
                    End If

                    IrateTextBox.ID = "IR" + row.ToString() + "_" + Irate.ToString()
                    OPC8.Controls.Add(IrateTextBox)
                    OPC8.CssClass = "CaseTD"
                    OPC8.BorderWidth = 1
                    OPR4.Controls.Add(OPC8)
                Next
                tblComparision.Controls.Add(OPR4)

                'Units
                Dim OPR5 As New TableRow
                Dim OPC9 As New TableCell
                OPR5.ID = "OP5_" + row.ToString()
                OPR5.Height = 25
                OPR5.CssClass = "ColorTR"
                OPC9.Text = "Units"
                OPC9.BorderWidth = 1
                OPC9.CssClass = "Displaynametd"
                OPR5.Controls.Add(OPC9)
                Dim UnitDes As New Integer
                For UnitDes = 0 To Count - 1
                    Dim OPC10 As New TableCell
                    Dim Unit As String = "EQUIPUNITS" + row.ToString()
                    OPC10.Text = Dts.Rows(UnitDes).Item(Unit).ToString()
                    OPC10.Style.Add("text-align", "center")
                    OPC10.BorderWidth = 1
                    OPR5.Controls.Add(OPC10)
                Next
                tblComparision.Controls.Add(OPR5)


                'Instantaneous Rate
                Dim OPR6 As New TableRow
                Dim OPC11 As New TableCell
                OPR6.ID = "OP6_" + row.ToString()
                OPR6.Height = 25
                OPR6.CssClass = "ColorTR"
                OPC11.Text = "Instantaneous Rate2"
                OPC11.BorderWidth = 1
                OPC11.CssClass = "Displaynametd"
                OPR6.Controls.Add(OPC11)
                Dim Iratelb As New Integer
                For Iratelb = 0 To Count - 1
                    Dim OPC12 As New TableCell
                    Dim Ratelb As String = "INSTANTANEOUS2RATE" + row.ToString()
                    OPC12.Text = FormatNumber(Dts.Rows(Iratelb).Item(Ratelb).ToString(), 2)
                    OPC12.Style.Add("text-align", "center")
                    OPC12.BorderWidth = 1
                    OPR6.Controls.Add(OPC12)
                Next
                tblComparision.Controls.Add(OPR6)


                'Downtime (%)
                Dim OPR7 As New TableRow
                Dim OPC13 As New TableCell
                OPR7.ID = "OP7_" + row.ToString()
                OPR7.CssClass = "ColorTR"
                OPC13.Text = "Downtime (%)"
                OPC13.BorderWidth = 1
                OPC13.CssClass = "Displaynametd"
                OPR7.Controls.Add(OPC13)
                Dim Downtime As New Integer
                For Downtime = 0 To Count - 1
                    Dim OPC14 As New TableCell
                    Dim DowntimeTextbox As New TextBox
                    Dim Down As String = "DOWNTIME" + row.ToString()
                    DowntimeTextbox.Text = FormatNumber(Dts.Rows(Downtime).Item(Down).ToString(), 1)
                    DowntimeTextbox.CssClass = "textBox"

                    If Dts.Rows(Downtime).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DowntimeTextbox.Enabled = False
                    Else
                        DowntimeTextbox.Enabled = True
                    End If

                    DowntimeTextbox.ID = "DW" + row.ToString() + "_" + Downtime.ToString()
                    OPC14.Controls.Add(DowntimeTextbox)
                    OPC14.CssClass = "CaseTD"
                    OPC14.BorderWidth = 1
                    OPR7.Controls.Add(OPC14)
                Next
                tblComparision.Controls.Add(OPR7)



                'Production Waste (%)  	
                Dim OPR8 As New TableRow
                Dim OPC15 As New TableCell
                OPR8.ID = "OP8_" + row.ToString()
                OPR8.CssClass = "ColorTR"
                OPC15.Text = "Production Waste (%)"
                OPC15.BorderWidth = 1
                OPC15.CssClass = "Displaynametd"
                OPR8.Controls.Add(OPC15)
                Dim ProductionWaste As New Integer
                For ProductionWaste = 0 To Count - 1
                    Dim OPC16 As New TableCell
                    Dim ProductionWasteTextbox As New TextBox
                    Dim Production As String = "PRODUCTIONWAST" + row.ToString()
                    ProductionWasteTextbox.Text = FormatNumber(Dts.Rows(ProductionWaste).Item(Production).ToString(), 1)
                    ProductionWasteTextbox.CssClass = "textBox"

                    If Dts.Rows(ProductionWaste).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        ProductionWasteTextbox.Enabled = False
                    Else
                        ProductionWasteTextbox.Enabled = True
                    End If

                    ProductionWasteTextbox.ID = "PW" + row.ToString() + "_" + ProductionWaste.ToString()
                    OPC16.Controls.Add(ProductionWasteTextbox)
                    OPC16.CssClass = "CaseTD"
                    OPC16.BorderWidth = 1
                    OPR8.Controls.Add(OPC16)
                Next
                tblComparision.Controls.Add(OPR8)




                'Design Waste (%)  	
                Dim OPR9 As New TableRow
                Dim OPC17 As New TableCell
                OPR9.ID = "OP9_" + row.ToString()
                OPR9.CssClass = "ColorTR"
                OPC17.Text = " Design Waste (%)"
                OPC17.BorderWidth = 1
                OPC17.CssClass = "Displaynametd"
                OPR9.Controls.Add(OPC17)
                Dim DesignWaste As New Integer
                For DesignWaste = 0 To Count - 1
                    Dim OPC18 As New TableCell
                    Dim DesignWasteTextbox As New TextBox
                    Dim Design As String = "DESIGNWAST" + row.ToString()
                    DesignWasteTextbox.Text = FormatNumber(Dts.Rows(DesignWaste).Item(Design).ToString(), 1)
                    DesignWasteTextbox.CssClass = "textBox"

                    If Dts.Rows(DesignWaste).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DesignWasteTextbox.Enabled = False
                    Else
                        DesignWasteTextbox.Enabled = True
                    End If

                    DesignWasteTextbox.ID = "DEW" + row.ToString() + "_" + DesignWaste.ToString()
                    OPC18.Controls.Add(DesignWasteTextbox)
                    OPC18.CssClass = "CaseTD"
                    OPC18.BorderWidth = 1
                    OPR9.Controls.Add(OPC18)
                Next
                tblComparision.Controls.Add(OPR9)
























            Next




        Catch ex As Exception
            Response.Write("Error:" + ex.Message.ToString())
        End Try

    End Sub

    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click, Update2.Click
        Try

            'declaration of varialbles

            Dim I As New Integer
            Dim J As New Integer

            Dim EquipmentUpdate As New Update()

            For I = 0 To Count - 1
                Dim WebWidth(30) As String
                Dim MaxAnnRunHrs(30) As String
                Dim InstantRate(30) As String
                Dim DownTime(30) As String
                Dim ProdWaste(30) As String
                Dim DesignWaste(30) As String

                Dim CaseID As String = ""

                For J = 1 To 30
                    WebWidth(J) = Request.Form("ctl00$ContentPlaceHolder1$Web" + J.ToString() + "_" + I.ToString())
                    MaxAnnRunHrs(J) = Request.Form("ctl00$ContentPlaceHolder1$MAR" + J.ToString() + "_" + I.ToString())
                    InstantRate(J) = Request.Form("ctl00$ContentPlaceHolder1$IR" + J.ToString() + "_" + I.ToString())
                    DownTime(J) = Request.Form("ctl00$ContentPlaceHolder1$DW" + J.ToString() + "_" + I.ToString())
                    ProdWaste(J) = Request.Form("ctl00$ContentPlaceHolder1$PW" + J.ToString() + "_" + I.ToString())
                    DesignWaste(J) = Request.Form("ctl00$ContentPlaceHolder1$DEW" + J.ToString() + "_" + I.ToString())
                    CaseID = Request.Form("Case" + I.ToString())
                Next

                If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
                Else
                    EquipmentUpdate.OperationsUpdate(CaseID, WebWidth, MaxAnnRunHrs, InstantRate, DownTime, ProdWaste, DesignWaste)
                End If

            Next
            Response.Redirect("OperationsIN.aspx")

        Catch ex As Exception
            Response.Write("EquipmentAss Error:-" + ex.Message.ToString())
        End Try


    End Sub

    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click, CalCulate2.Click

        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))

            'Checking The Case 
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                CI = CI + CaseID + ","
            End If

        Next
        If CI <> "" Then
            CI = CI.Remove(CI.Length - 1, 1)
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=OperationsIN.aspx")
        End If




    End Sub
End Class
