Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class CustIn
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblAID.Text = Session("AssumptionID").ToString()
        lblAdes.Text = Session("Description")
        Assid = Session("AssumptionID").ToString()
        UserName = Session("UserName").ToString()
        Password = Session("Password").ToString()


        'Getting Number Of Cases from 
        Dim GetCaseIDs As New Selectdata()
        Dim Cases As String = ""
        Cases = GetCaseIDs.Cases(Assid)


        'Getting the Datable
        Dim GetQuery As New Selectdata()
        Dim Dts As New DataTable()
        Dts = GetQuery.GetCustomerSql(Cases, UserName, Password)
        Count = Dts.Rows.Count



        'Plant  Area


        'Headded Part
        Dim tr1 As New TableRow
        Dim td1 As New TableCell
        tr1.ID = "Header1"
        td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='140px'height='0px'  />"
        td1.CssClass = "LeftHeading"
        tr1.CssClass = "HeaderTR"
        td1.BorderWidth = 1
        tr1.Controls.Add(td1)

        Dim I As New Integer
        For I = 0 To Count - 1
            Dim td2 As New TableCell
            td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>" + "<br><img alt='' src='../../Images/spacer.gif' width='300px'height='0px'  />"
            CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
            td2.CssClass = "CaseTD"
            td2.BorderWidth = 1
            tr1.Controls.Add(td2)
        Next
        tblComparision.Controls.Add(tr1)


        Dim tr2 As New TableRow
        Dim td3 As New TableCell
        tr2.ID = "Header2"
        td3.Text = "Unit"
        td3.CssClass = "LeftHeading"
        tr2.CssClass = "HeaderTR"
        td3.BorderWidth = 1
        tr2.Controls.Add(td3)
        Dim J As New Integer
        For J = 0 To Count - 1
            Dim td4 As New TableCell
            Dim Unit As String = Dts.Rows(J).Item("UNIT").ToString()
            If Unit = 0 Then
                td4.Text = "Product Purchase:" + Dts.Rows(J).Item("Title2") + "<br/>" + "Shipping Distance: mile " + "<br/>" + "Mileage cost:" + Dts.Rows(J).Item("Title4") + "/mile"
            Else
                td4.Text = "Product Purchase:" + Dts.Rows(J).Item("Title2") + "<br/>" + "Shipping Distance: kilometer " + "<br/>" + "Mileage cost:" + Dts.Rows(J).Item("Title4") + "/kilometer"
            End If
            td4.CssClass = "Unitd"
            td4.BorderWidth = 1
            tr2.Controls.Add(td4)
        Next
        tblComparision.Controls.Add(tr2)



        Dim tr3 As New TableRow
        Dim td5 As New TableCell
        tr3.ID = "Header3"
        td5.Text = "CaseType"
        td5.CssClass = "LeftHeading"
        tr3.CssClass = "HeaderTR"
        td5.BorderWidth = 1
        tr3.Controls.Add(td5)

        Dim k As New Integer
        For k = 0 To Count - 1
            Dim td6 As New TableCell
            If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                td6.Text = "Base Case"
            Else

                td6.Text = "Proprietary Case"
            End If
            td6.CssClass = "CaseTD"
            td6.BorderWidth = 1
            tr3.Controls.Add(td6)
        Next
        tblComparision.Controls.Add(tr3)

        Dim CUR1 As New TableRow
        Dim CUC1 As New TableCell
        CUR1.ID = "CU1_1"
        CUR1.CssClass = "ColorTR"
        CUC1.Text = "Product Purchase"
        CUC1.CssClass = "Displaynametd"
        CUC1.BorderWidth = 1
        CUR1.Controls.Add(CUC1)
        Dim productpurchase As New Integer
        For productpurchase = 0 To Count - 1
            Dim CUC2 As New TableCell
            Dim PurchaseTextBox As New TextBox
            PurchaseTextBox.Text = Dts.Rows(productpurchase).Item("PRODUCTPURCHASE").ToString()
            PurchaseTextBox.ID = "PRP" + productpurchase.ToString()
            PurchaseTextBox.CssClass = "textBox"

            If Dts.Rows(productpurchase).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                PurchaseTextBox.Enabled = False
            Else
                PurchaseTextBox.Enabled = True
            End If

            CUC2.Controls.Add(PurchaseTextBox)
            CUC2.CssClass = "CaseTD"
            CUC2.BorderWidth = 1
            CUR1.Controls.Add(CUC2)
        Next
        tblComparision.Controls.Add(CUR1)


        'Shipping Distance
        Dim CUR2 As New TableRow
        Dim CUC3 As New TableCell
        CUR2.ID = "CU2_1"
        CUR2.CssClass = "ColorTR"
        CUC3.Text = "Shipping Distance"
        CUC3.CssClass = "Displaynametd"
        CUC3.BorderWidth = 1
        CUR2.Controls.Add(CUC3)
        Dim ShippingDistance As New Integer
        For ShippingDistance = 0 To Count - 1
            Dim CUC4 As New TableCell
            Dim ShippingTextBox As New TextBox
            ShippingTextBox.Text = Dts.Rows(ShippingDistance).Item("SHIPPINGDISTANCE").ToString()
            ShippingTextBox.ID = "SD" + ShippingDistance.ToString()
            ShippingTextBox.CssClass = "textBox"

            If Dts.Rows(ShippingDistance).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                ShippingTextBox.Enabled = False
            Else
                ShippingTextBox.Enabled = True
            End If

            CUC4.Controls.Add(ShippingTextBox)
            CUC4.CssClass = "CaseTD"
            CUC4.BorderWidth = 1
            CUR2.Controls.Add(CUC4)
        Next
        tblComparision.Controls.Add(CUR2)



        'Mileage cost
        Dim CUR3 As New TableRow
        Dim CUC5 As New TableCell
        CUR3.ID = "CU3_1"
        CUR3.CssClass = "ColorTR"
        CUC5.Text = "Mileage cost"
        CUC5.CssClass = "Displaynametd"
        CUC5.BorderWidth = 1
        CUR3.Controls.Add(CUC5)
        Dim Mileagecost As New Integer
        For Mileagecost = 0 To Count - 1
            Dim CUC6 As New TableCell
            Dim MileageTextBox As New TextBox
            MileageTextBox.Text = Dts.Rows(Mileagecost).Item("MILEAGECOST").ToString()
            MileageTextBox.ID = "MI" + Mileagecost.ToString()
            MileageTextBox.CssClass = "textBox"

            If Dts.Rows(Mileagecost).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                MileageTextBox.Enabled = False
            Else
                MileageTextBox.Enabled = True
            End If

            CUC6.Controls.Add(MileageTextBox)
            CUC6.CssClass = "CaseTD"
            CUC6.BorderWidth = 1
            CUR3.Controls.Add(CUC6)
        Next
        tblComparision.Controls.Add(CUR3)



    End Sub
End Class
