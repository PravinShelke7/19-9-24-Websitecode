Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class FixCost
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetFixedCostSql(Cases, UserName, Password)
            Count = Dts.Rows.Count

            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='160px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)

            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)
            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                td4.Text = "Cost:" + Dts.Rows(J).Item("Title4") + "<br><img alt='' src='../../Images/spacer.gif' width='300px'height='0px'  />"
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)


            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)



            Dim row As New Integer
            For row = 1 To 30



                'Break
                Dim tr5 As New TableRow
                Dim td7 As New TableCell
                Dim Catg As String = "CATEGORY" + row.ToString()
                td7.Text = "<b>" + Dts.Rows(0).Item(Catg).ToString() + "</b>"
                tr5.CssClass = "Layer"
                tr5.Controls.Add(td7)
                Dim Break As New Integer
                For Break = 0 To Count - 1
                    Dim td8 As New TableCell
                    td8.Text = "&nbsp;"
                    tr5.Controls.Add(td8)
                Next
                tblComparision.Controls.Add(tr5)


                'Category
                'Dim FCR1 As New TableRow
                'Dim FCC1 As New TableCell
                'FCR1.ID = "FC1_" + row.ToString()
                'FCR1.CssClass = "ColorTR"
                'FCR1.Height = 25
                'FCC1.Text = "Category Name"
                'FCC1.CssClass = "Displaynametd"
                'FCC1.BorderWidth = 1
                'FCR1.Controls.Add(FCC1)
                'Dim Category As New Integer
                'For Category = 0 To Count - 1
                '    Dim FCC2 As New TableCell
                '    Dim Cat As String = "CATEGORY" + row.ToString()
                '    FCC2.Text = Dts.Rows(Category).Item(Cat).ToString()
                '    FCC2.Style.Add("text-align", "center")
                '    FCC2.BorderWidth = 1
                '    FCR1.Controls.Add(FCC2)
                'Next
                'tblComparision.Controls.Add(FCR1)





                'Fixed Values
                Dim FCR2 As New TableRow
                Dim FCC3 As New TableCell
                FCR2.ID = "FC2_" + row.ToString()
                FCR2.CssClass = "ColorTR"
                FCC3.Text = "Fixed Cost<br/> Guidelines Values"
                FCC3.CssClass = "Displaynametd"
                FCC3.BorderWidth = 1
                FCR2.Controls.Add(FCC3)
                Dim Value As New Integer
                For Value = 0 To Count - 1
                    Dim FCC4 As New TableCell
                    Dim Val As String = "FIXEDVALUE" + row.ToString()
                    Dim ValueTextBox As New TextBox
                    ValueTextBox.Text = Dts.Rows(Value).Item(Val).ToString()
                    ValueTextBox.ID = "VA" + row.ToString() + "_" + Value.ToString()
                    ValueTextBox.CssClass = "textBox"

                    If Dts.Rows(Value).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        ValueTextBox.Enabled = False
                    Else
                        ValueTextBox.Enabled = True
                    End If

                    FCC4.Controls.Add(ValueTextBox)
                    FCC4.CssClass = "CaseTD"
                    FCC4.BorderWidth = 1
                    FCR2.Controls.Add(FCC4)
                Next
                tblComparision.Controls.Add(FCR2)


                'Rule
                Dim FCR3 As New TableRow
                Dim FCC5 As New TableCell
                FCR3.ID = "FC3_" + row.ToString()
                FCR3.CssClass = "ColorTR"
                FCR3.Height = 25
                FCC5.Text = "Fixed Cost<br/> Guidelines  Rule"
                FCC5.CssClass = "Displaynametd"
                FCC5.BorderWidth = 1
                FCR3.Controls.Add(FCC5)
                Dim FRule As New Integer
                For FRule = 0 To Count - 1
                    Dim FCC6 As New TableCell
                    Dim Rul As String = "RULE" + row.ToString()
                    FCC6.Text = Dts.Rows(FRule).Item(Rul).ToString()
                    FCC6.Style.Add("text-align", "center")
                    FCC6.BorderWidth = 1
                    FCR3.Controls.Add(FCC6)
                Next
                tblComparision.Controls.Add(FCR3)


                'Fixed  Cost Suggested
                Dim FCR4 As New TableRow
                Dim FCC7 As New TableCell
                FCR4.ID = "FC4_" + row.ToString()
                FCR4.CssClass = "ColorTR"
                FCR4.Height = 25
                FCC7.Text = "Fixed  Cost Suggested"
                FCC7.CssClass = "Displaynametd"
                FCC7.BorderWidth = 1
                FCR4.Controls.Add(FCC7)
                Dim FixedCostS As New Integer
                For FixedCostS = 0 To Count - 1
                    Dim FCC8 As New TableCell
                    Dim Sug As String = "FIXEDCOSTSUG" + row.ToString()
                    FCC8.Text = FormatNumber(Dts.Rows(FixedCostS).Item(Sug).ToString(), 0)
                    FCC8.Style.Add("text-align", "center")
                    FCC8.BorderWidth = 1
                    FCR4.Controls.Add(FCC8)
                Next
                tblComparision.Controls.Add(FCR4)




                'Fixed Cost Preferred
                Dim FCR5 As New TableRow
                Dim FCC9 As New TableCell
                FCR5.ID = "FC5_" + row.ToString()
                FCR5.CssClass = "ColorTR"
                FCC9.Text = "Fixed Cost Preferred"
                FCC9.CssClass = "Displaynametd"
                FCC9.BorderWidth = 1
                FCR5.Controls.Add(FCC9)
                Dim FixedCostP As New Integer
                For FixedCostP = 0 To Count - 1
                    Dim FCC10 As New TableCell
                    Dim Pref As String = "FIXEDCOSTPREF" + row.ToString()
                    Dim PreferredTextBox As New TextBox
                    PreferredTextBox.Text = Dts.Rows(FixedCostP).Item(Pref).ToString()
                    PreferredTextBox.ID = "FCP" + row.ToString() + "_" + FixedCostP.ToString()
                    PreferredTextBox.CssClass = "textBox"

                    If Dts.Rows(FixedCostP).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PreferredTextBox.Enabled = False
                    Else
                        PreferredTextBox.Enabled = True
                    End If


                    FCC10.Controls.Add(PreferredTextBox)
                    FCC10.CssClass = "CaseTD"
                    FCC10.BorderWidth = 1
                    FCR5.Controls.Add(FCC10)
                Next
                tblComparision.Controls.Add(FCR5)


                'Department
                Dim FCR6 As New TableRow
                Dim FCC11 As New TableCell
                FCR6.ID = "FC6_" + row.ToString()
                FCR6.CssClass = "ColorTR"
                FCC11.Text = "Department"
                FCC11.CssClass = "Displaynametd"
                FCC11.BorderWidth = 1
                FCR6.Controls.Add(FCC11)
                Dim Dept As New Integer
                For Dept = 0 To Count - 1
                    Dim FCC12 As New TableCell
                    Dim DeptCombo As New DropDownList
                    Dim DP = "FIXEDCOSTDEP" + row.ToString()
                    Dim GetDept As New RepeatedControls()
                    DeptCombo = GetDept.DeptDropdown()
                    DeptCombo.SelectedValue = Dts.Rows(Dept).Item(DP).ToString()
                    DeptCombo.CssClass = "dropdown"
                    DeptCombo.ID = "DP" + row.ToString() + "_" + Dept.ToString()

                    If Dts.Rows(Dept).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo.Enabled = False
                    Else
                        DeptCombo.Enabled = True
                    End If

                    FCC12.Controls.Add(DeptCombo)
                    FCC12.CssClass = "CaseTD"
                    FCC12.BorderWidth = 1
                    FCR6.Controls.Add(FCC12)
                Next
                tblComparision.Controls.Add(FCR6)




            Next



            'DEPRECIATION
            Dim tr6 As New TableRow
            Dim td11 As New TableCell
            td11.Text = "<b>DEPRECIATION</b>"
            tr6.CssClass = "Layer"
            tr6.Controls.Add(td11)
            Dim Break1 As New Integer
            For Break1 = 0 To Count - 1
                Dim td12 As New TableCell
                td12.Text = "&nbsp;"
                tr6.Controls.Add(td12)
            Next
            tblComparision.Controls.Add(tr6)

            ' Total Asset Value
            Dim FCR7 As New TableRow
            Dim FCC13 As New TableCell
            FCR7.CssClass = "ColorTR"
            FCR7.ID = "FC7_1"
            FCR7.Height = 20
            FCC13.Text = "Total Asset Value"
            FCC13.CssClass = "Displaynametd"
            FCC13.BorderWidth = 1
            FCR7.Controls.Add(FCC13)
            Dim Depriciation As New Integer
            For Depriciation = 0 To Count - 1
                Dim FCC14 As New TableCell
                FCC14.Text = FormatCurrency(Dts.Rows(Depriciation).Item("TOTALASSETVALUE").ToString(), 0)
                FCC14.Style.Add("text-align", "center")
                FCC14.BorderWidth = 1
                FCR7.Controls.Add(FCC14)
            Next
            tblComparision.Controls.Add(FCR7)


            'Years to Depreciate
            Dim FCR8 As New TableRow
            Dim FCC15 As New TableCell
            FCR8.CssClass = "ColorTR"
            FCR8.ID = "FC8_1"
            FCC15.Text = "Years to Depreciate"
            FCC15.CssClass = "Displaynametd"
            FCC15.BorderWidth = 1
            FCR8.Controls.Add(FCC15)
            Dim year As New Integer
            For year = 0 To Count - 1
                Dim FCC16 As New TableCell
                Dim yearvalue As New TextBox
                yearvalue.Text = Dts.Rows(year).Item("DEPYEARS").ToString()
                yearvalue.CssClass = "textBox"
                yearvalue.ID = "YE" + year.ToString()

                If Dts.Rows(year).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    yearvalue.Enabled = False
                Else
                    yearvalue.Enabled = True
                End If

                FCC16.Controls.Add(yearvalue)
                FCC16.CssClass = "CaseTD"
                FCC16.BorderWidth = 1
                FCR8.Controls.Add(FCC16)
            Next
            tblComparision.Controls.Add(FCR8)



            ' ANNUAL DEPRECIATION COST
            Dim FCR9 As New TableRow
            Dim FCC17 As New TableCell
            FCR9.CssClass = "ColorTR"
            FCR9.ID = "FC9_1"
            FCR9.Height = 20
            FCC17.Text = "ANNUAL DEPRECIATION COST"
            FCC17.CssClass = "Displaynametd"
            FCC17.BorderWidth = 1
            FCR9.Controls.Add(FCC17)
            Dim ADepriciation As New Integer
            For ADepriciation = 0 To Count - 1
                Dim FCC18 As New TableCell
                FCC18.Text = FormatCurrency(Dts.Rows(ADepriciation).Item("ANNUALDEPRECIATIONCOST").ToString(), 0)
                FCC18.Style.Add("text-align", "center")
                FCC18.BorderWidth = 1
                FCR9.Controls.Add(FCC18)
            Next
            tblComparision.Controls.Add(FCR9)


        Catch ex As Exception
            Response.Write("Error:" + ex.Message.ToString())
        End Try

    End Sub
End Class
