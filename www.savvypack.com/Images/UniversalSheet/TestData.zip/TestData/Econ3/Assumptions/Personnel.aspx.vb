Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class Personnel
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetPersonnelSql(Cases, UserName, Password)
            Count = Dts.Rows.Count

            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='160px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)

            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)
            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                td4.Text = "Salary and Benefits  :" + Dts.Rows(J).Item("Title4") + "/Year<br><img alt='' src='../../Images/spacer.gif' width='300px'height='0px'  />"
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)


            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)



            Dim row As New Integer
            For row = 1 To 30

                'Break
                Dim tr5 As New TableRow
                Dim td7 As New TableCell
                td7.Text = "<b>Position" + row.ToString + "</b>"
                tr5.CssClass = "Layer"
                tr5.Controls.Add(td7)
                Dim Break As New Integer
                For Break = 0 To Count - 1
                    Dim td8 As New TableCell
                    td8.Text = "&nbsp;"
                    tr5.Controls.Add(td8)
                Next
                tblComparision.Controls.Add(tr5)



                'Position Description
                Dim PER1 As New TableRow
                Dim PEC1 As New TableCell
                PER1.ID = "PE1_" + row.ToString()
                PER1.CssClass = "ColorTR"
                PEC1.Text = "Position Description"
                PEC1.CssClass = "Displaynametd"
                PEC1.BorderWidth = 1
                PER1.Controls.Add(PEC1)
                Dim PDesc As New Integer
                For PDesc = 0 To Count - 1
                    Dim PEC2 As New TableCell
                    Dim PersonnelDropdown As New DropDownList
                    Dim ID As String = "ID" + row.ToString()
                    Dim Code As String = Dts.Rows(PDesc).Item("OCOUNTRY").ToString()
                    Dim Personnel As New Selectdata()
                    PersonnelDropdown = Personnel.GetPersonneldesCombo(Code)
                    PersonnelDropdown.SelectedValue = Dts.Rows(PDesc).Item(ID).ToString()
                    PersonnelDropdown.CssClass = "dropdown"
                    PersonnelDropdown.ID = "PDES" + row.ToString() + "_" + PDesc.ToString()

                    If Dts.Rows(PDesc).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PersonnelDropdown.Enabled = False
                    Else
                        PersonnelDropdown.Enabled = True
                    End If

                    PEC2.Controls.Add(PersonnelDropdown)
                    PEC2.CssClass = "CaseTD"
                    PEC2.BorderWidth = 1
                    PER1.Controls.Add(PEC2)
                Next
                tblComparision.Controls.Add(PER1)


                'Number
                Dim PER2 As New TableRow
                Dim PEC3 As New TableCell
                PER2.ID = "PE2_" + row.ToString()
                PER2.CssClass = "ColorTR"
                PEC3.Text = "Number of Workers"
                PEC3.CssClass = "Displaynametd"
                PEC3.BorderWidth = 1
                PER2.Controls.Add(PEC3)
                Dim NumberFeild As New Integer
                For NumberFeild = 0 To Count - 1
                    Dim PEC4 As New TableCell
                    Dim NumberTextBox As New TextBox
                    Dim NumberId As String = "NUMBER" + row.ToString()
                    NumberTextBox.Text = Dts.Rows(NumberFeild).Item(NumberId).ToString()
                    NumberTextBox.ID = "NU" + row.ToString() + "_" + NumberFeild.ToString()
                    NumberTextBox.CssClass = "textBox"

                    If Dts.Rows(NumberFeild).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        NumberTextBox.Enabled = False
                    Else
                        NumberTextBox.Enabled = True
                    End If

                    PEC4.Controls.Add(NumberTextBox)
                    PEC4.CssClass = "CaseTD"
                    PEC4.BorderWidth = 1
                    PER2.Controls.Add(PEC4)

                Next
                tblComparision.Controls.Add(PER2)


                'Salary Suggested
                Dim PER3 As New TableRow
                Dim PEC5 As New TableCell
                PER3.ID = "PE3_" + row.ToString()
                PER3.Height = 25
                PER3.CssClass = "ColorTR"
                PEC5.Text = "Salary Suggested"
                PEC5.CssClass = "Displaynametd"
                PEC5.BorderWidth = 1
                PER3.Controls.Add(PEC5)
                Dim SalaryS As New Integer
                For SalaryS = 0 To Count - 1
                    Dim PEC6 As New TableCell
                    Dim SALS As String = "SUGSALARY" + row.ToString()
                    PEC6.Text = FormatNumber(Dts.Rows(SalaryS).Item(SALS).ToString(), 0)
                    PEC6.Style.Add("text-align", "center")
                    PEC6.BorderWidth = 1
                    PER3.Controls.Add(PEC6)
                Next
                tblComparision.Controls.Add(PER3)



                'Salary Preferred
                Dim PER4 As New TableRow
                Dim PEC7 As New TableCell
                PER4.ID = "PE4_" + row.ToString()
                PER4.CssClass = "ColorTR"
                PEC7.Text = "Salary Preferred"
                PEC7.CssClass = "Displaynametd"
                PEC7.BorderWidth = 1
                PER4.Controls.Add(PEC7)
                Dim SalaryP As New Integer
                For SalaryP = 0 To Count - 1
                    Dim PEC8 As New TableCell
                    Dim SalaryPTextBox As New TextBox
                    Dim SALP As String = "PREFSALARY" + row.ToString()
                    SalaryPTextBox.Text = Dts.Rows(SalaryP).Item(SALP).ToString()
                    SalaryPTextBox.ID = "SP" + row.ToString() + "_" + SalaryP.ToString()
                    SalaryPTextBox.CssClass = "textBox"

                    If Dts.Rows(SalaryP).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        SalaryPTextBox.Enabled = False
                    Else
                        SalaryPTextBox.Enabled = True
                    End If

                    PEC8.Controls.Add(SalaryPTextBox)
                    PEC8.CssClass = "CaseTD"
                    PEC8.BorderWidth = 1
                    PER4.Controls.Add(PEC8)
                Next
                tblComparision.Controls.Add(PER4)


                'Cost Type
                Dim PER5 As New TableRow
                Dim PEC9 As New TableCell
                PER5.ID = "PE5_" + row.ToString()
                PER5.CssClass = "ColorTR"
                PEC9.Text = "Cost Type"
                PEC9.CssClass = "Displaynametd"
                PEC9.BorderWidth = 1
                PER5.Controls.Add(PEC9)
                Dim CostFeild As New Integer
                For CostFeild = 0 To Count - 1
                    Dim PEC10 As New TableCell
                    Dim CostID As String = "COSTTYPE" + row.ToString()
                    Dim CostCombo As New DropDownList
                    Dim GetCost As New Selectdata()
                    CostCombo = GetCost.GetCostCombo()
                    CostCombo.SelectedValue = Dts.Rows(CostFeild).Item(CostID).ToString()
                    CostCombo.ID = "CS" + row.ToString() + "_" + CostFeild.ToString()
                    CostCombo.CssClass = "dropdown"

                    If Dts.Rows(CostFeild).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        CostCombo.Enabled = False
                    Else
                        CostCombo.Enabled = True
                    End If

                    PEC10.Controls.Add(CostCombo)
                    PEC10.CssClass = "CaseTD"
                    PEC10.BorderWidth = 1
                    PER5.Controls.Add(PEC10)

                Next
                tblComparision.Controls.Add(PER5)


                'Manufacturing Process or Department
                Dim PER6 As New TableRow
                Dim PEC11 As New TableCell
                PER6.ID = "PE6_" + row.ToString()
                PER6.CssClass = "ColorTR"
                PEC11.Text = "Manufacturing Process <br/> or Department"
                PEC11.CssClass = "Displaynametd"
                PEC11.BorderWidth = 1
                PER6.Controls.Add(PEC11)
                Dim Dept As New Integer
                For Dept = 0 To Count - 1
                    Dim PEC12 As New TableCell
                    Dim DeptCombo As New DropDownList
                    Dim DP = "DEPARTMENT" + row.ToString()
                    Dim GetDept As New RepeatedControls()
                    DeptCombo = GetDept.DeptDropdown()
                    DeptCombo.SelectedValue = Dts.Rows(Dept).Item(DP).ToString()
                    DeptCombo.CssClass = "dropdown"
                    DeptCombo.ID = "DP" + row.ToString() + "_" + Dept.ToString()

                    If Dts.Rows(Dept).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo.Enabled = False
                    Else
                        DeptCombo.Enabled = True
                    End If

                    PEC12.Controls.Add(DeptCombo)
                    PEC12.CssClass = "CaseTD"
                    PEC12.BorderWidth = 1
                    PER6.Controls.Add(PEC12)
                Next
                tblComparision.Controls.Add(PER6)

            Next






        Catch ex As Exception
            Response.Write("Error:" + ex.Message.ToString())
        End Try

    End Sub

    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click, Update2.Click
        Try

            'declaration of varialbles
            Dim I As New Integer
            Dim J As New Integer

            Dim PersonnelUpdate As New Update()

            For I = 0 To Count - 1
                Dim PosDesc(30) As String
                Dim NumOfWorkers(30) As String
                Dim SalPref(30) As String
                Dim CostType(30) As String
                Dim ManfDept(30) As String

                Dim CaseId As String = ""

                For J = 1 To 30
                    PosDesc(J) = Request.Form("ctl00$ContentPlaceHolder1$PDES" + J.ToString() + "_" + I.ToString())
                    NumOfWorkers(J) = Request.Form("ctl00$ContentPlaceHolder1$NU" + J.ToString() + "_" + I.ToString())
                    SalPref(J) = Request.Form("ctl00$ContentPlaceHolder1$SP" + J.ToString() + "_" + I.ToString())
                    CostType(J) = Request.Form("ctl00$ContentPlaceHolder1$CS" + J.ToString() + "_" + I.ToString())
                    ManfDept(J) = Request.Form("ctl00$ContentPlaceHolder1$DP" + J.ToString() + "_" + I.ToString())
                    CaseId = Request.Form("Case" + I.ToString())
                Next

                If CaseId <= 1000 And Session("Password") <> "9krh65sve3" Then
                Else
                    PersonnelUpdate.PersonnelUpdate(CaseId, PosDesc, NumOfWorkers, SalPref, CostType, ManfDept)
                End If
            Next

            Response.Redirect("Personnel.aspx")


        Catch ex As Exception
            Response.Write("PersonnelAss Error:-" + ex.Message.ToString())
        End Try

    End Sub

    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click, CalCulate2.Click

        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))

            'Checking The Case 
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                CI = CI + CaseID + ","
            End If

        Next
        If CI <> "" Then
            CI = CI.Remove(CI.Length - 1, 1)
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=Personnel.aspx")
        End If




    End Sub
End Class
