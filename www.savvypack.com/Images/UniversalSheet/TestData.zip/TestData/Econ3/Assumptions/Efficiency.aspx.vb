Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class Effciency
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetEfficiencySql(Cases, UserName, Password)
            Count = Dts.Rows.Count


            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='140px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>" + "<br><img alt='' src='../../Images/spacer.gif' width='300px'height='0px'  />"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)




            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)



            Dim row As New Integer
            For row = 1 To 10

                'Break
                Dim tr5 As New TableRow
                Dim td7 As New TableCell
                td7.Text = "<b>Layer" + row.ToString + "</b>"
                tr5.CssClass = "Layer"
                tr5.Controls.Add(td7)
                Dim Break As New Integer
                For Break = 0 To Count - 1
                    Dim td8 As New TableCell
                    td8.Text = "&nbsp;"
                    tr5.Controls.Add(td8)
                Next
                tblComparision.Controls.Add(tr5)

                'Material Selection Feild
                Dim ETR1 As New TableRow
                Dim ETC1 As New TableCell
                ETR1.ID = "E1_" + row.ToString()
                ETR1.Height = 25
                ETR1.CssClass = "ColorTR"
                ETC1.Text = "<b>Material Name</b>"
                ETC1.CssClass = "Displaynametd"
                ETC1.BorderWidth = 1
                ETR1.Controls.Add(ETC1)
                Dim MainLayer As New Integer
                For MainLayer = 0 To Count - 1
                    Dim ETC2 As New TableCell
                    Dim Material1 As String = "Material" + row.ToString() + "Des"
                    ETC2.Text = Dts.Rows(MainLayer).Item(Material1).ToString()
                    ETC2.CssClass = "CaseTD"
                    ETC2.BorderWidth = 1
                    ETR1.Controls.Add(ETC2)
                Next
                tblComparision.Controls.Add(ETR1)


                'Depatment 1 Feild
                Dim ETR2 As New TableRow
                Dim ETC3 As New TableCell
                ETR2.ID = "E2_" + row.ToString()
                ETR2.CssClass = "ColorTR"
                ETC3.Text = "Department Name 1"
                ETC3.CssClass = "Displaynametd"
                ETC3.BorderWidth = 1
                ETR2.Controls.Add(ETC3)
                Dim Dept1 As New Integer
                For Dept1 = 0 To Count - 1
                    Dim ETC4 As New TableCell
                    Dim Dept1Chk As New CheckBox
                    Dim Dept1V As String = "Layer1Dept" + row.ToString + ""
                    Dim Dept1Value As String = Dts.Rows(Dept1).Item(Dept1V).ToString()
                    Dept1Chk.Text = Dts.Rows(Dept1).Item("Process1Des").ToString()
                    If Dept1Value > 0 Then
                        Dept1Chk.Checked = True
                    Else
                        Dept1Chk.Checked = False
                    End If
                    Dept1Chk.ID = "D1" + row.ToString() + "_" + Dept1.ToString()

                    If Dts.Rows(Dept1).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Dept1Chk.Enabled = False
                    Else
                        Dept1Chk.Enabled = True
                    End If

                    Dept1Chk.CssClass = "CheckBox"
                    ETC4.Controls.Add(Dept1Chk)
                    ETC4.BorderWidth = 1
                    ETR2.Controls.Add(ETC4)
                Next
                tblComparision.Controls.Add(ETR2)



                'Depatment 2 Feild
                Dim ETR3 As New TableRow
                Dim ETC5 As New TableCell
                ETR3.ID = "E3_" + row.ToString()
                ETR3.CssClass = "ColorTR"
                ETC5.Text = "Department Name 2"
                ETC5.CssClass = "Displaynametd"
                ETC5.BorderWidth = 1
                ETR3.Controls.Add(ETC5)
                Dim Dept2 As New Integer
                For Dept2 = 0 To Count - 1
                    Dim ETC6 As New TableCell
                    Dim Dept2Chk As New CheckBox
                    Dim Dept2V As String = "Layer2Dept" + row.ToString + ""
                    Dim Dept2Value As String = Dts.Rows(Dept2).Item(Dept2V).ToString()
                    Dept2Chk.Text = Dts.Rows(Dept2).Item("Process2Des").ToString()
                    If Dept2Value > 0 Then
                        Dept2Chk.Checked = True
                    Else
                        Dept2Chk.Checked = False
                    End If
                    Dept2Chk.ID = "D2" + row.ToString() + "_" + Dept2.ToString()

                    If Dts.Rows(Dept2).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Dept2Chk.Enabled = False
                    Else
                        Dept2Chk.Enabled = True
                    End If

                    Dept2Chk.CssClass = "CheckBox"
                    ETC6.Controls.Add(Dept2Chk)
                    ETC6.BorderWidth = 1
                    ETR3.Controls.Add(ETC6)
                Next
                tblComparision.Controls.Add(ETR3)



                'Depatment 3 Feild
                Dim ETR4 As New TableRow
                Dim ETC7 As New TableCell
                ETR4.ID = "E4_" + row.ToString()
                ETR4.CssClass = "ColorTR"
                ETC7.Text = "Department Name 3"
                ETC7.CssClass = "Displaynametd"
                ETC7.BorderWidth = 1
                ETR4.Controls.Add(ETC7)
                Dim Dept3 As New Integer
                For Dept3 = 0 To Count - 1
                    Dim ETC8 As New TableCell
                    Dim Dept3Chk As New CheckBox
                    Dim Dept3V As String = "Layer3Dept" + row.ToString + ""
                    Dim Dept3Value As String = Dts.Rows(Dept3).Item(Dept3V).ToString()
                    Dept3Chk.Text = Dts.Rows(Dept3).Item("Process3Des").ToString()
                    If Dept3Value > 0 Then
                        Dept3Chk.Checked = True
                    Else
                        Dept3Chk.Checked = False
                    End If
                    Dept3Chk.CssClass = "CheckBox"
                    Dept3Chk.ID = "D3" + row.ToString() + "_" + Dept3.ToString()

                    If Dts.Rows(Dept3).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Dept3Chk.Enabled = False
                    Else
                        Dept3Chk.Enabled = True
                    End If
                    ETC8.Controls.Add(Dept3Chk)
                    ETC8.BorderWidth = 1

                    ETR4.Controls.Add(ETC8)
                Next
                tblComparision.Controls.Add(ETR4)


                'Depatment 4 Feild
                Dim ETR5 As New TableRow
                Dim ETC9 As New TableCell
                ETR5.ID = "E5_" + row.ToString()
                ETR5.CssClass = "ColorTR"
                ETC9.Text = "Department Name 4"
                ETC9.CssClass = "Displaynametd"
                ETC9.BorderWidth = 1
                ETR5.Controls.Add(ETC9)
                Dim Dept4 As New Integer
                For Dept4 = 0 To Count - 1
                    Dim ETC10 As New TableCell
                    Dim Dept4Chk As New CheckBox
                    Dim Dept4V As String = "Layer4Dept" + row.ToString + ""
                    Dim Dept4Value As String = Dts.Rows(Dept4).Item(Dept4V).ToString()
                    Dept4Chk.Text = Dts.Rows(Dept4).Item("Process4Des").ToString()
                    If Dept4Value > 0 Then
                        Dept4Chk.Checked = True
                    Else
                        Dept4Chk.Checked = False
                    End If
                    Dept4Chk.ID = "D4" + row.ToString() + "_" + Dept4.ToString()

                    If Dts.Rows(Dept4).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Dept4Chk.Enabled = False
                    Else
                        Dept4Chk.Enabled = True
                    End If
                    Dept4Chk.CssClass = "CheckBox"
                    ETC10.Controls.Add(Dept4Chk)
                    ETC10.BorderWidth = 1

                    ETR5.Controls.Add(ETC10)
                Next
                tblComparision.Controls.Add(ETR5)


                'Depatment 5 Feild
                Dim ETR6 As New TableRow
                Dim ETC11 As New TableCell
                ETR6.ID = "E6_" + row.ToString()
                ETR6.CssClass = "ColorTR"
                ETC11.Text = "Department Name 5"
                ETC11.CssClass = "Displaynametd"
                ETC11.BorderWidth = 1
                ETR6.Controls.Add(ETC11)
                Dim Dept5 As New Integer
                For Dept5 = 0 To Count - 1
                    Dim ETC12 As New TableCell
                    Dim Dept5Chk As New CheckBox
                    Dim Dept5V As String = "Layer5Dept" + row.ToString + ""
                    Dim Dept5Value As String = Dts.Rows(Dept5).Item(Dept5V).ToString()
                    Dept5Chk.Text = Dts.Rows(Dept5).Item("Process5Des").ToString()
                    If Dept5Value > 0 Then
                        Dept5Chk.Checked = True
                    Else
                        Dept5Chk.Checked = False
                    End If
                    Dept5Chk.ID = "D5" + row.ToString() + "_" + Dept5.ToString()

                    If Dts.Rows(Dept5).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Dept5Chk.Enabled = False
                    Else
                        Dept5Chk.Enabled = True
                    End If
                    Dept5Chk.CssClass = "CheckBox"
                    ETC12.Controls.Add(Dept5Chk)
                    ETC12.BorderWidth = 1
                    ETR6.Controls.Add(ETC12)
                Next
                tblComparision.Controls.Add(ETR6)


                'Depatment 6 Feild
                Dim ETR7 As New TableRow
                Dim ETC13 As New TableCell
                ETR7.ID = "E7_" + row.ToString()
                ETR7.CssClass = "ColorTR"
                ETC13.Text = "Department Name 6"
                ETC13.CssClass = "Displaynametd"
                ETC13.BorderWidth = 1
                ETR7.Controls.Add(ETC13)
                Dim Dept6 As New Integer
                For Dept6 = 0 To Count - 1
                    Dim ETC14 As New TableCell
                    Dim Dept6Chk As New CheckBox
                    Dim Dept6V As String = "Layer6Dept" + row.ToString + ""
                    Dim Dept6Value As String = Dts.Rows(Dept6).Item(Dept6V).ToString()
                    Dept6Chk.Text = Dts.Rows(Dept6).Item("Process6Des").ToString()
                    If Dept6Value > 0 Then
                        Dept6Chk.Checked = True
                    Else
                        Dept6Chk.Checked = False
                    End If
                    Dept6Chk.ID = "D6" + row.ToString() + "_" + Dept6.ToString()

                    If Dts.Rows(Dept6).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Dept6Chk.Enabled = False
                    Else
                        Dept6Chk.Enabled = True
                    End If
                    Dept6Chk.CssClass = "CheckBox"
                    ETC14.Controls.Add(Dept6Chk)
                    ETC14.BorderWidth = 1
                    ETR7.Controls.Add(ETC14)
                Next
                tblComparision.Controls.Add(ETR7)


                'Depatment 7 Feild
                Dim ETR8 As New TableRow
                Dim ETC15 As New TableCell
                ETR8.ID = "E8_" + row.ToString()
                ETR8.CssClass = "ColorTR"
                ETC15.Text = "Department Name 7"
                ETC15.CssClass = "Displaynametd"
                ETC15.BorderWidth = 1
                ETR8.Controls.Add(ETC15)
                Dim Dept7 As New Integer
                For Dept7 = 0 To Count - 1
                    Dim ETC16 As New TableCell
                    Dim Dept7Chk As New CheckBox
                    Dim Dept7V As String = "Layer7Dept" + row.ToString + ""
                    Dim Dept7Value As String = Dts.Rows(Dept7).Item(Dept7V).ToString()
                    Dept7Chk.Text = Dts.Rows(Dept7).Item("Process7Des").ToString()
                    If Dept7Value > 0 Then
                        Dept7Chk.Checked = True
                    Else
                        Dept7Chk.Checked = False
                    End If
                    Dept7Chk.ID = "D7" + row.ToString() + "_" + Dept7.ToString()

                    If Dts.Rows(Dept7).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Dept7Chk.Enabled = False
                    Else
                        Dept7Chk.Enabled = True
                    End If
                    Dept7Chk.CssClass = "CheckBox"
                    ETC16.Controls.Add(Dept7Chk)
                    ETC16.BorderWidth = 1
                    ETR8.Controls.Add(ETC16)
                Next
                tblComparision.Controls.Add(ETR8)


                'Depatment 8 Feild
                Dim ETR9 As New TableRow
                Dim ETC17 As New TableCell
                ETR9.ID = "E9_" + row.ToString()
                ETR9.CssClass = "ColorTR"
                ETC17.Text = "Department Name 8"
                ETC17.CssClass = "Displaynametd"
                ETC17.BorderWidth = 1
                ETR9.Controls.Add(ETC17)
                Dim Dept8 As New Integer
                For Dept8 = 0 To Count - 1
                    Dim ETC18 As New TableCell
                    Dim Dept8Chk As New CheckBox
                    Dim Dept8V As String = "Layer8Dept" + row.ToString + ""
                    Dim Dept8Value As String = Dts.Rows(Dept8).Item(Dept8V).ToString()
                    Dept8Chk.Text = Dts.Rows(Dept8).Item("Process8Des").ToString()
                    If Dept8Value > 0 Then
                        Dept8Chk.Checked = True
                    Else
                        Dept8Chk.Checked = False
                    End If
                    Dept8Chk.ID = "D8" + row.ToString() + "_" + Dept8.ToString()

                    If Dts.Rows(Dept8).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Dept8Chk.Enabled = False
                    Else
                        Dept8Chk.Enabled = True
                    End If
                    Dept8Chk.CssClass = "CheckBox"
                    ETC18.Controls.Add(Dept8Chk)
                    ETC18.BorderWidth = 1
                    ETR9.Controls.Add(ETC18)
                Next
                tblComparision.Controls.Add(ETR9)


                'Depatment 9 Feild
                Dim ETR10 As New TableRow
                Dim ETC19 As New TableCell
                ETR10.ID = "E10_" + row.ToString()
                ETR10.CssClass = "ColorTR"
                ETC19.Text = "Department Name 9"
                ETC19.CssClass = "Displaynametd"
                ETC19.BorderWidth = 1
                ETR10.Controls.Add(ETC19)
                Dim Dept9 As New Integer
                For Dept9 = 0 To Count - 1
                    Dim ETC20 As New TableCell
                    Dim Dept9Chk As New CheckBox
                    Dim Dept9V As String = "Layer9Dept" + row.ToString + ""
                    Dim Dept9Value As String = Dts.Rows(Dept9).Item(Dept9V).ToString()
                    Dept9Chk.Text = Dts.Rows(Dept9).Item("Process9Des").ToString()
                    If Dept9Value > 0 Then
                        Dept9Chk.Checked = True
                    Else
                        Dept9Chk.Checked = False
                    End If
                    Dept9Chk.ID = "D9" + row.ToString() + "_" + Dept9.ToString()

                    If Dts.Rows(Dept9).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Dept9Chk.Enabled = False
                    Else
                        Dept9Chk.Enabled = True
                    End If
                    Dept9Chk.CssClass = "CheckBox"
                    ETC20.Controls.Add(Dept9Chk)
                    ETC20.BorderWidth = 1
                    ETR10.Controls.Add(ETC20)
                Next
                tblComparision.Controls.Add(ETR10)




                'Depatment 10 Feild
                Dim ETR11 As New TableRow
                Dim ETC21 As New TableCell
                ETR11.ID = "E11_" + row.ToString()
                ETR11.CssClass = "ColorTR"
                ETC21.Text = "Department Name 10"
                ETC21.CssClass = "Displaynametd"
                ETC21.BorderWidth = 1
                ETR11.Controls.Add(ETC21)
                Dim Dept10 As New Integer
                For Dept10 = 0 To Count - 1
                    Dim ETC22 As New TableCell
                    Dim Dept10Chk As New CheckBox
                    Dim Dept10V As String = "Layer10Dept" + row.ToString + ""
                    Dim Dept10Value As String = Dts.Rows(Dept10).Item(Dept10V).ToString()
                    Dept10Chk.Text = Dts.Rows(Dept10).Item("Process10Des").ToString()
                    If Dept10Value > 0 Then
                        Dept10Chk.Checked = True
                    Else
                        Dept10Chk.Checked = False
                    End If
                    Dept10Chk.ID = "D10" + row.ToString() + "_" + Dept10.ToString()

                    If Dts.Rows(Dept10).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Dept10Chk.Enabled = False
                    Else
                        Dept10Chk.Enabled = True
                    End If
                    Dept10Chk.CssClass = "CheckBox"
                    ETC22.Controls.Add(Dept10Chk)
                    ETC22.BorderWidth = 1
                    ETR11.Controls.Add(ETC22)
                Next
                tblComparision.Controls.Add(ETR11)



            Next




        Catch ex As Exception
            Response.Write("Error:--" + ex.Message.ToString())
        End Try

    End Sub

    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click, Update2.Click
        Try

            'declaring variables for row  and coloums

            Dim I As New Integer
            Dim J As New Integer
            Dim K As New Integer
            Dim MaterialEffiUpdate As New Update()

            'Case Loop
            For I = 0 To Count - 1
                Dim CaseID As String = ""
                Dim DN(10, 10) As String

                'Layer Loop
                For J = 1 To 10

                    'Getting CaseID
                    CaseID = Request.Form("Case" + I.ToString())

                    'Getting Arrary For 10 Layers as no.of cases
                    'Array Loop
                    For K = 1 To 10
                        DN(J, K) = Request.Form("ctl00$ContentPlaceHolder1$D" + K.ToString() + "" + J.ToString() + "_" + I.ToString())
                        If DN(J, K) = "on" Then
                            DN(J, K) = 1
                        Else
                            DN(J, K) = 0
                        End If
                    Next


                Next


                If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
                Else
                    MaterialEffiUpdate.MaterialEffiUpdate(CaseID, DN)

                End If

            Next

            Response.Redirect("Efficiency.aspx")
        Catch ex As Exception
            Response.Write("EfficiencyUpdateError:" + ex.Message.ToString())
        End Try

    End Sub

    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click, CalCulate2.Click
        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))

            'Checking The Case 
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                CI = CI + CaseID + ","
            End If

        Next
        If CI <> "" Then
            CI = CI.Remove(CI.Length - 1, 1)
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=Efficiency.aspx")
        End If

    End Sub

End Class
