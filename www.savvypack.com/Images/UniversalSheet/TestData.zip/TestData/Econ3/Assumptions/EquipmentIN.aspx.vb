Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class EqeuipmentIn
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetProcessEquipmentSql(Cases, UserName, Password)
            Count = Dts.Rows.Count


            'Getting the Equipment Combo
            'Dim Equip As New Selectdata()
            'Dim EquipmentCombo As New DropDownList
            'EquipmentCombo = Equip.GetEquipmentCombo()


            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='160px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)

            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)
            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                td4.Text = "Cost in:" + Dts.Rows(J).Item("Title4")
                'td4.Text = ""
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)


            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)



            Dim row As New Integer
            For row = 1 To 30

                'Break
                Dim tr5 As New TableRow
                Dim td7 As New TableCell
                td7.Text = "<b>Asset" + row.ToString + "</b>"
                tr5.CssClass = "Layer"
                tr5.Controls.Add(td7)
                Dim Break As New Integer
                For Break = 0 To Count - 1
                    Dim td8 As New TableCell
                    td8.Text = "&nbsp;"
                    tr5.Controls.Add(td8)
                Next
                tblComparision.Controls.Add(tr5)


                'Asset Des Feild
                Dim PER1 As New TableRow
                Dim PEC1 As New TableCell
                PER1.ID = "PE1_" + row.ToString()
                PER1.CssClass = "ColorTR"
                PEC1.Text = "Asset Description"
                PEC1.BorderWidth = 1
                PEC1.CssClass = "Displaynametd"
                PER1.Controls.Add(PEC1)
                Dim AssetComboFeild As New Integer
                For AssetComboFeild = 0 To Count - 1
                    Dim PEC2 As New TableCell
                    Dim EquipmentComo As New DropDownList
                    Dim EQC As String = "ASSETTYPE" + row.ToString()
                    Dim EQV As String = Dts.Rows(AssetComboFeild).Item(EQC).ToString()
                    Dim Equip As New Selectdata()
                    Dim WhichCombo As String = "EQUIPMENT"
                    EquipmentComo = Equip.GetEquipmentCombo(WhichCombo)
                    EquipmentComo.SelectedValue = EQV
                    EquipmentComo.ID = "AS" + row.ToString() + "_" + AssetComboFeild.ToString()

                    If Dts.Rows(AssetComboFeild).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        EquipmentComo.Enabled = False
                    Else
                        EquipmentComo.Enabled = True
                    End If

                    PEC2.Controls.Add(EquipmentComo)
                    EquipmentComo.CssClass = "dropdown"
                    PEC2.CssClass = "CaseTD"
                    PEC2.BorderWidth = 1
                    PER1.Controls.Add(PEC2)
                Next
                tblComparision.Controls.Add(PER1)



                'Asset Cost Suggested
                Dim PER2 As New TableRow
                Dim PEC3 As New TableCell
                PER2.ID = "PE2_" + row.ToString()
                PER2.CssClass = "ColorTR"
                PER2.Height = 22
                PEC3.Text = "Asset Cost Suggested"
                PEC3.BorderWidth = 1
                PEC3.CssClass = "Displaynametd"
                PER2.Controls.Add(PEC3)
                Dim AssetSuggested As New Integer
                For AssetSuggested = 0 To Count - 1
                    Dim PEC4 As New TableCell
                    Dim ASSSUG As String = "ASSESTSUGGESTED" + row.ToString()
                    Dim ASuggested As String = Dts.Rows(AssetSuggested).Item(ASSSUG).ToString()
                    PEC4.Text = FormatNumber(ASuggested.ToString, 0)
                    PEC4.Style.Add("text-align", "center")
                    PEC4.BorderWidth = 1
                    PER2.Controls.Add(PEC4)
                Next
                tblComparision.Controls.Add(PER2)


                'Asset Cost Preferred
                Dim PER3 As New TableRow
                Dim PEC5 As New TableCell
                PER3.ID = "PE3_" + row.ToString()
                PER3.CssClass = "ColorTR"
                PEC5.Text = "Asset Cost Preferred"
                PEC5.BorderWidth = 1
                PEC5.CssClass = "Displaynametd"
                PER3.Controls.Add(PEC5)
                Dim AssetPreferred As New Integer
                For AssetPreferred = 0 To Count - 1
                    Dim PEC6 As New TableCell
                    Dim AssetPrefTextbox As New TextBox
                    Dim ASSPREF As String = "ASSESTPREFERRED" + row.ToString()
                    Dim APreferred As String = Dts.Rows(AssetPreferred).Item(ASSPREF).ToString()
                    AssetPrefTextbox.Text = FormatNumber(APreferred.ToString, 0)
                    AssetPrefTextbox.ID = "APRE" + row.ToString() + "_" + AssetPreferred.ToString()
                    AssetPrefTextbox.CssClass = "textBox"

                    If Dts.Rows(AssetPreferred).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        AssetPrefTextbox.Enabled = False
                    Else
                        AssetPrefTextbox.Enabled = True
                    End If

                    PEC6.Controls.Add(AssetPrefTextbox)
                    PEC6.CssClass = "CaseTD"
                    PEC6.BorderWidth = 1
                    PER3.Controls.Add(PEC6)
                Next
                tblComparision.Controls.Add(PER3)


                'Area Type Feild
                Dim PER4 As New TableRow
                Dim PEC7 As New TableCell
                PER4.ID = "PE4_" + row.ToString()
                PER4.CssClass = "ColorTR"
                PER4.Height = 22
                PEC7.Text = "Area Type"
                PEC7.BorderWidth = 1
                PEC7.CssClass = "Displaynametd"
                PER4.Controls.Add(PEC7)
                Dim areatype As New Integer
                For areatype = 0 To Count - 1
                    Dim PEC8 As New TableCell
                    Dim AT As String = "AREATYPE" + row.ToString()
                    PEC8.Text = Dts.Rows(areatype).Item(AT).ToString()
                    PEC8.Style.Add("text-align", "center")
                    PEC8.BorderWidth = 1
                    PER4.Controls.Add(PEC8)

                Next
                tblComparision.Controls.Add(PER4)


                'Plant Area Suggested
                Dim PER5 As New TableRow
                Dim PEC9 As New TableCell
                PER5.ID = "PE5_" + row.ToString()
                PER5.CssClass = "ColorTR"
                PEC9.Text = "Plant Area Suggested"
                PEC9.BorderWidth = 1
                PEC9.CssClass = "Displaynametd"
                PER5.Controls.Add(PEC9)
                Dim AreaSuggested As New Integer
                For AreaSuggested = 0 To Count - 1
                    Dim PEC10 As New TableCell
                    Dim ARSSSUG As String = "PLANTAREASUGGESTED" + row.ToString()
                    Dim Unit As String = Dts.Rows(AreaSuggested).Item("UNIT").ToString()
                    Dim ARSuggested As String = Dts.Rows(AreaSuggested).Item(ARSSSUG).ToString()
                    If Unit = 0 Then
                        PEC10.Text = "<b>Plant Area in (square feet )</b><br />" + FormatNumber(ARSuggested.ToString, 0)
                    Else
                        PEC10.Text = "<b>Plant Area (square meters )</b><br />" + FormatNumber(ARSuggested.ToString, 0)
                    End If
                    PEC10.Style.Add("text-align", "center")
                    PEC10.BorderWidth = 1
                    PER5.Controls.Add(PEC10)
                Next
                tblComparision.Controls.Add(PER5)


                'Plant Area  Preferred
                Dim PER6 As New TableRow
                Dim PEC11 As New TableCell
                PER6.ID = "PE6_" + row.ToString()
                PER6.CssClass = "ColorTR"
                PEC11.Text = "Plant Area Preferred"
                PEC11.BorderWidth = 1
                PEC11.CssClass = "Displaynametd"
                PER6.Controls.Add(PEC11)
                Dim AreaPreferred As New Integer
                For AreaPreferred = 0 To Count - 1
                    Dim PEC12 As New TableCell
                    Dim AreaPrefTextbox As New TextBox
                    Dim Unit1 As String = Dts.Rows(AreaPreferred).Item("UNIT").ToString()
                    Dim AreaLable As New Label
                    If Unit1 = 0 Then
                        AreaLable.Text = "<b>Plant Area in (square feet )</b><br />"
                    Else
                        AreaLable.Text = "</b>Plant Area (square meters )</b><br />"
                    End If
                    Dim ARSSPREF As String = "PLANTAREAPREFERRED" + row.ToString()
                    Dim ARPreferred As String = Dts.Rows(AreaPreferred).Item(ARSSPREF).ToString()
                    AreaPrefTextbox.Text = FormatNumber(ARPreferred.ToString, 0)
                    AreaPrefTextbox.ID = "ARPRE" + row.ToString() + "_" + AreaPreferred.ToString()
                    AreaPrefTextbox.CssClass = "textBox"

                    If Dts.Rows(AreaPreferred).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        AreaPrefTextbox.Enabled = False
                    Else
                        AreaPrefTextbox.Enabled = True
                    End If

                    PEC12.Controls.Add(AreaLable)
                    PEC12.Controls.Add(AreaPrefTextbox)
                    PEC12.CssClass = "CaseTD"
                    PEC12.BorderWidth = 1
                    PER6.Controls.Add(PEC12)
                Next
                tblComparision.Controls.Add(PER6)



                'Process Energy Consumption
                Dim PER7 As New TableRow
                Dim PEC13 As New TableCell
                PER7.ID = "PE7_" + row.ToString()
                PER7.CssClass = "ColorTR"
                PEC13.Text = "Energy Consumption<br> Suggested"
                PEC13.BorderWidth = 1
                PEC13.CssClass = "Displaynametd"
                PER7.Controls.Add(PEC13)
                Dim EnergySuggested As New Integer
                For EnergySuggested = 0 To Count - 1
                    Dim PEC14 As New TableCell
                    Dim ENSSSUG As String = "PROCESSENERGYSUGGESTED" + row.ToString()
                    Dim ENSuggested As String = Dts.Rows(EnergySuggested).Item(ENSSSUG).ToString()
                    PEC14.Text = FormatNumber(ENSuggested.ToString, 0)
                    PEC14.Style.Add("text-align", "center")
                    PEC14.BorderWidth = 1
                    PER7.Controls.Add(PEC14)
                Next
                tblComparision.Controls.Add(PER7)



                'Process Energy Preferred
                Dim PER8 As New TableRow
                Dim PEC15 As New TableCell
                PER8.ID = "PE8_" + row.ToString()
                PER8.CssClass = "ColorTR"
                PEC15.Text = "Energy Consumption<br> Preferred"
                PEC15.BorderWidth = 1
                PEC15.CssClass = "Displaynametd"
                PER8.Controls.Add(PEC15)
                Dim EnergyPreferred As New Integer
                For EnergyPreferred = 0 To Count - 1
                    Dim PEC116 As New TableCell
                    Dim EnergyPrefTextbox As New TextBox
                    Dim ENSSPREF As String = "PROCESSENERGYPREFERRED" + row.ToString()
                    Dim ENPreferred As String = Dts.Rows(EnergyPreferred).Item(ENSSPREF).ToString()
                    EnergyPrefTextbox.Text = FormatNumber(ENPreferred.ToString, 0)
                    EnergyPrefTextbox.ID = "ENPR" + row.ToString() + "_" + EnergyPreferred.ToString()
                    EnergyPrefTextbox.CssClass = "textBox"

                    If Dts.Rows(EnergyPreferred).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        EnergyPrefTextbox.Enabled = False
                    Else
                        EnergyPrefTextbox.Enabled = True
                    End If

                    PEC116.Controls.Add(EnergyPrefTextbox)
                    PEC116.CssClass = "CaseTD"
                    PEC116.BorderWidth = 1
                    PER8.Controls.Add(PEC116)
                Next
                tblComparision.Controls.Add(PER8)


                'Mfg Dept Combo
                Dim PER9 As New TableRow
                Dim PEC17 As New TableCell
                PER9.ID = "PE9_" + row.ToString()
                PER9.CssClass = "ColorTR"
                PEC17.Text = "Manufacturing Process<br/> or Department"
                PEC17.CssClass = "Displaynametd"
                PEC17.BorderWidth = 1
                PER9.Controls.Add(PEC17)
                Dim MfgDept As New Integer
                For MfgDept = 0 To Count - 1
                    Dim PEC18 As New TableCell
                    Dim DeptCombo As New DropDownList
                    Dim DP2 = "DEPT" + row.ToString()
                    Dim GetDept As New RepeatedControls()
                    DeptCombo = GetDept.DeptDropdown()
                    DeptCombo.SelectedValue = Dts.Rows(MfgDept).Item(DP2).ToString()
                    DeptCombo.CssClass = "dropdown"
                    DeptCombo.ID = "MDP" + row.ToString() + "_" + MfgDept.ToString()

                    If Dts.Rows(MfgDept).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo.Enabled = False
                    Else
                        DeptCombo.Enabled = True
                    End If

                    PEC18.Controls.Add(DeptCombo)
                    PEC18.BorderWidth = 1
                    PEC18.CssClass = "CaseTD"
                    PER9.Controls.Add(PEC18)
                Next
                tblComparision.Controls.Add(PER9)


















            Next







        Catch ex As Exception
            Response.Write("Error" + ex.Message.ToString())

        End Try

    End Sub

    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click, Update2.Click
        Try

            'declaring variables

            Dim I As New Integer
            Dim J As New Integer
            Dim ProcessUpdate As New Update()

            'loop and array dclaration  

            For I = 0 To Count - 1
                Dim AD(30) As String
                Dim ACP(30) As String
                Dim PAP(30) As String
                Dim PEC(30) As String
                Dim MD(30) As String
                Dim CaseID As String = ""

                'passing a id to form

                For J = 1 To 30
                    AD(J) = Request.Form("ctl00$ContentPlaceHolder1$AS" + J.ToString + "_" + I.ToString())
                    ACP(J) = Request.Form("ctl00$ContentPlaceHolder1$APRE" + J.ToString + "_" + I.ToString())
                    PAP(J) = Request.Form("ctl00$ContentPlaceHolder1$ARPRE" + J.ToString + "_" + I.ToString())
                    PEC(J) = Request.Form("ctl00$ContentPlaceHolder1$ENPR" + J.ToString + "_" + I.ToString())
                    MD(J) = Request.Form("ctl00$ContentPlaceHolder1$MDP" + J.ToString + "_" + I.ToString())
                    CaseID = Request.Form("Case" + I.ToString())

                Next

                'checking case id 

                If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
                Else
                    ProcessUpdate.ProcessUpdate(CaseID, AD, ACP, PAP, PEC, MD)

                End If
            Next
            Response.Redirect("EquipmentIN.aspx")
        Catch ex As Exception
            Response.Write("UpdateError :" + ex.Message.ToString())
        End Try

    End Sub

    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click, CalCulate2.Click
        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))

            'Checking The Case 
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                CI = CI + CaseID + ","
            End If

        Next
        If CI <> "" Then
            CI = CI.Remove(CI.Length - 1, 1)
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=EquipmentIN.aspx")
        End If

    End Sub
End Class
