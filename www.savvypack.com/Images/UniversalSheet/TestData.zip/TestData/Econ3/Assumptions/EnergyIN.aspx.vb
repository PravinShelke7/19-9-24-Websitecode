Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class EnergyAssumption
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetEnergyQuery(Cases, UserName, Password)
            Count = Dts.Rows.Count


            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='140px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>" + "<br><img alt='' src='../../Images/spacer.gif' width='300px'height='0px'  />"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)


            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)
            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                td4.Text = "Electricity:" + Dts.Rows(J).Item("Title4") + "/kwh" + "<br/>" + " 	Natural Gas:" + Dts.Rows(J).Item("Title4") + "/Mcf"
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)



            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)

            'Break
            Dim tr4 As New TableRow
            Dim td7 As New TableCell
            td7.Text = "<b>Energy Prices</b>"
            tr4.CssClass = "Layer"
            tr4.Controls.Add(td7)
            Dim Break As New Integer
            For Break = 0 To Count - 1
                Dim td8 As New TableCell
                td8.Text = "&nbsp;"
                tr4.Controls.Add(td8)
            Next
            tblComparision.Controls.Add(tr4)

            'Electricity Prices
            Dim PER1 As New TableRow
            Dim PEC1 As New TableCell
            PER1.ID = "PE1_1"
            PER1.CssClass = "ColorTR"
            PEC1.Text = "Electricity"
            PEC1.CssClass = "Displaynametd"
            PEC1.BorderWidth = 1
            PER1.Controls.Add(PEC1)
            Dim EnergyS As New Integer
            For EnergyS = 0 To Count - 1
                Dim PEC2 As New TableCell
                Dim EnergySugg As New Table
                Dim ER1 As New TableRow
                Dim ER2 As New TableRow
                Dim EC1 As New TableCell
                Dim EC2 As New TableCell
                Dim EC3 As New TableCell
                Dim EC4 As New TableCell
                Dim EnerySug As New TextBox
                EC1.Text = "<b>Suggested</b>"
                EC2.Text = Dts.Rows(EnergyS).Item("ELECTRICITYSUG").ToString()
                EC3.Text = "<b>Preferred</b>"
                EnerySug.Text = Dts.Rows(EnergyS).Item("ELECTRICITYPREFPRICE").ToString()
                EnerySug.CssClass = "textBox"
                EnerySug.ID = "ESUG" + EnergyS.ToString()

                If Dts.Rows(EnergyS).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    EnerySug.Enabled = False
                Else
                    EnerySug.Enabled = True
                End If

                EC4.Controls.Add(EnerySug)
                ER1.Controls.Add(EC1)
                ER1.Controls.Add(EC3)
                ER2.Controls.Add(EC2)
                ER2.Controls.Add(EC4)
                EnergySugg.Controls.Add(ER1)
                EnergySugg.Controls.Add(ER2)
                PEC2.Controls.Add(EnergySugg)
                PEC2.Style.Add("text-align", "center")
                PEC2.BorderWidth = 1
                PER1.Controls.Add(PEC2)
            Next
            tblComparision.Controls.Add(PER1)


            'Nautral Gas Prices
            Dim PER2 As New TableRow
            Dim PEC3 As New TableCell
            PER2.ID = "PE2_1"
            PER2.CssClass = "ColorTR"
            PEC3.Text = "Natural Gas"
            PEC3.CssClass = "Displaynametd"
            PEC3.BorderWidth = 1
            PER2.Controls.Add(PEC3)
            Dim NaturalS As New Integer
            For NaturalS = 0 To Count - 1
                Dim PEC4 As New TableCell
                Dim NaturalSugg As New Table
                Dim NR1 As New TableRow
                Dim NR2 As New TableRow
                Dim NC1 As New TableCell
                Dim NC2 As New TableCell
                Dim NC3 As New TableCell
                Dim NC4 As New TableCell
                Dim NaturalST As New TextBox
                NC1.Text = "<b>Suggested</b>"
                NC2.Text = Dts.Rows(NaturalS).Item("NATURALGASSUG").ToString()
                NC3.Text = "<b>Preferred</b>"
                NaturalST.Text = Dts.Rows(NaturalS).Item("NATURALGASPREFPRICE").ToString()
                NC4.Controls.Add(NaturalST)
                NR1.Controls.Add(NC1)
                NR2.Controls.Add(NC2)
                NR1.Controls.Add(NC3)
                NR2.Controls.Add(NC4)
                NaturalSugg.Controls.Add(NR1)
                NaturalSugg.Controls.Add(NR2)
                PEC4.Controls.Add(NaturalSugg)
                NaturalST.ID = "NG" + NaturalS.ToString()
                NaturalST.CssClass = "textBox"

                If Dts.Rows(NaturalS).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    NaturalST.Enabled = False
                Else
                    NaturalST.Enabled = True
                End If

                PEC4.BorderWidth = 1
                PEC4.Style.Add("text-align", "Center")
                PER2.Controls.Add(PEC4)
            Next
            tblComparision.Controls.Add(PER2)

            '-----------------------------------------------------------------------------------
            'Energy Requirements
            'Break2
            Dim tr5 As New TableRow
            Dim td9 As New TableCell
            td9.Text = "<b>Energy Requirements</b>"
            tr5.CssClass = "Layer"
            tr5.Controls.Add(td9)
            Dim Break2 As New Integer
            For Break2 = 0 To Count - 1
                Dim td10 As New TableCell
                td10.Text = "&nbsp;"
                tr5.Controls.Add(td10)
            Next
            tblComparision.Controls.Add(tr5)


            'Production Req
            Dim PER3 As New TableRow
            Dim PEC5 As New TableCell
            PER3.ID = "PE3_1"
            PER3.CssClass = "ColorTR"
            PEC5.Text = "Production"
            PEC5.CssClass = "Displaynametd"
            PEC5.BorderWidth = 1
            PER3.Controls.Add(PEC5)
            Dim ProductionE As New Integer
            For ProductionE = 0 To Count - 1
                Dim PEC6 As New TableCell
                Dim Production As New Table
                Dim PR1 As New TableRow
                Dim PR2 As New TableRow
                Dim PC1 As New TableCell
                Dim PC2 As New TableCell
                Dim PC3 As New TableCell
                Dim PC4 As New TableCell
                PC1.Width = 150
                PC1.Text = "<b>Electricity</b>(kwh)"
                PC2.Text = FormatNumber(Dts.Rows(ProductionE).Item("PRODUCTIONELECTRICENERGYREQ").ToString(), 0)
                PC3.Text = "<b>Natural Gas</b>(cubic ft)"
                PC4.Text = FormatNumber(Dts.Rows(ProductionE).Item("PRODUCTIONNATURALENERGYREQ").ToString(), 0)
                PR1.Controls.Add(PC1)
                PR2.Controls.Add(PC2)
                PR1.Controls.Add(PC3)
                PR2.Controls.Add(PC4)
                Production.Controls.Add(PR1)
                Production.Controls.Add(PR2)
                PEC6.Controls.Add(Production)
                PEC6.BorderWidth = 1
                PEC6.Style.Add("text-align", "center")
                PER3.Controls.Add(PEC6)
            Next
            tblComparision.Controls.Add(PER3)


            'Warehouse Req
            Dim PER4 As New TableRow
            Dim PEC7 As New TableCell
            PER4.ID = "PE4_1"
            PER4.CssClass = "ColorTR"
            PEC7.Text = "Warehouse"
            PEC7.CssClass = "Displaynametd"
            PEC7.BorderWidth = 1
            PER4.Controls.Add(PEC7)
            Dim WarehouseE As New Integer
            For WarehouseE = 0 To Count - 1
                Dim PEC8 As New TableCell
                Dim Warehouse As New Table
                Dim WR1 As New TableRow
                Dim WR2 As New TableRow
                Dim WC1 As New TableCell
                Dim WC2 As New TableCell
                Dim WC3 As New TableCell
                Dim WC4 As New TableCell
                WC1.Text = "<b>Electricity</b>(kwh)"
                WC1.Width = 150
                WC2.Text = FormatNumber(Dts.Rows(WarehouseE).Item("WAREHOUSEELECTRICENERGYREQ").ToString(), 0)
                'WC2.ForeColor = Drawing.Color.Red
                WC3.Text = "<b>Natural Gas</b>(cubic ft)"
                WC4.Text = FormatNumber(Dts.Rows(WarehouseE).Item("WAREHOUSENATURALENERGYREQ").ToString(), 0)
                WR1.Controls.Add(WC1)
                WR2.Controls.Add(WC2)
                WR1.Controls.Add(WC3)
                WR2.Controls.Add(WC4)
                Warehouse.Controls.Add(WR1)
                Warehouse.Controls.Add(WR2)
                PEC8.Controls.Add(Warehouse)
                PEC8.BorderWidth = 1
                PEC8.Style.Add("text-align", "center")
                PER4.Controls.Add(PEC8)
            Next
            tblComparision.Controls.Add(PER4)


            'Office Req
            Dim PER5 As New TableRow
            Dim PEC9 As New TableCell
            PER5.ID = "PE5_1"
            PER5.CssClass = "ColorTR"
            PEC9.Text = "Office"
            PEC9.CssClass = "Displaynametd"
            PEC9.BorderWidth = 1
            PER5.Controls.Add(PEC9)
            Dim OfficeE As New Integer
            For OfficeE = 0 To Count - 1
                Dim PEC10 As New TableCell
                Dim Office As New Table
                Dim OR1 As New TableRow
                Dim OR2 As New TableRow
                Dim OC1 As New TableCell
                Dim OC2 As New TableCell
                Dim OC3 As New TableCell
                Dim OC4 As New TableCell
                OC1.Text = "<b>Electricity</b>(kwh)"
                OC1.Width = 150
                OC2.Text = FormatNumber(Dts.Rows(OfficeE).Item("OFFICEELECTRICENERGYREQ").ToString(), 0)
                OC3.Text = "<b>Natural Gas</b>(cubic ft)"
                OC4.Text = FormatNumber(Dts.Rows(OfficeE).Item("OFFICENATURALENERGYREQ").ToString(), 0)
                OR1.Controls.Add(OC1)
                OR2.Controls.Add(OC2)
                OR1.Controls.Add(OC3)
                OR2.Controls.Add(OC4)
                Office.Controls.Add(OR1)
                Office.Controls.Add(OR2)
                PEC10.Controls.Add(Office)
                PEC10.BorderWidth = 1
                PEC10.Style.Add("text-align", "center")
                PER5.Controls.Add(PEC10)
            Next
            tblComparision.Controls.Add(PER5)


            'Support Req
            Dim PER6 As New TableRow
            Dim PEC11 As New TableCell
            PER6.ID = "PE6_1"
            PER6.CssClass = "ColorTR"
            PEC11.Text = "Support"
            PEC11.CssClass = "Displaynametd"
            PEC11.BorderWidth = 1
            PER6.Controls.Add(PEC11)
            Dim SupportE As New Integer
            For SupportE = 0 To Count - 1
                Dim PEC12 As New TableCell
                Dim Support As New Table
                Dim SR1 As New TableRow
                Dim SR2 As New TableRow
                Dim SC1 As New TableCell
                Dim SC2 As New TableCell
                Dim SC3 As New TableCell
                Dim SC4 As New TableCell
                SC1.Text = "<b>Electricity</b>(kwh)"
                SC1.Width = 150
                SC2.Text = FormatNumber(Dts.Rows(SupportE).Item("SUPPORTELECTRICENERGYREQ").ToString(), 0)
                SC3.Text = "<b>Natural Gas</b>(cubic ft)"
                SC4.Text = FormatNumber(Dts.Rows(SupportE).Item("SUPPORTNATURALENERGYREQ").ToString(), 0)
                SR1.Controls.Add(SC1)
                SR2.Controls.Add(SC2)
                SR1.Controls.Add(SC3)
                SR2.Controls.Add(SC4)
                Support.Controls.Add(SR1)
                Support.Controls.Add(SR2)
                PEC12.Controls.Add(Support)
                PEC12.BorderWidth = 1
                PEC12.Style.Add("text-align", "center")
                PER6.Controls.Add(PEC12)
            Next
            tblComparision.Controls.Add(PER6)



            'Total Req
            Dim PER7 As New TableRow
            Dim PEC13 As New TableCell
            PER7.ID = "PE7_1"
            PER7.CssClass = "ColorTR"
            PEC13.Text = "Total Energy Requirements"
            PEC13.CssClass = "Displaynametd"
            PEC13.BorderWidth = 1
            PER7.Controls.Add(PEC13)
            Dim TotalE As New Integer
            For TotalE = 0 To Count - 1
                Dim PEC14 As New TableCell
                Dim Total As New Table
                Dim TOR1 As New TableRow
                Dim TOR2 As New TableRow
                Dim TOC1 As New TableCell
                Dim TOC2 As New TableCell
                Dim TOC3 As New TableCell
                Dim TOC4 As New TableCell
                TOC1.Text = "<b>Electricity</b>(kwh)"
                TOC1.Width = 150
                TOC2.Text = FormatNumber(Dts.Rows(TotalE).Item("TOTALELECTRICENERGYREQ").ToString(), 0)
                TOC3.Text = "<b>Natural Gas</b>(cubic ft)"
                TOC4.Text = FormatNumber(Dts.Rows(TotalE).Item("TOTALNATURALENERGYREQ").ToString(), 0)
                TOR1.Controls.Add(TOC1)
                TOR2.Controls.Add(TOC2)
                TOR1.Controls.Add(TOC3)
                TOR2.Controls.Add(TOC4)
                Total.Controls.Add(TOR1)
                Total.Controls.Add(TOR2)
                PEC14.Controls.Add(Total)
                PEC14.BorderWidth = 1
                PEC14.Style.Add("text-align", "center")
                PER7.Controls.Add(PEC14)
            Next
            tblComparision.Controls.Add(PER7)






            '-----------------------------------------------------------------------------------
            'Energy Cost
            'Break3
            Dim tr6 As New TableRow
            Dim td11 As New TableCell
            td11.Text = "<b>Energy Cost</b>"
            tr6.CssClass = "Layer"
            tr6.Controls.Add(td11)
            Dim Break3 As New Integer
            For Break3 = 0 To Count - 1
                Dim td12 As New TableCell
                td12.Text = "&nbsp;"
                tr6.Controls.Add(td12)
            Next
            tblComparision.Controls.Add(tr6)


            'Production Cost
            Dim PER8 As New TableRow
            Dim PEC15 As New TableCell
            PER8.ID = "PE8_1"
            PER8.CssClass = "ColorTR"
            PEC15.Text = "Production"
            PEC15.CssClass = "Displaynametd"
            PEC15.BorderWidth = 1
            PER8.Controls.Add(PEC15)
            Dim ProductionC As New Integer
            For ProductionC = 0 To Count - 1
                Dim PEC16 As New TableCell
                Dim ProductionCO As New Table
                Dim PCR1 As New TableRow
                Dim PCR2 As New TableRow
                Dim PCC1 As New TableCell
                Dim PCC2 As New TableCell
                Dim PCC3 As New TableCell
                Dim PCC4 As New TableCell
                Dim PCC5 As New TableCell
                Dim PCC6 As New TableCell
                PCC1.Text = "<b>Electricity</b>(" + Dts.Rows(ProductionC).Item("TITLE4") + ")"
                PCC2.Text = FormatNumber(Dts.Rows(ProductionC).Item("PRODUCTIONELECTRICENERGYCOST").ToString(), 0)
                PCC3.Text = "<b>Natural Gas</b>(" + Dts.Rows(ProductionC).Item("TITLE4") + ")"
                PCC4.Text = FormatNumber(Dts.Rows(ProductionC).Item("PRODUCTIONNATURALENERGYCOST").ToString(), 0)
                PCC5.Text = "<b>Total</b>(" + Dts.Rows(ProductionC).Item("TITLE4") + ")"
                PCC6.Text = FormatNumber(Dts.Rows(ProductionC).Item("PRODUCTIONTOTALENERGYCOST").ToString(), 0)
                PCR1.Controls.Add(PCC1)
                PCR2.Controls.Add(PCC2)
                PCR1.Controls.Add(PCC3)
                PCR2.Controls.Add(PCC4)
                PCR1.Controls.Add(PCC5)
                PCR2.Controls.Add(PCC6)
                ProductionCO.Controls.Add(PCR1)
                ProductionCO.Controls.Add(PCR2)
                PEC16.Controls.Add(ProductionCO)
                PEC16.BorderWidth = 1
                PEC16.Style.Add("text-align", "center")
                PER8.Controls.Add(PEC16)
            Next
            tblComparision.Controls.Add(PER8)




            'Warehouse Cost
            Dim PER9 As New TableRow
            Dim PEC17 As New TableCell
            PER9.ID = "PE9_1"
            PER9.CssClass = "ColorTR"
            PEC17.Text = "Warehouse"
            PEC17.CssClass = "Displaynametd"
            PEC17.BorderWidth = 1
            PER9.Controls.Add(PEC17)
            Dim WarehouseC As New Integer
            For WarehouseC = 0 To Count - 1
                Dim PEC18 As New TableCell
                Dim WarehouseCO As New Table
                Dim WCR1 As New TableRow
                Dim WCR2 As New TableRow
                Dim WCC1 As New TableCell
                Dim WCC2 As New TableCell
                Dim WCC3 As New TableCell
                Dim WCC4 As New TableCell
                Dim WCC5 As New TableCell
                Dim WCC6 As New TableCell
                WCC1.Text = "<b>Electricity</b>(" + Dts.Rows(WarehouseC).Item("TITLE4") + ")"
                WCC2.Text = FormatNumber(Dts.Rows(WarehouseC).Item("WAREHOUSEELECTRICENERGYCOST").ToString(), 0)
                WCC3.Text = "<b>Natural Gas</b>(" + Dts.Rows(WarehouseC).Item("TITLE4") + ")"
                WCC4.Text = FormatNumber(Dts.Rows(WarehouseC).Item("WAREHOUSENATURALENERGYCOST").ToString(), 0)
                WCC5.Text = "<b>Total</b>(" + Dts.Rows(WarehouseC).Item("TITLE4") + ")"
                WCC6.Text = FormatNumber(Dts.Rows(WarehouseC).Item("WAREHOUSETOTALENERGYCOST").ToString(), 0)
                WCR1.Controls.Add(WCC1)
                WCR2.Controls.Add(WCC2)
                WCR1.Controls.Add(WCC3)
                WCR2.Controls.Add(WCC4)
                WCR1.Controls.Add(WCC5)
                WCR2.Controls.Add(WCC6)
                WarehouseCO.Controls.Add(WCR1)
                WarehouseCO.Controls.Add(WCR2)
                PEC18.Controls.Add(WarehouseCO)
                PEC18.BorderWidth = 1
                PEC18.Style.Add("text-align", "center")
                PER9.Controls.Add(PEC18)
            Next
            tblComparision.Controls.Add(PER9)


            'Office Cost
            Dim PER10 As New TableRow
            Dim PEC19 As New TableCell
            PER10.ID = "PE10_1"
            PER10.CssClass = "ColorTR"
            PEC19.Text = "Office"
            PEC19.CssClass = "Displaynametd"
            PEC19.BorderWidth = 1
            PER10.Controls.Add(PEC19)
            Dim OfficeC As New Integer
            For OfficeC = 0 To Count - 1
                Dim PEC20 As New TableCell
                Dim OfficeCO As New Table
                Dim OCR1 As New TableRow
                Dim OCR2 As New TableRow
                Dim OCC1 As New TableCell
                Dim OCC2 As New TableCell
                Dim OCC3 As New TableCell
                Dim OCC4 As New TableCell
                Dim OCC5 As New TableCell
                Dim OCC6 As New TableCell
                OCC1.Text = "<b>Electricity</b>(" + Dts.Rows(OfficeC).Item("TITLE4") + ")"
                OCC2.Text = FormatNumber(Dts.Rows(OfficeC).Item("OFFICEELECTRICENERGYCOST").ToString(), 0)
                OCC3.Text = "<b>Natural Gas</b>(" + Dts.Rows(OfficeC).Item("TITLE4") + ")"
                OCC4.Text = FormatNumber(Dts.Rows(OfficeC).Item("OFFICENATURALENERGYCOST").ToString(), 0)
                OCC5.Text = "<b>Total</b>(" + Dts.Rows(OfficeC).Item("TITLE4") + ")"
                OCC6.Text = FormatNumber(Dts.Rows(OfficeC).Item("OFFICETOTALENERGYCOST").ToString(), 0)
                OCR1.Controls.Add(OCC1)
                OCR2.Controls.Add(OCC2)
                OCR1.Controls.Add(OCC3)
                OCR2.Controls.Add(OCC4)
                OCR1.Controls.Add(OCC5)
                OCR2.Controls.Add(OCC6)
                OfficeCO.Controls.Add(OCR1)
                OfficeCO.Controls.Add(OCR2)
                PEC20.Controls.Add(OfficeCO)
                PEC20.BorderWidth = 1
                PEC20.Style.Add("text-align", "center")
                PER10.Controls.Add(PEC20)
            Next
            tblComparision.Controls.Add(PER10)


            'Support Cost
            Dim PER11 As New TableRow
            Dim PEC21 As New TableCell
            PER11.ID = "PE11_1"
            PER11.CssClass = "ColorTR"
            PEC21.Text = "Support"
            PEC21.CssClass = "Displaynametd"
            PEC21.BorderWidth = 1
            PER11.Controls.Add(PEC21)
            Dim SupportC As New Integer
            For SupportC = 0 To Count - 1
                Dim PEC22 As New TableCell
                Dim SupportCO As New Table
                Dim SCR1 As New TableRow
                Dim SCR2 As New TableRow
                Dim SCC1 As New TableCell
                Dim SCC2 As New TableCell
                Dim SCC3 As New TableCell
                Dim SCC4 As New TableCell
                Dim SCC5 As New TableCell
                Dim SCC6 As New TableCell
                SCC1.Text = "<b>Electricity</b>(" + Dts.Rows(SupportC).Item("TITLE4") + ")"
                SCC2.Text = FormatNumber(Dts.Rows(SupportC).Item("SUPPORTELECTRICENERGYCOST").ToString(), 0)
                SCC3.Text = "<b>Natural Gas</b>(" + Dts.Rows(SupportC).Item("TITLE4") + ")"
                SCC4.Text = FormatNumber(Dts.Rows(SupportC).Item("SUPPORTNATURALENERGYCOST").ToString(), 0)
                SCC5.Text = "<b>Total</b>(" + Dts.Rows(SupportC).Item("TITLE4") + ")"
                SCC6.Text = FormatNumber(Dts.Rows(SupportC).Item("SUPPORTTOTALENERGYCOST").ToString(), 0)
                SCR1.Controls.Add(SCC1)
                SCR2.Controls.Add(SCC2)
                SCR1.Controls.Add(SCC3)
                SCR2.Controls.Add(SCC4)
                SCR1.Controls.Add(SCC5)
                SCR2.Controls.Add(SCC6)
                SupportCO.Controls.Add(SCR1)
                SupportCO.Controls.Add(SCR2)
                PEC22.Controls.Add(SupportCO)
                PEC22.BorderWidth = 1
                PEC22.Style.Add("text-align", "center")
                PER11.Controls.Add(PEC22)
            Next
            tblComparision.Controls.Add(PER11)



            'Total Cost
            Dim PER12 As New TableRow
            Dim PEC23 As New TableCell
            PER12.ID = "PE12_1"
            PER12.CssClass = "ColorTR"
            PEC23.Text = "Total Energy Cost"
            PEC23.CssClass = "Displaynametd"
            PEC23.BorderWidth = 1
            PER12.Controls.Add(PEC23)
            Dim TotalC As New Integer
            For TotalC = 0 To Count - 1
                Dim PEC24 As New TableCell
                Dim TotalCO As New Table
                Dim TCR1 As New TableRow
                Dim TCR2 As New TableRow
                Dim TCC1 As New TableCell
                Dim TCC2 As New TableCell
                Dim TCC3 As New TableCell
                Dim TCC4 As New TableCell
                Dim TCC5 As New TableCell
                Dim TCC6 As New TableCell
                TCC1.Text = "<b>Electricity</b>(" + Dts.Rows(TotalC).Item("TITLE4") + ")"
                TCC2.Text = FormatNumber(Dts.Rows(TotalC).Item("TOTALELECTRICENERGYCOST").ToString(), 0)
                TCC3.Text = "<b>Natural Gas</b>(" + Dts.Rows(TotalC).Item("TITLE4") + ")"
                TCC4.Text = FormatNumber(Dts.Rows(TotalC).Item("TOTALNATURALENERGYCOST").ToString(), 0)
                TCC5.Text = "<b>Total</b>(" + Dts.Rows(TotalC).Item("TITLE4") + ")"
                TCC6.Text = FormatNumber(Dts.Rows(TotalC).Item("TOTALTOTALENERGYCOST").ToString(), 0)
                TCR1.Controls.Add(TCC1)
                TCR2.Controls.Add(TCC2)
                TCR1.Controls.Add(TCC3)
                TCR2.Controls.Add(TCC4)
                TCR1.Controls.Add(TCC5)
                TCR2.Controls.Add(TCC6)
                TotalCO.Controls.Add(TCR1)
                TotalCO.Controls.Add(TCR2)
                PEC24.Controls.Add(TotalCO)
                PEC24.BorderWidth = 1
                PEC24.Style.Add("text-align", "center")
                PER12.Controls.Add(PEC24)
            Next
            tblComparision.Controls.Add(PER12)


        Catch ex As Exception
            Response.Write("Error:" + ex.Message.ToString())
        End Try
    End Sub

    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click

        'declaring variable 

        Dim I As New Integer
        'Dim J As New Integer
        Dim PlantEnergyUpdate As New Update()

        'case loop

        For I = 0 To Count - 1

            Dim ElectricityPre As String = ""
            Dim NaturalGas As String = ""

            Dim CaseId As String = ""

            'passing a field ID to form

            Dim EP As String = Request.Form("ctl00$ContentPlaceHolder1$ESUG" + I.ToString())
            Dim NG As String = Request.Form("ctl00$ContentPlaceHolder1$NG" + I.ToString())

            CaseId = Request.Form("Case" + I.ToString() + "")

            ElectricityPre = ElectricityPre + EP + ","
            NaturalGas = NaturalGas + NG + ","

            ElectricityPre = ElectricityPre.Remove(ElectricityPre.Length - 1)
            NaturalGas = NaturalGas.Remove(NaturalGas.Length - 1)

            'checking case ID

            If CaseId <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                PlantEnergyUpdate.PlantEnergyUpdate(CaseId, ElectricityPre, NaturalGas)

            End If

        Next

    End Sub

    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click
        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))

            'Checking The Case 
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                CI = CI + CaseID + ","
            End If

        Next
        If CI <> "" Then
            CI = CI.Remove(CI.Length - 1, 1)
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=EnergyIN.aspx")
        End If

    End Sub
End Class
