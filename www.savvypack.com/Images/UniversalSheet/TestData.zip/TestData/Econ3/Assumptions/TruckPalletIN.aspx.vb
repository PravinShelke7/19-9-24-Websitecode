Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class TruckPalletIn
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetPalletTruckSql(Cases, UserName, Password)
            Count = Dts.Rows.Count

            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='140px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDE").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)




            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)

            Dim row As New Integer
            For row = 1 To 1

                'Pallet Width
                Dim PATR1 As New TableRow
                Dim PATC1 As New TableCell
                PATR1.ID = "P1_1"
                PATR1.CssClass = "ColorTR"
                PATC1.Text = "Pallet Width"
                PATC1.CssClass = "Displaynametd"
                PATC1.BorderWidth = 1
                PATR1.Controls.Add(PATC1)
                Dim PalletWidth As New Integer
                For PalletWidth = 0 To Count - 1
                    Dim PATC2 As New TableCell
                    Dim PATTEXTBOX As New TextBox
                    Dim PATLABLE As New Label
                    Dim Convthic1 As String = Dts.Rows(PalletWidth).Item("THICKNESSCONVERSION")
                    Dim Unit1 As String = Dts.Rows(PalletWidth).Item("UNITS")
                    Dim PATTV As Double = Convert.ToDouble(Dts.Rows(PalletWidth).Item("PALLETWIDTH").ToString() * Convthic1)
                    PATTEXTBOX.Text = FormatNumber(PATTV.ToString(), 3)
                    If Unit1 = 0 Then
                        PATLABLE.Text = "Width(in)<br />"
                    Else
                        PATLABLE.Text = "Width(mm)<br />"
                    End If

                    If Dts.Rows(PalletWidth).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PATTEXTBOX.Enabled = False
                    Else
                        PATTEXTBOX.Enabled = True
                    End If

                    PATTEXTBOX.CssClass = "textBox"
                    PATTEXTBOX.ID = "P1" + PalletWidth.ToString()
                    PATC2.CssClass = "CaseTD"
                    PATC2.BorderWidth = 1
                    PATC2.Controls.Add(PATLABLE)
                    PATC2.Controls.Add(PATTEXTBOX)
                    PATR1.Controls.Add(PATC2)
                Next
                tblComparision.Controls.Add(PATR1)

                'Pallet Length
                Dim PATR2 As New TableRow
                Dim PATC3 As New TableCell
                PATR2.ID = "P2_1"
                PATR2.CssClass = "ColorTR"
                PATC3.Text = "Pallet Length"
                PATC3.CssClass = "Displaynametd"
                PATC3.BorderWidth = 1
                PATR2.Controls.Add(PATC3)
                Dim PalletLength As New Integer
                For PalletLength = 0 To Count - 1
                    Dim PATC4 As New TableCell
                    Dim PATTEXTBOX2 As New TextBox
                    Dim PATLABLE2 As New Label
                    Dim Convthic2 As String = Dts.Rows(PalletLength).Item("THICKNESSCONVERSION")
                    Dim Unit2 As String = Dts.Rows(PalletLength).Item("UNITS")
                    Dim PATTV2 As Double = Convert.ToDouble(Dts.Rows(PalletLength).Item("PALLETLENGTH").ToString() * Convthic2)
                    PATTEXTBOX2.Text = FormatNumber(PATTV2.ToString(), 3)
                    If Unit2 = 0 Then
                        PATLABLE2.Text = "Length(in)<br />"
                    Else
                        PATLABLE2.Text = "Length(mm)<br />"
                    End If

                    If Dts.Rows(PalletLength).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PATTEXTBOX2.Enabled = False
                    Else
                        PATTEXTBOX2.Enabled = True
                    End If


                    PATTEXTBOX2.CssClass = "textBox"
                    PATTEXTBOX2.ID = "P2" + PalletLength.ToString()
                    PATC4.CssClass = "CaseTD"
                    PATC4.BorderWidth = 1
                    PATC4.Controls.Add(PATLABLE2)
                    PATC4.Controls.Add(PATTEXTBOX2)
                    PATR2.Controls.Add(PATC4)
                Next
                tblComparision.Controls.Add(PATR2)


                'Pallet Height
                Dim PATR3 As New TableRow
                Dim PATC5 As New TableCell
                PATR3.ID = "P3_1"
                PATR3.CssClass = "ColorTR"
                PATC5.Text = "Pallet Height"
                PATC5.CssClass = "Displaynametd"
                PATC5.BorderWidth = 1
                PATR3.Controls.Add(PATC5)
                Dim PalletHeight As New Integer
                For PalletHeight = 0 To Count - 1
                    Dim PATC6 As New TableCell
                    Dim PATTEXTBOX3 As New TextBox
                    Dim PATLABLE3 As New Label
                    Dim Convthic3 As String = Dts.Rows(PalletHeight).Item("THICKNESSCONVERSION")
                    Dim Unit3 As String = Dts.Rows(PalletHeight).Item("UNITS")
                    Dim PATTV3 As Double = Convert.ToDouble(Dts.Rows(PalletHeight).Item("PALLETHEIGHT").ToString() * Convthic3)
                    PATTEXTBOX3.Text = FormatNumber(PATTV3.ToString(), 3)
                    If Unit3 = 0 Then
                        PATLABLE3.Text = "Height(in)<br />"
                    Else
                        PATLABLE3.Text = "Height(mm)<br />"
                    End If

                    If Dts.Rows(PalletHeight).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PATTEXTBOX3.Enabled = False
                    Else
                        PATTEXTBOX3.Enabled = True
                    End If


                    PATTEXTBOX3.CssClass = "textBox"
                    PATTEXTBOX3.ID = "P3" + PalletHeight.ToString()
                    PATC6.CssClass = "CaseTD"
                    PATC6.BorderWidth = 1
                    PATC6.Controls.Add(PATLABLE3)
                    PATC6.Controls.Add(PATTEXTBOX3)
                    PATR3.Controls.Add(PATC6)
                Next
                tblComparision.Controls.Add(PATR3)


                'Cartons Per Pallet
                Dim PATR4 As New TableRow
                Dim PATC7 As New TableCell
                PATR4.ID = "P4_1"
                PATR4.CssClass = "ColorTR"
                PATC7.Text = "Cartons Per Pallet"
                PATC7.CssClass = "Displaynametd"
                PATC7.BorderWidth = 1
                PATR4.Controls.Add(PATC7)
                Dim PalletCartons As New Integer
                For PalletCartons = 0 To Count - 1
                    Dim PATC8 As New TableCell
                    Dim PATTEXTBOX4 As New TextBox
                    Dim PATLABLE4 As New Label
                    Dim Unit4 As String = Dts.Rows(PalletCartons).Item("UNITS")
                    Dim PATTV4 As Double = Convert.ToDouble(Dts.Rows(PalletCartons).Item("CARTONSNUMBER").ToString())
                    PATTEXTBOX4.Text = FormatNumber(PATTV4.ToString(), 3)
                    If Unit4 = 0 Then
                        PATLABLE4.Text = "Number<br />"
                    Else
                        PATLABLE4.Text = "Number<br />"
                    End If

                    If Dts.Rows(PalletCartons).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PATTEXTBOX4.Enabled = False
                    Else
                        PATTEXTBOX4.Enabled = True
                    End If

                    PATTEXTBOX4.CssClass = "textBox"
                    PATTEXTBOX4.ID = "P4" + PalletCartons.ToString()
                    PATC8.CssClass = "CaseTD"
                    PATC8.BorderWidth = 1
                    PATC8.Controls.Add(PATLABLE4)
                    PATC8.Controls.Add(PATTEXTBOX4)
                    PATR4.Controls.Add(PATC8)
                Next
                tblComparision.Controls.Add(PATR4)


                'Product Per Pallet
                Dim PATR5 As New TableRow
                Dim PATC9 As New TableCell
                PATR5.ID = "P5_1"
                PATR5.CssClass = "ColorTR"
                PATC9.Text = "Product Per Pallet"
                PATC9.CssClass = "Displaynametd"
                PATC9.BorderWidth = 1
                PATR5.Controls.Add(PATC9)
                Dim PalletProduct As New Integer
                For PalletProduct = 0 To Count - 1
                    Dim PATC10 As New TableCell
                    Dim PATTEXTBOX5 As New TextBox
                    Dim PATLABLE5 As New Label
                    Dim Unit5 As String = Dts.Rows(PalletProduct).Item("UNITS")
                    Dim PATTV5 As Double = Convert.ToDouble(Dts.Rows(PalletProduct).Item("PRODUCTNUMBER").ToString())
                    PATTEXTBOX5.Text = FormatNumber(PATTV5.ToString(), 3)
                    If Unit5 = 0 Then
                        PATLABLE5.Text = "Number<br />"
                    Else
                        PATLABLE5.Text = "Number<br />"
                    End If

                    If Dts.Rows(PalletProduct).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PATTEXTBOX5.Enabled = False
                    Else
                        PATTEXTBOX5.Enabled = True
                    End If

                    PATTEXTBOX5.CssClass = "textBox"
                    PATTEXTBOX5.ID = "P5" + PalletProduct.ToString()
                    PATC10.CssClass = "CaseTD"
                    PATC10.BorderWidth = 1
                    PATC10.Controls.Add(PATLABLE5)
                    PATC10.Controls.Add(PATTEXTBOX5)
                    PATR5.Controls.Add(PATC10)
                Next
                tblComparision.Controls.Add(PATR5)


                'Truck Width
                Dim PATR6 As New TableRow
                Dim PATC11 As New TableCell
                PATR6.ID = "P6_1"
                PATR6.CssClass = "ColorTR"
                PATC11.Text = "Truck Width"
                PATC11.CssClass = "Displaynametd"
                PATC11.BorderWidth = 1
                PATR6.Controls.Add(PATC11)
                Dim TruckWidth As New Integer
                For TruckWidth = 0 To Count - 1
                    Dim PATC12 As New TableCell
                    Dim PATTEXTBOX6 As New TextBox
                    Dim PATLABLE6 As New Label
                    Dim Convthic6 As String = Dts.Rows(TruckWidth).Item("THICKNESSCONVERSION")
                    Dim Unit6 As String = Dts.Rows(TruckWidth).Item("UNITS")
                    Dim PATTV6 As Double = Convert.ToDouble(Dts.Rows(TruckWidth).Item("TRUCKWIDTH").ToString() * Convthic6)
                    PATTEXTBOX6.Text = FormatNumber(PATTV6.ToString(), 3)
                    If Unit6 = 0 Then
                        PATLABLE6.Text = "Width(in)<br />"
                    Else
                        PATLABLE6.Text = "Width(mm)<br />"
                    End If

                    If Dts.Rows(TruckWidth).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PATTEXTBOX6.Enabled = False
                    Else
                        PATTEXTBOX6.Enabled = True
                    End If


                    PATTEXTBOX6.CssClass = "textBox"
                    PATTEXTBOX6.ID = "T1" + TruckWidth.ToString()
                    PATC12.CssClass = "CaseTD"
                    PATC12.BorderWidth = 1
                    PATC12.Controls.Add(PATLABLE6)
                    PATC12.Controls.Add(PATTEXTBOX6)
                    PATR6.Controls.Add(PATC12)
                Next
                tblComparision.Controls.Add(PATR6)


                'Truck Length
                Dim PATR7 As New TableRow
                Dim PATC13 As New TableCell
                PATR7.ID = "P7_1"
                PATR7.CssClass = "ColorTR"
                PATC13.Text = "Truck Length"
                PATC13.CssClass = "Displaynametd"
                PATC13.BorderWidth = 1
                PATR7.Controls.Add(PATC13)
                Dim TruckLength As New Integer
                For TruckLength = 0 To Count - 1
                    Dim PATC14 As New TableCell
                    Dim PATTEXTBOX7 As New TextBox
                    Dim PATLABLE7 As New Label
                    Dim Convthic7 As String = Dts.Rows(TruckLength).Item("THICKNESSCONVERSION")
                    Dim Unit7 As String = Dts.Rows(TruckLength).Item("UNITS")
                    Dim PATTV7 As Double = Convert.ToDouble(Dts.Rows(TruckLength).Item("TRUCKLENGTH").ToString() * Convthic7)
                    PATTEXTBOX7.Text = FormatNumber(PATTV7.ToString(), 3)
                    If Unit7 = 0 Then
                        PATLABLE7.Text = "Length(in)<br />"
                    Else
                        PATLABLE7.Text = "Length(mm)<br />"
                    End If

                    If Dts.Rows(TruckLength).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PATTEXTBOX7.Enabled = False
                    Else
                        PATTEXTBOX7.Enabled = True
                    End If

                    PATTEXTBOX7.CssClass = "textBox"
                    PATTEXTBOX7.ID = "T2" + TruckLength.ToString()
                    PATC14.CssClass = "CaseTD"
                    PATC14.BorderWidth = 1
                    PATC14.Controls.Add(PATLABLE7)
                    PATC14.Controls.Add(PATTEXTBOX7)
                    PATR7.Controls.Add(PATC14)
                Next
                tblComparision.Controls.Add(PATR7)


                'Truck Height
                Dim PATR8 As New TableRow
                Dim PATC15 As New TableCell
                PATR8.ID = "P8_1"
                PATR8.CssClass = "ColorTR"
                PATC15.Text = "Truck Height"
                PATC15.CssClass = "Displaynametd"
                PATC15.BorderWidth = 1
                PATR8.Controls.Add(PATC15)
                Dim TruckHeight As New Integer
                For TruckHeight = 0 To Count - 1
                    Dim PATC16 As New TableCell
                    Dim PATTEXTBOX8 As New TextBox
                    Dim PATLABLE8 As New Label
                    Dim Convthic8 As String = Dts.Rows(TruckHeight).Item("THICKNESSCONVERSION")
                    Dim Unit8 As String = Dts.Rows(TruckHeight).Item("UNITS")
                    Dim PATTV8 As Double = Convert.ToDouble(Dts.Rows(TruckHeight).Item("TRUCKHEIGHT").ToString() * Convthic8)
                    PATTEXTBOX8.Text = FormatNumber(PATTV8.ToString(), 3)
                    If Unit8 = 0 Then
                        PATLABLE8.Text = "Height(in)<br />"
                    Else
                        PATLABLE8.Text = "Height(mm)<br />"
                    End If

                    If Dts.Rows(TruckHeight).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PATTEXTBOX8.Enabled = False
                    Else
                        PATTEXTBOX8.Enabled = True
                    End If

                    PATTEXTBOX8.CssClass = "textBox"
                    PATTEXTBOX8.ID = "T3" + TruckHeight.ToString()
                    PATC16.CssClass = "CaseTD"
                    PATC16.BorderWidth = 1
                    PATC16.Controls.Add(PATLABLE8)
                    PATC16.Controls.Add(PATTEXTBOX8)
                    PATR8.Controls.Add(PATC16)
                Next
                tblComparision.Controls.Add(PATR8)


                'Pallets Per Truck
                Dim PATR9 As New TableRow
                Dim PATC17 As New TableCell
                PATR9.ID = "P9_1"
                PATR9.CssClass = "ColorTR"
                PATC17.Text = "Pallets Per Truck"
                PATC17.CssClass = "Displaynametd"
                PATC17.BorderWidth = 1
                PATR9.Controls.Add(PATC17)
                Dim TruckPallets As New Integer
                For TruckPallets = 0 To Count - 1
                    Dim PATC18 As New TableCell
                    Dim PATTEXTBOX9 As New TextBox
                    Dim PATLABLE9 As New Label
                    Dim Unit9 As String = Dts.Rows(TruckPallets).Item("UNITS")
                    Dim PATTV9 As Double = Convert.ToDouble(Dts.Rows(TruckPallets).Item("TRUCKNUMBER").ToString())
                    PATTEXTBOX9.Text = FormatNumber(PATTV9.ToString(), 3)
                    If Unit9 = 0 Then
                        PATLABLE9.Text = "Number<br />"
                    Else
                        PATLABLE9.Text = "Number<br />"
                    End If

                    If Dts.Rows(TruckPallets).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PATTEXTBOX9.Enabled = False
                    Else
                        PATTEXTBOX9.Enabled = True
                    End If

                    PATTEXTBOX9.CssClass = "textBox"
                    PATTEXTBOX9.ID = "T4" + TruckPallets.ToString()
                    PATC18.CssClass = "CaseTD"
                    PATC18.BorderWidth = 1
                    PATC18.Controls.Add(PATLABLE9)
                    PATC18.Controls.Add(PATTEXTBOX9)
                    PATR9.Controls.Add(PATC18)
                Next
                tblComparision.Controls.Add(PATR9)



                'Truck Weight Limit
                Dim PATR10 As New TableRow
                Dim PATC19 As New TableCell
                PATR10.ID = "P10_1"
                PATR10.CssClass = "ColorTR"
                PATC19.Text = "Truck Weight Limit"
                PATC19.CssClass = "Displaynametd"
                PATC19.BorderWidth = 1
                PATR10.Controls.Add(PATC19)
                Dim TruckWeightLimit As New Integer
                For TruckWeightLimit = 0 To Count - 1
                    Dim PATC20 As New TableCell
                    Dim PATTEXTBOX10 As New TextBox
                    Dim PATLABLE10 As New Label
                    Dim Unit10 As String = Dts.Rows(TruckWeightLimit).Item("UNITS")
                    Dim Convwt As String = Dts.Rows(TruckWeightLimit).Item("WIGHTCONVERSION")
                    Dim PATTV10 As Double = Convert.ToDouble(Dts.Rows(TruckWeightLimit).Item("TRUCKWEIGHTLIMIT").ToString() * Convwt)
                    PATTEXTBOX10.Text = FormatNumber(PATTV10.ToString(), 3)
                    If Unit10 = 0 Then
                        PATLABLE10.Text = "Weight Limit(lb)<br />"
                    Else
                        PATLABLE10.Text = "Weight Limit(kg)<br />"
                    End If

                    If Dts.Rows(TruckWeightLimit).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PATTEXTBOX10.Enabled = False
                    Else
                        PATTEXTBOX10.Enabled = True
                    End If

                    PATTEXTBOX10.CssClass = "textBox"
                    PATTEXTBOX10.ID = "T5" + TruckWeightLimit.ToString()
                    PATC20.CssClass = "CaseTD"
                    PATC20.BorderWidth = 1
                    PATC20.Controls.Add(PATLABLE10)
                    PATC20.Controls.Add(PATTEXTBOX10)
                    PATR10.Controls.Add(PATC20)
                Next
                tblComparision.Controls.Add(PATR10)



                'Calculated Weight
                Dim PATR11 As New TableRow
                Dim PATC21 As New TableCell
                PATR11.ID = "P11_1"
                PATR11.CssClass = "ColorTR"
                PATC21.Text = "Calculated Weight"
                PATC21.CssClass = "Displaynametd"
                PATC21.BorderWidth = 1
                PATR11.Controls.Add(PATC21)
                Dim CalculatedWeight As New Integer
                For CalculatedWeight = 0 To Count - 1
                    Dim PATC22 As New TableCell
                    Dim PATTLABLE11 As New Label
                    Dim PATLABLE11 As New Label
                    Dim Unit11 As String = Dts.Rows(CalculatedWeight).Item("UNITS")
                    Dim Convwt11 As String = Dts.Rows(CalculatedWeight).Item("WIGHTCONVERSION")
                    Dim PATTV11 As Double = Dts.Rows(CalculatedWeight).Item("CALCULATEDWEIGHT").ToString() * Convwt11
                    PATTLABLE11.Text = FormatNumber(PATTV11, 0)
                    'PATTLABLE11.Text = PATTV11.ToString("0.000")

                    If Unit11 = 0 Then
                        PATLABLE11.Text = "Calculated Weight(lb)<br />"
                    Else
                        PATLABLE11.Text = "Calculated Weight(kg)<br />"
                    End If
                    PATTLABLE11.CssClass = "textBox"
                    PATTLABLE11.ForeColor = Drawing.Color.Red
                    PATC22.CssClass = "CaseTD"
                    PATC22.BorderWidth = 1
                    PATC22.Controls.Add(PATLABLE11)
                    PATC22.Controls.Add(PATTLABLE11)
                    PATR11.Controls.Add(PATC22)
                Next
                tblComparision.Controls.Add(PATR11)

            Next






        Catch ex As Exception
            Response.Write("Error:--" + ex.Message.ToString())
        End Try
    End Sub

    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click, Update2.Click
        Try

            Dim I As New Integer
            Dim PTUPDATE As New Update()
            Dim PW As String = ""
            Dim PL As String = ""
            Dim PH As String = ""
            Dim CPP As String = ""
            Dim PP As String = ""
            Dim TW As String = ""
            Dim TL As String = ""
            Dim TH As String = ""
            Dim PT As String = ""
            Dim TWL As String = ""
            Dim CaseID As String = ""

            For I = 0 To Count - 1
                PW = Replace(Trim(Request.Form("ctl00$ContentPlaceHolder1$P1" + I.ToString())), ",", "")
                PL = Replace(Trim(Request.Form("ctl00$ContentPlaceHolder1$P2" + I.ToString())), ",", "")
                PH = Replace(Trim(Request.Form("ctl00$ContentPlaceHolder1$P3" + I.ToString())), ",", "")
                CPP = Replace(Trim(Request.Form("ctl00$ContentPlaceHolder1$P4" + I.ToString())), ",", "")
                PP = Replace(Trim(Request.Form("ctl00$ContentPlaceHolder1$P5" + I.ToString())), ",", "")
                TW = Replace(Trim(Request.Form("ctl00$ContentPlaceHolder1$T1" + I.ToString())), ",", "")
                TL = Replace(Trim(Request.Form("ctl00$ContentPlaceHolder1$T2" + I.ToString())), ",", "")
                TH = Replace(Trim(Request.Form("ctl00$ContentPlaceHolder1$T3" + I.ToString())), ",", "")
                PT = Replace(Trim(Request.Form("ctl00$ContentPlaceHolder1$T4" + I.ToString())), ",", "")
                TWL = Replace(Trim(Request.Form("ctl00$ContentPlaceHolder1$T5" + I.ToString())), ",", "")
                CaseID = Request.Form("Case" + I.ToString() + "")

                If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
                Else
                    PTUPDATE.PalletAndTruckUpdate(CaseID, PW, PL, PH, CPP, PP, TW, TL, TH, PT, TWL)
                End If

            Next
            Response.Redirect("TruckPalletIN.aspx")
        Catch ex As Exception
            Response.Write("UpdateError:" + ex.Message.ToString())
        End Try

    End Sub

    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click, CalCulate2.Click
        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))

            'Checking The Case 
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                CI = CI + CaseID + ","
            End If

        Next
        If CI <> "" Then
            CI = CI.Remove(CI.Length - 1, 1)
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=TruckPalletIN.aspx")
        End If

    End Sub
End Class
