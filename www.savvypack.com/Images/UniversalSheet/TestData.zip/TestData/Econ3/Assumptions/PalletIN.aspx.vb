Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class PalletIn
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetPalletINSql(Cases, UserName, Password)
            Count = Dts.Rows.Count


            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='140px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)

            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)
            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                td4.Text = "Price in:" + Dts.Rows(J).Item("Title4")
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)


            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)



            Dim row As New Integer
            For row = 1 To 10

                'Break
                Dim tr5 As New TableRow
                Dim td7 As New TableCell
                td7.Text = "<b>Item" + row.ToString + "</b>"
                tr5.CssClass = "Layer"
                tr5.Controls.Add(td7)
                Dim Break As New Integer
                For Break = 0 To Count - 1
                    Dim td8 As New TableCell
                    td8.Text = "&nbsp;"
                    tr5.Controls.Add(td8)
                Next
                tblComparision.Controls.Add(tr5)


                'Item Combo
                Dim PAR1 As New TableRow
                Dim PAC1 As New TableCell
                PAR1.CssClass = "ColorTR"
                PAR1.ID = "PA1_" + row.ToString()
                PAC1.Text = "Item"
                PAC1.CssClass = "Displaynametd"
                PAC1.BorderWidth = 1
                PAR1.Controls.Add(PAC1)
                Dim ItemCombo As New Integer
                For ItemCombo = 0 To Count - 1
                    Dim PAC2 As New TableCell
                    Dim PACOMBO As New DropDownList
                    Dim List As String = "ITEM" + row.ToString()
                    Dim GetDept As New Selectdata()
                    PACOMBO = GetDept.GetItemCombo()
                    PACOMBO.SelectedValue = Dts.Rows(ItemCombo).Item(List).ToString()
                    PACOMBO.CssClass = "dropdown"
                    PACOMBO.ID = "P" + row.ToString() + "_" + ItemCombo.ToString()

                    If Dts.Rows(ItemCombo).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PACOMBO.Enabled = False
                    Else
                        PACOMBO.Enabled = True
                    End If

                    PAC2.Controls.Add(PACOMBO)
                    PAC2.CssClass = "CaseTD"
                    PAC2.BorderWidth = 1
                    PAR1.Controls.Add(PAC2)

                Next
                tblComparision.Controls.Add(PAR1)

                'Number Feild
                Dim PAR2 As New TableRow
                Dim PAC3 As New TableCell
                PAR2.CssClass = "ColorTR"
                PAR2.ID = "PA2_" + row.ToString()
                PAC3.Text = "Number"
                PAC3.CssClass = "Displaynametd"
                PAC3.BorderWidth = 1
                PAR2.Controls.Add(PAC3)
                Dim NumberFeild As New Integer
                For NumberFeild = 0 To Count - 1
                    Dim PAC4 As New TableCell
                    Dim NumberTextBox As New TextBox
                    Dim Num As String = "NUMBER" + row.ToString()
                    NumberTextBox.Text = Dts.Rows(NumberFeild).Item(Num).ToString()
                    NumberTextBox.CssClass = "textBox"
                    NumberTextBox.ID = "N" + row.ToString() + "_" + NumberFeild.ToString()

                    If Dts.Rows(NumberFeild).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        NumberTextBox.Enabled = False
                    Else
                        NumberTextBox.Enabled = True
                    End If

                    PAC4.Controls.Add(NumberTextBox)
                    PAC4.CssClass = "CaseTD"
                    PAC4.BorderWidth = 1
                    PAR2.Controls.Add(PAC4)
                Next
                tblComparision.Controls.Add(PAR2)

                'Recycle (%) Feild
                Dim PAR3 As New TableRow
                Dim PAC5 As New TableCell
                PAR3.CssClass = "ColorTR"
                PAR3.ID = "PA3_" + row.ToString()
                PAC5.Text = "Recycle (%)"
                PAC5.CssClass = "Displaynametd"
                PAC5.BorderWidth = 1
                PAR3.Controls.Add(PAC5)
                Dim RecycleFeild As New Integer
                For RecycleFeild = 0 To Count - 1
                    Dim PAC6 As New TableCell
                    Dim RecycleTextBox As New TextBox
                    Dim rec As String = "RECYCLE" + row.ToString()
                    Dim Recycle As Double = Convert.ToDouble(Dts.Rows(RecycleFeild).Item(rec).ToString())
                    RecycleTextBox.Text = Recycle.ToString("0.00")
                    RecycleTextBox.ID = "RE" + row.ToString() + "_" + RecycleFeild.ToString()
                    RecycleTextBox.CssClass = "textBox"

                    If Dts.Rows(RecycleFeild).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        RecycleTextBox.Enabled = False
                    Else
                        RecycleTextBox.Enabled = True
                    End If


                    PAC6.Controls.Add(RecycleTextBox)
                    PAC6.CssClass = "CaseTD"
                    PAC6.BorderWidth = 1
                    PAR3.Controls.Add(PAC6)
                Next
                tblComparision.Controls.Add(PAR3)


                'Weight Feild
                Dim PAR4 As New TableRow
                Dim PAC7 As New TableCell
                PAR4.CssClass = "ColorTR"
                PAR4.ID = "PA4_" + row.ToString()
                PAC7.Text = "Weight Each"
                PAC7.CssClass = "Displaynametd"
                PAC7.BorderWidth = 1
                PAR4.Controls.Add(PAC7)
                Dim WeightFeild As New Integer
                For WeightFeild = 0 To Count - 1
                    Dim PAC8 As New TableCell
                    Dim Unit As String = Dts.Rows(WeightFeild).Item("UNITS").ToString()
                    Dim Wet As String = "Weight" + row.ToString()
                    Dim Weight As Double = Convert.ToDouble(Dts.Rows(WeightFeild).Item(Wet).ToString())
                    If Unit = 0 Then
                        PAC8.Text = "<b>Weight(lb)</b><br>" + Weight.ToString("0.00")
                    Else
                        PAC8.Text = "<b>Weight(Kg)</b><br>" + Weight.ToString("0.00")

                    End If
                    PAC8.Style.Add("text-align", "Center")
                    PAC8.BorderWidth = 1
                    PAR4.Controls.Add(PAC8)

                Next
                tblComparision.Controls.Add(PAR4)


                'Price each(Sugessted) 
                Dim PAR5 As New TableRow
                Dim PAC9 As New TableCell
                PAR5.CssClass = "ColorTR"
                PAR5.ID = "PA5_" + row.ToString()
                PAC9.Text = "<img alt='' src='../../Images/spacer.gif' width='0px'height='20px'  />Price (Suggested)"
                PAC9.CssClass = "Displaynametd"
                PAC9.BorderWidth = 1
                PAR5.Controls.Add(PAC9)
                Dim PriceSFeild As New Integer
                For PriceSFeild = 0 To Count - 1
                    Dim PAC10 As New TableCell
                    Dim PS As String = "PRICE" + row.ToString()
                    Dim Price As Double = Convert.ToDouble(Dts.Rows(PriceSFeild).Item(PS).ToString())
                    PAC10.Text = Price.ToString("0.00")
                    PAC10.Style.Add("text-align", "Center")
                    PAC10.BorderWidth = 1
                    PAR5.Controls.Add(PAC10)
                Next
                tblComparision.Controls.Add(PAR5)

                'Price each(Preferred) 
                Dim PAR6 As New TableRow
                Dim PAC11 As New TableCell
                PAR6.CssClass = "ColorTR"
                PAR6.ID = "PA6_" + row.ToString()
                PAC11.Text = "Price (Preferred) "
                PAC11.CssClass = "Displaynametd"
                PAC11.BorderWidth = 1
                PAR6.Controls.Add(PAC11)
                Dim PricePfeild As New Integer
                For PricePfeild = 0 To Count - 1
                    Dim PAC12 As New TableCell
                    Dim PriceTextbox As New TextBox
                    Dim PF As String = "Preferred" + row.ToString()
                    Dim PFprice As Double = Convert.ToDouble(Dts.Rows(PricePfeild).Item(PF).ToString())
                    PriceTextbox.Text = PFprice.ToString("0.00")
                    PriceTextbox.ID = "PF" + row.ToString() + "_" + PricePfeild.ToString()
                    PriceTextbox.CssClass = "textBox"

                    If Dts.Rows(PricePfeild).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        PriceTextbox.Enabled = False
                    Else
                        PriceTextbox.Enabled = True
                    End If

                    PAC12.Controls.Add(PriceTextbox)
                    PAC12.CssClass = "CaseTD"
                    PAC12.BorderWidth = 1
                    PAR6.Controls.Add(PAC12)
                Next
                tblComparision.Controls.Add(PAR6)


                'Dept Combo Feild
                Dim PAR7 As New TableRow
                Dim PAC13 As New TableCell
                PAR7.CssClass = "ColorTR"
                PAR7.ID = "PA7_" + row.ToString()
                PAC13.Text = "Manufacturing Process<br> or Department"
                PAC13.CssClass = "Displaynametd"
                PAC13.BorderWidth = 1
                PAR7.Controls.Add(PAC13)
                Dim DeptCombofeild As New Integer
                For DeptCombofeild = 0 To Count - 1
                    Dim PAC14 As New TableCell
                    Dim deptcombo As New DropDownList
                    Dim DV As String = "DEPT" + row.ToString()
                    Dim SelectedValue As String = Dts.Rows(DeptCombofeild).Item(DV).ToString()
                    Dim GetDept As New RepeatedControls()
                    deptcombo = GetDept.DeptDropdown()
                    deptcombo.SelectedValue = SelectedValue
                    deptcombo.CssClass = "dropdown"
                    deptcombo.ID = "D" + row.ToString() + "_" + DeptCombofeild.ToString()

                    If Dts.Rows(DeptCombofeild).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        deptcombo.Enabled = False
                    Else
                        deptcombo.Enabled = True
                    End If

                    PAC14.Controls.Add(deptcombo)
                    PAC14.CssClass = "CaseTD"
                    PAC14.BorderWidth = 1
                    PAR7.Controls.Add(PAC14)
                Next
                tblComparision.Controls.Add(PAR7)

            Next


        Catch ex As Exception
            Response.Write("Error:--" + ex.Message.ToString())

        End Try
    End Sub

    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click
        Try


            Dim I As New Integer
            Dim J As New Integer
            Dim PalletInUpdate As New Update()
            For I = 0 To Count - 1
                Dim IT As String = ""
                Dim NO As String = ""
                Dim RE As String = ""
                Dim PP As String = ""
                Dim MFD As String = ""
                Dim CaseID As String = ""
                Dim Item As String = ""
                Dim Number As String = ""
                Dim Recycle As String = ""
                Dim Prefred As String = ""
                Dim Dept As String = ""
                For J = 1 To 10
                    IT = Request.Form("ctl00$ContentPlaceHolder1$P" + J.ToString() + "_" + I.ToString())
                    NO = Request.Form("ctl00$ContentPlaceHolder1$N" + J.ToString() + "_" + I.ToString())
                    RE = Request.Form("ctl00$ContentPlaceHolder1$RE" + J.ToString() + "_" + I.ToString())
                    PP = Request.Form("ctl00$ContentPlaceHolder1$PF" + J.ToString() + "_" + I.ToString())
                    MFD = Request.Form("ctl00$ContentPlaceHolder1$D" + J.ToString() + "_" + I.ToString())
                    CaseID = Request.Form("Case" + I.ToString())
                    Item = Item + IT + ","
                    Number = Number + NO + ","
                    Recycle = Recycle + RE + ","
                    Prefred = Prefred + PP + ","
                    Dept = Dept + MFD + ","
                Next
                Item = Item.Remove(Item.Length - 1)
                Number = Number.Remove(Number.Length - 1)
                Recycle = Recycle.Remove(Recycle.Length - 1)
                Prefred = Prefred.Remove(Prefred.Length - 1)
                Dept = Dept.Remove(Dept.Length - 1)
                If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
                Else
                    PalletInUpdate.PalletInUpdate(CaseID, Item, Number, Recycle, Prefred, Dept)
                End If
            Next
            Response.Redirect("PalletIN.aspx")
        Catch ex As Exception
            Response.Write("UpdateError:" + ex.Message.ToString())
        End Try


    End Sub

    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click
        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))

            'Checking The Case 
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                CI = CI + CaseID + ","
            End If

        Next
        If CI <> "" Then
            CI = CI.Remove(CI.Length - 1, 1)
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=TruckPalletIN.aspx")
        End If




    End Sub
End Class
