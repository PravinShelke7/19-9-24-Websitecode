Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Partial Class AssumptionsMenu
    Inherits System.Web.UI.Page




    Public StrWhichForm As String = ""
    Public SavedName As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try
            lblID.Text = Session("AssumptionID").ToString()
            lblrecord.Visible = False
            'Description Of Assumptions
            Dim oDBUtil As New DBUtil()
            Dim MyConnectionString As String
            Dim MyConnectionString1 As String
            MyConnectionString = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
            MyConnectionString1 = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
            Dim StrSqlDes As String = "Select DESCRIPTION from ASSUMPTIONS where ASSUMPTIONID = " + Session("AssumptionID").ToString() + " "
            Dim Dts As New DataTable()
            Dts = oDBUtil.FillDataTable(StrSqlDes, MyConnectionString)
            lbldes.Text = Dts.Rows(0).Item("DESCRIPTION").ToString()
            Session("Description") = Dts.Rows(0).Item("DESCRIPTION").ToString()

            StrWhichForm = Session("WhichForm")


            SavedName = Dts.Rows(0).Item("DESCRIPTION").ToString()
            'Selected Cases
            Dim StrSqlCases As String = ""
            StrSqlCases = "select to_char( nvl(Assumptions.Case1,0) )  ||  ',' || to_char( nvl(Assumptions.Case2,0))    ||   ',' ||  to_char( nvl(Assumptions.Case3,0) )  ||   ',' || to_char( nvl(Assumptions.Case4,0) )  ||  ',' ||  to_char( nvl(Assumptions.Case5,0) )  ||  ',' ||  to_char ( nvl(Assumptions.Case6,0) ) ||   ',' || to_char( nvl(Assumptions.Case7,0)  )  ||   ','  ||  to_char( nvl(Assumptions.Case8,0)  )  ||  ',' || to_char( nvl(Assumptions.Case9,0) )   ||   ','  || to_Char( nvl(Assumptions.Case10,0) )  as Cases   from  Assumptions WHERE Assumptions.AssumptionId =" + Session("AssumptionID").ToString() + ""
            Dim Cs As New DataTable()
            Cs = oDBUtil.FillDataTable(StrSqlCases, MyConnectionString)
            Dim Cases As String = ""
            Cases = Cs.Rows(0).Item(0).ToString()
            Session("Cases") = Cases
            'Response.Write(Cases)

            Dim StrSqlCaseDes As String = ""
            StrSqlCaseDes = "SELECT CaseID ,('Case:'||caseID||' - '||caseDE1||caseDE2) As Des "
            StrSqlCaseDes = StrSqlCaseDes + " From permissionscases "
            StrSqlCaseDes = StrSqlCaseDes + " Where permissionscases.username='" + Session("UserName") + "' "
            StrSqlCaseDes = StrSqlCaseDes + "and  permissionscases.caseID in (" + Cases + ")"
            StrSqlCaseDes = StrSqlCaseDes + "UNION"
            StrSqlCaseDes = StrSqlCaseDes + " SELECT CaseID ,('Case:'||caseID||'-'||caseDE1||caseDE2) As Des "
            StrSqlCaseDes = StrSqlCaseDes + " From basecases "
            StrSqlCaseDes = StrSqlCaseDes + " WHERE basecases.caseID in (" + Cases + ")"
            'Response.Write(StrSqlCaseDes)

            Dim dt As New DataTable()
            dt = oDBUtil.FillDataTable(StrSqlCaseDes, MyConnectionString1)
            Dim Des As String = ""
            Dim Des1 As String = ""
            Dim I As Integer
            For I = 0 To dt.Rows.Count - 1

                Des = dt.Rows(I).Item("Des").ToString()
                If Des1 = "" Then
                    Des1 = Des1 + Des
                Else
                    Des1 = Des1 + "<br/>" + Des
                End If

            Next
            lblCases.Text = Des1





        Catch ex As Exception
            Dim Errors As String = ""
            Errors = ex.Message.ToString()
            lblrecord.Visible = True

            'Response.Write("Error:--" + Errors)

        End Try






    End Sub

    Protected Sub Save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Save.Click
        SaveButton.Visible = True
        CancleButton1.Visible = True
        SaveText.Visible = True
    End Sub

    Protected Sub Rename_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Rename.Click
        RenameButton.Visible = True
        ReanameText.Visible = True
        CancleButton2.Visible = True
        ReanameText.Text = SavedName
        Dim Name As String = ""

    End Sub

    Protected Sub Delete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Delete.Click
        DeleteButton.Visible = True
        CancleButton3.Visible = True
    End Sub

    Protected Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        Dim Name As String
        Dim ID As String = 1
        Name = SaveText.Text
        Session("WhichForm") = "2"
        Dim UpadateFun As New Update()
        UpadateFun.AlterComparison(Name, ID, Session("AssumptionID"), Session("UserName"), Session("Password"))



    End Sub

    Protected Sub RenameButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RenameButton.Click
        Dim ID As String = 2
        Dim Name As String = ReanameText.Text
        Session("WhichForm") = "2"
        Dim Renamefun As New Update()
        Renamefun.AlterComparison(Name, ID, Session("AssumptionID"), Session("UserName"), Session("Password"))

    End Sub

    Protected Sub DeleteButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DeleteButton.Click
        Dim ID As String = 3
        Dim Name As String = SavedName
        Session("WhichForm") = "2"
        Dim Deletefun As New Update()
        Deletefun.AlterComparison(Name, ID, Session("AssumptionID"), Session("UserName"), Session("Password"))
        lblrecord.Visible = True
    End Sub

    Protected Sub CancleButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancleButton1.Click, CancleButton2.Click, CancleButton3.Click
        SaveText.Visible = False
        ReanameText.Visible = False
        SaveButton.Visible = False
        CancleButton1.Visible = False
        CancleButton2.Visible = False
        CancleButton3.Visible = False
        DeleteButton.Visible = False
        RenameButton.Visible = False
        DeleteButton.Visible = False




    End Sub


End Class
