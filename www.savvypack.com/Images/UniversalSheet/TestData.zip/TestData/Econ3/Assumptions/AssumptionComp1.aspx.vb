Imports System.Data
Imports System.Data.OleDb
Imports System.HttpStyleUriParser
Imports System.Web.UI.WebControls
Imports UpdateData
Imports SelectQuery


Partial Class AssumpComp1
    Inherits System.Web.UI.Page
    Dim GetData As New Selectdata()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try


                'Calling Database Class File
                Dim oDbUtil As New DBUtil()



                'Database Connection Sting
                Dim MyConnectionString As String
                Dim MyConnectionString1 As String

                'Assigning the Connection string 
                MyConnectionString = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
                MyConnectionString1 = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")


                Dim StrSqlUser As String
                Dim ID As String = Session("ID")
                If (ID >= 1) Then
                    StrSqlUser = "Select Uname,Upwd From Ulogin Where ID= " & ID


                    'Dim Dt = New DataTable
                    Dim Dtst As New DataTable
                    'Calling the datset fuction
                    Dtst = oDbUtil.FillDataTable(StrSqlUser, MyConnectionString)



                    Session("UserName") = Dtst.Rows(0).Item("Uname").ToString()
                    Session("Password") = Dtst.Rows(0).Item("Upwd").ToString()
                    Dim Username As String = Session("UserName")



                End If


                'Sql Declarecation
                Dim StrSql As String = "SELECT caseID,caseDE1,('Case:'||caseID||' - '|| caseDE1||' ' || caseDE2) as CaseDe FROM econ.permissionscases WHERE username='" + Session("UserName") + "'"
                StrSql = StrSql + "UNION SELECT caseID,caseDE1,('Case:'||caseID||' - '|| caseDE1||' ' || caseDE2) as CaseDe  FROM econ.basecases ORDER BY caseDE1"


                Dim Dt As New DataTable()
                'Calling the datset fuction
                Dt = oDbUtil.FillDataTable(StrSql, MyConnectionString)

                'Filling Combo
                CaseComp.DataSource = Dt
                CaseComp.DataValueField = "caseID"
                CaseComp.DataTextField = "CaseDe"
                CaseComp.DataBind()


                Call SavedSahredCombo()









                'Couser Combo

                Dim StrSqlCoworker As String = " Select Users.Username , Users.userid From Users  where exists"
                StrSqlCoworker = StrSqlCoworker + " (select 1 from UserPermissions "
                StrSqlCoworker = StrSqlCoworker + " Inner Join Services on Services.SERVICEID = UserPermissions.SERVICEID "
                StrSqlCoworker = StrSqlCoworker + " where UserPermissions.UserID =Users.UserID and  Services.SERVICEID = '12'  "
                StrSqlCoworker = StrSqlCoworker + " and Users.company IN(select Users.company from users where username='" + Session("UserName") + "')"
                StrSqlCoworker = StrSqlCoworker + " )order by  Users.Username"

                Dt = oDbUtil.FillDataTable(StrSqlCoworker, MyConnectionString)

                Coworker.DataSource = Dt
                Coworker.DataValueField = "Username"
                Coworker.DataTextField = "Username"
                Coworker.DataBind()


            Catch ex As Exception
            Finally

            End Try
        End If
    End Sub

    Protected Sub StartComp_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles StartComp.Click

        Dim Caseid As String
        Dim ID As String = 1
        Dim Name As String = ""
        Name = Trim(ComparisonName.Text)
        Dim CaseArray() As String
        If Name.Length <> 0 Then
            CreateCompError.Visible = False

            'Getting Selected CaseID From Combo
            Caseid = Request.Form("ctl00$ContentPlaceHolder1$CaseComp")
            CaseArray = Split(Caseid, ",")
            If CaseArray.Length < 10 And CaseArray.Length > 2 Then
                CreateCompError.Visible = False
                Dim UpadateFun As New Update()
                Session("AssumptionID") = UpadateFun.AssumptionUpdate(Caseid)
                Displaynote.Visible = False

                Session("WhichForm") = "2"
                UpadateFun.AlterComparison(Name, ID, Session("AssumptionID"), Session("UserName"), Session("Password"))
                'Response.Redirect("FinancialManger.aspx")

                Call SavedSahredCombo()
                ComparisonName.Text = ""
                Response.Write("<script language=JavaScript>window.open('FinancialManger.aspx','new_Win');</script>")

            Else
                CaseComp.Focus()
                If CaseArray.Length > 10 Then
                    CreateCompError.Text = "You cannot select the more than 10 cases"
                    CreateCompError.Visible = True
                Else
                    CreateCompError.Text = "Please atleast select 2 cases for comparison"
                    CreateCompError.Visible = True
                End If
            End If


            'Server.Transfer("FinancialManger.aspx")
        Else
            ComparisonName.Focus()
            CreateCompError.Text = "Please enter the text for new comparison"
            CreateCompError.Visible = True
        End If





    End Sub

    Protected Sub StartComp2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SavedButton.Click
        Session("AssumptionID") = SavedComp.SelectedValue
        Displaynote.Visible = False
        Session("WhichForm") = "2"
        'Response.Redirect("FinancialManger.aspx")
        Response.Write("<script language=JavaScript>window.open('FinancialManger.aspx','new_Win');</script>")


    End Sub

    Protected Sub SharedButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SharedButton.Click
        Dim shareusername As String = Coworker.SelectedValue
        Dim ID As String = SharedComp.SelectedValue
        Dim Insert As New Update()
        Insert.SharedCase(shareusername, ID)
        Displaynote.Visible = True
        Displaynote.Text = "Comparison:--" + ID + " has been successfully shared with:--" + shareusername + ""

    End Sub

    Protected Sub DeleteButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DeleteButton.Click
        Try
            Dim ID As String = 3
            Dim Name As String = ""
            Dim Deletefun As New Update()
            Deletefun.AlterComparison(Name, ID, SavedComp.SelectedValue, Session("UserName"), Session("Password"))
            Dim Dts As New DataSet()
            Call SavedSahredCombo()
        Catch ex As Exception
            Response.Write("Assumptions Comparisons.DeleteButton_Click.Error" + ex.Message.ToString())
        End Try
    End Sub

    Protected Sub RenameButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RenameButton.Click
        Try
            Dim ID As String = 4
            Dim Name As String = Trim(txtrename.Text)
            If Name.Length <> 0 Then
                Dim AssumptionID As String
                AssumptionID = SavedComp.SelectedValue
                Dim Renamefun As New Update()
                Renamefun.AlterComparison(Name, ID, AssumptionID, Session("UserName"), Session("Password"))
                Dim Dts As New DataSet()
                'Dts = GetData.GetSavedCaseAsperUser(Session("UserName").ToString())

                Call SavedSahredCombo()

                txtrename.Text = ""
                RenameError.Visible = False

            Else
                RenameError.Text = "Please enter the text for renaming comparison"
                RenameError.Visible = True

            End If


        Catch ex As Exception
            Response.Write("Assumptions Comparisons.RenameButton_Click.Error" + ex.Message.ToString())
        End Try
    End Sub


    Protected Sub SavedSahredCombo()
        Try
            Dim Dts As New DataSet()
            Dts = GetData.GetSavedCaseAsperUser(Session("UserName").ToString())
            If Dts.Tables(0).Rows.Count = 0 Then
                nodatatr1.Visible = True
                nodatatr2.Visible = True
                ddtr1.Visible = False
                ddtr2.Visible = False
                ddtr3.Visible = False
                headingtr1.Visible = False
                headingtr2.Visible = False
                buttontr1.Visible = False
                buttontr11.Visible = False
                buttontr3.Visible = False
            Else
                nodatatr1.Visible = False
                nodatatr2.Visible = False
                ddtr1.Visible = True
                ddtr2.Visible = True
                ddtr3.Visible = True
                headingtr1.Visible = True
                headingtr2.Visible = True
                buttontr1.Visible = True
                buttontr11.Visible = True
                buttontr3.Visible = True
                'Saved Comparison Combo

                Dts = GetData.GetSavedCaseAsperUser(Session("UserName").ToString())
                SavedComp.DataSource = Dts
                SavedComp.DataValueField = "AssumptionId"
                SavedComp.DataTextField = "Des"
                SavedComp.DataBind()

                'Saved Shared Comparison Combo

                SharedComp.DataSource = Dts
                SharedComp.DataValueField = "AssumptionId"
                SharedComp.DataTextField = "Des"
                SharedComp.DataBind()

            End If
        Catch ex As Exception

        End Try
    End Sub
End Class

