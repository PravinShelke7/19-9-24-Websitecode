Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports System.Collections
Imports System.IO.StringWriter
Imports System.Web.UI.HtmlTextWriter


Partial Class MaterialAssumption
    Inherits System.Web.UI.Page

    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList
    Public matidcount As Integer



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()




            'Database Connection
            Dim odbUtil As New DBUtil()
            Dim MyConnectionString As String = ""
            Dim MyConnectionString1 As String = ""
            MyConnectionString = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
            MyConnectionString1 = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")

            'Required Sqls for Data 
            Dim StrSqlCases As String = ""
            StrSqlCases = "select to_char( nvl(Assumptions.Case1,0) )  ||  ',' || to_char( nvl(Assumptions.Case2,0))    ||   ',' ||  to_char( nvl(Assumptions.Case3,0) )  ||   ',' || to_char( nvl(Assumptions.Case4,0) )  ||  ',' ||  to_char( nvl(Assumptions.Case5,0) )  ||  ',' ||  to_char ( nvl(Assumptions.Case6,0) ) ||   ',' || to_char( nvl(Assumptions.Case7,0)  )  ||   ','  ||  to_char( nvl(Assumptions.Case8,0)  )  ||  ',' || to_char( nvl(Assumptions.Case9,0) )   ||   ','  || to_Char( nvl(Assumptions.Case10,0) )  as Cases   from  Assumptions WHERE Assumptions.AssumptionId =" + Assid + ""
            Dim Cs As New DataTable()
            Cs = odbUtil.FillDataTable(StrSqlCases, MyConnectionString1)
            Dim Cases As String = ""
            Cases = Cs.Rows(0).Item("Cases").ToString()



            Dim StrSqlMaterialIn As String = ""
            StrSqlMaterialIn = "select Matid, (Matid||':'||matde1||' '||matde2) MaterialDes ,price,sg from Materials ORDER BY matde1 "
            Dim Dt As New DataTable()
            Dt = odbUtil.FillDataTable(StrSqlMaterialIn, MyConnectionString)


            matidcount = Dt.Rows.Count.ToString()



            Dim StrSqlCombine As String = ""
            StrSqlCombine = "select distinct mat.*,"
            StrSqlCombine = StrSqlCombine + "pref.convthick, pref.curr, pref.convwt , "
            StrSqlCombine = StrSqlCombine + " case.caseDE1 as CaseDE1 ,case.caseDE2 as CaseDe2 , "
            StrSqlCombine = StrSqlCombine + "(CaseDE1||' '||CaseDE2) as casesDE,"
            StrSqlCombine = StrSqlCombine + " Pref.Title1,Pref.Title2,Pref.Title8 "
            StrSqlCombine = StrSqlCombine + " from MaterialInput mat, preferences pref, "
            StrSqlCombine = StrSqlCombine + " ( SELECT caseID,caseDE1,caseDE2 FROM permissionscases "
            StrSqlCombine = StrSqlCombine + " WHERE username='" + UserName + "'"
            StrSqlCombine = StrSqlCombine + " UNION SELECT caseID,caseDE1,caseDE2 FROM basecases )"
            StrSqlCombine = StrSqlCombine + " case WHERE mat.caseid = case.caseid and mat.caseid = pref.caseid "
            StrSqlCombine = StrSqlCombine + " and mat.caseID in  (" + Cases + ") "

            Dim Dts As New DataTable()
            Dts = odbUtil.FillDataTable(StrSqlCombine, MyConnectionString)

            Count = Dts.Rows.Count.ToString





            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='140px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("casesDE").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)

            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)


            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                td4.Text = "Weight:-" + Dts.Rows(J).Item("Title8").ToString() + "<br/>Price:-" + Dts.Rows(J).Item("Title2").ToString()
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)


            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)




            Dim row As New Integer

            For row = 1 To 10
                'Break
                Dim MTR5 As New TableRow
                Dim MTC9 As New TableCell
                MTC9.Text = "<b>Layer" + row.ToString + "</b>"
                MTR5.CssClass = "Layer"
                MTR5.Controls.Add(MTC9)
                Dim Break As New Integer
                For Break = 0 To Count - 1
                    Dim MTC10 As New TableCell
                    MTC10.Text = "&nbsp;"
                    MTR5.Controls.Add(MTC10)
                Next
                tblComparision.Controls.Add(MTR5)

                'Materials
                Dim MTR1 As New TableRow
                MTR1.ID = "M_" + row.ToString()
                MTR1.CssClass = "ColorTR"
                Dim MTC1 As New TableCell
                MTC1.Text = "Material"
                MTC1.CssClass = "Displaynametd"
                MTC1.BorderWidth = 1
                MTR1.Controls.Add(MTC1)
                Dim Material As New Integer
                For Material = 0 To Count - 1
                    Dim MTC2 As New TableCell
                    Dim matid As New Integer
                    Dim M As String = "M" + row.ToString()
                    Dim MI As String = Dts.Rows(Material).Item(M).ToString
                    Dim MaterialCombo As New DropDownList

                    MaterialCombo.DataSource = Dt
                    MaterialCombo.DataValueField = "Matid"
                    MaterialCombo.DataTextField = "MaterialDes"
                    MaterialCombo.DataBind()
                    MaterialCombo.CssClass = "dropdown"
                    MaterialCombo.ID = "M" + row.ToString() + "_" + Material.ToString()

                    For matid = 0 To matidcount - 1
                        Dim MT As String = Dt.Rows(matid).Item("Matid").ToString()
                        If MT = MI Then
                            MaterialCombo.SelectedValue = MT

                        End If
                        MTC2.Controls.Add(MaterialCombo)
                    Next
                    If Dts.Rows(Material).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        MaterialCombo.Enabled = False
                    Else
                        MaterialCombo.Enabled = True

                    End If

                    MTC2.CssClass = "CaseTD"
                    MTC2.BorderWidth = 1
                    MTR1.Controls.Add(MTC2)
                Next
                tblComparision.Controls.Add(MTR1)

                'Thckness
                Dim MTR2 As New TableRow
                MTR2.ID = "T_" + row.ToString()
                MTR2.CssClass = "ColorTR"
                Dim MTC3 As New TableCell
                MTC3.Text = "Thickness"
                MTC3.BorderWidth = 1
                MTR2.Controls.Add(MTC3)
                Dim Thickness As New Integer
                For Thickness = 0 To Count - 1
                    Dim MTC4 As New TableCell
                    Dim thick As New TextBox
                    Dim T As String = "T" + row.ToString
                    Dim convthick As String = Dts.Rows(Thickness).Item("convthick")
                    Dim TH As Double = Convert.ToDouble(Dts.Rows(Thickness).Item(T).ToString() * convthick)
                    thick.Text = TH.ToString("0.000")
                    thick.CssClass = "textBox"
                    thick.ID = "T" + row.ToString() + "_" + Thickness.ToString()
                    If Dts.Rows(Thickness).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        thick.Enabled = False
                    Else
                        thick.Enabled = True

                    End If
                    MTC4.Controls.Add(thick)
                    MTC4.CssClass = "CaseTD"
                    MTC4.BorderWidth = 1
                    MTR2.Controls.Add(MTC4)

                Next
                tblComparision.Controls.Add(MTR2)

                'Suggested
                Dim MTR3 As New TableRow
                MTR3.ID = "S_" + row.ToString()
                MTR3.CssClass = "ColorTR"
                MTR3.Height = 20
                Dim MTC5 As New TableCell
                MTC5.Text = "Suggested Price"
                MTC5.BorderWidth = 1
                MTR3.Controls.Add(MTC5)
                Dim Preffred As New Integer
                For Preffred = 0 To Count - 1
                    Dim MTC6 As New TableCell
                    Dim conwtp As String = Dts.Rows(Preffred).Item("convwt").ToString()
                    Dim currp As String = Dts.Rows(Preffred).Item("curr").ToString()
                    Dim matidP As New Integer
                    Dim MA As String = "M" + row.ToString()
                    Dim MIP As String = Dts.Rows(Preffred).Item(MA).ToString()
                    'MTC6.ID = "P" + row.ToString() + "_" + Preffred.ToString()
                    For matidP = 0 To matidcount - 1
                        Dim MTP As String = Dt.Rows(matidP).Item("Matid").ToString()
                        Dim price As String = Dt.Rows(matidP).Item("price").ToString()
                        If MTP = MIP Then
                            Dim Preffredpriese As Double = Convert.ToDouble(price / conwtp * currp)
                            MTC6.Text = "$" + Preffredpriese.ToString("0.000")
                        End If

                    Next
                    MTC6.CssClass = "textfeild"
                    MTC6.BorderWidth = 1
                    MTR3.Controls.Add(MTC6)

                Next
                tblComparision.Controls.Add(MTR3)


                'Preferred 
                Dim MTR4 As New TableRow
                MTR4.ID = "P_" + row.ToString()
                MTR4.CssClass = "ColorTR"
                Dim MTC7 As New TableCell
                MTC7.Text = "Preferred  Price"
                MTC7.BorderWidth = 1
                MTR4.Controls.Add(MTC7)
                Dim Suggested As New Integer
                For Suggested = 0 To Count - 1
                    Dim MTC8 As New TableCell
                    Dim Sugg As New TextBox
                    Dim S As String = "S" + row.ToString
                    Dim currs As String = Dts.Rows(Suggested).Item("Curr")
                    Dim SP As Double = Convert.ToDouble(Dts.Rows(Suggested).Item(S).ToString() * currs)
                    Sugg.Text = SP.ToString("0.000")
                    Sugg.ID = "P" + row.ToString() + "_" + Suggested.ToString()
                    Sugg.CssClass = "textBox"
                    If Dts.Rows(Suggested).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        Sugg.Enabled = False
                    Else
                        Sugg.Enabled = True

                    End If
                    MTC8.Controls.Add(Sugg)
                    MTC8.CssClass = "textfeild"
                    MTC8.BorderWidth = 1
                    MTR4.Controls.Add(MTC8)

                Next
                tblComparision.Controls.Add(MTR4)






            Next



        Catch ex As Exception
            Dim Errors As String = ""
            Errors = ex.Message.ToString()
            Response.Write(Errors)

        End Try
    End Sub




    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click, Upadate2.Click


        Dim Update As New Update()
        Dim I As New Integer
        Dim J As New Integer

        For J = 0 To Count - 1
            Dim Material As String = ""
            Dim Thickness As String = ""
            Dim Pereffred As String = ""
            Dim CaseID As String = ""
            Dim M As String = ""
            Dim MI As String = ""
            Dim SI As String = ""
            Dim TI As String = ""
            Dim T As String = ""
            Dim P As String = ""
            Dim C As String = ""
            For I = 1 To 10
                M = "ctl00$ContentPlaceHolder1$M" + I.ToString() + "_" + J.ToString() + ""
                T = "ctl00$ContentPlaceHolder1$T" + I.ToString() + "_" + J.ToString() + ""
                P = "ctl00$ContentPlaceHolder1$P" + I.ToString() + "_" + J.ToString() + ""
                C = "Case" + J.ToString() + ""
                Material = Request.Form(M)
                MI = MI + Material + ","
                Thickness = Request.Form(T)
                TI = TI + Thickness + ","
                Pereffred = Request.Form(P)
                SI = SI + Pereffred + ","
                CaseID = Request.Form(C)

            Next
            MI = MI.Remove(MI.Length - 1, 1)
            TI = TI.Remove(TI.Length - 1, 1)
            SI = SI.Remove(SI.Length - 1, 1)
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                Update.MaterialUpdate(CaseID, MI, TI, SI)
            End If



        Next

        Response.Redirect("MaterialAssumption.aspx")
    End Sub


    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click, Calculate2.Click
        Dim CaseID As String
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))
            CI = CI + CaseID + ","

        Next
        CI = CI.Remove(CI.Length - 1, 1)
        If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
        Else
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=MaterialAssumption.aspx")
        End If





    End Sub


End Class
