Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class PlantConfig2
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetPlantAreaQuery(Cases, UserName, Password)
            Count = Dts.Rows.Count

            Dim GetLeaseRate As New Selectdata()
            Dim Dt As New DataTable()
            Dt = GetLeaseRate.GetPlantLeaseRate()
            Dim Count1 As String = Dt.Rows.Count

            'Plant  Area


            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='140px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>" + "<br><img alt='' src='../../Images/spacer.gif' width='300px'height='0px'  />"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)


            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)
            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                Dim Unit As String = Dts.Rows(J).Item("UNIT").ToString()
                If Unit = 0 Then
                    td4.Text = "Area In:Sq Ft<br>" + "Lease Cost in:" + Dts.Rows(J).Item("Title4") + "<br/>" + "Suggested and Preferred Cost in:" + Dts.Rows(J).Item("Title4") + "/Sq Ft" + "<br/>Total Lease Cost in:" + Dts.Rows(J).Item("Title4")
                Else
                    td4.Text = "Area In:Sq M<br>" + "Lease Cost in:" + Dts.Rows(J).Item("Title4") + "<br/>" + "Suggested and Preferred Cost in:" + Dts.Rows(J).Item("Title4") + "/Sq M" + "<br/>Total Lease Cost in:" + Dts.Rows(J).Item("Title4")
                End If
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)



            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)

            'Break
            Dim tr4 As New TableRow
            Dim td7 As New TableCell
            td7.Text = "<b>Space Requirements</b>"
            tr4.CssClass = "Layer"
            tr4.Controls.Add(td7)
            Dim Break As New Integer
            For Break = 0 To Count - 1
                Dim td8 As New TableCell
                td8.Text = "&nbsp;"
                tr4.Controls.Add(td8)
            Next
            tblComparision.Controls.Add(tr4)


            'Production Area
            Dim PAR1 As New TableRow
            Dim PAC1 As New TableCell
            PAR1.CssClass = "ColorTR"
            PAR1.ID = "PA1_1"
            PAR1.Height = 25
            PAC1.Text = "Production "
            PAC1.CssClass = "Displaynametd"
            PAC1.BorderWidth = 1
            PAR1.Controls.Add(PAC1)
            Dim Productionarea As New Integer
            For Productionarea = 0 To Count - 1
                Dim PAC2 As New TableCell
                PAC2.Text = FormatNumber(Dts.Rows(Productionarea).Item("Productionarea").ToString(), 0)
                PAC2.Style.Add("text-align", "Center")
                PAC2.BorderWidth = 1
                PAR1.Controls.Add(PAC2)

            Next
            tblComparision.Controls.Add(PAR1)

            'Warehouse Area
            Dim PAR2 As New TableRow
            Dim PAC3 As New TableCell
            PAR2.CssClass = "ColorTR"
            PAR2.ID = "PA2_1"
            PAC3.Text = "Warehouse "
            PAC3.CssClass = "Displaynametd"
            PAC3.BorderWidth = 1
            PAR2.Controls.Add(PAC3)
            Dim Warehousearea As New Integer
            For Warehousearea = 0 To Count - 1
                Dim PAC4 As New TableCell
                Dim WarehouseTextBox As New TextBox
                WarehouseTextBox.Text = FormatNumber(Dts.Rows(Warehousearea).Item("WAREHOUSEAREA").ToString(), 0)
                WarehouseTextBox.ID = "W" + Warehousearea.ToString()
                WarehouseTextBox.CssClass = "textBox"
                PAC4.CssClass = "CaseTD"

                If Dts.Rows(Warehousearea).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    WarehouseTextBox.Enabled = False
                Else
                    WarehouseTextBox.Enabled = True
                End If

                PAC4.Controls.Add(WarehouseTextBox)
                PAC4.BorderWidth = 1
                PAR2.Controls.Add(PAC4)

            Next
            tblComparision.Controls.Add(PAR2)


            'Office Area
            Dim PAR3 As New TableRow
            Dim PAC5 As New TableCell
            PAR3.CssClass = "ColorTR"
            PAR3.ID = "PA3_1"
            PAC5.Text = "Office"
            PAC5.CssClass = "Displaynametd"
            PAC5.BorderWidth = 1
            PAR3.Controls.Add(PAC5)
            Dim Officearea As New Integer
            For Officearea = 0 To Count - 1
                Dim PAC6 As New TableCell
                Dim OfficeTextBox As New TextBox
                OfficeTextBox.Text = FormatNumber(Dts.Rows(Officearea).Item("OFFICEAREA").ToString(), 0)
                OfficeTextBox.ID = "O" + Officearea.ToString()
                OfficeTextBox.CssClass = "textBox"
                PAC6.CssClass = "CaseTD"

                If Dts.Rows(Officearea).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    OfficeTextBox.Enabled = False
                Else
                    OfficeTextBox.Enabled = True
                End If

                PAC6.Controls.Add(OfficeTextBox)
                PAC6.BorderWidth = 1
                PAR3.Controls.Add(PAC6)

            Next
            tblComparision.Controls.Add(PAR3)


            'Support Area
            Dim PAR4 As New TableRow
            Dim PAC7 As New TableCell
            PAR4.CssClass = "ColorTR"
            PAR4.ID = "PA4_1"
            PAC7.Text = "Support"
            PAC7.CssClass = "Displaynametd"
            PAC7.BorderWidth = 1
            PAR4.Controls.Add(PAC7)
            Dim Supportarea As New Integer
            For Supportarea = 0 To Count - 1
                Dim PAC8 As New TableCell
                Dim SupportTextBox As New TextBox
                SupportTextBox.Text = FormatNumber(Dts.Rows(Supportarea).Item("SUPPORTAREA").ToString(), 0)
                SupportTextBox.ID = "S" + Supportarea.ToString()
                SupportTextBox.CssClass = "textBox"
                PAC8.CssClass = "CaseTD"

                If Dts.Rows(Supportarea).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    SupportTextBox.Enabled = False
                Else
                    SupportTextBox.Enabled = True
                End If

                PAC8.Controls.Add(SupportTextBox)
                PAC8.BorderWidth = 1
                PAR4.Controls.Add(PAC8)

            Next
            tblComparision.Controls.Add(PAR4)


            'Total Area
            Dim PAR5 As New TableRow
            Dim PAC9 As New TableCell
            PAR5.CssClass = "ColorTR"
            PAR5.ID = "PA5_1"
            PAC9.Text = "Total"
            PAC9.CssClass = "Displaynametd"
            PAC9.BorderWidth = 1
            PAR5.Controls.Add(PAC9)
            Dim Totalarea As New Integer
            For Totalarea = 0 To Count - 1
                Dim PAC10 As New TableCell
                Dim TotalTextBox As New TextBox
                TotalTextBox.Text = FormatNumber(Dts.Rows(Totalarea).Item("TOTALAREA").ToString(), 0)
                TotalTextBox.ID = "T" + Totalarea.ToString()
                TotalTextBox.CssClass = "textBox"
                PAC10.CssClass = "CaseTD"

                If Dts.Rows(Totalarea).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    TotalTextBox.Enabled = False
                Else
                    TotalTextBox.Enabled = True
                End If

                PAC10.Controls.Add(TotalTextBox)
                PAC10.BorderWidth = 1
                PAR5.Controls.Add(PAC10)

            Next
            tblComparision.Controls.Add(PAR5)

            '--------------------------------------------------------------------------------------------------------------------



            'Break2
            Dim tr6 As New TableRow
            Dim td10 As New TableCell
            td10.Text = "<b>Lease Cost</b>"
            tr6.CssClass = "Layer"
            tr6.Controls.Add(td10)
            Dim Break1 As New Integer
            For Break1 = 0 To Count - 1
                Dim td11 As New TableCell
                td11.Text = "&nbsp;"
                tr6.Controls.Add(td11)
            Next
            tblComparision.Controls.Add(tr6)





            'Laease Cost

            'Production High Bay
            Dim PAR6 As New TableRow
            Dim PAC11 As New TableCell
            PAR6.ID = "PA6_1"
            PAR6.CssClass = "ColorTR"
            PAC11.Text = "Production High Bay"
            PAC11.CssClass = "Displaynametd"
            PAC11.BorderWidth = 1
            PAR6.Controls.Add(PAC11)
            Dim highbay As New Integer
            For highbay = 0 To Count - 1
                Dim PAC12 As New TableCell
                Dim HighBayP As New TextBox
                Dim HihgbayTable As New Table
                Dim HighBaytr1 As New TableRow
                Dim HighBaytr2 As New TableRow
                Dim HighBaytd1 As New TableCell
                Dim HighBaytd2 As New TableCell
                Dim HighBaytd3 As New TableCell
                Dim HighBaytd4 As New TableCell
                Dim HighBaytd5 As New TableCell
                Dim HighBaytd6 As New TableCell

                'Suggested Value
                HighBaytd1.Text = "<b>Suggested</b>"
                HighBaytd1.Width = 100
                HighBaytr1.Controls.Add(HighBaytd1)
                HighBaytd2.Text = Dt.Rows(0).Item("Leaserate").ToString()
                HighBaytr2.Controls.Add(HighBaytd2)

                'Preferred Value
                HighBaytd3.Text = "<b>Preferred</b>"
                HighBaytr1.Controls.Add(HighBaytd3)
                HighBayP.Text = Dts.Rows(highbay).Item("PRODUCTIONHIGHBAYLEASERATE").ToString()
                HighBayP.ID = "HB" + highbay.ToString()
                HighBayP.CssClass = "textBox"

                If Dts.Rows(highbay).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    HighBayP.Enabled = False
                Else
                    HighBayP.Enabled = True
                End If

                HighBaytd4.Controls.Add(HighBayP)
                HighBaytr2.Controls.Add(HighBaytd4)


                'Total Value
                HighBaytd5.Text = "<b>Total Lease</b>"
                HighBaytr1.Controls.Add(HighBaytd5)
                HighBaytd6.Text = FormatNumber(Dts.Rows(highbay).Item("TOTALPRODUCTIONRATE").ToString(), 0)
                HighBaytr2.Controls.Add(HighBaytd6)


                HihgbayTable.Controls.Add(HighBaytr1)
                HihgbayTable.Controls.Add(HighBaytr2)


                HihgbayTable.CellSpacing = 4
                PAC12.Style.Add("text-align", "Center")
                PAC12.Controls.Add(HihgbayTable)
                PAC12.BorderWidth = 1
                PAR6.Controls.Add(PAC12)
            Next
            tblComparision.Controls.Add(PAR6)



            'Production Partial High Bay
            Dim PAR7 As New TableRow
            Dim PAC13 As New TableCell
            PAR7.ID = "PA7_1"
            PAR7.CssClass = "ColorTR"
            PAC13.Text = "Production Partial High Bay"
            PAC13.CssClass = "Displaynametd"
            PAC13.BorderWidth = 1
            PAR7.Controls.Add(PAC13)
            Dim Partialhighbay As New Integer
            For Partialhighbay = 0 To Count - 1
                Dim PAC14 As New TableCell
                Dim PHighBayP As New TextBox
                Dim PHihgbayTable As New Table
                Dim PHighBaytr1 As New TableRow
                Dim PHighBaytr2 As New TableRow
                Dim PHighBaytd1 As New TableCell
                Dim PHighBaytd2 As New TableCell
                Dim PHighBaytd3 As New TableCell
                Dim PHighBaytd4 As New TableCell
                Dim PHighBaytd5 As New TableCell
                Dim PHighBaytd6 As New TableCell

                'Suggested Value
                PHighBaytd1.Text = "<b>Suggested</b>"
                PHighBaytd1.Width = 100
                PHighBaytr1.Controls.Add(PHighBaytd1)
                PHighBaytd2.Text = Dt.Rows(1).Item("Leaserate").ToString()
                PHighBaytr2.Controls.Add(PHighBaytd2)


                'Preferred Value
                PHighBaytd3.Text = "<b>Preferred</b>"
                PHighBaytr1.Controls.Add(PHighBaytd3)
                PHighBayP.Text = Dts.Rows(Partialhighbay).Item("PRODUCTIONPHIGHBAYLEASERATE").ToString()
                PHighBayP.CssClass = "textBox"
                PHighBayP.ID = "PHB" + Partialhighbay.ToString()
                PHighBaytd4.Controls.Add(PHighBayP)

                If Dts.Rows(Partialhighbay).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    PHighBayP.Enabled = False
                Else
                    PHighBayP.Enabled = True
                End If

                PHighBaytr2.Controls.Add(PHighBaytd4)
                PHihgbayTable.Controls.Add(PHighBaytr1)
                PHihgbayTable.Controls.Add(PHighBaytr2)


                'Total Value
                PHighBaytd5.Text = "<b>Total Lease</b>"
                PHighBaytr1.Controls.Add(PHighBaytd5)
                PHighBaytd6.Text = FormatNumber(Dts.Rows(Partialhighbay).Item("TOTALPRODUCTIONRATE").ToString(), 3)
                PHighBaytr2.Controls.Add(PHighBaytd6)

                PHihgbayTable.Controls.Add(PHighBaytr1)
                PHihgbayTable.Controls.Add(PHighBaytr2)



                PHihgbayTable.CellSpacing = 4
                PAC14.Style.Add("text-align", "Center")
                PAC14.Controls.Add(PHihgbayTable)
                PAC14.BorderWidth = 1
                PAR7.Controls.Add(PAC14)
            Next
            tblComparision.Controls.Add(PAR7)



            'Production Standard
            Dim PAR8 As New TableRow
            Dim PAC15 As New TableCell
            PAR8.ID = "PA8_1"
            PAR8.CssClass = "ColorTR"
            PAC15.Text = "Production Standard"
            PAC15.CssClass = "Displaynametd"
            PAC15.BorderWidth = 1
            PAR8.Controls.Add(PAC15)
            Dim Standard As New Integer
            For Standard = 0 To Count - 1
                Dim PAC16 As New TableCell
                Dim PAC14 As New TableCell
                Dim PStandardP As New TextBox
                Dim PStandardTable As New Table
                Dim PStandardtr1 As New TableRow
                Dim PStandardtr2 As New TableRow
                Dim PStandardtd1 As New TableCell
                Dim PStandardtd2 As New TableCell
                Dim PStandardtd3 As New TableCell
                Dim PStandardtd4 As New TableCell
                Dim PStandardtd5 As New TableCell
                Dim PStandardtd6 As New TableCell

                'Suggested Value
                PStandardtd1.Text = "<b>Suggested</b>"
                PStandardtd1.Width = 100
                PStandardtr1.Controls.Add(PStandardtd1)
                PStandardtd2.Text = Dt.Rows(2).Item("Leaserate").ToString()
                PStandardtr2.Controls.Add(PStandardtd2)


                'Preferred Value
                PStandardtd3.Text = "<b>Preferred</b>"
                PStandardtr1.Controls.Add(PStandardtd3)
                PStandardP.Text = Dts.Rows(Standard).Item("PRODUCTIONSTDLEASERATE").ToString()
                PStandardP.CssClass = "textBox"
                PStandardP.ID = "STD" + Standard.ToString()
                PStandardtd4.Controls.Add(PStandardP)

                If Dts.Rows(Standard).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    PStandardP.Enabled = False
                Else
                    PStandardP.Enabled = True
                End If

                PStandardtr2.Controls.Add(PStandardtd4)


                'Total Value
                PStandardtd5.Text = "<b>Total Lease</b>"
                PStandardtr1.Controls.Add(PStandardtd5)
                PStandardtd6.Text = FormatNumber(Dts.Rows(Standard).Item("TOTALPRODUCTIONRATE").ToString(), 0)
                PStandardtr2.Controls.Add(PStandardtd6)


                PStandardTable.Controls.Add(PStandardtr1)
                PStandardTable.Controls.Add(PStandardtr2)

                PStandardTable.CellSpacing = 4
                PAC16.Style.Add("text-align", "Center")
                PAC16.Controls.Add(PStandardTable)
                PAC16.BorderWidth = 1
                PAR8.Controls.Add(PAC16)


            Next
            tblComparision.Controls.Add(PAR8)


            'Warehouse Lease
            Dim PAR9 As New TableRow
            Dim PAC17 As New TableCell
            PAR9.ID = "PA9_1"
            PAR9.CssClass = "ColorTR"
            PAC17.Text = "Warehouse"
            PAC17.CssClass = "Displaynametd"
            PAC17.BorderWidth = 1
            PAR9.Controls.Add(PAC17)
            Dim Warehouse As New Integer
            For Warehouse = 0 To Count - 1
                Dim PAC18 As New TableCell
                Dim WareHouseLP As New TextBox
                Dim WareHouseLTable As New Table
                Dim WareHouseLtr1 As New TableRow
                Dim WareHouseLtr2 As New TableRow
                Dim WareHouseLtd1 As New TableCell
                Dim WareHouseLtd2 As New TableCell
                Dim WareHouseLtd3 As New TableCell
                Dim WareHouseLtd4 As New TableCell
                Dim WareHouseLtd5 As New TableCell
                Dim WareHouseLtd6 As New TableCell

                'Suggested Value
                WareHouseLtd1.Text = "<b>Suggested</b>"
                WareHouseLtd1.Width = 100
                WareHouseLtr1.Controls.Add(WareHouseLtd1)
                WareHouseLtd2.Text = Dt.Rows(3).Item("Leaserate").ToString()
                WareHouseLtr2.Controls.Add(WareHouseLtd2)


                'Preferred Value
                WareHouseLtd3.Text = "<b>Preferred</b>"
                WareHouseLtr1.Controls.Add(WareHouseLtd3)
                WareHouseLP.Text = Dts.Rows(Warehouse).Item("WAREHOUSELEASERATE").ToString()
                WareHouseLP.CssClass = "textBox"
                WareHouseLP.ID = "WARE" + Warehouse.ToString()
                WareHouseLtd4.Controls.Add(WareHouseLP)

                If Dts.Rows(Warehouse).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    WareHouseLP.Enabled = False
                Else
                    WareHouseLP.Enabled = True
                End If

                WareHouseLtr2.Controls.Add(WareHouseLtd4)


                'Total(Value)
                WareHouseLtd5.Text = "<b>Total Lease</b>"
                WareHouseLtr1.Controls.Add(WareHouseLtd5)
                WareHouseLtd6.Text = FormatNumber(Dts.Rows(Warehouse).Item("TOTALWAREHOUSERATE").ToString(), 0)
                WareHouseLtr2.Controls.Add(WareHouseLtd6)


                WareHouseLTable.Controls.Add(WareHouseLtr1)
                WareHouseLTable.Controls.Add(WareHouseLtr2)



                WareHouseLTable.CellSpacing = 4
                PAC18.Style.Add("text-align", "Center")
                PAC18.Controls.Add(WareHouseLTable)
                PAC18.BorderWidth = 1
                PAR9.Controls.Add(PAC18)
            Next
            tblComparision.Controls.Add(PAR9)




            'Office Lease
            Dim PAR10 As New TableRow
            Dim PAC19 As New TableCell
            PAR10.ID = "PA10_1"
            PAR10.CssClass = "ColorTR"
            PAC19.Text = "Office"
            PAC19.CssClass = "Displaynametd"
            PAC19.BorderWidth = 1
            PAR10.Controls.Add(PAC19)
            Dim Office As New Integer
            For Office = 0 To Count - 1
                Dim PAC20 As New TableCell
                Dim OfficeLP As New TextBox
                Dim OfficeLTable As New Table
                Dim OfficeLtr1 As New TableRow
                Dim OfficeLtr2 As New TableRow
                Dim OfficeLtd1 As New TableCell
                Dim OfficeLtd2 As New TableCell
                Dim OfficeLtd3 As New TableCell
                Dim OfficeLtd4 As New TableCell
                Dim OfficeLtd5 As New TableCell
                Dim OfficeLtd6 As New TableCell

                'Suggested Value
                OfficeLtd1.Text = "<b>Suggested</b>"
                OfficeLtd1.Width = 100
                OfficeLtr1.Controls.Add(OfficeLtd1)
                OfficeLtd2.Text = Dt.Rows(4).Item("Leaserate").ToString()
                OfficeLtr2.Controls.Add(OfficeLtd2)


                'Preferred Value
                OfficeLtd3.Text = "<b>Preferred</b>"
                OfficeLtr1.Controls.Add(OfficeLtd3)
                OfficeLP.Text = Dts.Rows(Office).Item("OFFICELEASERATE").ToString()
                OfficeLP.CssClass = "textBox"
                OfficeLP.ID = "OFF" + Office.ToString()
                OfficeLtd4.Controls.Add(OfficeLP)

                If Dts.Rows(Office).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    OfficeLP.Enabled = False
                Else
                    OfficeLP.Enabled = True
                End If


                OfficeLtr2.Controls.Add(OfficeLtd4)


                'Total Value
                OfficeLtd5.Text = "<b>Total Lease</b>"
                OfficeLtr1.Controls.Add(OfficeLtd5)
                OfficeLtd6.Text = FormatNumber(Dts.Rows(Office).Item("TOTALOFFICERATE").ToString(), 3)
                OfficeLtr2.Controls.Add(OfficeLtd6)


                OfficeLTable.Controls.Add(OfficeLtr1)
                OfficeLTable.Controls.Add(OfficeLtr2)



                OfficeLTable.CellSpacing = 4
                PAC20.Style.Add("text-align", "Center")
                PAC20.Controls.Add(OfficeLTable)
                PAC20.BorderWidth = 1
                PAR10.Controls.Add(PAC20)

            Next
            tblComparision.Controls.Add(PAR10)




            'Support Lease
            Dim PAR11 As New TableRow
            Dim PAC21 As New TableCell
            PAR11.ID = "PA11_1"
            PAR11.CssClass = "ColorTR"
            PAC21.Text = "Support"
            PAC21.CssClass = "Displaynametd"
            PAC21.BorderWidth = 1
            PAR11.Controls.Add(PAC21)
            Dim Support As New Integer
            For Support = 0 To Count - 1
                Dim PAC22 As New TableCell
                Dim SuuportLP As New TextBox
                Dim SuuportLTable As New Table
                Dim SuuportLtr1 As New TableRow
                Dim SuuportLtr2 As New TableRow
                Dim SuuportLtd1 As New TableCell
                Dim SuuportLtd2 As New TableCell
                Dim SuuportLtd3 As New TableCell
                Dim SuuportLtd4 As New TableCell
                Dim SuuportLtd5 As New TableCell
                Dim SuuportLtd6 As New TableCell

                'Suggested(Value)
                SuuportLtd1.Text = "<b>Suggested</b>"
                SuuportLtd1.Width = 100
                SuuportLtr1.Controls.Add(SuuportLtd1)
                SuuportLtd2.Text = Dt.Rows(5).Item("Leaserate").ToString()
                SuuportLtr2.Controls.Add(SuuportLtd2)


                'Preferred(Value)
                SuuportLtd3.Text = "<b>Preferred</b>"
                SuuportLtr1.Controls.Add(SuuportLtd3)
                SuuportLP.Text = Dts.Rows(Support).Item("SUPPORTLEASERATE").ToString()
                SuuportLP.CssClass = "textBox"
                SuuportLP.ID = "SUPP" + Support.ToString()
                SuuportLtd4.Controls.Add(SuuportLP)

                If Dts.Rows(Support).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                    SuuportLP.Enabled = False
                Else
                    SuuportLP.Enabled = True
                End If

                SuuportLtr2.Controls.Add(SuuportLtd4)


                'Total(Value)
                SuuportLtd5.Text = "<b>Total Lease</b>"
                SuuportLtr1.Controls.Add(SuuportLtd5)
                SuuportLtd6.Text = FormatNumber(Dts.Rows(Support).Item("TOTALSUPPORTRATE").ToString(), 0)
                SuuportLtr2.Controls.Add(SuuportLtd6)

                SuuportLTable.Controls.Add(SuuportLtr1)
                SuuportLTable.Controls.Add(SuuportLtr2)


                SuuportLTable.CellSpacing = 4
                PAC22.Style.Add("text-align", "Center")
                PAC22.Controls.Add(SuuportLTable)
                PAC22.BorderWidth = 1
                PAR11.Controls.Add(PAC22)

            Next
            tblComparision.Controls.Add(PAR11)





            'Total Lease
            Dim PAR12 As New TableRow
            Dim PAC23 As New TableCell
            PAR12.ID = "PA12_1"
            PAR12.CssClass = "ColorTR"
            PAC23.Text = "Total Lease"
            PAC23.CssClass = "Displaynametd"
            PAC23.BorderWidth = 1
            PAR12.Controls.Add(PAC23)
            Dim total As New Integer
            For total = 0 To Count - 1
                Dim PAC24 As New TableCell
                Dim totalLP As New TextBox
                Dim totalLTable As New Table
                Dim totalLtr1 As New TableRow
                Dim totalLtr2 As New TableRow
                Dim totalLtr3 As New TableRow
                Dim totalLtd1 As New TableCell
                Dim totalLtd2 As New TableCell
                Dim totalLtd3 As New TableCell
                Dim totalLtd4 As New TableCell
                Dim totalLtd5 As New TableCell
                Dim totalLtd6 As New TableCell

                ''Suggested(Value)
                'totalLtd1.Text = "<b>Suggested</b>"
                'totalLtd1.Width = 100
                'totalLtr1.Controls.Add(totalLtd1)
                'totalLtd2.Text = Dt.Rows(5).Item("Leaserate").ToString()
                'totalLtr2.Controls.Add(totalLtd2)
                'totalLTable.Controls.Add(totalLtr1)

                ''Preferred(Value)
                'totalLtd3.Text = "<b>Preferred</b>"
                'totalLtr1.Controls.Add(totalLtd3)
                'totalLP.Text = Dts.Rows(total).Item("SUPPORTLEASERATE").ToString()
                'totalLP.CssClass = "textBox"
                'totalLtd4.Controls.Add(totalLP)
                'totalLtr2.Controls.Add(totalLtd4)
                'totalLTable.Controls.Add(totalLtr2)

                'Total(Value)
                totalLtd5.Text = "<b>Total Lease</b>"
                totalLtd5.Style.Add("color", "#D4DDED")
                totalLtr1.Controls.Add(totalLtd5)
                totalLtd6.Text = FormatNumber(Dts.Rows(total).Item("TOTALTRATE").ToString(), 0)
                'totalLtd6.Style.Add("text-align", "Center")
                totalLtr2.Controls.Add(totalLtd6)

                totalLTable.Controls.Add(totalLtr1)
                totalLTable.Controls.Add(totalLtr2)


                totalLTable.CellSpacing = 4
                PAC24.Style.Add("text-align", "right")
                PAC24.Controls.Add(totalLTable)
                PAC24.BorderWidth = 1
                PAR12.Controls.Add(PAC24)

            Next
            tblComparision.Controls.Add(PAR12)











        Catch ex As Exception
            Response.Write("Error:" + ex.Message.ToString())
        End Try

    End Sub

    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click

        'Declaring Variables

        Dim PlantSpaceUpdate As New Update()
        Dim I As New Integer
        Dim J As New Integer

        'loop 

        For I = 0 To Count - 1

            Dim CaseId As String = ""
            Dim warehouse As String = ""
            Dim office As String = ""
            Dim support As String = ""
            Dim total As String = ""
            Dim prodHighBay As String = ""
            Dim prodPartHighBay As String = ""
            Dim prodStandard As String = ""
            Dim warehouseLeaseRate As String = ""
            Dim officeLeaseRate As String = ""
            Dim supportLeaseRate As String = ""

            'passing ID to form 
            Dim whouse As String = Request.Form("ctl00$ContentPlaceHolder1$W" + I.ToString())
            Dim off As String = Request.Form("ctl00$ContentPlaceHolder1$O" + I.ToString())
            Dim supp As String = Request.Form("ctl00$ContentPlaceHolder1$S" + I.ToString())
            Dim tot As String = Request.Form("ctl00$ContentPlaceHolder1$T" + I.ToString())
            Dim prodHB As String = Request.Form("ctl00$ContentPlaceHolder1$HB" + I.ToString())
            Dim prodPartHB As String = Request.Form("ctl00$ContentPlaceHolder1$PHB" + I.ToString())
            Dim prodStd As String = Request.Form("ctl00$ContentPlaceHolder1$STD" + I.ToString())
            Dim warehouseLR As String = Request.Form("ctl00$ContentPlaceHolder1$WARE" + I.ToString())
            Dim offLR As String = Request.Form("ctl00$ContentPlaceHolder1$OFF" + I.ToString())
            Dim suppLR As String = Request.Form("ctl00$ContentPlaceHolder1$SUPP" + I.ToString())

            CaseId = Request.Form("Case" + I.ToString() + "")

            warehouse = warehouse + whouse + ","
            office = office + off + ","
            support = support + supp + ","
            total = total + tot + ","
            prodHighBay = prodHighBay + prodHB + ","
            prodPartHighBay = prodPartHighBay + prodPartHB + ","
            prodStandard = prodStandard + prodStd + ","
            warehouseLeaseRate = warehouseLeaseRate + warehouseLR + ","
            officeLeaseRate = officeLeaseRate + offLR + ","
            supportLeaseRate = supportLeaseRate + suppLR + ","


            warehouse = warehouse.Remove(warehouse.Length - 1, 1)
            office = office.Remove(office.Length - 1, 1)
            support = support.Remove(support.Length - 1, 1)
            total = total.Remove(total.Length - 1, 1)
            prodHighBay = prodHighBay.Remove(prodHighBay.Length - 1, 1)
            prodPartHighBay = prodPartHighBay.Remove(prodPartHighBay.Length - 1, 1)
            prodStandard = prodStandard.Remove(prodStandard.Length - 1, 1)
            warehouseLeaseRate = warehouseLeaseRate.Remove(warehouseLeaseRate.Length - 1, 1)
            officeLeaseRate = officeLeaseRate.Remove(officeLeaseRate.Length - 1, 1)
            supportLeaseRate = supportLeaseRate.Remove(supportLeaseRate.Length - 1, 1)

            If CaseId <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                PlantSpaceUpdate.PlantSpaceUpdate(CaseId, warehouse, office, support, total, prodHighBay, prodPartHighBay, prodStandard, warehouseLeaseRate, officeLeaseRate, supportLeaseRate)
            End If
        Next

        Response.Redirect("PlantConfig2.aspx")

    End Sub

    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click
        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))

            'Checking The Case 
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                CI = CI + CaseID + ","
            End If

        Next
        If CI <> "" Then
            CI = CI.Remove(CI.Length - 1, 1)
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=PlantConfig2.aspx")
        End If

    End Sub
End Class
