Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Partial Class DeptConfig
    Inherits System.Web.UI.Page

    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList
    Public DeptCombo As New DropDownList


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)

            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetDeptConfigSql(Cases, UserName, Password)

            'Dim GetDept As New RepeatedControls()
            'DeptCombo = GetDept.DeptDropdown()


            Count = Dts.Rows.Count.ToString()


            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='170px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item(1).ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)




            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)




            Dim row As New Integer

            For row = 1 To 10
                'Break
                Dim tr5 As New TableRow
                Dim td7 As New TableCell
                td7.Text = "<b>Department" + row.ToString + "</b>"
                tr5.CssClass = "Layer"
                tr5.Controls.Add(td7)
                Dim Break As New Integer
                For Break = 0 To Count - 1
                    Dim td8 As New TableCell
                    td8.Text = "&nbsp;"
                    tr5.Controls.Add(td8)
                Next
                tblComparision.Controls.Add(tr5)

                'DepartMent Config


                Dim DPR1 As New TableRow
                Dim DPC1 As New TableCell
                DPR1.ID = "D1_" + row.ToString()
                DPR1.CssClass = "ColorTR"
                DPC1.Text = "Required Departments"
                DPC1.CssClass = "Displaynametd"
                DPC1.BorderWidth = 1
                DPR1.Controls.Add(DPC1)
                Dim Dept1 As New Integer
                For Dept1 = 0 To Count - 1
                    Dim DPC2 As New TableCell
                    Dim DeptCombo1 As New DropDownList
                    Dim DP1 As String = "D" + row.ToString() + "P1"
                    Dim GetDept As New RepeatedControls()
                    DeptCombo1 = GetDept.DeptDropdown()
                    DeptCombo1.SelectedValue = Dts.Rows(Dept1).Item(DP1).ToString()
                    DeptCombo1.CssClass = "dropdown"
                    DeptCombo1.ID = "D1P" + row.ToString() + "_" + Dept1.ToString()

                    If Dts.Rows(Dept1).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo1.Enabled = False
                    Else
                        DeptCombo1.Enabled = True
                    End If

                    DPC2.Controls.Add(DeptCombo1)
                    DPC2.BorderWidth = 1
                    DPC2.CssClass = "CaseTD"
                    DPR1.Controls.Add(DPC2)
                Next
                tblComparision.Controls.Add(DPR1)


                Dim DPR2 As New TableRow
                Dim DPC3 As New TableCell
                DPR2.ID = "D2_" + row.ToString()
                DPR2.CssClass = "ColorTR"
                DPC3.Text = "Next Process1"
                DPC3.CssClass = "Displaynametd"
                DPC3.BorderWidth = 1
                DPR2.Controls.Add(DPC3)
                Dim Dept2 As New Integer
                For Dept2 = 0 To Count - 1
                    Dim DPC4 As New TableCell
                    Dim DeptCombo2 As New DropDownList
                    Dim DP2 As String = "D" + row.ToString() + "P2"
                    Dim GetDept As New RepeatedControls()
                    DeptCombo2 = GetDept.DeptDropdown()
                    DeptCombo2.SelectedValue = Dts.Rows(Dept2).Item(DP2).ToString()
                    DeptCombo2.CssClass = "dropdown"
                    DeptCombo2.ID = "D2P" + row.ToString() + "_" + Dept2.ToString()

                    If Dts.Rows(Dept2).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo2.Enabled = False
                    Else
                        DeptCombo2.Enabled = True
                    End If

                    DPC4.Controls.Add(DeptCombo2)
                    DPC4.BorderWidth = 1
                    DPC4.CssClass = "CaseTD"
                    DPR2.Controls.Add(DPC4)
                Next
                tblComparision.Controls.Add(DPR2)


                Dim DPR3 As New TableRow
                Dim DPC5 As New TableCell
                DPR3.ID = "D3_" + row.ToString()
                DPR3.CssClass = "ColorTR"
                DPC5.Text = "Next Process2"
                DPC5.CssClass = "Displaynametd"
                DPC5.BorderWidth = 1
                DPR3.Controls.Add(DPC5)
                Dim Dept3 As New Integer
                For Dept3 = 0 To Count - 1
                    Dim DPC6 As New TableCell
                    Dim DeptCombo3 As New DropDownList
                    Dim DP3 As String = "D" + row.ToString() + "P3"
                    Dim GetDept As New RepeatedControls()
                    DeptCombo3 = GetDept.DeptDropdown()
                    DeptCombo3.SelectedValue = Dts.Rows(Dept3).Item(DP3).ToString()
                    DeptCombo3.CssClass = "dropdown"
                    DeptCombo3.ID = "D3P" + row.ToString() + "_" + Dept3.ToString()

                    If Dts.Rows(Dept3).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo3.Enabled = False
                    Else
                        DeptCombo3.Enabled = True
                    End If

                    DPC6.Controls.Add(DeptCombo3)
                    DPC6.BorderWidth = 1
                    DPC6.CssClass = "CaseTD"
                    DPR3.Controls.Add(DPC6)
                Next
                tblComparision.Controls.Add(DPR3)



                Dim DPR4 As New TableRow
                Dim DPC7 As New TableCell
                DPR4.ID = "D4_" + row.ToString()
                DPR4.CssClass = "ColorTR"
                DPC7.Text = "Next Process3"
                DPC7.CssClass = "Displaynametd"
                DPC7.BorderWidth = 1
                DPR4.Controls.Add(DPC7)
                Dim Dept4 As New Integer
                For Dept4 = 0 To Count - 1
                    Dim DPC8 As New TableCell
                    Dim DeptCombo4 As New DropDownList
                    Dim DP4 As String = "D" + row.ToString() + "P4"
                    Dim GetDept As New RepeatedControls()
                    DeptCombo4 = GetDept.DeptDropdown()
                    DeptCombo4.SelectedValue = Dts.Rows(Dept4).Item(DP4).ToString()
                    DeptCombo4.CssClass = "dropdown"
                    DeptCombo4.ID = "D4P" + row.ToString() + "_" + Dept4.ToString()

                    If Dts.Rows(Dept4).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo4.Enabled = False
                    Else
                        DeptCombo4.Enabled = True
                    End If

                    DPC8.Controls.Add(DeptCombo4)
                    DPC8.BorderWidth = 1
                    DPC8.CssClass = "CaseTD"
                    DPR4.Controls.Add(DPC8)
                Next
                tblComparision.Controls.Add(DPR4)



                Dim DPR5 As New TableRow
                Dim DPC9 As New TableCell
                DPR5.ID = "D5_" + row.ToString()
                DPR5.CssClass = "ColorTR"
                DPC9.Text = "Next Process4"
                DPC9.CssClass = "Displaynametd"
                DPC9.BorderWidth = 1
                DPR5.Controls.Add(DPC9)
                Dim Dept5 As New Integer
                For Dept5 = 0 To Count - 1
                    Dim DPC10 As New TableCell
                    Dim DeptCombo5 As New DropDownList
                    Dim DP5 As String = "D" + row.ToString() + "P5"
                    Dim GetDept As New RepeatedControls()
                    DeptCombo5 = GetDept.DeptDropdown()
                    DeptCombo5.SelectedValue = Dts.Rows(Dept5).Item(DP5).ToString()
                    DeptCombo5.CssClass = "dropdown"
                    DeptCombo5.ID = "D5P" + row.ToString() + "_" + Dept5.ToString()

                    If Dts.Rows(Dept5).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo5.Enabled = False
                    Else
                        DeptCombo5.Enabled = True
                    End If

                    DPC10.Controls.Add(DeptCombo5)
                    DPC10.BorderWidth = 1
                    DPC10.CssClass = "CaseTD"
                    DPR5.Controls.Add(DPC10)
                Next
                tblComparision.Controls.Add(DPR5)


                Dim DPR6 As New TableRow
                Dim DPC11 As New TableCell
                DPR6.ID = "D6_" + row.ToString()
                DPR6.CssClass = "ColorTR"
                DPC11.Text = "Next Process5"
                DPC11.CssClass = "Displaynametd"
                DPC11.BorderWidth = 1
                DPR6.Controls.Add(DPC11)
                Dim Dept6 As New Integer
                For Dept6 = 0 To Count - 1
                    Dim DPC12 As New TableCell
                    Dim DeptCombo6 As New DropDownList
                    Dim DP6 As String = "D" + row.ToString() + "P6"
                    Dim GetDept As New RepeatedControls()
                    DeptCombo6 = GetDept.DeptDropdown()
                    DeptCombo6.SelectedValue = Dts.Rows(Dept6).Item(DP6).ToString()
                    DeptCombo6.CssClass = "dropdown"
                    DeptCombo6.ID = "D6P" + row.ToString() + "_" + Dept6.ToString()

                    If Dts.Rows(Dept6).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo6.Enabled = False
                    Else
                        DeptCombo6.Enabled = True
                    End If


                    DPC12.Controls.Add(DeptCombo6)
                    DPC12.BorderWidth = 1
                    DPC12.CssClass = "CaseTD"
                    DPR6.Controls.Add(DPC12)
                Next
                tblComparision.Controls.Add(DPR6)



                Dim DPR7 As New TableRow
                Dim DPC13 As New TableCell
                DPR7.ID = "D7_" + row.ToString()
                DPR7.CssClass = "ColorTR"
                DPC13.Text = "Next Process6"
                DPC13.CssClass = "Displaynametd"
                DPC13.BorderWidth = 1
                DPR7.Controls.Add(DPC13)
                Dim Dept7 As New Integer
                For Dept7 = 0 To Count - 1
                    Dim DPC14 As New TableCell
                    Dim DeptCombo7 As New DropDownList
                    Dim DP7 As String = "D" + row.ToString() + "P7"
                    Dim GetDept As New RepeatedControls()
                    DeptCombo7 = GetDept.DeptDropdown()
                    DeptCombo7.SelectedValue = Dts.Rows(Dept7).Item(DP7).ToString()
                    DeptCombo7.CssClass = "dropdown"
                    DeptCombo7.ID = "D7P" + row.ToString() + "_" + Dept7.ToString()

                    If Dts.Rows(Dept7).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo7.Enabled = False
                    Else
                        DeptCombo7.Enabled = True
                    End If

                    DPC14.Controls.Add(DeptCombo7)
                    DPC14.BorderWidth = 1
                    DPC14.CssClass = "CaseTD"
                    DPR7.Controls.Add(DPC14)
                Next
                tblComparision.Controls.Add(DPR7)


                Dim DPR8 As New TableRow
                Dim DPC15 As New TableCell
                DPR8.ID = "D8_" + row.ToString()
                DPR8.CssClass = "ColorTR"
                DPC15.Text = "Next Process7"
                DPC15.CssClass = "Displaynametd"
                DPC15.BorderWidth = 1
                DPR8.Controls.Add(DPC15)
                Dim Dept8 As New Integer
                For Dept8 = 0 To Count - 1
                    Dim DPC16 As New TableCell
                    Dim DeptCombo8 As New DropDownList
                    Dim DP8 As String = "D" + row.ToString() + "P8"
                    Dim GetDept As New RepeatedControls()
                    DeptCombo8 = GetDept.DeptDropdown()
                    DeptCombo8.SelectedValue = Dts.Rows(Dept8).Item(DP8).ToString()
                    DeptCombo8.CssClass = "dropdown"
                    DeptCombo8.ID = "D8P" + row.ToString() + "_" + Dept8.ToString()

                    If Dts.Rows(Dept8).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo8.Enabled = False
                    Else
                        DeptCombo8.Enabled = True
                    End If


                    DPC16.Controls.Add(DeptCombo8)
                    DPC16.BorderWidth = 1
                    DPC16.CssClass = "CaseTD"
                    DPR8.Controls.Add(DPC16)
                Next
                tblComparision.Controls.Add(DPR8)


                Dim DPR9 As New TableRow
                Dim DPC17 As New TableCell
                DPR9.ID = "D9_" + row.ToString()
                DPR9.CssClass = "ColorTR"
                DPC17.Text = "Next Process8"
                DPC17.CssClass = "Displaynametd"
                DPC17.BorderWidth = 1
                DPR9.Controls.Add(DPC17)
                Dim Dept9 As New Integer
                For Dept9 = 0 To Count - 1
                    Dim DPC18 As New TableCell
                    Dim DeptCombo9 As New DropDownList
                    Dim DP9 As String = "D" + row.ToString() + "P9"
                    Dim GetDept As New RepeatedControls()
                    DeptCombo9 = GetDept.DeptDropdown()
                    DeptCombo9.SelectedValue = Dts.Rows(Dept9).Item(DP9).ToString()
                    DeptCombo9.CssClass = "dropdown"
                    DeptCombo9.ID = "D9P" + row.ToString() + "_" + Dept9.ToString()

                    If Dts.Rows(Dept9).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo9.Enabled = False
                    Else
                        DeptCombo9.Enabled = True
                    End If

                    DPC18.Controls.Add(DeptCombo9)
                    DPC18.BorderWidth = 1
                    DPC18.CssClass = "CaseTD"
                    DPR9.Controls.Add(DPC18)
                Next
                tblComparision.Controls.Add(DPR9)



                Dim DPR10 As New TableRow
                Dim DPC20 As New TableCell
                DPR10.ID = "D10_" + row.ToString()
                DPR10.CssClass = "ColorTR"
                DPC20.Text = "Next Process9"
                DPC20.CssClass = "Displaynametd"
                DPC20.BorderWidth = 1
                DPR10.Controls.Add(DPC20)
                Dim Dept10 As New Integer
                For Dept10 = 0 To Count - 1
                    Dim DPC21 As New TableCell
                    Dim DeptCombo10 As New DropDownList
                    Dim DP10 As String = "D" + row.ToString() + "P10"
                    Dim GetDept As New RepeatedControls()
                    DeptCombo10 = GetDept.DeptDropdown()
                    DeptCombo10.SelectedValue = Dts.Rows(Dept10).Item(DP10).ToString()
                    DeptCombo10.CssClass = "dropdown"
                    DeptCombo10.ID = "D10P" + row.ToString() + "_" + Dept10.ToString()

                    If Dts.Rows(Dept10).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo10.Enabled = False
                    Else
                        DeptCombo10.Enabled = True
                    End If

                    DPC21.Controls.Add(DeptCombo10)
                    DPC21.BorderWidth = 1
                    DPC21.CssClass = "CaseTD"
                    DPR10.Controls.Add(DPC21)
                Next
                tblComparision.Controls.Add(DPR10)



            Next













        Catch ex As Exception
            Response.Write("Error:" + ex.Message)
        End Try

    End Sub

    Protected Sub Update1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update1.Click, Update2.Click
        Try

            'declaring variables for row and coloums
            Dim I As New Integer
            Dim J As New Integer
            Dim K As New Integer
            Dim DepartmentConFigUpdate As New Update()

            'Case Loop
            For I = 0 To Count - 1
                Dim CaseID As String = ""
                Dim DF(10, 10) As String

                'Layer Loop
                For J = 1 To 10

                    'Getting CaseID
                    CaseID = Request.Form("Case" + I.ToString())

                    'Getting Arrary For 10 Layers as no.of cases
                    'Array Loop
                    For K = 1 To 10
                        DF(J, K) = Request.Form("ctl00$ContentPlaceHolder1$D" + K.ToString() + "P" + J.ToString() + "_" + I.ToString())
                    Next


                Next


                If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
                Else
                    DepartmentConFigUpdate.DepartmentConFigUpdate(CaseID, DF)
                End If

            Next

            Response.Redirect("DepartmentConfiguration.aspx")
        Catch ex As Exception
            Response.Write("UpdatedError:" + ex.Message.ToString())
        End Try
        'Try


        '    Dim I As New Integer
        '    Dim J As New Integer

        '    Dim DepartmentInUpdate As New Update()
        '    For I = 0 To Count - 1
        '        Dim RD As String = ""
        '        Dim NP1 As String = ""
        '        Dim NP2 As String = ""
        '        Dim NP3 As String = ""
        '        Dim NP4 As String = ""
        '        Dim NP5 As String = ""
        '        Dim NP6 As String = ""
        '        Dim NP7 As String = ""
        '        Dim NP8 As String = ""
        '        Dim NP9 As String = ""

        '        Dim CaseID As String = ""

        '        Dim RequiredDepartment As String = ""
        '        Dim NextProcess1 As String = ""
        '        Dim NextProcess2 As String = ""
        '        Dim NextProcess3 As String = ""
        '        Dim NextProcess4 As String = ""
        '        Dim NextProcess5 As String = ""
        '        Dim NextProcess6 As String = ""
        '        Dim NextProcess7 As String = ""
        '        Dim NextProcess8 As String = ""
        '        Dim NextProcess9 As String = ""


        '        For J = 1 To 10
        '            RD = Request.Form("ctl00$ContentPlaceHolder1$D1P" + J.ToString() + "_" + I.ToString())
        '            NP1 = Request.Form("ctl00$ContentPlaceHolder1$D2P" + J.ToString() + "_" + I.ToString())
        '            NP2 = Request.Form("ctl00$ContentPlaceHolder1$D3P" + J.ToString() + "_" + I.ToString())
        '            NP3 = Request.Form("ctl00$ContentPlaceHolder1$D4P" + J.ToString() + "_" + I.ToString())
        '            NP4 = Request.Form("ctl00$ContentPlaceHolder1$D5P" + J.ToString() + "_" + I.ToString())
        '            NP5 = Request.Form("ctl00$ContentPlaceHolder1$D6P" + J.ToString() + "_" + I.ToString())
        '            NP6 = Request.Form("ctl00$ContentPlaceHolder1$D7P" + J.ToString() + "_" + I.ToString())
        '            NP7 = Request.Form("ctl00$ContentPlaceHolder1$D8P" + J.ToString() + "_" + I.ToString())
        '            NP8 = Request.Form("ctl00$ContentPlaceHolder1$D9P" + J.ToString() + "_" + I.ToString())
        '            NP9 = Request.Form("ctl00$ContentPlaceHolder1$D10P" + J.ToString() + "_" + I.ToString())

        '            CaseID = Request.Form("Case" + I.ToString())

        '            RequiredDepartment = RequiredDepartment + RD + ","
        '            NextProcess1 = NextProcess1 + NP1 + ","
        '            NextProcess2 = NextProcess2 + NP2 + ","
        '            NextProcess3 = NextProcess3 + NP3 + ","
        '            NextProcess4 = NextProcess4 + NP4 + ","
        '            NextProcess5 = NextProcess5 + NP5 + ","
        '            NextProcess6 = NextProcess6 + NP6 + ","
        '            NextProcess7 = NextProcess7 + NP7 + ","
        '            NextProcess8 = NextProcess8 + NP8 + ","
        '            NextProcess9 = NextProcess9 + NP9 + ","
        '        Next

        '        RequiredDepartment = RequiredDepartment.Remove(RequiredDepartment.Length - 1)
        '        NextProcess1 = NextProcess1.Remove(NextProcess1.Length - 1)
        '        NextProcess2 = NextProcess2.Remove(NextProcess2.Length - 1)
        '        NextProcess3 = NextProcess3.Remove(NextProcess3.Length - 1)
        '        NextProcess4 = NextProcess4.Remove(NextProcess4.Length - 1)
        '        NextProcess5 = NextProcess5.Remove(NextProcess5.Length - 1)
        '        NextProcess6 = NextProcess6.Remove(NextProcess6.Length - 1)
        '        NextProcess7 = NextProcess7.Remove(NextProcess7.Length - 1)
        '        NextProcess8 = NextProcess8.Remove(NextProcess8.Length - 1)
        '        NextProcess9 = NextProcess9.Remove(NextProcess9.Length - 1)

        '        If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
        '        Else
        '            DepartmentInUpdate.DepartmentInUpdate(CaseID, RequiredDepartment, NextProcess1, NextProcess2, NextProcess3, NextProcess4, NextProcess5, NextProcess6, NextProcess7, NextProcess8, NextProcess9)
        '        End If
        '    Next
        '    Response.Redirect("DepartmentConfiguration.aspx")
        'Catch ex As Exception
        '    Response.Write("UpdatedError:" + ex.Message.ToString())
        'End Try
    End Sub

    Protected Sub CalCulate1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate1.Click, CalCulate2.Click
        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))

            'Checking The Case 
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                CI = CI + CaseID + ","
            End If

        Next
        If CI <> "" Then
            CI = CI.Remove(CI.Length - 1, 1)
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=DepartmentConfiguration.aspx")
        End If

    End Sub
End Class
