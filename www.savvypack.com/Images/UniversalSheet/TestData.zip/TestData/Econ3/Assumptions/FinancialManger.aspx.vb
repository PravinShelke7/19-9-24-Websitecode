Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math

Partial Class FincncialManager
    Inherits System.Web.UI.Page

    Public StrWhichForm As String = ""
    Public SavedName As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            lblrecord.Visible = False
            'Description Of Assumptions
            Dim oDBUtil As New DBUtil()
            Dim MyConnectionString As String
            Dim MyConnectionString1 As String
            MyConnectionString = System.Configuration.ConfigurationManager.AppSettings("Econ3ConnectionString")
            MyConnectionString1 = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
            Dim StrSqlDes As String = "Select DESCRIPTION from ASSUMPTIONS where ASSUMPTIONID = " + Session("AssumptionID").ToString() + " "
            Dim Dts As New DataTable()
            Dts = oDBUtil.FillDataTable(StrSqlDes, MyConnectionString)
            Session("Description") = Dts.Rows(0).Item("DESCRIPTION").ToString()
            StrWhichForm = Session("WhichForm")
            lblSavedComparison.Text = Session("Description")
            SavedName = Dts.Rows(0).Item("DESCRIPTION").ToString()
        Catch ex As Exception

        End Try
    End Sub

    'Protected Sub Save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Save.Click
    '    SaveButton.Visible = True
    '    CancleButton1.Visible = True
    '    SaveText.Visible = True
    'End Sub


    'Protected Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveButton.Click
    '    Dim Name As String
    '    Dim ID As String = 1
    '    Name = SaveText.Text
    '    Session("WhichForm") = "2"
    '    Dim UpadateFun As New Update()
    '    UpadateFun.AlterComparison(Name, ID, Session("AssumptionID"), Session("UserName"), Session("Password"))



    'End Sub


    'Protected Sub CancleButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancleButton1.Click
    '    SaveText.Visible = False
    '    'ReanameText.Visible = False
    '    SaveButton.Visible = False
    '    CancleButton1.Visible = False
    '    'CancleButton2.Visible = False
    '    'RenameButton.Visible = False
    'End Sub


End Class
