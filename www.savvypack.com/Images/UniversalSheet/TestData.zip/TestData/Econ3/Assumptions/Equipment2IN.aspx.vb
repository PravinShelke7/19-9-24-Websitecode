Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class SupportEquipment
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            lblAID.Text = Session("AssumptionID").ToString()
            lblAdes.Text = Session("Description")
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetSupportEquipmentSql(Cases, UserName, Password)
            Count = Dts.Rows.Count


            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='160px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)

            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)
            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                td4.Text = "Cost in:" + Dts.Rows(J).Item("Title4")
                'td4.Text = ""
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)


            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)



            Dim row As New Integer
            For row = 1 To 30

                'Break
                Dim tr5 As New TableRow
                Dim td7 As New TableCell
                td7.Text = "<b>Asset" + row.ToString + "</b>"
                tr5.CssClass = "Layer"
                tr5.Controls.Add(td7)
                Dim Break As New Integer
                For Break = 0 To Count - 1
                    Dim td8 As New TableCell
                    td8.Text = "&nbsp;"
                    tr5.Controls.Add(td8)
                Next
                tblComparision.Controls.Add(tr5)


                'Asset Des Feild
                Dim SER1 As New TableRow
                Dim SEC1 As New TableCell
                SER1.ID = "SE1_" + row.ToString()
                SER1.CssClass = "ColorTR"
                SEC1.Text = "Asset Description"
                SEC1.BorderWidth = 1
                SEC1.CssClass = "Displaynametd"
                SER1.Controls.Add(SEC1)
                Dim AssetComboFeild As New Integer
                For AssetComboFeild = 0 To Count - 1
                    Dim SEC2 As New TableCell
                    Dim EquipmentComo As New DropDownList
                    Dim EQC As String = "ASSETTYPE" + row.ToString()
                    Dim EQV As String = Dts.Rows(AssetComboFeild).Item(EQC).ToString()
                    Dim Equip As New Selectdata()
                    Dim WhichCombo As String = "EQUIPMENT2"
                    EquipmentComo = Equip.GetEquipmentCombo(WhichCombo)
                    EquipmentComo.SelectedValue = EQV
                    EquipmentComo.ID = "SEC" + row.ToString() + "_" + AssetComboFeild.ToString()

                    If Dts.Rows(AssetComboFeild).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        EquipmentComo.Enabled = False
                    Else
                        EquipmentComo.Enabled = True
                    End If

                    SEC2.Controls.Add(EquipmentComo)
                    EquipmentComo.CssClass = "dropdown"
                    SEC2.CssClass = "CaseTD"
                    SEC2.BorderWidth = 1
                    SER1.Controls.Add(SEC2)
                Next
                tblComparision.Controls.Add(SER1)



                'Asset Cost Suggested
                Dim SER2 As New TableRow
                Dim SEC3 As New TableCell
                SER2.ID = "SE2_" + row.ToString()
                SER2.CssClass = "ColorTR"
                SER2.Height = 22
                SEC3.Text = "Asset Cost Suggested"
                SEC3.BorderWidth = 1
                SEC3.CssClass = "Displaynametd"
                SER2.Controls.Add(SEC3)
                Dim AssetSuggested As New Integer
                For AssetSuggested = 0 To Count - 1
                    Dim SEC4 As New TableCell
                    Dim ASSSUG As String = "ASSESTSUGGESTED" + row.ToString()
                    Dim ASuggested As String = Dts.Rows(AssetSuggested).Item(ASSSUG).ToString()
                    SEC4.Text = FormatNumber(ASuggested.ToString, 0)
                    SEC4.Style.Add("text-align", "center")
                    SEC4.BorderWidth = 1
                    SER2.Controls.Add(SEC4)
                Next
                tblComparision.Controls.Add(SER2)


                'Asset Cost Preferred
                Dim SER3 As New TableRow
                Dim SEC5 As New TableCell
                SER3.ID = "SE3_" + row.ToString()
                SER3.CssClass = "ColorTR"
                SEC5.Text = "Asset Cost Preferred"
                SEC5.BorderWidth = 1
                SEC5.CssClass = "Displaynametd"
                SER3.Controls.Add(SEC5)
                Dim AssetPreferred As New Integer
                For AssetPreferred = 0 To Count - 1
                    Dim SEC6 As New TableCell
                    Dim AssetPrefTextbox As New TextBox
                    Dim ASSPREF As String = "ASSESTPREFERRED" + row.ToString()
                    Dim APreferred As String = Dts.Rows(AssetPreferred).Item(ASSPREF).ToString()
                    AssetPrefTextbox.Text = FormatNumber(APreferred.ToString, 0)
                    AssetPrefTextbox.ID = "SEP" + row.ToString() + "_" + AssetPreferred.ToString()
                    AssetPrefTextbox.CssClass = "textBox"

                    If Dts.Rows(AssetPreferred).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        AssetPrefTextbox.Enabled = False
                    Else
                        AssetPrefTextbox.Enabled = True
                    End If

                    SEC6.Controls.Add(AssetPrefTextbox)
                    SEC6.CssClass = "CaseTD"
                    SEC6.BorderWidth = 1
                    SER3.Controls.Add(SEC6)
                Next
                tblComparision.Controls.Add(SER3)


                'Mfg Dept Combo
                Dim SER4 As New TableRow
                Dim SEC7 As New TableCell
                SER4.ID = "SE4_" + row.ToString()
                SER4.CssClass = "ColorTR"
                SEC7.Text = "Manufacturing Process<br/> or Department"
                SEC7.CssClass = "Displaynametd"
                SEC7.BorderWidth = 1
                SER4.Controls.Add(SEC7)
                Dim MfgDept As New Integer
                For MfgDept = 0 To Count - 1
                    Dim SEC8 As New TableCell
                    Dim DeptCombo As New DropDownList
                    Dim DP2 As String = "DEPT" + row.ToString()
                    Dim GetDept As New RepeatedControls()
                    DeptCombo = GetDept.DeptDropdown()
                    DeptCombo.SelectedValue = Dts.Rows(MfgDept).Item(DP2).ToString()
                    DeptCombo.CssClass = "dropdown"
                    DeptCombo.ID = "Dep" + row.ToString() + "_" + MfgDept.ToString()

                    If Dts.Rows(MfgDept).Item("CaseID").ToString <= 1000 And Session("Password") <> "9krh65sve3" Then
                        DeptCombo.Enabled = False
                    Else
                        DeptCombo.Enabled = True
                    End If

                    SEC8.Controls.Add(DeptCombo)
                    SEC8.BorderWidth = 1
                    SEC8.CssClass = "CaseTD"
                    SER4.Controls.Add(SEC8)
                Next
                tblComparision.Controls.Add(SER4)



            Next


        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Update.Click, Update2.Click
        Try
            'declaring variables

            Dim I As New Integer
            Dim J As New Integer

            Dim SupportUpdate As New Update()

            'loop and array dclaration  

            For I = 1 To Count - 1

                Dim AssDes(30) As String
                Dim AssCostPre(30) As String
                Dim ManDept(30) As String

                Dim CaseID As String = ""

                'passing a id to form

                For J = 1 To 30
                    AssDes(J) = Request.Form("ctl00$ContentPlaceHolder1$SEC" + J.ToString() + "_" + I.ToString())
                    AssCostPre(J) = Request.Form("ctl00$ContentPlaceHolder1$SEP" + J.ToString() + "_" + I.ToString())
                    ManDept(J) = Request.Form("ctl00$ContentPlaceHolder1$Dep" + J.ToString() + "_" + I.ToString())
                    CaseID = Request.Form("Case" + I.ToString())
                Next
                'checking case id 

                If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
                Else
                    SupportUpdate.SupportUpdate(CaseID, AssDes, AssCostPre, ManDept)
                End If
            Next

            Response.Redirect("Equipment2IN.aspx")

        Catch ex As Exception
            Response.Write("SupportUpDateErro:-" + ex.Message.ToString())
        End Try

    End Sub

    Protected Sub CalCulate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CalCulate.Click, CalCulate2.Click
        Dim CaseID As String = ""
        Dim I As New Integer
        Dim C As String
        Dim CI As String = ""
        For I = 0 To Count - 1
            C = "Case" + I.ToString()
            CaseID = Trim(Request.Form(C))

            'Checking The Case 
            If CaseID <= 1000 And Session("Password") <> "9krh65sve3" Then
            Else
                CI = CI + CaseID + ","
            End If

        Next
        If CI <> "" Then
            CI = CI.Remove(CI.Length - 1, 1)
            Response.Redirect("SubCalCulate1.asp?ID=" + CI + "&Path=Equipment2IN.aspx")
        End If

    End Sub
End Class
