Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class ROI
    Inherits System.Web.UI.Page

    Dim Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Cases As String = ""
    Dim Title4 As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Dim Status As String = ""
            Assid = Session("AssumptionID").ToString()
            Dim GetCaseStatus As New Selectdata()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()

            'Geting Cases
            Dim GetCaseIDs As New Selectdata()
            Cases = GetCaseIDs.Cases(Assid)

            'Getting Main Datatable
            Dim Roi As New Selectdata()
            Dim Dts As New DataTable()
            Dts = Roi.GetROISql(Cases, UserName, Password)

            'lblAID.Text = "Case:" + Dts.Rows(0).Item("CASEID").ToString() + "<font style='color:black'> vs</font> Case:" + Dts.Rows(1).Item("CASEID").ToString()
            'lblAdes.Text = Dts.Rows(0).Item("CASEDES").ToString() + " vs " + Dts.Rows(1).Item("CASEDES").ToString()


            If IsPostBack = False Then
                casedd.DataSource = Dts
                casedd.DataValueField = "CASEID"
                casedd.DataTextField = "DES"
                casedd.DataBind()
            End If






        Catch ex As Exception

        End Try

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try


            Dim CostValue As String = cost.Text
            Dim YearValue As String = year.Text

            If CostValue <> "" And YearValue <> "" Then
                lblnull.Visible = False
                If CostValue <> 0 And YearValue <> 0 Then
                    lblnull.Visible = False

                    tblroi.Visible = True

                    Dim SelctedCase As String = ""
                    SelctedCase = casedd.SelectedValue.ToString()



                    Dim CostofCapital As String = CostValue / 100


                    'Getting Main Datatable
                    Dim Roi As New Selectdata()
                    Dim Dts As New DataTable()
                    Dim Dt As New DataTable()
                    Dts = Roi.GetROI(SelctedCase, Cases, UserName, Password, CostofCapital, YearValue)
                    Dt = Roi.GetROISql(Cases, UserName, Password)
                    Dim Count As String = Dts.Rows.Count
                    Dim CaseDesp As New ArrayList

                    'Headded Part
                    Dim tr1 As New TableRow
                    Dim td1 As New TableCell
                    tr1.ID = "Header1"
                    td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='100px'height='0px'  />"
                    td1.CssClass = "LeftHeading"
                    tr1.CssClass = "HeaderTR"
                    td1.BorderWidth = 1
                    tr1.Controls.Add(td1)
                    Dim td2 As New TableCell
                    td2.CssClass = "CaseTD"
                    td2.BackColor = Drawing.Color.DarkCyan
                    td2.Text = "CaseID:" + Dts.Rows(0).Item("caseID").ToString() + "<br/>" + Dts.Rows(0).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(0).Item("caseID").ToString() + "' name='Case0""'/>" + "<br /><img alt='' src='../../Images/spacer.gif' width='200px'height='0px'  />"
                    td2.BorderWidth = 1
                    tr1.Controls.Add(td2)
                    Dim I As New Integer
                    For I = 1 To Count - 1
                        Dim td3 As New TableCell
                        td3.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>" + "<br /><img alt='' src='../../Images/spacer.gif' width='200px'height='0px'  />"
                        CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                        td3.CssClass = "CaseTD"
                        td3.BorderWidth = 1
                        tr1.Controls.Add(td3)
                    Next
                    tblroi.Controls.Add(tr1)



                    Dim tr3 As New TableRow
                    Dim td7 As New TableCell
                    Dim td9 As New TableCell
                    tr3.ID = "Header2"
                    td7.Text = "Unit"
                    td7.CssClass = "LeftHeading"
                    tr3.CssClass = "HeaderTR"
                    td7.BorderWidth = 1
                    td9.Text = "<b>Currency:" + Dt.Rows(0).Item("Title4").ToString() + "</b>"
                    td9.BorderWidth = 1
                    td9.BackColor = Drawing.Color.DarkCyan
                    tr3.Controls.Add(td7)
                    tr3.Controls.Add(td9)
                    Dim Unit As New Integer
                    For Unit = 1 To Count - 1
                        Dim td8 As New TableCell
                        td8.Text = "Currency:" + Dt.Rows(Unit).Item("Title4").ToString()
                        td8.CssClass = "Unitd"
                        td8.BorderWidth = 1
                        tr3.Controls.Add(td8)
                    Next
                    tblroi.Controls.Add(tr3)

                    Dim tr2 As New TableRow
                    Dim td4 As New TableCell
                    tr2.ID = "Header3"
                    td4.Text = "CaseType"
                    td4.CssClass = "LeftHeading"
                    tr2.CssClass = "HeaderTR"
                    td4.BorderWidth = 1
                    tr2.Controls.Add(td4)
                    Dim td5 As New TableCell
                    If Dts.Rows(0).Item("CaseID").ToString < 1000 Then
                        td5.Text = "Base Case"
                    Else

                        td5.Text = "Proprietary Case"
                    End If
                    td5.CssClass = "CaseTD"
                    td5.BackColor = Drawing.Color.DarkCyan
                    td5.BorderWidth = 1
                    tr2.Controls.Add(td5)

                    Dim k As New Integer
                    For k = 1 To Count - 1
                        Dim td6 As New TableCell
                        If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                            td6.Text = "Base Case"
                        Else

                            td6.Text = "Proprietary Case"
                        End If
                        td6.CssClass = "CaseTD"
                        td6.BorderWidth = 1
                        tr2.Controls.Add(td6)
                    Next
                    tblroi.Controls.Add(tr2)






                    Dim ROR1 As New TableRow
                    Dim ROC1 As New TableCell
                    Dim ROC2 As New TableCell
                    ROR1.ID = "RO1_1"
                    ROR1.CssClass = "ColorTR"
                    ROR1.Height = 25
                    ROC1.Text = "Plant margin"
                    ROC1.BorderWidth = 1
                    ROC1.CssClass = "Displaynametd"
                    ROR1.Controls.Add(ROC1)
                    ROC2.Text = FormatNumber(Dts.Rows(0).Item("PLANTMARGIN").ToString(), 2)
                    ROC2.Style.Add("text-align", "right")
                    ROC2.BorderWidth = 1
                    ROR1.Controls.Add(ROC2)
                    Dim pm As New Integer
                    For pm = 1 To Count - 1
                        Dim ROC3 As New TableCell
                        ROC3.Text = FormatNumber(Dts.Rows(pm).Item("PLANTMARGIN").ToString(), 2)
                        ROC3.Style.Add("text-align", "right")
                        ROC3.BorderWidth = 1
                        ROR1.Controls.Add(ROC3)
                    Next
                    tblroi.Controls.Add(ROR1)


                    Dim ROR2 As New TableRow
                    Dim ROC4 As New TableCell
                    Dim ROC5 As New TableCell
                    ROR2.ID = "RO1_1"
                    ROR2.CssClass = "ColorTR"
                    ROR2.Height = 25
                    ROC4.Text = "Incremental plant margin"
                    ROC4.BorderWidth = 1
                    ROC4.CssClass = "Displaynametd"
                    ROR2.Controls.Add(ROC4)
                    ROC5.Text = Dts.Rows(0).Item("GAINFROMINVESTMENT").ToString()
                    ROC5.Style.Add("text-align", "right")
                    ROC5.BorderWidth = 1
                    ROR2.Controls.Add(ROC5)
                    Dim goi As New Integer
                    For goi = 1 To Count - 1
                        Dim ROC6 As New TableCell
                        ROC6.Text = FormatNumber(Dts.Rows(goi).Item("GAINFROMINVESTMENT").ToString(), 2)
                        ROC6.Style.Add("text-align", "right")
                        ROC6.BorderWidth = 1
                        ROR2.Controls.Add(ROC6)
                    Next
                    tblroi.Controls.Add(ROR2)

                    Dim ROR3 As New TableRow
                    Dim ROC7 As New TableCell
                    Dim ROC8 As New TableCell
                    ROR3.ID = "RO1_1"
                    ROR3.CssClass = "ColorTR"
                    ROR3.Height = 25
                    ROC7.Text = "Net present value of plant margin"
                    ROC7.BorderWidth = 1
                    ROC7.CssClass = "Displaynametd"
                    ROR3.Controls.Add(ROC7)
                    ROC8.Text = Dts.Rows(0).Item("NPV").ToString()
                    ROC8.Style.Add("text-align", "right")
                    ROC8.BorderWidth = 1
                    ROR3.Controls.Add(ROC8)
                    Dim npv As New Integer
                    For npv = 1 To Count - 1
                        Dim ROC9 As New TableCell
                        ROC9.Text = FormatNumber(Dts.Rows(npv).Item("NPV").ToString(), 2)
                        ROC9.Style.Add("text-align", "right")
                        ROC9.BorderWidth = 1
                        ROR3.Controls.Add(ROC9)
                    Next
                    tblroi.Controls.Add(ROR3)


                    Dim ROR5 As New TableRow
                    Dim ROC13 As New TableCell
                    Dim ROC14 As New TableCell
                    ROR5.ID = "RO1_1"
                    ROR5.CssClass = "ColorTR"
                    ROR5.Height = 25
                    ROC13.Text = "Total Investment"
                    ROC13.BorderWidth = 1
                    ROC13.CssClass = "Displaynametd"
                    ROR5.Controls.Add(ROC13)
                    ROC14.Text = FormatNumber(Dts.Rows(0).Item("TOTALINVESTMENT").ToString(), 0)
                    ROC14.Style.Add("text-align", "right")
                    ROC14.BorderWidth = 1
                    ROR5.Controls.Add(ROC14)
                    Dim npi As New Integer
                    For npi = 1 To Count - 1
                        Dim ROC15 As New TableCell
                        ROC15.Text = FormatNumber(Dts.Rows(npi).Item("TOTALINVESTMENT").ToString(), 0)
                        ROC15.Style.Add("text-align", "right")
                        ROC15.BorderWidth = 1
                        ROR5.Controls.Add(ROC15)
                    Next
                    tblroi.Controls.Add(ROR5)



                    Dim ROR6 As New TableRow
                    Dim ROC16 As New TableCell
                    Dim ROC17 As New TableCell
                    ROR6.ID = "RO1_1"
                    ROR6.CssClass = "ColorTR"
                    ROR6.Height = 25
                    ROC16.Text = "Incremental Investment"
                    ROC16.BorderWidth = 1
                    ROC16.CssClass = "Displaynametd"
                    ROR6.Controls.Add(ROC16)
                    ROC17.Text = Dts.Rows(0).Item("COSTOFINVESTMENT").ToString()
                    ROC17.Style.Add("text-align", "right")
                    ROC17.BorderWidth = 1
                    ROR6.Controls.Add(ROC17)
                    Dim Incremental As New Integer
                    For Incremental = 1 To Count - 1
                        Dim ROC18 As New TableCell
                        ROC18.Text = FormatNumber(Dts.Rows(Incremental).Item("COSTOFINVESTMENT").ToString(), 0)
                        ROC18.Style.Add("text-align", "right")
                        ROC18.BorderWidth = 1
                        ROR6.Controls.Add(ROC18)
                    Next
                    tblroi.Controls.Add(ROR6)



                    Dim ROR4 As New TableRow
                    Dim ROC10 As New TableCell
                    Dim ROC11 As New TableCell
                    ROR4.ID = "RO1_1"
                    ROR4.CssClass = "ColorTR"
                    ROR4.Height = 25
                    ROC10.Text = "Return On Investment"
                    ROC10.BorderWidth = 1
                    ROC10.CssClass = "Displaynametd"
                    ROR4.Controls.Add(ROC10)
                    ROC11.Text = Dts.Rows(0).Item("NPV").ToString()
                    ROC11.Style.Add("text-align", "right")
                    ROC11.BorderWidth = 1
                    ROR4.Controls.Add(ROC11)
                    Dim roie As New Integer
                    For roie = 1 To Count - 1
                        Dim ROC12 As New TableCell
                        ROC12.Text = FormatNumber(Dts.Rows(roie).Item("ROI").ToString(), 2) + " %"
                        ROC12.Style.Add("text-align", "right")
                        ROC12.BorderWidth = 1
                        ROR4.Controls.Add(ROC12)
                    Next
                    tblroi.Controls.Add(ROR4)
                Else
                    lbl.Text = "The Cost of Capital and Year are can't be zero <br/>please eneter the non-zero values "
                    lblnull.Visible = True
                End If
            Else
                lbl.Text = "The Cost of Capital and Year are can't be NULL <br/> please enter the non-zero values "
                lblnull.Visible = True

            End If

        Catch ex As Exception

        End Try



    End Sub
End Class


