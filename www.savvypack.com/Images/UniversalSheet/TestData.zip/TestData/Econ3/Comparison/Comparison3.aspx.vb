Imports System.Data
Imports System.Data.OleDb
Imports System
Imports UpdateData
Imports SelectQuery
Imports System.Collections
Imports System.Math
Partial Class Comp3
    Inherits System.Web.UI.Page
    Public Assid As String = ""
    Public UserName As String = ""
    Public Password As String = ""
    Public Count As Integer
    Public CaseDesp As New ArrayList


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try


            lblAID.Text = Session("AssumptionID").ToString()
            Dim GetDes As New Selectdata()
            lblAdes.Text = GetDes.GetDescription(Session("AssumptionID"))
            Assid = Session("AssumptionID").ToString()
            UserName = Session("UserName").ToString()
            Password = Session("Password").ToString()


            'Getting Number Of Cases from 
            Dim GetCaseIDs As New Selectdata()
            Dim Cases As String = ""
            Cases = GetCaseIDs.Cases(Assid)


            'Getting the Datable
            Dim GetQuery As New Selectdata()
            Dim Dts As New DataTable()
            Dts = GetQuery.GetComparison3Sql(Cases, UserName, Password)
            Count = Dts.Rows.Count


            'Headded Part
            Dim tr1 As New TableRow
            Dim td1 As New TableCell
            tr1.ID = "Header1"
            td1.Text = "Type" + "<br/>" + "<img alt='' src='../../Images/spacer.gif' width='140px'height='0px'  />"
            td1.CssClass = "LeftHeading"
            tr1.CssClass = "HeaderTR"
            td1.BorderWidth = 1
            tr1.Controls.Add(td1)

            Dim I As New Integer
            For I = 0 To Count - 1
                Dim td2 As New TableCell
                td2.Text = "CaseID:" + Dts.Rows(I).Item("caseID").ToString() + "<br/>" + Dts.Rows(I).Item("CASEDES").ToString() + "<br/>" + "<input type='hidden' value='" + Dts.Rows(I).Item("caseID").ToString() + "' name='Case" + I.ToString() + "'/>"
                CaseDesp.Add(Dts.Rows(I).Item("caseID").ToString())
                td2.CssClass = "CaseTD"
                td2.BorderWidth = 1
                tr1.Controls.Add(td2)
            Next
            tblComparision.Controls.Add(tr1)


            Dim tr2 As New TableRow
            Dim td3 As New TableCell
            tr2.ID = "Header2"
            td3.Text = "Unit"
            td3.CssClass = "LeftHeading"
            tr2.CssClass = "HeaderTR"
            td3.BorderWidth = 1
            tr2.Controls.Add(td3)
            Dim J As New Integer
            For J = 0 To Count - 1
                Dim td4 As New TableCell
                td4.Text = "Cost: " + Dts.Rows(J).Item("TITLE6").ToString() + "/unit" + "<br><img alt='' src='../../Images/spacer.gif' width='300px'height='0px'  />"
                td4.CssClass = "Unitd"
                td4.BorderWidth = 1
                tr2.Controls.Add(td4)
            Next
            tblComparision.Controls.Add(tr2)


            Dim tr3 As New TableRow
            Dim td5 As New TableCell
            tr3.ID = "Header3"
            td5.Text = "CaseType"
            td5.CssClass = "LeftHeading"
            tr3.CssClass = "HeaderTR"
            td5.BorderWidth = 1
            tr3.Controls.Add(td5)

            Dim k As New Integer
            For k = 0 To Count - 1
                Dim td6 As New TableCell
                If Dts.Rows(k).Item("CaseID").ToString < 1000 Then
                    td6.Text = "Base Case"
                Else

                    td6.Text = "Proprietary Case"
                End If
                td6.CssClass = "CaseTD"
                td6.BorderWidth = 1
                tr3.Controls.Add(td6)
            Next
            tblComparision.Controls.Add(tr3)

            Dim CMR1 As New TableRow
            Dim CMC1 As New TableCell
            CMR1.ID = "CM1_1"
            CMR1.CssClass = "ColorTR"
            CMC1.Text = "Sales Volume In Weight"
            CMC1.BorderWidth = 1
            CMC1.CssClass = "Displaynametd"
            CMR1.Controls.Add(CMC1)
            Dim SV1 As New Integer
            For SV1 = 0 To Count - 1
                Dim CMC2 As New TableCell
                Dim Unit As String = Dts.Rows(SV1).Item("UNITS").ToString()
                If Unit = 0 Then
                    CMC2.Text = "<b>Sales Volume(lb)</b><br>" + FormatNumber(Dts.Rows(SV1).Item("SALESVOLUME1").ToString(), 0)
                Else
                    CMC2.Text = "<b>Sales Volume(kg)</b><br>" + FormatNumber(Dts.Rows(SV1).Item("SALESVOLUME1").ToString(), 0)
                End If
                CMC2.Style.Add("text-align", "center")
                CMC2.BorderWidth = 1
                CMR1.Controls.Add(CMC2)
            Next
            tblComparision.Controls.Add(CMR1)



            Dim CMR2 As New TableRow
            Dim CMC3 As New TableCell
            CMR2.ID = "CM2_1"
            CMR2.CssClass = "ColorTR"
            CMC3.Text = "Sales Volume In Unit"
            CMC3.BorderWidth = 1
            CMC3.CssClass = "Displaynametd"
            CMR2.Controls.Add(CMC3)
            Dim SV2 As New Integer
            For SV2 = 0 To Count - 1
                Dim CMC4 As New TableCell
                Dim Unit1 As String = Dts.Rows(SV2).Item("UNITS").ToString()
                Dim Status As String = Dts.Rows(SV2).Item("STATUS").ToString()
                If Status = 1 Then
                    If Unit1 = 0 Then
                        CMC4.Text = "<b>Sales Volume(msi)</b><br>" + FormatNumber(Dts.Rows(SV2).Item("SALESVOLUME2").ToString(), 0)
                    Else
                        CMC4.Text = "<b>Sales Volume(m2)</b><br>" + FormatNumber(Dts.Rows(SV2).Item("SALESVOLUME2").ToString(), 0)
                    End If
                Else
                    CMC4.Text = "<b>Sales Volume(units)</b><br>" + FormatNumber(Dts.Rows(SV2).Item("SALESVOLUME2").ToString(), 0)
                End If

                CMC4.Style.Add("text-align", "center")
                CMC4.BorderWidth = 1
                CMR2.Controls.Add(CMC4)
            Next
            tblComparision.Controls.Add(CMR2)



            'Revenue
            Dim CMR3 As New TableRow
            Dim CMC5 As New TableCell
            CMR3.ID = "CM3_1"
            CMR3.CssClass = "ColorTR"
            CMR3.Height = 25
            CMC5.Text = "Revenue"
            CMC5.BorderWidth = 1
            CMC5.CssClass = "Displaynametd"
            CMR3.Controls.Add(CMC5)
            Dim revenue As New Integer
            For revenue = 0 To Count - 1
                Dim CMC6 As New TableCell
                CMC6.Text = FormatNumber(Dts.Rows(revenue).Item("UNITREVENUE").ToString(), 3)
                CMC6.Width = 185
                CMC6.Style.Add("text-align", "right")
                CMC6.BorderWidth = 1
                CMR3.Controls.Add(CMC6)
            Next
            tblComparision.Controls.Add(CMR3)


            'Material
            Dim CMR4 As New TableRow
            Dim CMC7 As New TableCell
            CMR4.ID = "CM4_1"
            CMR4.CssClass = "ColorTR"
            CMR4.Height = 25
            CMC7.Text = "Material"
            CMC7.BorderWidth = 1
            CMC7.CssClass = "Displaynametd"
            CMR4.Controls.Add(CMC7)
            Dim material As New Integer
            For material = 0 To Count - 1
                Dim CMC8 As New TableCell
                CMC8.Text = FormatNumber(Dts.Rows(material).Item("UNITMATERIAL").ToString(), 3)
                CMC8.Width = 185
                CMC8.Style.Add("text-align", "right")
                CMC8.BorderWidth = 1
                CMR4.Controls.Add(CMC8)
            Next
            tblComparision.Controls.Add(CMR4)


            'Labor
            Dim CMR5 As New TableRow
            Dim CMC9 As New TableCell
            CMR5.ID = "CM5_1"
            CMR5.CssClass = "ColorTR"
            CMR5.Height = 25
            CMC9.Text = "Labor"
            CMC9.BorderWidth = 1
            CMC9.CssClass = "Displaynametd"
            CMR5.Controls.Add(CMC9)
            Dim Labor As New Integer
            For Labor = 0 To Count - 1
                Dim CMC10 As New TableCell
                CMC10.Text = FormatNumber(Dts.Rows(Labor).Item("UNITVLABOR").ToString(), 3)
                CMC10.Width = 185
                CMC10.Style.Add("text-align", "right")
                CMC10.BorderWidth = 1
                CMR5.Controls.Add(CMC10)
            Next
            tblComparision.Controls.Add(CMR5)

            'Energy
            Dim CMR6 As New TableRow
            Dim CMC11 As New TableCell
            CMR6.ID = "CM6_1"
            CMR6.CssClass = "ColorTR"
            CMR6.Height = 25
            CMC11.Text = "Energy"
            CMC11.BorderWidth = 1
            CMC11.CssClass = "Displaynametd"
            CMR6.Controls.Add(CMC11)
            Dim Energy As New Integer
            For Energy = 0 To Count - 1
                Dim CMC12 As New TableCell
                CMC12.Text = FormatNumber(Dts.Rows(Energy).Item("UNITVENERGY").ToString(), 3)
                CMC12.Width = 185
                CMC12.Style.Add("text-align", "right")
                CMC12.BorderWidth = 1
                CMR6.Controls.Add(CMC12)
            Next
            tblComparision.Controls.Add(CMR6)

            'Distribution Packaging
            Dim CMR7 As New TableRow
            Dim CMC13 As New TableCell
            CMR7.ID = "CM7_1"
            CMR7.CssClass = "ColorTR"
            CMR7.Height = 25
            CMC13.Text = "Distribution Packaging"
            CMC13.BorderWidth = 1
            CMC13.CssClass = "Displaynametd"
            CMR7.Controls.Add(CMC13)
            Dim Distribution As New Integer
            For Distribution = 0 To Count - 1
                Dim CMC14 As New TableCell
                CMC14.Text = FormatNumber(Dts.Rows(Distribution).Item("UNITDISTRIBUTIONPACK").ToString(), 3)
                CMC14.Width = 185
                CMC14.Style.Add("text-align", "right")
                CMC14.BorderWidth = 1
                CMR7.Controls.Add(CMC14)
            Next
            tblComparision.Controls.Add(CMR7)


            'Shipping to Customer
            Dim CMR8 As New TableRow
            Dim CMC15 As New TableCell
            CMR8.ID = "CM8_1"
            CMR8.CssClass = "ColorTR"
            CMR8.Height = 25
            CMC15.Text = "Shipping to Customer"
            CMC15.BorderWidth = 1
            CMC15.CssClass = "Displaynametd"
            CMR8.Controls.Add(CMC15)
            Dim Shipping As New Integer
            For Shipping = 0 To Count - 1
                Dim CMC16 As New TableCell
                CMC16.Text = FormatNumber(Dts.Rows(Shipping).Item("UNITSHIPPING").ToString(), 3)
                CMC16.Width = 185
                CMC16.Style.Add("text-align", "right")
                CMC16.BorderWidth = 1
                CMR8.Controls.Add(CMC16)
            Next
            tblComparision.Controls.Add(CMR8)


            'Variable Margin 
            Dim CMR9 As New TableRow
            Dim CMC17 As New TableCell
            CMR9.ID = "CM9_1"
            CMR9.CssClass = "ColorTR"
            CMR9.Height = 25
            CMC17.Text = "Variable Margin"
            CMC17.BorderWidth = 1
            CMC17.CssClass = "Displaynametd"
            CMR9.Controls.Add(CMC17)
            Dim Variable As New Integer
            For Variable = 0 To Count - 1
                Dim CMC18 As New TableCell
                CMC18.Text = FormatNumber(Dts.Rows(Variable).Item("UNITVARIABLEMARGIN").ToString(), 3)
                CMC18.Width = 185
                CMC18.Style.Add("text-align", "right")
                CMC18.BorderWidth = 1
                CMR9.Controls.Add(CMC18)
            Next
            tblComparision.Controls.Add(CMR9)


            'Office Supplies
            Dim CMR10 As New TableRow
            Dim CMC19 As New TableCell
            CMR10.ID = "CM10_1"
            CMR10.CssClass = "ColorTR"
            CMR10.Height = 25
            CMC19.Text = "Office Supplies"
            CMC19.BorderWidth = 1
            CMC19.CssClass = "Displaynametd"
            CMR10.Controls.Add(CMC19)
            Dim Office As New Integer
            For Office = 0 To Count - 1
                Dim CMC20 As New TableCell
                CMC20.Text = FormatNumber(Dts.Rows(Office).Item("UNITOFFICESUPP").ToString(), 3)
                CMC20.Width = 185
                CMC20.Style.Add("text-align", "right")
                CMC20.BorderWidth = 1
                CMR10.Controls.Add(CMC20)
            Next
            tblComparision.Controls.Add(CMR10)


            'LaborP
            Dim CMR11 As New TableRow
            Dim CMC21 As New TableCell
            CMR11.ID = "CM11_1"
            CMR11.CssClass = "ColorTR"
            CMR11.Height = 25
            CMC21.Text = "Labor"
            CMC21.BorderWidth = 1
            CMC21.CssClass = "Displaynametd"
            CMR11.Controls.Add(CMC21)
            Dim LaborP As New Integer
            For LaborP = 0 To Count - 1
                Dim CMC22 As New TableCell
                Dim PctLaborP As New Table
                CMC22.Text = FormatNumber(Dts.Rows(LaborP).Item("UNITPLABOR").ToString(), 3)
                CMC22.Width = 185
                CMC22.Style.Add("text-align", "right")
                CMC22.BorderWidth = 1
                CMR11.Controls.Add(CMC22)
            Next
            tblComparision.Controls.Add(CMR11)


            'EnergyP
            Dim CMR12 As New TableRow
            Dim CMC23 As New TableCell
            CMR12.ID = "CM12_1"
            CMR12.CssClass = "ColorTR"
            CMR12.Height = 25
            CMC23.Text = "Energy"
            CMC23.BorderWidth = 1
            CMC23.CssClass = "Displaynametd"
            CMR12.Controls.Add(CMC23)
            Dim EnergyP As New Integer
            For EnergyP = 0 To Count - 1
                Dim CMC24 As New TableCell
                CMC24.Text = FormatNumber(Dts.Rows(EnergyP).Item("UNITPENERGY").ToString(), 3)
                CMC24.Width = 185
                CMC24.Style.Add("text-align", "right")
                CMC24.BorderWidth = 1
                CMR12.Controls.Add(CMC24)
            Next
            tblComparision.Controls.Add(CMR12)


            'Lease cost
            Dim CMR13 As New TableRow
            Dim CMC25 As New TableCell
            CMR13.ID = "CM13_1"
            CMR13.CssClass = "ColorTR"
            CMR13.Height = 25
            CMC25.Text = "Lease cost"
            CMC25.BorderWidth = 1
            CMC25.CssClass = "Displaynametd"
            CMR13.Controls.Add(CMC25)
            Dim Lease As New Integer
            For Lease = 0 To Count - 1
                Dim CMC26 As New TableCell
                CMC26.Text = FormatNumber(Dts.Rows(Lease).Item("UNITLEASECOST").ToString(), 3)
                CMC26.Width = 185
                CMC26.Style.Add("text-align", "right")
                CMC26.BorderWidth = 1
                CMR13.Controls.Add(CMC26)
            Next
            tblComparision.Controls.Add(CMR13)

            'Insurance
            Dim CMR14 As New TableRow
            Dim CMC27 As New TableCell
            CMR14.ID = "CM14_1"
            CMR14.CssClass = "ColorTR"
            CMR14.Height = 25
            CMC27.Text = "Insurance"
            CMC27.BorderWidth = 1
            CMC27.CssClass = "Displaynametd"
            CMR14.Controls.Add(CMC27)
            Dim Insurance As New Integer
            For Insurance = 0 To Count - 1
                Dim CMC28 As New TableCell
                CMC28.Text = FormatNumber(Dts.Rows(Insurance).Item("UNITINSURANCE").ToString(), 3)
                CMC28.Width = 185
                CMC28.Style.Add("text-align", "right")
                CMC28.BorderWidth = 1
                CMR14.Controls.Add(CMC28)
            Next
            tblComparision.Controls.Add(CMR14)

            'Utilities
            Dim CMR15 As New TableRow
            Dim CMC29 As New TableCell
            CMR15.ID = "CM15_1"
            CMR15.CssClass = "ColorTR"
            CMR15.Height = 25
            CMC29.Text = "Utilities"
            CMC29.BorderWidth = 1
            CMC29.CssClass = "Displaynametd"
            CMR15.Controls.Add(CMC29)
            Dim Utilities As New Integer
            For Utilities = 0 To Count - 1
                Dim CMC30 As New TableCell
                CMC30.Text = FormatNumber(Dts.Rows(Utilities).Item("UNITUTILITIES").ToString(), 3)
                CMC30.Width = 185
                CMC30.Style.Add("text-align", "right")
                CMC30.BorderWidth = 1
                CMR15.Controls.Add(CMC30)
            Next
            tblComparision.Controls.Add(CMR15)


            'Communications
            Dim CMR16 As New TableRow
            Dim CMC31 As New TableCell
            CMR16.ID = "CM16_1"
            CMR16.CssClass = "ColorTR"
            CMR16.Height = 25
            CMC31.Text = "Communications"
            CMC31.BorderWidth = 1
            CMC31.CssClass = "Displaynametd"
            CMR16.Controls.Add(CMC31)
            Dim Communications As New Integer
            For Communications = 0 To Count - 1
                Dim CMC32 As New TableCell
                CMC32.Text = FormatNumber(Dts.Rows(Communications).Item("UNITCOMMUNICATIONS").ToString(), 3)
                CMC32.Width = 185
                CMC32.Style.Add("text-align", "right")
                CMC32.BorderWidth = 1
                CMR16.Controls.Add(CMC32)
            Next
            tblComparision.Controls.Add(CMR16)


            'Travel
            Dim CMR17 As New TableRow
            Dim CMC33 As New TableCell
            CMR17.ID = "CM17_1"
            CMR17.CssClass = "ColorTR"
            CMR17.Height = 25
            CMC33.Text = "Travel"
            CMC33.BorderWidth = 1
            CMC33.CssClass = "Displaynametd"
            CMR17.Controls.Add(CMC33)
            Dim Travel As New Integer
            For Travel = 0 To Count - 1
                Dim CMC34 As New TableCell
                CMC34.Text = FormatNumber(Dts.Rows(Travel).Item("UNITTRAVEL").ToString(), 3)
                CMC34.Width = 185
                CMC34.Style.Add("text-align", "right")
                CMC34.BorderWidth = 1
                CMR17.Controls.Add(CMC34)
            Next
            tblComparision.Controls.Add(CMR17)


            'Maintenance supplies
            Dim CMR18 As New TableRow
            Dim CMC35 As New TableCell
            CMR18.ID = "CM18_1"
            CMR18.CssClass = "ColorTR"
            CMR18.Height = 25
            CMC35.Text = "Maintenance supplies"
            CMC35.BorderWidth = 1
            CMC35.CssClass = "Displaynametd"
            CMR18.Controls.Add(CMC35)
            Dim Maintenance As New Integer
            For Maintenance = 0 To Count - 1
                Dim CMC36 As New TableCell
                CMC36.Text = FormatNumber(Dts.Rows(Maintenance).Item("UNITMAINTENANCESUPP").ToString(), 3)
                CMC36.Width = 185
                CMC36.Style.Add("text-align", "right")
                CMC36.BorderWidth = 1
                CMR18.Controls.Add(CMC36)
            Next
            tblComparision.Controls.Add(CMR18)


            'Minor equipment
            Dim CMR19 As New TableRow
            Dim CMC37 As New TableCell
            CMR19.ID = "CM19_1"
            CMR19.CssClass = "ColorTR"
            CMR19.Height = 25
            CMC37.Text = "Minor equipment"
            CMC37.BorderWidth = 1
            CMC37.CssClass = "Displaynametd"
            CMR19.Controls.Add(CMC37)
            Dim Minor As New Integer
            For Minor = 0 To Count - 1
                Dim CMC38 As New TableCell
                CMC38.Text = FormatNumber(Dts.Rows(Minor).Item("UNITMINOREQUIP").ToString(), 3)
                CMC38.Width = 185
                CMC38.Style.Add("text-align", "right")
                CMC38.BorderWidth = 1
                CMR19.Controls.Add(CMC38)
            Next
            tblComparision.Controls.Add(CMR19)


            'Outside services
            Dim CMR20 As New TableRow
            Dim CMC39 As New TableCell
            CMR20.ID = "CM20_1"
            CMR20.CssClass = "ColorTR"
            CMR20.Height = 25
            CMC39.Text = "Outside services"
            CMC39.BorderWidth = 1
            CMC39.CssClass = "Displaynametd"
            CMR20.Controls.Add(CMC39)
            Dim Outside As New Integer
            For Outside = 0 To Count - 1
                Dim CMC40 As New TableCell
                CMC40.Text = FormatNumber(Dts.Rows(Outside).Item("UNITOUTSIDESERV").ToString(), 3)
                CMC40.Width = 185
                CMC40.Style.Add("text-align", "right")
                CMC40.BorderWidth = 1
                CMR20.Controls.Add(CMC40)
            Next
            tblComparision.Controls.Add(CMR20)

            'Professional services
            Dim CMR21 As New TableRow
            Dim CMC41 As New TableCell
            CMR21.ID = "CM21_1"
            CMR21.CssClass = "ColorTR"
            CMR21.Height = 25
            CMC41.Text = "Professional services"
            CMC41.BorderWidth = 1
            CMC41.CssClass = "Displaynametd"
            CMR21.Controls.Add(CMC41)
            Dim Professional As New Integer
            For Professional = 0 To Count - 1
                Dim CMC42 As New TableCell
                CMC42.Text = FormatNumber(Dts.Rows(Professional).Item("UNITPROFESSIONALSERV").ToString(), 3)
                CMC42.Width = 185
                CMC42.Style.Add("text-align", "right")
                CMC42.BorderWidth = 1
                CMR21.Controls.Add(CMC42)
            Next
            tblComparision.Controls.Add(CMR21)


            'Laboratory supplies
            Dim CMR22 As New TableRow
            Dim CMC43 As New TableCell
            CMR22.ID = "CM22_1"
            CMR22.CssClass = "ColorTR"
            CMR22.Height = 25
            CMC43.Text = "Laboratory supplies"
            CMC43.BorderWidth = 1
            CMC43.CssClass = "Displaynametd"
            CMR22.Controls.Add(CMC43)
            Dim Laboratory As New Integer
            For Laboratory = 0 To Count - 1
                Dim CMC44 As New TableCell
                CMC44.Text = FormatNumber(Dts.Rows(Laboratory).Item("UNITLABORATORYSUPP").ToString(), 3)
                CMC44.Width = 185
                CMC44.Style.Add("text-align", "right")
                CMC44.BorderWidth = 1
                CMR22.Controls.Add(CMC44)
            Next
            tblComparision.Controls.Add(CMR22)


            'Ink supplies
            Dim CMR23 As New TableRow
            Dim CMC45 As New TableCell
            CMR23.ID = "CM23_1"
            CMR23.CssClass = "ColorTR"
            CMR23.Height = 25
            CMC45.Text = "Ink supplies"
            CMC45.BorderWidth = 1
            CMC45.CssClass = "Displaynametd"
            CMR23.Controls.Add(CMC45)
            Dim Ink As New Integer
            For Ink = 0 To Count - 1
                Dim CMC46 As New TableCell
                CMC46.Text = FormatNumber(Dts.Rows(Ink).Item("UNITINKSUPP").ToString(), 3)
                CMC46.Width = 185
                CMC46.Style.Add("text-align", "right")
                CMC46.BorderWidth = 1
                CMR23.Controls.Add(CMC46)
            Next
            tblComparision.Controls.Add(CMR23)


            'Plate supplies
            Dim CMR24 As New TableRow
            Dim CMC47 As New TableCell
            CMR24.ID = "CM24_1"
            CMR24.CssClass = "ColorTR"
            CMR24.Height = 25
            CMC47.Text = "Plate supplies"
            CMC47.BorderWidth = 1
            CMC47.CssClass = "Displaynametd"
            CMR24.Controls.Add(CMC47)
            Dim Plate As New Integer
            For Plate = 0 To Count - 1
                Dim CMC48 As New TableCell
                CMC48.Text = FormatNumber(Dts.Rows(Plate).Item("UNITPLATESUPP").ToString(), 3)
                CMC48.Width = 185
                CMC48.Style.Add("text-align", "right")
                CMC48.BorderWidth = 1
                CMR24.Controls.Add(CMC48)
            Next
            tblComparision.Controls.Add(CMR24)


            'Metal supplies
            Dim CMR25 As New TableRow
            Dim CMC49 As New TableCell
            CMR25.ID = "CM25_1"
            CMR25.CssClass = "ColorTR"
            CMR25.Height = 25
            CMC49.Text = "Metal supplies"
            CMC49.BorderWidth = 1
            CMC49.CssClass = "Displaynametd"
            CMR25.Controls.Add(CMC49)
            Dim Metal As New Integer
            For Metal = 0 To Count - 1
                Dim CMC50 As New TableCell
                CMC50.Text = FormatNumber(Dts.Rows(Metal).Item("UNITMETALSUPP").ToString(), 3)
                CMC50.Width = 185
                CMC50.Style.Add("text-align", "right")
                CMC50.BorderWidth = 1
                CMR25.Controls.Add(CMC50)
            Next
            tblComparision.Controls.Add(CMR25)


            'Plant Margin
            Dim CMR26 As New TableRow
            Dim CMC51 As New TableCell
            CMR26.ID = "CM26_1"
            CMR26.CssClass = "ColorTR"
            CMR26.Height = 25
            CMC51.Text = "Plant Margin"
            CMC51.BorderWidth = 1
            CMC51.CssClass = "Displaynametd"
            CMR26.Controls.Add(CMC51)
            Dim Plant As New Integer
            For Plant = 0 To Count - 1
                Dim CMC52 As New TableCell
                CMC52.Text = FormatNumber(Dts.Rows(Plant).Item("UNITPLANTMARGIN").ToString(), 3)
                CMC52.Width = 185
                CMC52.Style.Add("text-align", "right")
                CMC52.BorderWidth = 1
                CMR26.Controls.Add(CMC52)
            Next
            tblComparision.Controls.Add(CMR26)



        Catch ex As Exception
            Response.Write("Error:" + ex.Message.ToString())

        End Try


    End Sub
End Class
