﻿// build out the divs, set attributes and call the fade function //
var MSGTIMER = 20;
var MSGSPEED = 5;
var MSGOFFSET = 3;
var MSGHIDE = 5;
var msg;

var hour1="0";
var hour2 = "0";
var hour3 = "0";
var hour4 = "0";
var hour5 = "0";
var hour6 = "0";
var hour7 = "0";
var hour8 = "0";
var hour9 = "0";
var hour10 = "0";

var hour11 = "0";
var hour12 = "0";
var hour13 = "0";
var hour14 = "0";
var hour15 = "0";
var hour16 = "0";
var hour17 = "0";
var hour18 = "0";
var hour19 = "0";
var hour20 = "0";

var hour21 = "0";
var hour22 = "0";
var hour23 = "0";
var hour24 = "0";
var hour25 = "0";
var hour26 = "0";
var hour27 = "0";
var hour28 = "0";
var hour29 = "0";
var hour30 = "0";

var Param1;
var Param2;
var Param3;
var Param4;
var Param5;
var HoursCntValueNew;
var HoursCountNew;
var ii;

function getData1() {
    return hour1 + "-" + hour2 + "-" + hour3 + "-" + hour4 + "-" + hour5;
}
function inlineMsg(target, string, autohide) {
    // START OF MESSAGE SCRIPT //


    var msgcontent;
    if (!document.getElementById('msg')) {
        msg = document.createElement('div');
        msg.id = 'msg';
        msgcontent = document.createElement('div');
        msgcontent.id = 'msgcontent';
        document.body.appendChild(msg);
        msg.appendChild(msgcontent);
        msg.style.filter = 'alpha(opacity=0)';
        msg.style.opacity = 0;
        msg.alpha = 0;
    } else {
        msg = document.getElementById('msg');
        msgcontent = document.getElementById('msgcontent');
    }
    msgcontent.innerHTML = string;
    msg.style.display = 'block';
    var msgheight = msg.offsetHeight;
    var msgwidth = msg.offsetWidth;
    var targetdiv = document.getElementById(target);
    targetdiv.focus();
    var targetheight = targetdiv.offsetHeight;
    var targetwidth = targetdiv.offsetWidth;
  
     var topposition;
    if(msgwidth<200)
    {
       topposition = topPosition(targetdiv) - ((msgheight - targetheight) / 2)-msgheight;
    }
    else
    {
      topposition = topPosition(targetdiv) - ((msgheight - targetheight) / 2)-msgheight+9;
    }
    var leftposition = leftPosition(targetdiv) - (msgwidth / 2) + (targetwidth/2) + MSGOFFSET;
    msg.style.top = topposition + 'px';
    msg.style.left = leftposition + 'px';
    clearInterval(msg.timer);
    msg.timer = setInterval("fadeMsg(1)", MSGTIMER);
    if (!autohide) {
        autohide = MSGHIDE;
    }
    window.setTimeout("hideMsg()", (autohide * 2000));
}

// hide the form alert //
function hideMsg(msg) {
    var msg = document.getElementById('msg');
    if (!msg.timer) {
        msg.timer = setInterval("fadeMsg(0)", MSGTIMER);
    }
}

// face the message box //
function fadeMsg(flag) {
    if (flag == null) {
        flag = 1;
    }
    var msg = document.getElementById('msg');
    var value;
    if (flag == 1) {
        value = msg.alpha + MSGSPEED;
    } else {
        value = msg.alpha - MSGSPEED;
    }
    msg.alpha = value;
    msg.style.opacity = (value / 100);
    msg.style.filter = 'alpha(opacity=' + value + ')';
    if (value >= 99) {
        clearInterval(msg.timer);
        msg.timer = null;
    } else if (value <= 1) {
        msg.style.display = "none";
        clearInterval(msg.timer);
    }
}

// calculate the position of the element in relation to the left of the browser //
function leftPosition(target) {
    var left = 0;
    if (target.offsetParent) {
        while (1) {
            left += target.offsetLeft;
            if (!target.offsetParent) {
                break;
            }
            target = target.offsetParent;
        }
    } else if (target.x) {
        left += target.x;
    }
    return left;
}

// calculate the position of the element in relation to the top of the browser window //
function topPosition(target) {
    var top = 0;
    if (target.offsetParent) {
        while (1) {
            top += target.offsetTop;
            if (!target.offsetParent) {
                break;
            }
            target = target.offsetParent;
        }
    } else if (target.y) {
        top += target.y;
    }
    return top;
}

// preload the arrow //
if (document.images) {
    arrow = new Image(7, 80);
    arrow.src = "../images/msg_arrow.gif";
}


// Checking individual text box for numric
function checkNumeric(value, id) {

    var anum = /(^\d+$)|(^\d+\.\d+$)/

    if (anum.test(value.replace(/,/g, ""))) {
        return true;
    }
    else {
             
        return false;
    }
}

function inlineMsgOperating(cnt, target, string, autohide) {
    // START OF MESSAGE SCRIPT //

   
    var msgcontent;
    if (!document.getElementById('msg')) {
        msg = document.createElement('div');
        msg.id = 'msg';
        msgcontent = document.createElement('div');
        msgcontent.id = 'msgcontent';
        document.body.appendChild(msg);
        msg.appendChild(msgcontent);
        msg.style.filter = 'alpha(opacity=0)';
        msg.style.opacity = 0;
        msg.alpha = 0;

//        details_btn = document.createelement("button"); //create details button
//        //details_btn.id = 'msgcontent121'; 
//        btn_txt = document.createtextnode("yes"); //create button text
//        details_btn.appendchild(btn_txt);  //add "details" to button text
//        details_btn.onclick = function () { moreinfo("moreInfo"); }; //assign button function
//        msg.appendchild(details_btn)

//        details_btn1 = document.createElement("button"); //create details button
//        //details_btn1.id = 'msgcontent121'; 
//        btn_txt1 = document.createTextNode("no"); //create button text
//        details_btn1.appendChild(btn_txt1);  //add "details" to button text
//        details_btn1.onclick = function () { moreinfo("2"); }; //assign button function
//        msg.appendChild(details_btn1)

    } else {
        msg = document.getElementById('msg');
        msgcontent = document.getElementById('msgcontent');
    }


    msgcontent.innerHTML = "There is mismatch between equipment selection and hours value,Do you wana to update without correction?<br/> <button id='btn1' class='ButtonJMessage' title='Click here to update without change' onclick='AllowUpdate(" + cnt + ");'>Yes</button><button id='btn2' class='ButtonJMessage' onclick='CancelUpdate();' title='Click here to change before update'>No</button>"; //string;
    
    msg.style.display = 'block';
    var msgheight = msg.offsetHeight;
    var msgwidth = msg.offsetWidth;
    var targetdiv = document.getElementById(target);
    targetdiv.focus();
    var targetheight = targetdiv.offsetHeight;
    var targetwidth = targetdiv.offsetWidth;

    var topposition;
    if (msgwidth < 600) {
        topposition = topPosition(targetdiv) - ((msgheight - targetheight) / 2) - msgheight;
    }
    else {
        topposition = topPosition(targetdiv) - ((msgheight - targetheight) / 2) - msgheight + 9;
    }
   
    var leftposition = leftPosition(targetdiv) - (msgwidth / 2) + (targetwidth / 2) + MSGOFFSET;
    msg.style.top = topposition+27 + 'px';
    msg.style.left = leftposition + 'px';
    clearInterval(msg.timer);
    msg.timer = setInterval("fadeMsg(1)", MSGTIMER);
    if (!autohide) {
        autohide = MSGHIDE;
    }
    //alert(cnt + "-" + HoursCntValueNew);
    if (cnt == HoursCntValueNew) {
        window.setTimeout("hideMsg()", (autohide * 5));
    }
    else {
        window.setTimeout("hideMsg()", (autohide * 2000));
    }
   

    return false;
}
function inlineMsgEquipment(cnt, target, string, autohide) {
    var msgcontent;
    if (!document.getElementById('msg')) {
        msg = document.createElement('div');
        msg.id = 'msg';
        msgcontent = document.createElement('div');
        msgcontent.id = 'msgcontentEq';
        document.body.appendChild(msg);
        msg.appendChild(msgcontent);
        msg.style.filter = 'alpha(opacity=0)';
        msg.style.opacity = 0;
        msg.alpha = 0;

       

    } else {
        msg = document.getElementById('msg');
        msgcontent = document.getElementById('msgcontentEq');
    }

   // alert(msgcontent);
    msgcontent.innerHTML = "There is mismatch between equipment selection and hours value,Do you wana to update without correction?<br/> <button id='btn1' class='ButtonJMessage' title='Click here to update without change' onclick='AllowUpdateEq(" + cnt + ");'>Yes</button><button id='btn2' class='ButtonJMessage' onclick='CancelUpdate();' title='Click here to change before update'>No</button>"; //string;

    msg.style.display = 'block';
    var msgheight = msg.offsetHeight;
    var msgwidth = msg.offsetWidth;
    
    var targetdiv = document.getElementById(target);
    targetdiv.focus();
    var targetheight = targetdiv.offsetHeight;
    var targetwidth = targetdiv.offsetWidth;

    var topposition;
    if (msgwidth < 600) {
        topposition = topPosition(targetdiv) - ((msgheight - targetheight) / 2) - msgheight;
    }
    else {
        topposition = topPosition(targetdiv) - ((msgheight - targetheight) / 2) - msgheight + 9;
    }
    //alert(topposition);
    var leftposition = leftPosition(targetdiv) - (msgwidth / 2) + (targetwidth / 2) + MSGOFFSET;
//    if (topposition < 0) {
//        msg.style.top = topposition + 322 + 'px';
//        msg.style.left = leftposition + 100 + 'px';
//    }
//    else {
//        msg.style.top = topposition + 44 + 'px';
//        msg.style.left = leftposition + 55 + 'px';
//    }
    msg.style.top = topposition + 30 + 'px';
    msg.style.left = leftposition + 'px';
   
    clearInterval(msg.timer);
    msg.timer = setInterval("fadeMsg(1)", MSGTIMER);
    if (!autohide) {
        autohide = MSGHIDE;
    }
  
    if (cnt == HoursCntValueNew) {
        window.setTimeout("hideMsg()", (autohide * 5));
    }
    else {
        window.setTimeout("hideMsg()", (autohide * 2000));
    }


    return false;
}
function AllowUpdateEq(cnt) {
   
    //alert(cnt);
    if (cnt == 1) {
        hour1 = "1";
    }

    if (cnt == 2) {
        hour2 = "1";
    }
    if (cnt == 3) {
        hour3 = "1";
    }
    if (cnt == 4) {
        hour4 = "1";
    }
    if (cnt == 5) {
        hour5 = "1";
    }
    if (cnt == 6) {
        hour6 = "1";
    }
    if (cnt == 7) {
        hour7 = "1";
    }
    if (cnt == 8) {
        hour8 = "1";
    }
    if (cnt == 9) {
        hour9 = "1";
    }
    if (cnt == 10) {
        hour10 = "1";
    }

    if (cnt == 11) {
        hour11 = "1";
    }

    if (cnt == 12) {
        hour12 = "1";
    }
    if (cnt == 13) {
        hour13 = "1";
    }
    if (cnt == 14) {
        hour14 = "1";
    }
    if (cnt == 15) {
        hour15 = "1";
    }
    if (cnt == 16) {
        hour16 = "1";
    }
    if (cnt == 17) {
        hour17 = "1";
    }
    if (cnt == 18) {
        hour18 = "1";
    }
    if (cnt == 19) {
        hour19 = "1";
    }
    if (cnt == 20) {
        hour20 = "1";
    }

    if (cnt == 21) {
        hour21 = "1";
    }

    if (cnt == 22) {
        hour22 = "1";
    }
    if (cnt == 23) {
        hour23 = "1";
    }
    if (cnt == 24) {
        hour24 = "1";
    }
    if (cnt == 25) {
        hour25 = "1";
    }
    if (cnt == 26) {
        hour26 = "1";
    }
    if (cnt == 27) {
        hour27 = "1";
    }
    if (cnt == 28) {
        hour28 = "1";
    }
    if (cnt == 29) {
        hour29 = "1";
    }
    if (cnt == 30) {
        hour30 = "1";
    }

    hideMsg();
    //alert(Param1 + "," + Param2 + "," + Param3 + "," + Param4);
    CheckForEquipmentPage(Param1, Param2,Param6, Param3, Param4, Param5);
}
function AllowUpdate(cnt) 
{
    if (cnt == 1) {
        hour1 = "1";
    }
   
    if (cnt == 2) {
        hour2 = "1";
    }
    if (cnt == 3) {
        hour3 = "1";
    }
    if (cnt == 4) {
        hour4 = "1";
    }
    if (cnt == 5) {
        hour5 = "1";
    }
    if (cnt == 6) {
        hour6 = "1";
    }
    if (cnt == 7) {
        hour7 = "1";
    }
    if (cnt == 8) {
        hour8 = "1";
    }
    if (cnt == 9) {
        hour9 = "1";
    }
    if (cnt == 10) {
        hour10 = "1";
    }
    
     if (cnt == 11) {
        hour11 = "1";
    }
   
    if (cnt == 12) {
        hour12 = "1";
    }
    if (cnt == 13) {
        hour13 = "1";
    }
    if (cnt == 14) {
        hour14 = "1";
    }
    if (cnt == 15) {
        hour15 = "1";
    }
    if (cnt == 16) {
        hour16 = "1";
    }
    if (cnt == 17) {
        hour17 = "1";
    }
    if (cnt == 18) {
        hour18 = "1";
    }
    if (cnt == 19) {
        hour19 = "1";
    }
    if (cnt == 20) {
        hour20 = "1";
    }
   
     if (cnt == 21) {
        hour21 = "1";
    }
   
    if (cnt == 22) {
        hour22 = "1";
    }
    if (cnt == 23) {
        hour23 = "1";
    }
    if (cnt == 24) {
        hour24 = "1";
    }
    if (cnt == 25) {
        hour25 = "1";
    }
    if (cnt == 26) {
        hour26 = "1";
    }
    if (cnt == 27) {
        hour27 = "1";
    }
    if (cnt == 28) {
        hour28 = "1";
    }
    if (cnt == 29) {
        hour29 = "1";
    }
    if (cnt == 30) {
        hour30 = "1";
    }

    hideMsg();
    CheckForOperating(Param1, Param2, Param3, HoursCountNew);
}
function CancelUpdate() 
{
    hideMsg();
}
function moreInfo1() {
    i = 2;
  
    return false;
}
// Checking All text box for numric
function checkNumericAll() {

    var txtarray = document.getElementsByTagName("input");
    var flag;
    var anum = /(^\d+$)|(^\d+\.\d+$)/

    for (var i = 0; i < txtarray.length; i++) {
        if (txtarray[i].type == "text") 
        {
            var id = txtarray[i].id;
           // alert(id);
           // if (anum.test(txtarray[i].value.replace(/,/g, "")))
            if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) {

                flag = true;
            }
            else 
            {
                     inlineMsg(id, "Invalid Number");
                            flag = false;
                             break;
                      
            }

        }

    }

    return flag;
}

function CheckForOperating(MasterId, Mat, Hours, HoursCount) 
{
    var IsNumflag;
    var IsThick;
    var IsDep;
    var IsMod;
    var HoursArr = new Array();
    HoursCountNew = HoursCount;

     Param1=MasterId;
     Param2=Mat;
     Param3 = Hours;
    
    //Numeric Check
    if (checkNumericAll(MasterId)) {
        IsNumflag = true;
    }
    else {
        IsNumflag = false;

    }
  
    HoursArr[1] = hour1;
    HoursArr[2] = hour2;
    HoursArr[3] = hour3;
    HoursArr[4] = hour4;
    HoursArr[5] = hour5;
    HoursArr[6] = hour6;
    HoursArr[7] = hour7;
    HoursArr[8] = hour8;
    HoursArr[9] = hour9;
    HoursArr[10] = hour10;

    HoursArr[11] = hour11;
    HoursArr[12] = hour12;
    HoursArr[13] = hour13;
    HoursArr[14] = hour14;
    HoursArr[15] = hour15;
    HoursArr[16] = hour16;
    HoursArr[17] = hour17;
    HoursArr[18] = hour18;
    HoursArr[19] = hour19;
    HoursArr[20] = hour20;

    HoursArr[21] = hour21;
    HoursArr[22] = hour22;
    HoursArr[23] = hour23;
    HoursArr[24] = hour24;
    HoursArr[25] = hour25;
    HoursArr[26] = hour26;
    HoursArr[27] = hour27;
    HoursArr[28] = hour28;
    HoursArr[29] = hour29;
    HoursArr[30] = hour30;

    //Non zero thickness check for selected material
    var HoursCntId = MasterId + "_" + HoursCount
    var HoursCntValue = document.getElementById(HoursCntId).value;
    HoursCntValueNew = HoursCntValue;
   // alert(HoursCntValue);
    if (IsNumflag) {

        for (var i = 1; i <= 30; i++) {
            var MatId = MasterId + "_" + Mat + i;
            var HoursId = MasterId + "_" + Hours + i;
            //alert(MatId+" "+HoursId);
            var MatVal = document.getElementById(MatId).value;
            //alert(MatVal);
            var HourskVal = document.getElementById(HoursId).value;
            HourskVal = HourskVal.replace(",", "");
            //alert(HourskVal);

            if (MatVal > 0) 
            {
               IsThick = true;

            }
            else 
            {
                if (HourskVal > 0) 
                {
                    //alert(HourskVal);
                        //alert(hour1 + " " + i);
                        if (HoursArr[i] == "1") 
                        {
                            IsThick = true;
                        }
                        else 
                        {
                            IsThick = false;
                            //inlineMsgOperating(i, HoursId, "Update did not complete because no equipment is selected. Please enter zero.");
                            break;

                        }
                             
                }
                else 
                {                   
                    IsThick = true;
                }
            }
        }

    }

    //alert(IsThick+" "+HoursArr[1] + "-" + HoursArr[2] + "-" + HoursArr[3] + "-" + HoursArr[4] + "-" + HoursArr[5] + "-" + HoursArr[6]);
    //alert(IsNumflag);

    if (IsNumflag && IsThick) {
        return true;
    }
    else {
        return false;
    }


}

function IsNumeric(input) 
{
    return (input - 0) == input && input.length > 0;
}
function checkNumericMaterial(MasterId) 
{

    var txtarray = document.getElementsByTagName("input");
    var flag;
    var anum = /(^\d+$)|(^\d+\.\d+$)/
    var k=1;

    for (var i = 0; i < txtarray.length; i++) {
        if (txtarray[i].type == "text") 
        {
            var id = txtarray[i].id;
            var PriceId = MasterId + "_P" + k; 
                   
            if(PriceId==id)//check for Preferred Price Textboxes
            {
                k=k+1;
                 if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) 
                 {
                            flag = true;
                  }
                  else
                  {
                    if(txtarray[i].value!="")
                        {
                            inlineMsg(id, "Invalid Number");
                            flag = false;
                             break;
                        }
                        else
                        {
                            flag=true;
                        }                       
                    }
             }
             else
             {       
                       if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) 
                       {
                            flag = true;
                        }
                        else 
                        {
                            inlineMsg(id, "Invalid Number");
                            flag = false;
                             break;                                
                        }
               }
        }

    }

    return flag;
}

function checkNumericEquipment(MasterId) 
{

    var txtarray = document.getElementsByTagName("input");
    var flag;
    var anum = /(^\d+$)|(^\d+\.\d+$)/
    var k=1;

    for (var i = 0; i < txtarray.length; i++) {
        if (txtarray[i].type == "text") 
        {
            var id = txtarray[i].id;
            var AssetId = MasterId + "_ASSETP" + k; 
                   
            if(AssetId==id)//check for Preferred Price Textboxes
            {
                k=k+1;
                 if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) 
                 {
                            flag = true;
                  }
                  else
                  {
                    if(txtarray[i].value!="")
                        {
                            inlineMsg(id, "Invalid Number");
                            flag = false;
                             break;
                        }
                        else
                        {
                            flag=true;
                        }                       
                    }
             }
             else
             {       
                       if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) 
                       {
                            flag = true;
                        }
                        else 
                        {
                            inlineMsg(id, "Invalid Number");
                            flag = false;
                             break;                                
                        }
               }
        }

    }

    return flag;
}

function CheckForPersonnelPage(MasterId, Pos,SSal,PSal,PrefRatio,CostT,CostTName,Flag,Dep, DepName)
{  
  //alert(Flag);
  var IsNumflag;
  var IsDep;
  var isCostFlag;
   //Checking Preferred Value
  var anum = /(^\d+$)|(^\d+\.\d+$)/
  var id =  MasterId + "_" + PrefRatio;
  var val=document.getElementById(id).value
  if (anum.test(val.replace(/,/g, "")))
  {
    IsNumflag=true;
  }
  else
  {
    IsNumflag=false;
    inlineMsg(id, "Invalid Number");    
  }
              if(Flag=="Y")
              {
                        if (IsNumflag) {     
                   
                            for (var i = 1; i <= 30; i++) 
                            {
                                var PosId = MasterId + "_" + Pos + i;
                                var PosVal = document.getElementById(PosId).value;
                                var SSalId=MasterId + "_" + SSal + i;
                                var SSalVal=document.getElementById(SSalId).innerText;                    
                                var PSalId=MasterId + "_" + PSal + i;
                                var PSalVal=document.getElementById(PSalId).value;  
                                    if (PosVal > 0) 
                                    {    
                                      SSalVal=SSalVal.replace(/,/g, "");  
                                      val=val.replace(/,/g, "");  
                                       var newPrefSal=SSalVal*val;                                         
                                       document.getElementById(PSalId).value=newPrefSal.toFixed(0); 
                                    }  
                             }
                           }
                               if(IsNumflag)
                               {         
                                  return true;
                               }
                               else
                               {
                                 return false;
                               }
                 }
                 else
                 {
                   if (checkNumericAll()) 
                    {
                        IsNumflag = true;
                    }
                    else
                    {
                        IsNumflag = false;
                    }
                   
                    //Checking Cost type
                     if (IsNumflag)
                        {
                            for (var j = 1; j <= 30; j++)
                            {
                                var PosId = MasterId + "_" + Pos + j;
                                var PosVal = document.getElementById(PosId).value;
                               
                                var costId = MasterId + "_" + CostT + j;
                                var costNameId = MasterId + "_" + CostTName + j;
                                var costVal = document.getElementById(costId).value;
                                //alert(DepId);
                                if (PosVal > 0)
                                {
                                    if (costVal == 0)
                                    {
                                        isCostFlag = false;
                                        inlineMsg(costNameId, "Update did not complete, please select a cost type.");
                                        break;
                                    }
                                    else
                                    {
                                        isCostFlag = true;
                                    }

                                }
                                else
                                {
                                    isCostFlag = true;
                                }

                            }
                        }                       
                        
                           if(IsNumflag && isCostFlag)
                           {         
                              return true;
                           }
                           else
                           {
                             return false;
                           }
                    
                    
                 }
  
  

 }

function CheckForMaterialPage(MasterId, Mat, Thick, Dep, DepName) 
{
    var IsNumflag;
    var IsThick;
    var IsDep;
     var IsMod;
   
    //Numeric Check
    if (checkNumericMaterial(MasterId)) {
        IsNumflag = true;
    }
    else {
        IsNumflag = false;

    }

    //Non zero thickness check for selected material
    if (IsNumflag) {

        for (var i = 1; i <= 10; i++) {
            var MatId = MasterId + "_" + Mat + i;
            var ThickId = MasterId + "_" + Thick + i;
            var MatVal = document.getElementById(MatId).value;
            var ThickVal = document.getElementById(ThickId).value;
            if (MatVal > 0) {
                if (ThickVal == 0) {
                    IsThick = false;
                    inlineMsg(ThickId, "Update did not complete, please enter a positive, non-zero number.");
                    break;

                }
                else {
                    IsThick = true;
                }

            }
            else {
                if (ThickVal > 0) {
                    IsThick = false;
                    inlineMsg(ThickId, "Update did not complete because no material is selected. Please enter zero.");
                    break;
                }
                else {
                    IsThick = true;
                }
            }
        }

    }

    //Cheking Dept.
    if (IsThick) {
        for (var j = 1; j <= 10; j++) {
            var MatId = MasterId + "_" + Mat + j;
            var DepId = MasterId + "_" + Dep + j;
            var DepNameId = MasterId + "_" + DepName + j;
            var MatVal = document.getElementById(MatId).value;
            var DepVal = document.getElementById(DepId).value;
            var DepText=document.getElementById(DepNameId);
            
            //alert(DepId);
            if (MatVal > 0) {
                if (DepVal == 0) {
                    IsDep = false;
                    inlineMsg(DepNameId, "Update did not complete, please select a department.");
                    break;
                }
                else 
                {
                    if(DepText.innerHTML=='Dept. Conflict')
                    {
                       IsDep = false;
                       inlineMsg(DepNameId, "Update did not complete, please select a department.");
                       break;
                    }
                    else
                    {
                        IsDep = true;                    
                    }
                }

            }
            else {
                IsDep = true;
            }

        }
    }

//    if (IsDep) 
//    {
//             
//        for (var j = 1; j <= 10; j++) 
//        {
//            var ModId = MasterId + "_" + ModType + j;
//            var CaseId = MasterId + "_" + ModCases + j;           
//            var ModVal = document.getElementById(ModId).value;
//            var CaseVal = document.getElementById(CaseId).value;
//            var CaseNameId = MasterId + "_" + CaseName + j;
//                              
//            if (ModVal > 0) 
//            {
//                if (CaseVal == 0)
//                {
//                    IsMod = false;
//                    inlineMsg(CaseNameId, "Update did not complete, please select a Case.");
//                    break;
//                }
//                else 
//                {
//                   IsMod = true ;
//                }

//            }
//            else 
//            {
//                IsMod = true;
//            }

//        }
//    }
    
    if (IsNumflag && IsThick && IsDep) 
    {
        return true;
    }
    else 
    {
        return false;
    }


}


function CheckForPalletInPage(MasterId, Pallet, Num, NOFUSE) {
    var IsNumflag;
    var IsNumberflag;
    var IsNumUsesflag;
    //Numeric Check
    if (checkNumericAll()) {
        IsNumflag = true;
    }
    else {
        IsNumflag = false;

    }

    //Non zero thickness check for selected material
    if (IsNumflag) {

        for (var i = 1; i <= 10; i++) {
            var PalId = MasterId + "_" + Pallet + i;
            var NumId = MasterId + "_" + Num + i;
            var PalVal = document.getElementById(PalId).value;
            var NumVal = document.getElementById(NumId).value;
//            alert(PalVal+"  "+NumVal);
            if (PalVal > 0) {
                if (NumVal == 0) {
                    IsNumberflag = false;
                    inlineMsg(NumId, "Update did not complete, please enter a positive, non-zero number.");
                    break;

                }
                else {
                    IsNumberflag = true;
                }

            }
            else {
                if (NumVal > 0) {
                    IsNumberflag = false;
                    inlineMsg(NumId, "Update did not complete because no Pallet Packaging Item selected.  Please enter zero.");
                    break;
                }
                else {
                    IsNumberflag = true;
                }
            }
        }

    }  
    if(IsNumberflag)
    {
            for (var i = 1; i <= 10; i++) 
            {
                var NUsesId = MasterId + "_" + NOFUSE + i;
                var  NUsesVal = document.getElementById(NUsesId).value;
                 if (NUsesVal == 0) 
                 {
                        IsNumUsesflag = false;
                        inlineMsg(NUsesId, "Update did not complete, please enter a positive, non-zero number.");
                        break;
                 }
                 else
                 {
                   IsNumUsesflag = true;
                 }
            }
    }  

    if (IsNumflag && IsNumberflag && IsNumUsesflag) {
        return true;
    }
    else {
        return false;
    }
}


////function CheckForEquipmentPage(MasterId, Equip, EquipDes, Dep, DepName, HoursMaxCount) {

////   
////    var IsNumflag;
////    var IsDep;

////    var HoursArr = new Array();
////    HoursCountNew = HoursMaxCount;

////    Param1 = MasterId;
////    Param2 = Equip;
////    Param3 = Dep;
////    Param4 = DepName;
////    Param5 = HoursMaxCount;
////    Param6 = EquipDes;

////    HoursArr[1] = hour1;
////    HoursArr[2] = hour2;
////    HoursArr[3] = hour3;
////    HoursArr[4] = hour4;
////    HoursArr[5] = hour5;
////    HoursArr[6] = hour6;
////    HoursArr[7] = hour7;
////    HoursArr[8] = hour8;
////    HoursArr[9] = hour9;
////    HoursArr[10] = hour10;

////    HoursArr[11] = hour11;
////    HoursArr[12] = hour12;
////    HoursArr[13] = hour13;
////    HoursArr[14] = hour14;
////    HoursArr[15] = hour15;
////    HoursArr[16] = hour16;
////    HoursArr[17] = hour17;
////    HoursArr[18] = hour18;
////    HoursArr[19] = hour19;
////    HoursArr[20] = hour20;

////    HoursArr[21] = hour21;
////    HoursArr[22] = hour22;
////    HoursArr[23] = hour23;
////    HoursArr[24] = hour24;
////    HoursArr[25] = hour25;
////    HoursArr[26] = hour26;
////    HoursArr[27] = hour27;
////    HoursArr[28] = hour28;
////    HoursArr[29] = hour29;
////    HoursArr[30] = hour30;
////  
////    //Numeric Check
////    if (checkNumericEquipment(MasterId)) {
////        IsNumflag = true;
////    }
////    else {
////        IsNumflag = false;

////    }

////    var HoursCntId = MasterId + "_" + HoursMaxCount;
////   // alert(HoursCntId);
////    var HoursCntValue = document.getElementById(HoursCntId).value;
////    HoursCntValueNew = HoursCntValue;

////   
////    //Cheking Dept.
////    if (IsNumflag) {
////        for (var j = 1; j <= 30; j++) {
////            var EqId = MasterId + "_" + Equip + j;
////            var DepId = MasterId + "_" + Dep + j;
////            var DepNameId = MasterId + "_" + DepName + j;
////            var EquipDesId = MasterId + "_" + EquipDes + j;
////            var EqVal = document.getElementById(EqId).value;
////            var DepVal = document.getElementById(DepId).value;
////            var DepText = document.getElementById(DepNameId);

////            var OpHoursId = MasterId + "_hdnOp" + j;
////            var OpHoursVal = document.getElementById(OpHoursId).value;
////            if (EqVal > 0) 
////            {
////                if (DepVal == 0) 
////                {
////                    IsDep = false;
////                    inlineMsg(DepNameId, "Update did not complete, please select a department.");
////                    break;
////                }
////                else 
////                {                    
////                           if(DepText.innerHTML=='Dept. Conflict')
////                            {
////                               IsDep = false;
////                               inlineMsg(DepNameId, "Update did not complete, please select a department.");
////                               break;
////                            }
////                            else
////                            {
////                                IsDep = true;                    
////                            }
////                }
////            }
////            else {

////               
//////                if (OpHoursVal == 0) 
//////                {
//////                    IsDep = true;
//////                    
//////                }
//////                else 
//////                {
//////                   
//////                    if (HoursArr[j] == "1") {
//////                        IsDep = true;
//////                    }
//////                    else {
//////                        IsDep = false;
//////                        //inlineMsgEquipment(j, EquipDesId, "Update did not complete, please select a department.");
//////                        break;

//////                    }
////                   
////                 
////           //     }
////                 IsDep = true;
////            }

////        }
////    }

////    if (IsNumflag && IsDep) {
////        return true;
////    }
////    else {
////        return false;
////    }
////}

function CheckForEquipmentPage(MasterId, Equip, Dep, DepName, EqNum) {
    var IsNumflag;
    var IsDep;
    //Numeric Check
    if (checkNumericEquipment(MasterId)) {
        IsNumflag = true;
    }
    else {
        IsNumflag = false;

    }


    //Cheking Dept.
    if (IsNumflag) {
        for (var j = 1; j <= 30; j++) {
            var EqId = MasterId + "_" + Equip + j;
            var DepId = MasterId + "_" + Dep + j;
            var DepNameId = MasterId + "_" + DepName + j;
            var EqNumId = MasterId + "_" + EqNum + j;

            var EqVal = document.getElementById(EqId).value;
            var DepVal = document.getElementById(DepId).value;
            var DepText = document.getElementById(DepNameId);
            var EqpNumVal = document.getElementById(EqNumId).value;
            if (EqVal > 0) {
                if (EqpNumVal == 0) {
                    IsNumber = false;
                    inlineMsg(EqNumId, "Update did not complete, please enter a positive, non-zero number.");
                    break;
                }
                else {
                    IsNumber = true;
                }
                if (DepVal == 0) {
                    IsDep = false;
                    inlineMsg(DepNameId, "Update did not complete, please select a department.");
                    break;
                }
                else {
                    if (DepText.innerHTML == 'Dept. Conflict') {
                        IsDep = false;
                        inlineMsg(DepNameId, "Update did not complete, please select a department.");
                        break;
                    }
                    else {
                        IsDep = true;
                    }
                }
            }
            else {
                IsDep = true;
            }

        }
    }

    if (IsNumflag && IsDep && IsNumber) {
        return true;
    }
    else {
        return false;
    }
}



function CheckForSEquipmentPage(MasterId, Equip, CstType, CstTypeName,EqNum) {
    var IsCostType
    var IsNumflag
    var IsNumber;
   //alert('sud--' + enum1);
      if (checkNumericAll()) 
        {
         IsNumflag = true;
        }
        else 
        {
         IsNumflag = false;
     }
     //alert(document.getElementById("ctl00_Econ1ContentPlaceHolder_hidTest").value);
     var enum1= document.getElementById("ctl00_Econ1ContentPlaceHolder_hidTest").value;
    // alert(enum1);
       if (IsNumflag) 
       {
           for (var j = 1; j <= enum1; j++) 
        {

            var EqId = MasterId + "_" + Equip + j;
            var CstTypeId = MasterId + "_" + CstType + j;
            var CstTypeNameId = MasterId + "_" + CstTypeName + j;
            var EqNumId = MasterId + "_" + EqNum + j;
          
            //alert(EqId + "  ctl00_Econ1ContentPlaceHolder_hidAssetId1");
            var EqVal =  document.getElementById(EqId).value;
           // alert(CstTypeId);
            var CstTypeVal = document.getElementById(CstTypeId).value;
            //alert(EqNumId);
            var EqpNumVal = document.getElementById(EqNumId).value;

            if (EqVal > 0) {
                if (EqpNumVal == 0) {
                    IsNumber = false;
                    inlineMsg(EqNumId, "Update did not complete, please enter a positive, non-zero number.");
                    break;
                }
                else {
                    IsNumber = true;
                }

                if (CstTypeVal == 0) {
                    IsCostType = false;
                    inlineMsg(CstTypeNameId, "Update did not complete, please select a cost type.");
                    break;
                }
                else {
                    IsCostType = true;
                }
            }
            else
            {
               IsCostType = true;
            }
        }
      }

   if (IsNumflag && IsCostType && IsNumber) {
      
        return true;
    }
    else {
        return false;
    }
}
function CheckForSEquipmentPageAll(MasterId, Equip, CstType, CstTypeName, enum1,EqNum) {
    var IsCostType
    var IsNumflag
    var IsNumber;
   // alert('sud--' + enum1);
    if (checkNumericAll()) {
        IsNumflag = true;
    }
    else {
        IsNumflag = false;
    }
    alert(document.getElementById("ctl00_Econ1ContentPlaceHolder_hidTest").value);
   // alert(enum1);
    if (IsNumflag) {
        for (var j = 1; j <= enum1; j++) {

            var EqId = MasterId + "_" + Equip + j;
            var CstTypeId = MasterId + "_" + CstType + j;
            var CstTypeNameId = MasterId + "_" + CstTypeName + j;
            var EqNumId = MasterId + "_" + EqNum + j;

            //alert(EqId + "  ctl00_Econ1ContentPlaceHolder_hidAssetId1");
            var EqVal = document.getElementById(EqId).value;
            // alert(CstTypeId);
            var CstTypeVal = document.getElementById(CstTypeId).value;
            //alert(EqNumId);
            var EqpNumVal = document.getElementById(EqNumId).value;

            if (EqVal > 0) {
                if (EqpNumVal == 0) {
                    IsNumber = false;
                    inlineMsg(EqNumId, "Update did not complete, please enter a positive, non-zero number.");
                    break;
                }
                else {
                    IsNumber = true;
                }

                if (CstTypeVal == 0) {
                    IsCostType = false;
                    inlineMsg(CstTypeNameId, "Update did not complete, please select a cost type.");
                    break;
                }
                else {
                    IsCostType = true;
                }
            }
            else {
                IsCostType = true;
            }
        }
    }

    if (IsNumflag && IsCostType && IsNumber) {
        return true;
    }
    else {
        return false;
    }
}
function checkNumeric1All() {
   // alert('hi');
    //    window.opener.location.reload();
    //    window.opener.location.reload();
    var txtarray = document.getElementsByTagName("input");
    var flag;
    var anum = /(^\d+$)|(^\d+\.\d+$)/
   
    for (var i = 0; i < txtarray.length-110; i++) {
        if (txtarray[i].type == "text") {
            var id = txtarray[i].id;
            // alert(id);

            if (txtarray[i].value.match(/\S/)) {
                if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) {
                    flag = true;


                }
                else {
                    inlineMsg(id, "Invalid Number");
                    flag = false;
                    break;
                }
                //alert(id + '---' + txtarray[i].value.match(/\S/) + '---' + flag);
            }
          
        

        }

    }

    return flag;
}
function CheckForBarrierPage(MasterId, OTRTEMP, RH, TEMPVAL1, TEMPVAL2, RHVAL) {
  //  alert('sud');
    var IsNumflag = true;
    var IsTemp;
    var IsTemp1;
    var IsRH;
    var IsRH2;

    IsNumflag = checkNumeric1All();
    //    var txtOTR = document.getElementById(MasterId + "_" + TEMPVAL1).value;
    //    var txtWVTR = document.getElementById(MasterId + "_" + TEMPVAL2).value;
    //    var txtRH = document.getElementById(MasterId + "_" + RHVAL).value;

    if (IsNumflag) {
        IsTemp = true;
        //alert(IsTemp+'sud1');
        var OTRTEMPL = MasterId + "_" + OTRTEMP + "1";
        var OTRTEMPValL = document.getElementById(OTRTEMPL).value;
        var OTRTEMPH = MasterId + "_" + OTRTEMP + "2";
        var OTRTEMPValH = document.getElementById(OTRTEMPH).value;


        var OTRT = MasterId + "_" + TEMPVAL1;
        var OTRTVal = document.getElementById(OTRT).value;

        if (eval(OTRTVal) < eval(OTRTEMPValL)) {
            IsTemp = false;
        }
        else if (eval(OTRTVal) > eval(OTRTEMPValH)) {
            IsTemp = false;
        }
        if (!IsTemp) {
            istemp = false;
            // var OTRV = OTRT.replace(/^\s+|\s+$/g, '');
            //  alert(OTRT);
            //inlineMsg(OTRT, "Update did not complete.Please enter proper Temprature.");
            inlineMsgBarrier("ctl00_E1InkContentPlaceHolder_txtOTRTemp", "Update did not complete.Please enter proper Temprature.");

        }

    }
    //  alert(TEMPVAL2);
    //alert('ok');
    if (IsTemp) {
        IsTemp1 = true;
        //     alert(IsTemp+'sud1');
        var OTRTEMPL = MasterId + "_" + OTRTEMP + "1";
        var OTRTEMPValL = document.getElementById(OTRTEMPL).value;
        var OTRTEMPH = MasterId + "_" + OTRTEMP + "2";
        var OTRTEMPValH = document.getElementById(OTRTEMPH).value;


        var WVTRT = MasterId + "_" + TEMPVAL2;
        var WVTRTVal = document.getElementById(WVTRT).value;

        if (eval(WVTRTVal) < eval(OTRTEMPValL)) {
            IsTemp1 = false;
        }
        else if (eval(WVTRTVal) > eval(OTRTEMPValH)) {
            IsTemp1 = false;
        }
        if (!IsTemp1) {
            istemp1 = false;
            //             var OTRV = OTRT.replace(/^\s+|\s+$/g, '');
            //              alert(OTRT);
            //            inlineMsg(OTRT, "Update did not complete.Please enter proper Temprature.");
            inlineMsgBarrier("ctl00_E1InkContentPlaceHolder_txtWVTRTemp", "Update did not complete.Please enter proper Temprature.");

        }

    }
    //    alert('ok');
    if (IsTemp1) {
        IsRH = true;
        //alert(IsTemp+'sud2');

        var RHL = MasterId + "_" + RH + "1";
        var RHValL = document.getElementById(RHL).value;


        var RHH = MasterId + "_" + RH + "2";
        var RHValH = document.getElementById(RHH).value;
        //alert(RHValH);

        var OTRRH = MasterId + "_" + RHVAL;
        var RHVal = document.getElementById(OTRRH).value;
        //alert(RHVal);

        if (eval(RHVal) < eval(RHValL)) {
            IsRH = false;
        }
        else if (eval(RHVal) > eval(RHValH)) {
            IsRH = false;
        }
        //alert(IsRH);
        if (!IsRH) {
            IsRH = false;
            // var OTRV = OTRT.replace(/^\s+|\s+$/g, '');
            //  alert(OTRT);
            //inlineMsg(OTRT, "Update did not complete.Please enter proper Temprature.");
            inlineMsgBarrier("ctl00_E1InkContentPlaceHolder_txtOTRHumidity", "Update did not complete.Please enter proper Relative Humidity..");

        }

    }

    if (IsRH) {
        IsRH2 = true;
        //alert(IsTemp+'sud2');

        var RHL = MasterId + "_" + RH + "1";
        var RHValL = document.getElementById(RHL).value;


        var RHH = MasterId + "_" + RH + "2";
        var RHValH = document.getElementById(RHH).value;
        //alert(RHValH);

        var WVTRRH = MasterId + "_txtWVTRHumidity";
        var RHVal = document.getElementById(WVTRRH).value;
        //alert(RHVal);

        if (eval(RHVal) < 90) {
            IsRH2 = false;

        }
        else if (eval(RHVal) > 100) {
            IsRH2 = false;

        }

        if (!IsRH2) {
            IsRH2 = false;

            inlineMsgBarrier("ctl00_E1InkContentPlaceHolder_txtWVTRHumidity", "Update did not complete.Please enter 100% Relative Humidity..");

        }

    }

    // alert(IsNumflag + '-' + IsTemp);
    if (IsNumflag && IsTemp && IsRH & IsRH2) {
        return true;
    }
    else {
        return false;
    }
}
function inlineMsgBarrier(target, string, autohide) {
    // START OF MESSAGE SCRIPT //


    var msgcontent;
    if (!document.getElementById('msg')) {
        msg = document.createElement('div');
        msg.id = 'msg';
        msgcontent = document.createElement('div');
        msgcontent.id = 'msgcontent';
        document.body.appendChild(msg);
        msg.appendChild(msgcontent);
        msg.style.filter = 'alpha(opacity=0)';
        msg.style.opacity = 0;
        msg.alpha = 0;
    } else {
        msg = document.getElementById('msg');
        msgcontent = document.getElementById('msgcontent');
    }
    msgcontent.innerHTML = string;
    msg.style.display = 'block';
    var msgheight = msg.offsetHeight;
    var msgwidth = msg.offsetWidth;
    var targetdiv = document.getElementById(target);
     //alert(targetdiv+'sud');
    targetdiv.focus();
    var targetheight = targetdiv.offsetHeight;
    var targetwidth = targetdiv.offsetWidth;

    var topposition;
    if (msgwidth < 200) {
        topposition = topPosition(targetdiv) - ((msgheight - targetheight) / 2) - msgheight;
    }
    else {
        topposition = topPosition(targetdiv) - ((msgheight - targetheight) / 2) - msgheight + 9;
    }
    var leftposition = leftPosition(targetdiv) - (msgwidth / 2) + (targetwidth / 2) + MSGOFFSET;
    msg.style.top = topposition + 'px';
    msg.style.left = leftposition + 'px';
    clearInterval(msg.timer);
    msg.timer = setInterval("fadeMsg(1)", MSGTIMER);
    if (!autohide) {
        autohide = MSGHIDE;
    }
    window.setTimeout("hideMsg()", (autohide * 500));
}

function CheckForMaterialPage2(MasterId, Mat, Thick, Dep, DepName) {
    var IsNumflag;
    var IsThick;
    var IsDep;
    var IsMod;
   // alert('SAud');
    //Numeric Check
    if (checkNumericMaterial(MasterId)) {
        IsNumflag = true;
    }
    else {
        IsNumflag = false;

    }

    //Non zero thickness check for selected material
    if (IsNumflag) {


        for (var i = 1; i <= 10; i++) {
            var MatId = MasterId + "_" + Mat + i;
            var ThickId = MasterId + "_" + Thick + i;
            var MatVal = document.getElementById(MatId).value;
            var ThickVal = document.getElementById(ThickId).value;
            if (MatVal > 0) {
                if (ThickVal == 0) {
                    IsThick = false;
                    inlineMsg(ThickId, "Update did not complete, please enter a positive, non-zero number.");
                    break;

                }
                else {
                    IsThick = true;
                }

            }
            else {
                if (ThickVal > 0) {
                    IsThick = false;
                    inlineMsg(ThickId, "Update did not complete because no material is selected. Please enter zero.");
                    break;
                }
                else {
                    IsThick = true;
                }
            }
        }

    }

    //Cheking Dept.
    if (IsThick) {
        for (var j = 1; j <= 10; j++) {
            var MatId = MasterId + "_" + Mat + j;
            var DepId = MasterId + "_" + Dep + j;
            var DepNameId = MasterId + "_" + DepName + j;
            var MatVal = document.getElementById(MatId).value;
            var DepVal = document.getElementById(DepId).value;
            var DepText = document.getElementById(DepNameId);

            //alert(DepId);
            if (MatVal > 0) {
                if (DepVal == 0) {
                    IsDep = false;
                    inlineMsg(DepNameId, "Update did not complete, please select a department.");
                    break;
                }
                else {
                    if (DepText.innerHTML == 'Dept. Conflict') {
                        IsDep = false;
                        inlineMsg(DepNameId, "Update did not complete, please select a department.");
                        break;
                    }
                    else {
                        IsDep = true;
                    }
                }

            }
            else {
                IsDep = true;
            }

        }
    }

  
    if (IsNumflag && IsThick && IsDep) {
        return true;
    }
    else {
        return false;
    }


}

function CheckForMaterialPageNew(MasterId, Mat, Thick, Dep, DepName,OTRTEMP, RH, TEMPVAL1, TEMPVAL2, RHVAL) {
    var IsNumflag;
    var IsThick;
    var IsDep;
    var IsMod;

    //Numeric Check
    var radbarr = document.getElementById("ctl00_Econ1ContentPlaceHolder_hidBarrier").value;
    if (radbarr == "0") {
        if (checkNumeric2AllWOBarr(MasterId, OTRTEMP, RH, TEMPVAL1, TEMPVAL2, RHVAL)) {
            IsNumflag = true;
        }
        else {
            IsNumflag = false;
        }
    }
    else {
        if (checkNumeric2AllWithBarr(MasterId, OTRTEMP, RH, TEMPVAL1, TEMPVAL2, RHVAL)) {
            IsNumflag = true;
        }
        else {
            IsNumflag = false;
        }
    }

    //Non zero thickness check for selected material
    if (IsNumflag) 
    {
      

        for (var i = 1; i <= 10; i++) {
            var MatId = MasterId + "_" + Mat + i;
            var ThickId = MasterId + "_" + Thick + i;
            var MatVal = document.getElementById(MatId).value;
            var ThickVal = document.getElementById(ThickId).value;
            if (MatVal > 0) {
                if (ThickVal == 0) {
                    IsThick = false;
                    inlineMsg(ThickId, "Update did not complete, please enter a positive, non-zero number.");
                    break;

                }
                else {
                    IsThick = true;
                }

            }
            else {
                if (ThickVal > 0) {
                    IsThick = false;
                    inlineMsg(ThickId, "Update did not complete because no material is selected. Please enter zero.");
                    break;
                }
                else {
                    IsThick = true;
                }
            }
        }

    }

    //Cheking Dept.
    if (IsThick) {
        for (var j = 1; j <= 10; j++) {
            var MatId = MasterId + "_" + Mat + j;
            var DepId = MasterId + "_" + Dep + j;
            var DepNameId = MasterId + "_" + DepName + j;
            var MatVal = document.getElementById(MatId).value;
            var DepVal = document.getElementById(DepId).value;
            var DepText = document.getElementById(DepNameId);

            //alert(DepId);
            if (MatVal > 0) {
                if (DepVal == 0) {
                    IsDep = false;
                    inlineMsg(DepNameId, "Update did not complete, please select a department.");
                    break;
                }
                else {
                    if (DepText.innerHTML == 'Dept. Conflict') {
                        IsDep = false;
                        inlineMsg(DepNameId, "Update did not complete, please select a department.");
                        break;
                    }
                    else {
                        IsDep = true;
                    }
                }

            }
            else {
                IsDep = true;
            }

        }
    }

    //    if (IsDep) 
    //    {
    //             
    //        for (var j = 1; j <= 10; j++) 
    //        {
    //            var ModId = MasterId + "_" + ModType + j;
    //            var CaseId = MasterId + "_" + ModCases + j;           
    //            var ModVal = document.getElementById(ModId).value;
    //            var CaseVal = document.getElementById(CaseId).value;
    //            var CaseNameId = MasterId + "_" + CaseName + j;
    //                              
    //            if (ModVal > 0) 
    //            {
    //                if (CaseVal == 0)
    //                {
    //                    IsMod = false;
    //                    inlineMsg(CaseNameId, "Update did not complete, please select a Case.");
    //                    break;
    //                }
    //                else 
    //                {
    //                   IsMod = true ;
    //                }

    //            }
    //            else 
    //            {
    //                IsMod = true;
    //            }

    //        }
    //    }

    if (IsNumflag && IsThick && IsDep) {
        return true;
    }
    else {
        return false;
    }


}
function checkNumeric2All(MasterId, OTRTEMP, RH, TEMPVAL1, TEMPVAL2, RHVAL) 
{
   
    var txtarray = document.getElementsByTagName("input");
    var flag;
    var anum = /(^\d+$)|(^\d+\.\d+$)/
    var k = 1;
    var k1 = 1;
    var k2 = 1;
    for (var i = 0; i < txtarray.length ; i++) {
        if (txtarray[i].type == "text") {
            var id = txtarray[i].id;
            // alert(id);
            var radbarr = document.getElementById("ctl00_Econ1ContentPlaceHolder_hidBarrier").value;
          //  alert(radbarr);

            if (txtarray[i].value.match(/\S/)) 
            {
                if (radbarr == "1") 
                {
                    if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) 
                    {
                        flag = true;

                    }
                    else {
                        inlineMsg(id, "Invalid Number");
                        flag = false;
                        break;
                    }

                }
                else {
                    var OTRID = MasterId + "_OTR" + k;
                    var WVTRID = MasterId + "_WVTR" + k1;
                    var PRICEID = MasterId + "_P" + k2;
                    if (OTRID == id)//check for Preferred Price Textboxes
                    {
                        k = k + 1;
                        flag = true;
                    }
                    else if (WVTRID == id)//check for Preferred Price Textboxes
                    {
                        k1 = k1 + 1;
                        flag = true;
                    }
                    else if (PRICEID == id)//check for Preferred Price Textboxes
                    {
                        k2 = k2 + 1;
                        if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) {
                            flag = true;


                        }
                        else {
                            inlineMsg(id, "Invalid Number");
                            flag = false;
                            break;
                        }l
                    }
                    else 
                    {
                        if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) {
                            flag = true;


                        }
                        else {
                            inlineMsg(id, "Invalid Number");
                            flag = false;
                            break;
                        }
                    }  
                }
                
                //alert(id + '---' + txtarray[i].value.match(/\S/) + '---' + flag);
            }
            else 
            {
                //alert(id + '---' + txtarray[i].value.match(/\S/) + '---' + flag);
                 
                    var OTRID = MasterId + "_OTR" + k;
                    var WVTRID = MasterId + "_WVTR" + k1;
                    var PRICEID = MasterId + "_P" + k2;
                    if (OTRID == id)//check for Preferred Price Textboxes
                    {
                        k = k + 1;
                        flag = true;
                    }
                    else if (WVTRID == id)//check for Preferred Price Textboxes
                    {
                        k1 = k1 + 1;
                        flag = true;
                    }
                    else if (PRICEID == id)//check for Preferred Price Textboxes
                    {
                        k2 = k2 + 1;
                        flag = true;
                    }
                    else 
                    {
                        if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) {
                            flag = true;


                        }
                        else {
                            inlineMsg(id, "Invalid Number");
                            flag = false;
                            break;
                        }
                    }       
                                
            }


        }

        }
        

        if (CheckForBarrierPageNew(MasterId, OTRTEMP, RH, TEMPVAL1, TEMPVAL2, RHVAL) == true) {
            return flag;

        }
        else {
            return false;
        }
       
    
}

function CheckForBarrierPageNew(MasterId, OTRTEMP, RH, TEMPVAL1, TEMPVAL2, RHVAL) {
    var IsNumflag = true;
    var IsTemp;
    var IsTemp1;
    var IsRH;
    var IsRH2;

    if (IsNumflag) 
    {
        IsTemp = true;
        //alert(IsTemp+'sud1');

        var UID = MasterId + "_UnitId";
        // alert(UID);
       // alert(document.getElementById(UID).value);
        var UIDVAL =  document.getElementById(UID).value;
        // alert(UIDVAL);

        var OTRTEMPL = MasterId + "_" + OTRTEMP + "1";
        var OTRTEMPValL = document.getElementById(OTRTEMPL).value;
        var OTRTEMPH = MasterId + "_" + OTRTEMP + "2";
        var OTRTEMPValH = document.getElementById(OTRTEMPH).value;


        var OTRT = MasterId + "_" + TEMPVAL1;
        var OTRTVal = document.getElementById(OTRT).value;

        if (eval(OTRTVal) < eval(OTRTEMPValL)) {
            IsTemp = false;
        }
        else if (eval(OTRTVal) > eval(OTRTEMPValH)) {
            IsTemp = false;
        }
        if (!IsTemp) 
        {
            istemp = false;
            if (UIDVAL == "0") 
            {
                inlineMsgBarrier("ctl00_Econ1ContentPlaceHolder_txtOTRTemp", "Please enter a value between 32 and 122 Fahrenheit.");
            }
            else 
            {
                inlineMsgBarrier("ctl00_Econ1ContentPlaceHolder_txtOTRTemp", "Please enter a value between 0 and 50 celsius");
            }
        }
      

    }

    if (IsTemp) 
    {
        IsTemp1 = true;

        var OTRTEMPL = MasterId + "_" + OTRTEMP + "1";
        var OTRTEMPValL = document.getElementById(OTRTEMPL).value;
        var OTRTEMPH = MasterId + "_" + OTRTEMP + "2";
        var OTRTEMPValH = document.getElementById(OTRTEMPH).value;


        var WVTRT = MasterId + "_" + TEMPVAL2;
        var WVTRTVal = document.getElementById(WVTRT).value;

        if (eval(WVTRTVal) < eval(OTRTEMPValL)) {
            IsTemp1 = false;
        }
        else if (eval(WVTRTVal) > eval(OTRTEMPValH)) {
            IsTemp1 = false;
        }
        if (!IsTemp1) 
        {
            istemp1 = false;

            if (UIDVAL == "0") {
                inlineMsgBarrier("ctl00_Econ1ContentPlaceHolder_txtWVTRTemp", "Please enter a value between 32 and 122 Fahrenheit.");
            }
            else {
                inlineMsgBarrier("ctl00_Econ1ContentPlaceHolder_txtWVTRTemp", "Please enter a value between 0 and 50 celsius");
            }
            //inlineMsgBarrier("ctl00_Econ1ContentPlaceHolder_txtWVTRTemp", "Update did not complete.Please enter proper Temprature.");

        }
       
    }
    //    alert('ok');
    if (IsTemp1) {
        IsRH = true;
        //alert(IsTemp+'sud2');

        var RHL = MasterId + "_" + RH + "1";
        var RHValL = document.getElementById(RHL).value;


        var RHH = MasterId + "_" + RH + "2";
        var RHValH = document.getElementById(RHH).value;
        //alert(RHValH);

        var OTRRH = MasterId + "_" + RHVAL;
        var RHVal = document.getElementById(OTRRH).value;
        //alert(RHVal);

        if (eval(RHVal) < eval(RHValL)) {
            IsRH = false;
        }
        else if (eval(RHVal) > eval(RHValH)) {
            IsRH = false;
        }
        //alert(IsRH);
        if (!IsRH) 
        {
            IsRH = false;
            // var OTRV = OTRT.replace(/^\s+|\s+$/g, '');
            //  alert(OTRT);
            //inlineMsg(OTRT, "Update did not complete.Please enter proper Temprature.");
            inlineMsgBarrier("ctl00_Econ1ContentPlaceHolder_txtOTRHumidity", "Please enter a value between 0% and 100%.");

        }

    }
  
    if (IsRH) {
        IsRH2 = true;
        //alert(IsTemp+'sud2');

        var RHL = MasterId + "_" + RH + "1";
        var RHValL = document.getElementById(RHL).value;


        var RHH = MasterId + "_" + RH + "2";
        var RHValH = document.getElementById(RHH).value;
        //alert(RHValH);

        var WVTRRH = MasterId + "_txtWVTRHumidity";
        var RHVal = document.getElementById(WVTRRH).value;
        //alert(RHVal);

        //        if (eval(RHVal) != 100) {
        //            IsRH2 = false;
        //           
        //        }

        if (eval(RHVal) < 90) {
            IsRH2 = false;

        }
        else if (eval(RHVal) > 100) {
            IsRH2 = false;

        }

        if (!IsRH2) {
            IsRH2 = false;

            inlineMsgBarrier("ctl00_Econ1ContentPlaceHolder_txtWVTRHumidity", "Please enter a value between 90% and 100%.");

        }

    }

    //alert(IsNumflag + '-' + IsTemp + '-' + IsRH2 + '-' + IsRH);
    if (IsNumflag && IsTemp && IsRH & IsRH2) {
        
        return true;
    }
    else {
       
        return false;
    }
}

function checkNumeric2AllWOBarr(MasterId, OTRTEMP, RH, TEMPVAL1, TEMPVAL2, RHVAL) {

    var txtarray = document.getElementsByTagName("input");
    var flag;
    var anum = /(^\d+$)|(^\d+\.\d+$)/
    var k = 1;
    var k1 = 1;
    var k2 = 1;
    var radbarr = document.getElementById("ctl00_Econ1ContentPlaceHolder_hidBarrier").value;
    //alert(radbarr);

    for (var i = 0; i < txtarray.length; i++) {
        if (txtarray[i].type == "text") {
            var id = txtarray[i].id;
            var OTRID = MasterId + "_OTR" + k;
            var WVTRID = MasterId + "_WVTR" + k1;
            var PRICEID = MasterId + "_P" + k2;
            // alert(id);
            if (txtarray[i].value.match(/\S/)) {

                if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) {
                    flag = true;
                    if (OTRID == id)//check for Preferred Price Textboxes
                    {
                        k = k + 1;
                        flag = true;
                    }
                    else if (WVTRID == id)//check for Preferred Price Textboxes
                    {
                        k1 = k1 + 1;
                        flag = true;
                    }
                    else if (PRICEID == id)//check for Preferred Price Textboxes
                    {
                        k2 = k2 + 1;
                        flag = true;
                    }
                }
                else {

                    inlineMsg(id, "Invalid Number");
                    flag = false;
                    break;
                }

            }
            else {
               // alert(id + '---' + txtarray[i].value.match(/\S/) + '---' + flag);

                if (OTRID == id)//check for Preferred Price Textboxes
                {
                    k = k + 1;
                    flag = true;
                }
                else if (WVTRID == id)//check for Preferred Price Textboxes
                {
                    k1 = k1 + 1;
                    flag = true;
                }
                else if (PRICEID == id)//check for Preferred Price Textboxes
                {
                    k2 = k2 + 1;
                    flag = true;
                }

                else {
                    if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) {
                        flag = true;
                    }
                    else {
                        inlineMsg(id, "Invalid Number");
                        flag = false;
                        break;
                    }
                }

            }


        }

    }
   // alert(flag);
    return flag;


}





function checkNumeric2AllWithBarr(MasterId, OTRTEMP, RH, TEMPVAL1, TEMPVAL2, RHVAL) {

    var txtarray = document.getElementsByTagName("input");
    var flag;
    var anum = /(^\d+$)|(^\d+\.\d+$)/
    var k = 1;
    var k1 = 1;
    var k2 = 1;
    var radbarr = document.getElementById("ctl00_Econ1ContentPlaceHolder_hidBarrier").value;
  //  alert('sud1');

    for (var i = 0; i < txtarray.length; i++) {
        if (txtarray[i].type == "text") {
            var id = txtarray[i].id;
            var OTRID = MasterId + "_OTR" + k;
            var WVTRID = MasterId + "_WVTR" + k1;
            var PRICEID = MasterId + "_P" + k2;
            // alert(id);
            if (txtarray[i].value.match(/\S/)) 
            {

                if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) 
                {
                    flag = true;
                    if (OTRID == id)//check for Preferred Price Textboxes
                    {
                        k = k + 1;
                        flag = true;
                    }
                    else if (WVTRID == id)//check for Preferred Price Textboxes
                    {
                        k1 = k1 + 1;
                        flag = true;
                    }
                    else if (PRICEID == id)//check for Preferred Price Textboxes
                    {
                        k2 = k2 + 1;
                        flag = true;
                    }
                }
                else 
                {
                   // alert('sud');
                    inlineMsg(id, "Invalid Number");
                 //   alert('sud2');
                    flag = false;
                    break;
                }

            }
            else 
            {
                //alert(id + '---' + txtarray[i].value.match(/\S/) + '---' + flag);

                if (OTRID == id)//check for Preferred Price Textboxes
                {
                    k = k + 1;
                    flag = true;
                }
                else if (WVTRID == id)//check for Preferred Price Textboxes
                {
                    k1 = k1 + 1;
                    flag = true;
                }
                else if (PRICEID == id)//check for Preferred Price Textboxes
                {
                    k2 = k2 + 1;
                    flag = true;
                }

                else {
                    if (IsNumeric(txtarray[i].value.replace(/,/g, ""))) {
                        flag = true;
                    }
                    else {
                        inlineMsg(id, "Invalid Number");
                        flag = false;
                        break;
                    }
                }

            }


        }

    }
    //alert(flag);
    if (flag) {
        if (CheckForBarrierPageNew(MasterId, OTRTEMP, RH, TEMPVAL1, TEMPVAL2, RHVAL) == true) {
            return flag;

        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
   

}