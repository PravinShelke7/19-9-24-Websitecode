﻿Imports System.Data

Partial Class DownLoad_DownloadHistory
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Dim objCrypt As New CryptoHelper
            hdnUserId.Value = objCrypt.Decrypt(Request.QueryString("Id").ToString())

            If Not IsPostBack Then
                getDownloadDeatils()
                hvUserGrd.Value = "0"
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub getDownloadDeatils()
        Dim ds As New DataSet
        Dim objGetData As New ShopGetData.DownloadGetData()
        Try
            ds = objGetData.GetDwnldLogDetails(hdnUserId.Value)
            ViewState("DwnldHistory") = ds
            grdDownLoadDetails.DataSource = ds
            grdDownLoadDetails.DataBind()
        Catch ex As Exception
            '_lErrorLble.Text = "Error:getUserDeatils:" + ex.Message.ToString()
        End Try
    End Sub
#Region "User Grid Events"
    'Protected Sub grdDownLoadDetails_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdDownLoadDetails.SelectedIndexChanged
    '    Try
    '        Dim factId As New Integer
    '        factId = Convert.ToInt32(grdDownLoadDetails.SelectedDataKey.Value)
    '        Response.Redirect("EditFact.aspx?ID=" + factId.ToString() + "&FactType=" + ddlFactType.SelectedItem.Value, False)
    '    Catch ex As Exception

    '    End Try
    'End Sub
    Protected Sub grdDownLoadDetails_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdDownLoadDetails.PageIndexChanging
        Try
            grdDownLoadDetails.PageIndex = e.NewPageIndex
            BindUserGridUsingSession()
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub grdDownLoadDetails_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles grdDownLoadDetails.Sorting
        Try
            Dim Dts As New DataSet
            Dim dv As DataView
            Dim numberDiv As Integer
            numberDiv = Convert.ToInt16(hvUserGrd.Value.ToString())
            Dts = ViewState("DwnldHistory")
            dv = Dts.Tables(0).DefaultView

            If ((numberDiv Mod 2) = 0) Then
                dv.Sort = e.SortExpression + " " + "DESC"
            Else
                dv.Sort = e.SortExpression + " " + "ASC"
            End If

            numberDiv += 1
            hvUserGrd.Value = numberDiv.ToString()
            grdDownLoadDetails.DataSource = dv
            grdDownLoadDetails.DataBind()
            'lblmsg.Visible = False
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub BindUserGridUsingSession()
        Try
            Dim Dts As New DataSet
            Dts = ViewState("DwnldHistory")
            grdDownLoadDetails.DataSource = Dts
            grdDownLoadDetails.DataBind()
        Catch ex As Exception

        End Try
    End Sub
#End Region
End Class
