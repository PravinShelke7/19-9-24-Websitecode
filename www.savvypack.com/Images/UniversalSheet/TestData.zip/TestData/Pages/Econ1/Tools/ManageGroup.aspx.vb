Imports System.Data
Imports System.Data.OleDb
Imports System.HttpStyleUriParser
Imports System.Web.UI.WebControls
Imports E1GetData
Imports E1UpInsData
Partial Class Pages_Econ1_Tools_ManageGroup
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Session("Back") = Nothing Then
                Dim obj As New CryptoHelper
                Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE112") + "")
            End If

            If Not IsPostBack Then
                GetPCaseDetails()

                If Session("E1GroupID") <> Nothing Then
                    Dim ObjGetData As New E1GetData.Selectdata()
                    Dim ds As New DataSet()
                    ds = ObjGetData.GetGroupDetailsByID(Session("E1GroupID").ToString())
                    If ds.Tables(0).Rows.Count > 0 Then
                        lnkGroup.Text = ds.Tables(0).Rows(0).Item("GroupID").ToString() + ":" + ds.Tables(0).Rows(0).Item("GDES").ToString()
                        hidGroupID.Value = Session("E1GroupID").ToString()
                    End If
                Else
                    hidGroupID.Value = "0"
                End If
            End If
        Catch ex As Exception
            lblError.Text = "Page_Load:" + ex.Message
        End Try
    End Sub
    Protected Sub GetPCaseDetails()
        Dim objGetData As New E1GetData.Selectdata
        Dim ds As New DataSet
        Try
            ds = objGetData.GetPCaseDetails(Session("E1UserName").ToString())
            With lstCases
                .DataSource = ds
                .DataTextField = "CASEDES"
                .DataValueField = "CASEID"
                .DataBind()
                .Font.Size = 8
            End With
        Catch ex As Exception
            lblError.Text = "GetPCaseDetails:" + ex.Message
        End Try
    End Sub
    Protected Sub btnCreateGrp_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCreateGrp.Click
        Try
            Dim Caseid As String
            Dim ID As String = 1
            Dim Name As String = ""
            Name = Trim(txtGroupDe1.Text)
            Dim CaseArray() As String
            Dim objUpdateData As New E1UpInsData.UpdateInsert
            Dim objGetData As New E1GetData.Selectdata()
            Dim dt As New DataSet()
            Dim message As String
            Dim message1 As String
            'Validating Cases
            Caseid = Request.Form("lstCases")
            dt = objGetData.ValiDateGroupcases(Caseid, Session("UserId").ToString())

            If dt.Tables(0).Rows.Count > 0 Then
                message = "--------------------------------------------------------------------\n"
                message1 = message + "Cases can only be included in one group.\n"
                For i = 0 To dt.Tables(0).Rows.Count - 1
                    message1 = message1 + "      Cases " + dt.Tables(0).Rows(i).Item("CaseID").ToString() + " is included in group " + dt.Tables(0).Rows(i).Item("GroupName").ToString()
                    If i = dt.Tables(0).Rows.Count - 1 Then
                        message1 = message1 + "\n" + message + "\n"
                    Else
                        message1 = message1 + "\n"
                    End If
                Next
                message = message + "--------------------------------------------------------------------\n"
                trCreate.Style.Add("Display", "Inline")
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "New_WinCopy", "alert('" + message1 + "');", True)
            Else
                If Name.Length <> 0 Then
                    CaseArray = Split(Caseid, ",")
                    objUpdateData.AddGroup(txtGroupDe1.Text, txtGroupDe2.Text, Session("UserId"), CaseArray)

                    txtGroupDe1.Text = ""
                    txtGroupDe2.Text = ""
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "New_WinRename", "alert('Group created successfully');", True)
                    trCreate.Style.Add("Display", "none")
                End If
            End If
           
        Catch ex As Exception
            lblError.Text = "btnCreateGrp_Click:" + ex.Message
        End Try
    End Sub
    Protected Sub btEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btEdit.Click
        Try
            Dim obj As New CryptoHelper
            Session("E1GroupID") = hidGroupID.Value
            Response.Redirect("EditComparision.aspx?Id=" + obj.Encrypt(hidGroupID.Value))
        Catch ex As Exception
            lblError.Text = "btnCreateGrp_Click:" + ex.Message
        End Try
    End Sub
    Protected Sub btnGlobalManager_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnGlobalManager.Click
        Try
            Session("E1GroupID") = Nothing
            Response.Redirect("~/Pages/Econ1/Default.aspx")
        Catch ex As Exception

        End Try
    End Sub
End Class
