﻿
Partial Class Pages_Econ1_Default3
    Inherits System.Web.UI.Page

End Class
