﻿
Partial Class Pages_Econ1_Default4
    Inherits System.Web.UI.Page

End Class
