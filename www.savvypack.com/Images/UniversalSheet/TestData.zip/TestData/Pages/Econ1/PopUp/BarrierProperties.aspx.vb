﻿Imports System.Data
Imports System.Data.OleDb
Imports System
Imports E1GetData
Imports E1UpInsData
Imports System.Collections
Imports System.IO.StringWriter
Imports System.Math
Imports System.Web.UI.HtmlTextWriter
Partial Class Pages_Econ1_PopUp_BarrierProperties
    Inherits System.Web.UI.Page
    Shared objCalc As New BarrierCalc.Calculations

#Region "Get Set Variables"
    Dim _lErrorLble As Label
    Dim _iCaseId As Integer
    Dim _iUserId As Integer
    Dim _strUserRole As String
    Dim _ctlContentPlaceHolder As ContentPlaceHolder
    Dim _btnUpdate As ImageButton
    Dim _divMainHeading As HtmlGenericControl
    Dim _hypPref As HyperLink
    Public Property MainHeading() As HtmlGenericControl
        Get
            Return _divMainHeading
        End Get
        Set(ByVal value As HtmlGenericControl)
            _divMainHeading = value
        End Set
    End Property
    Public Property ErrorLable() As Label
        Get
            Return _lErrorLble
        End Get
        Set(ByVal Value As Label)
            _lErrorLble = Value
        End Set
    End Property
    Public Property HypePref() As HyperLink
        Get
            Return _hypPref
        End Get
        Set(ByVal Value As HyperLink)
            _hypPref = Value
        End Set
    End Property
    Public Property CaseId() As Integer
        Get
            Return _iCaseId
        End Get
        Set(ByVal Value As Integer)
            _iCaseId = Value
        End Set
    End Property

    Public Property UserId() As Integer
        Get
            Return _iUserId
        End Get
        Set(ByVal Value As Integer)
            _iUserId = Value
        End Set
    End Property

    Public Property UserRole() As String
        Get
            Return _strUserRole
        End Get
        Set(ByVal Value As String)
            _strUserRole = Value
        End Set
    End Property
    Public Property ctlContentPlaceHolder() As ContentPlaceHolder
        Get
            Return _ctlContentPlaceHolder
        End Get
        Set(ByVal value As ContentPlaceHolder)
            _ctlContentPlaceHolder = value
        End Set
    End Property
    Public Property Updatebtn() As ImageButton
        Get
            Return _btnUpdate
        End Get
        Set(ByVal value As ImageButton)
            _btnUpdate = value
        End Set
    End Property

    Public DataCnt As Integer
    Public CaseDesp As New ArrayList
#End Region

#Region "MastePage Content Variables"

    Protected Sub GetMasterPageControls()
        GetErrorLable()
        GetContentPlaceHolder()
        GetUpdatebtn()
        GetMainHeadingdiv()
        GetHyperPref()
    End Sub
    Protected Sub GetHyperPref()
        HypePref = Page.Master.FindControl("hypPref")
        HypePref.NavigateUrl = "../Pages/Econ1/Assumptions/Preferences.aspx"
        HypePref.Visible = True
    End Sub
    Protected Sub GetErrorLable()
        ErrorLable = Page.Master.FindControl("lblError")
    End Sub
    Protected Sub GetContentPlaceHolder()
        ctlContentPlaceHolder = Page.Master.FindControl("E1InkContentPlaceHolder")
    End Sub
    Protected Sub GetUpdatebtn()
        Updatebtn = Page.Master.FindControl("imgUpdate")
        Updatebtn.Visible = True

        Updatebtn.Attributes.Add("onclick", "return CheckForBarrierPage('" + ctlContentPlaceHolder.ClientID + "','OTRTEMP','RH','txtOTRTemp','txtWVTRTemp','txtOTRHumidity','txtWVTRHumidity');")

        Updatebtn.Attributes.Add("OnClientClick", "return refreshParent();")

        AddHandler Updatebtn.Click, AddressOf Update_Click
    End Sub
    Protected Sub GetMainHeadingdiv()
        MainHeading = Page.Master.FindControl("divMainHeading")
        MainHeading.Attributes.Add("onmouseover", "Tip('Properties  Assistant')")
        MainHeading.Attributes.Add("onmouseout", "UnTip()")
        MainHeading.InnerHtml = "Econ1 - Properties  Assistant"
    End Sub
#End Region

#Region "Browser Refresh Check"
    Dim objRefresh As zCon.Net.Refresh

    Protected Sub Page_PreInit(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreInit
        objRefresh = New zCon.Net.Refresh("_PAGES_ECON1_POPUP_INKCOST")
    End Sub

    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        objRefresh.Render(Page)
    End Sub

#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Session("Back") = Nothing Then
                Dim obj As New CryptoHelper
                Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE112") + "")
            End If
            GetSessionDetails()
            GetMasterPageControls()

            If Not IsPostBack Then
                ViewState("TabId") = 1
                ViewState("UnitId1") = Session("UnitId")
                'Calculate()
                GetPageDetailsForTab()
                GetTempRH()
            Else

            End If
            CreateTab()
        Catch ex As Exception
            ErrorLable.Text = "Error:Page_Load:" + ex.Message.ToString() + ""
        End Try
    End Sub

    Protected Sub CreateTab()
        Dim tr As New TableRow
        Dim td As New TableCell
        Dim i As New Integer
        Dim lnk As New LinkButton
        Try
            tblTab.Rows.Clear()
            For i = 1 To 3
                td = New TableCell
                lnk = New LinkButton
                If i = 1 Then
                    lnk.Text = "Barrier Properties "
                ElseIf i = 2 Then
                    lnk.Text = "Physical Properties "
                Else
                    lnk.Text = "Chemical Properties "
                End If



                lnk.CssClass = "TabLink"
                lnk.ID = "lnkProperty" + i.ToString()
                ' If ViewState("TabId").ToString() = "1" Then
                'lnk.Attributes.Add("onclick", "return CheckForPalletIn('" + ctlContentPlaceHolder.ClientID + "','hidMatId','PWT','MWT')")
                '  ElseIf ViewState("TabId").ToString() = "2" Then
                ' lnk.Attributes.Add("onclick", "return checkNumericAll();")
                ' End If

                AddHandler lnk.Click, AddressOf lnkProperty_Click
                If i = Convert.ToInt32(ViewState("TabId").ToString()) Then
                    td.CssClass = "AlterNateTab3"
                Else
                    td.CssClass = "AlterNateTab4"
                End If
                td.Controls.Add(lnk)
                tr.Controls.Add(td)
            Next
            tblTab.Controls.Add(tr)
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub lnkProperty_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            If ViewState("UnitId1") <> Session("UnitId") Then
                'If Not Session("Post") Is Nothing And Session("Post") <> Session("Prev") Then
                GetPageDetailsForBarrier()
                ScriptManager.RegisterStartupScript(Page, Me.GetType(), "JSScript", "alert('There has been done changes in Preference page,Please close this page and reopen again.');", True)
                Exit Sub
            End If
            Dim lnk As LinkButton = DirectCast(sender, System.Web.UI.WebControls.LinkButton)
            'UpdatePage() --399
            ViewState("TabId") = Convert.ToInt32(lnk.ID.Replace("lnkProperty", "").ToString())
            ' If Not IsNothing(ViewState("TabId")) Then
            'If ViewState("TabId").ToString() = "1" Then
            '  'Updatebtn.Attributes.Add("onclick", "return CheckForPalletIn('" + ctlContentPlaceHolder.ClientID + "','hidMatId','PWT','MWT')")
            ' ElseIf ViewState("TabId").ToString() = "2" Then
            ' Updatebtn.Attributes.Add("onclick", "return checkNumericAll();")
            '  End If
            ' End If
            CreateTab()

            GetPageDetailsForTab()
        Catch ex As Exception
            Response.Write("lnkPallet_Click" + ex.Message)
        End Try
    End Sub

    Protected Sub GetPageDetailsForTab()
        Dim ds As New DataSet
        Dim objGetData As New E1GetData.Selectdata
        Try

            'objCalc.InjectionMoldCalculate(CaseId)
            ' ds = objGetData.GetInjectionDetails(CaseId)
            If ViewState("TabId") = "1" Then
                GetPageDetailsForBarrier()
            ElseIf ViewState("TabId") = "2" Then
                TblBarHeader.Visible = False
            Else
                TblBarHeader.Visible = False
            End If

        Catch ex As Exception
            _lErrorLble.Text = "Error:GetPageDetails:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Sub GetTempRH()
        Dim ds1 As New DataSet()
        Dim ds2 As New DataSet()
        Dim ds3 As New DataSet()
        Dim objGetData As New E1GetData.Selectdata()
        Try
            ds3 = objGetData.GetPrefDetails(CaseId)
            ds1 = objGetData.GetMinMaxBarrierTemp()
            ds2 = objGetData.GetMinMaxBarrierHumidity()

            If ds1.Tables(0).Rows.Count > 0 Then
                If ds3.Tables(0).Rows(0).Item("UNITS").ToString() <> "1" Then
                    OTRTEMP1.Value = ds1.Tables(0).Rows(0).Item("MINVAL").ToString()
                    OTRTEMP2.Value = ds1.Tables(0).Rows(0).Item("MAXVAL").ToString()
                Else
                    OTRTEMP1.Value = (CDbl(ds1.Tables(0).Rows(0).Item("MINVAL").ToString()) - 32) * (5 / 9)
                    OTRTEMP2.Value = (CDbl(ds1.Tables(0).Rows(0).Item("MAXVAL").ToString()) - 32) * (5 / 9)
                End If

            End If

                If ds2.Tables(0).Rows.Count > 0 Then
                    RH1.Value = ds2.Tables(0).Rows(0).Item("MINVAL").ToString()
                    RH2.Value = ds2.Tables(0).Rows(0).Item("MAXVAL").ToString()
                End If

        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GetSessionDetails()
        Try
            UserId = Session("UserId")
            CaseId = Session("E1CaseId")
            UserRole = Session("E1UserRole")
        Catch ex As Exception
            _lErrorLble.Text = "Error:GetSessionDetails:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Sub GetPageDetailsForBarrier()
        Dim ds As New DataSet
        Dim dts As New DataSet
        Dim objGetData As New E1GetData.Selectdata
        Dim i As New Integer
        Dim j As New Integer
        Dim DWidth As String = String.Empty
        Dim trHeader As New TableRow
        Dim trHeader1 As New TableRow
        Dim trHeader2 As New TableRow

        Dim trInner As New TableRow
        Dim tdHeader1 As TableCell
        Dim tdHeader As TableCell
        Dim tdHeader2 As TableCell


        Dim lbl As New Label
        Dim hid As New HiddenField
        Dim Link As New HyperLink
        Dim txt As New TextBox
        Dim tdInner As TableCell
        Dim OTRFlag As String
        Dim WVTRFlag As String
        Dim OTR As String
        Dim WVTR As String
        Dim chk As New CheckBox

        Dim radio As New RadioButton

        Try
            TblBarHeader.Visible = True
            ds = objGetData.GetBarriersDetails(CaseId)
            dts = objGetData.GetBarrierInput(CaseId)
            OTRFlag = GetOTRFlag(ds.Tables(0).Rows(0).Item("OTRTEMP").ToString(), ds.Tables(0).Rows(0).Item("OTRRH").ToString())
            WVTRFlag = GetOTRFlag(ds.Tables(0).Rows(0).Item("WVTRTEMP").ToString(), ds.Tables(0).Rows(0).Item("WVTRRH").ToString())


            If ds.Tables(0).Rows(0).Item("UNITS").ToString() <> 1 Then
                OTR = ds.Tables(0).Rows(0).Item("OTRTEMP").ToString()
                WVTR = ds.Tables(0).Rows(0).Item("WVTRTEMP").ToString()
            Else
                OTR = (CDbl(ds.Tables(0).Rows(0).Item("OTRTEMP").ToString()) - 32) * 5 / 9
                WVTR = (CDbl(ds.Tables(0).Rows(0).Item("WVTRTEMP").ToString()) - 32) * 5 / 9
            End If

            objCalc.BarrierPropCalculate(CaseId, OTRFlag, WVTRFlag, ds.Tables(0).Rows(0).Item("OTRTEMP").ToString(), ds.Tables(0).Rows(0).Item("WVTRTEMP").ToString(), ds.Tables(0).Rows(0).Item("OTRRH").ToString(), ds.Tables(0).Rows(0).Item("WVTRRH").ToString())

            If objCalc.Msg <> "" Then

                Page.ClientScript.RegisterStartupScript(Me.GetType(), "New_WinRename", "alert('" + objCalc.Msg + "');", True)
            End If

            lblOTRTemp.Text = "OTR Temperature(" + ds.Tables(0).Rows(0).Item("TITLE20").ToString() + "):"
            lblWVTRTemp.Text = "WVTR Temperature(" + ds.Tables(0).Rows(0).Item("TITLE20").ToString() + "):"

            txtOTRTemp.Text = OTR 'ds.Tables(0).Rows(0).Item("OTRTEMP").ToString()
            txtWVTRTemp.Text = WVTR 'ds.Tables(0).Rows(0).Item("WVTRTEMP").ToString()
            txtOTRHumidity.Text = ds.Tables(0).Rows(0).Item("OTRRH").ToString()
            txtWVTRHumidity.Text = ds.Tables(0).Rows(0).Item("WVTRRH").ToString()
            If ds.Tables(0).Rows(0).Item("OTRTEMP").ToString() <> 1 Then
                OTR = ds.Tables(0).Rows(0).Item("OTRTEMP").ToString()
                WVTR = ds.Tables(0).Rows(0).Item("WVTRTEMP").ToString()
            Else
                OTR = (CDbl(ds.Tables(0).Rows(0).Item("OTRTEMP").ToString()) - 32) * 5 / 9
                WVTR = (CDbl(ds.Tables(0).Rows(0).Item("WVTRTEMP").ToString()) - 32) * 5 / 9
            End If
            For i = 1 To 8
                tdHeader = New TableCell
                tdHeader1 = New TableCell
                tdHeader2 = New TableCell
                Dim Title As String = String.Empty
                'Header
                Select Case i
                    Case 1
                        HeaderTdSetting(tdHeader, "50px", "Layers", "1")
                        Header2TdSetting(tdHeader2, "", "", "1")
                        Header2TdSetting(tdHeader1, "", "", "1")
                        trHeader.Controls.Add(tdHeader)
                        trHeader2.Controls.Add(tdHeader2)
                        trHeader1.Controls.Add(tdHeader1)
                    Case 2
                        HeaderTdSetting(tdHeader, "180px", "Primary Materials", "1")
                        Header2TdSetting(tdHeader2, "", "", "1")
                        Header2TdSetting(tdHeader1, "", "", "1")
                        trHeader.Controls.Add(tdHeader)
                        trHeader2.Controls.Add(tdHeader2)
                        trHeader1.Controls.Add(tdHeader1)
                    Case 3
                        HeaderTdSetting(tdHeader, "50px", "Grade", "1")
                        Header2TdSetting(tdHeader2, "", "", "1")
                        Header2TdSetting(tdHeader1, "", "", "1")
                        trHeader.Controls.Add(tdHeader)
                        trHeader2.Controls.Add(tdHeader2)
                        trHeader1.Controls.Add(tdHeader1)
                    Case 4
                        Title = "(" + ds.Tables(0).Rows(0).Item("TITLE1").ToString() + ")"
                        HeaderTdSetting(tdHeader, "70px", "Thickness", "1")
                        Header2TdSetting(tdHeader2, "", Title, "1")
                        Header2TdSetting(tdHeader1, "", "", "1")
                        trHeader.Controls.Add(tdHeader)
                        trHeader2.Controls.Add(tdHeader2)
                        trHeader1.Controls.Add(tdHeader1)
                    Case 5
                        Title = "" + ds.Tables(0).Rows(0).Item("TITLE19").ToString() + ""
                        HeaderTdSetting(tdHeader, "110px", "OTR", "2")
                        tdHeader.Attributes.Add("Title", "Oxygen Transformation Rate")
                        Header2TdSetting(tdHeader1, "76px", "Suggested", "1")
                        If ds.Tables(0).Rows(0).Item("UNITS").ToString() = "1" Then
                            Header2TdSetting(tdHeader2, "", "(cc/ " + Title + "/day)", "2")
                        Else
                            Header2TdSetting(tdHeader2, "", "(cc/100 " + Title + "/day)", "2")
                        End If

                        trHeader.Controls.Add(tdHeader)
                        trHeader2.Controls.Add(tdHeader2)
                        trHeader1.Controls.Add(tdHeader1)
                    Case 6
                        Header2TdSetting(tdHeader1, "76px", "Preferred", "1")
                        trHeader1.Controls.Add(tdHeader1)
                    Case 7
                        Title = "" + ds.Tables(0).Rows(0).Item("TITLE19").ToString() + ""
                        HeaderTdSetting(tdHeader, "110px", "WVTR", "2")
                        tdHeader.Attributes.Add("Title", "Water Vapour Transformation Rate")
                        Header2TdSetting(tdHeader1, "76px", "Suggested", "1")
                        If ds.Tables(0).Rows(0).Item("UNITS").ToString() = "1" Then
                            Header2TdSetting(tdHeader2, "", "(gm/" + Title + "/day)", "2")
                        Else
                            Header2TdSetting(tdHeader2, "", "(gm/100 " + Title + "/day)", "2")
                        End If

                        trHeader.Controls.Add(tdHeader)
                        trHeader2.Controls.Add(tdHeader2)
                        trHeader1.Controls.Add(tdHeader1)
                    Case 8
                        Header2TdSetting(tdHeader1, "76px", "Preferred", "1")
                        trHeader1.Controls.Add(tdHeader1)
                End Select





            Next
            trHeader.Height = 30
            trHeader.Height = 30

            tblComparision.Controls.Add(trHeader)
            tblComparision.Controls.Add(trHeader2)
            tblComparision.Controls.Add(trHeader1)



            'Inner
            For i = 1 To 10
                trInner = New TableRow
                For j = 1 To 9
                    tdInner = New TableCell

                    Select Case j
                        Case 1
                            'Layer
                            InnerTdSetting(tdInner, "", "Center")
                            tdInner.Text = "<b>" + i.ToString() + "</b>"
                            trInner.Controls.Add(tdInner)
                        Case 2
                            InnerTdSetting(tdInner, "", "Left")
                            Link = New HyperLink
                            hid = New HiddenField
                            Link.ID = "hypMatDes" + i.ToString()
                            hid.ID = "hidMatid" + i.ToString()
                            Link.Width = 120
                            Link.CssClass = "Link"
                            GetMaterialDetails(Link, hid, CInt(ds.Tables(0).Rows(0).Item("M" + i.ToString() + "").ToString()), "hypGradeDes" + i.ToString(), "hidGradeId" + i.ToString())
                            tdInner.Controls.Add(hid)
                            tdInner.Controls.Add(Link)
                            trInner.Controls.Add(tdInner)
                        Case 3
                            InnerTdSetting(tdInner, "", "Left")
                            Link = New HyperLink
                            hid = New HiddenField
                            Link.ID = "hypGradeDes" + i.ToString()
                            hid.ID = "hidGradeId" + i.ToString()
                            Link.Width = 100
                            Link.CssClass = "Link"
                            GetGrades(Link, hid, "hidMatid" + i.ToString(), CInt(dts.Tables(0).Rows(0).Item("GRADE" + i.ToString() + "").ToString()))
                            tdInner.Controls.Add(hid)
                            tdInner.Controls.Add(Link)
                            trInner.Controls.Add(tdInner)
                        Case 4
                            InnerTdSetting(tdInner, "", "Center")
                            txt = New TextBox
                            txt.CssClass = "SmallTextBox"
                            txt.ID = "T" + i.ToString()
                            txt.Text = FormatNumber(ds.Tables(0).Rows(0).Item("THICK" + i.ToString() + "").ToString(), 3)
                            txt.MaxLength = 6

                            tdInner.Controls.Add(txt)
                            trInner.Controls.Add(tdInner)

                        Case 5
                            InnerTdSetting(tdInner, "", "Right")
                            lbl = New Label

                            If dts.Tables(0).Rows(0).Item("GRADE" + i.ToString() + "").ToString() <> 0 Then
                                If ds.Tables(0).Rows(0).Item("UNITS").ToString() = "1" Then
                                    lbl.Text = FormatNumber(CDbl(objCalc.OTR(i - 1)) / (CDbl(ds.Tables(0).Rows(0).Item("CONVAREA").ToString()) / 1000) / 100, 3)

                                Else
                                    lbl.Text = FormatNumber(objCalc.OTR(i - 1), 3)
                                End If
                            Else
                                lbl.Text = ""
                            End If



                            tdInner.Controls.Add(lbl)
                            trInner.Controls.Add(tdInner)
                        Case 6
                            InnerTdSetting(tdInner, "", "Center")
                            txt = New TextBox
                            txt.CssClass = "SmallTextBox"
                            txt.ID = "OTR" + i.ToString()
                            If Not IsNumeric(dts.Tables(0).Rows(0).Item("OTR" + i.ToString())) Then
                                txt.Text = ""
                            Else
                                If ds.Tables(0).Rows(0).Item("UNITS").ToString() = "1" Then
                                    txt.Text = FormatNumber(CDbl(dts.Tables(0).Rows(0).Item("OTR" + i.ToString())) / (CDbl(ds.Tables(0).Rows(0).Item("CONVAREA").ToString()) / 1000) / 100, 3)
                                Else
                                    txt.Text = FormatNumber(dts.Tables(0).Rows(0).Item("OTR" + i.ToString()).ToString(), 3)
                                End If


                            End If
                            ' txt.Text = FormatNumber(dts.Tables(0).Rows(0).Item("OTR" + i.ToString()), 3)
                            txt.MaxLength = 6

                            tdInner.Controls.Add(txt)
                            trInner.Controls.Add(tdInner)
                        Case 7
                            InnerTdSetting(tdInner, "", "Right")
                            lbl = New Label
                            If dts.Tables(0).Rows(0).Item("GRADE" + i.ToString() + "").ToString() <> 0 Then
                                If ds.Tables(0).Rows(0).Item("UNITS").ToString() = "1" Then
                                    lbl.Text = FormatNumber(CDbl(objCalc.WVTR(i - 1)) / (CDbl(ds.Tables(0).Rows(0).Item("CONVAREA").ToString()) / 1000) / 100, 3)

                                Else
                                    lbl.Text = FormatNumber(objCalc.WVTR(i - 1), 3)
                                End If
                            Else
                                lbl.Text = ""
                            End If

                            tdInner.Controls.Add(lbl)
                            trInner.Controls.Add(tdInner)
                        Case 8
                            InnerTdSetting(tdInner, "", "Center")
                            txt = New TextBox
                            txt.CssClass = "SmallTextBox"
                            txt.ID = "WVTR" + i.ToString()
                            If Not IsNumeric(dts.Tables(0).Rows(0).Item("WVTR" + i.ToString())) Then
                                txt.Text = ""
                            Else

                                If ds.Tables(0).Rows(0).Item("UNITS").ToString() = "1" Then
                                    txt.Text = FormatNumber(CDbl(dts.Tables(0).Rows(0).Item("WVTR" + i.ToString())) / (CDbl(ds.Tables(0).Rows(0).Item("CONVAREA").ToString()) / 1000) / 100, 3)
                                Else
                                    txt.Text = FormatNumber(dts.Tables(0).Rows(0).Item("WVTR" + i.ToString()).ToString(), 3)
                                End If
                            End If
                            txt.MaxLength = 6

                            tdInner.Controls.Add(txt)
                            trInner.Controls.Add(tdInner)
                        Case 9
                            If i = 1 Then
                                hid = New HiddenField
                                hid.ID = "UnitId"
                                hid.Value = ds.Tables(0).Rows(0).Item("UNITS").ToString()
                                tdInner.Controls.Add(hid)
                                trInner.Controls.Add(tdInner)
                            End If


                    End Select
                Next
                If (i Mod 2 = 0) Then
                    trInner.CssClass = "AlterNateColor1"
                Else
                    trInner.CssClass = "AlterNateColor2"
                End If
                trInner.Height = 30
                tblComparision.Controls.Add(trInner)
            Next


            'Total
            trInner = New TableRow
            For i = 1 To 8
                tdInner = New TableCell
                Select Case i
                    Case 1
                        InnerTdSetting(tdInner, "", "Left")
                        tdInner.Text = "<span class='CalculatedFeilds'><b> Total </b></span>"
                        trInner.Controls.Add(tdInner)
                    Case 2, 3
                        InnerTdSetting(tdInner, "", "Right")
                        tdInner.Text = ""
                        trInner.Controls.Add(tdInner)
                    Case 4
                        InnerTdSetting(tdInner, "", "Right")
                        tdInner.Text = "<span class='CalculatedFeilds'><b>" + FormatNumber(ds.Tables(0).Rows(0).Item("THICK").ToString(), 3) + " </b> </span>"
                        trInner.Controls.Add(tdInner)
                    Case 5
                        InnerTdSetting(tdInner, "", "Center")
                        If ds.Tables(0).Rows(0).Item("UNITS").ToString() = "1" Then
                            tdInner.Text = FormatNumber(CDbl(objCalc.TotalOTR) / (CDbl(ds.Tables(0).Rows(0).Item("CONVAREA").ToString()) / 1000) / 100, 3)
                        Else
                            tdInner.Text = FormatNumber(objCalc.TotalOTR, 3)
                        End If
                        tdInner.Text = "<b>" + tdInner.Text + "</b>"
                        tdInner.ColumnSpan = 2
                        trInner.Controls.Add(tdInner)

                    Case 7
                        InnerTdSetting(tdInner, "", "Center")
                        If ds.Tables(0).Rows(0).Item("UNITS").ToString() = "1" Then
                            tdInner.Text = FormatNumber(CDbl(objCalc.TotalWVTR) / (CDbl(ds.Tables(0).Rows(0).Item("CONVAREA").ToString()) / 1000) / 100, 3)
                        Else
                            tdInner.Text = FormatNumber(objCalc.TotalWVTR, 3)
                        End If
                        tdInner.Text = "<b>" + tdInner.Text + "</b>"
                        tdInner.ColumnSpan = 2
                        trInner.Controls.Add(tdInner)
                     
                End Select
            Next
            trInner.Height = 30
            trInner.CssClass = "AlterNateColor2"
            tblComparision.Controls.Add(trInner)





        Catch ex As Exception
            _lErrorLble.Text = "Error:GetPageDetails:" + ex.Message.ToString()
        End Try
    End Sub
    
    Protected Sub GetGrades(ByRef LinkGrade As HyperLink, ByVal hid As HiddenField, ByVal MatId As String, ByVal GradeId As Integer)
        Dim Ds As New DataSet
        Dim ObjGetdata As New E1GetData.Selectdata()
        Dim Path As String = String.Empty
        Dim MaterialId As String = String.Empty
        Try
            Ds = ObjGetdata.GetGradesVal(GradeId.ToString())
            LinkGrade.Text = Ds.Tables(0).Rows(0).Item("GRADENAME").ToString()
            LinkGrade.ToolTip = Ds.Tables(0).Rows(0).Item("GRADENAME").ToString()
            LinkGrade.Attributes.Add("text-decoration", "none")
            MaterialId = ctlContentPlaceHolder.ClientID.ToString() + "_" + MatId
            Path = "../PopUp/GetGradeDetails.aspx?Des=" + ctlContentPlaceHolder.ClientID.ToString() + "_" + LinkGrade.ClientID + "&Id=" + ctlContentPlaceHolder.ClientID.ToString() + "_" + hid.ClientID + ""
            LinkGrade.NavigateUrl = "javascript:ShowGradePopWindow('" + Path + "','" + MaterialId + "')"
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GetMaterialDetails(ByRef LinkMat As HyperLink, ByVal hid As HiddenField, ByVal MatId As Integer, ByVal linkGrade As String, ByVal hidGrade As String)
        Dim Ds As New DataSet
        Dim ObjGetdata As New E1GetData.Selectdata()
        Dim hidval As New HiddenField
        Dim Path As String = String.Empty

        Try

            Ds = ObjGetdata.GetMaterials(MatId, "", "")
            If Ds.Tables(0).Rows(0).Item("MATDES").ToString().Length > 25 Then
                'LinkMat.Font.Size = 8
            End If
            LinkMat.Text = Ds.Tables(0).Rows(0).Item("MATDES").ToString()
            LinkMat.ToolTip = Ds.Tables(0).Rows(0).Item("MATDES").ToString()
            LinkMat.Attributes.Add("text-decoration", "none")


            hid.Value = MatId.ToString()
            Path = "../PopUp/GetMatPopUpGrade.aspx?Des=" + ctlContentPlaceHolder.ClientID.ToString() + "_" + LinkMat.ClientID + "&Id=" + ctlContentPlaceHolder.ClientID.ToString() + "_" + hid.ClientID + "&GradeDes=" + ctlContentPlaceHolder.ClientID.ToString() + "_" + linkGrade + "&GradeId=" + ctlContentPlaceHolder.ClientID.ToString() + "_" + hidGrade + ""
            LinkMat.NavigateUrl = "javascript:ShowPopWindow('" + Path + "')"

        Catch ex As Exception
            ErrorLable.Text = "Error:Update_Click:" + ex.Message.ToString() + ""
        End Try
    End Sub
    Protected Sub HeaderTdSetting(ByVal Td As TableCell, ByVal Width As String, ByVal HeaderText As String, ByVal ColSpan As String)
        Try
            Td.Text = HeaderText
            Td.ColumnSpan = ColSpan
            If Width <> "" Then
                Td.Style.Add("width", Width)
            End If
            Td.CssClass = "TdHeading"
            Td.Height = 20
            Td.Font.Size = 10
            Td.Font.Bold = True
            Td.HorizontalAlign = HorizontalAlign.Center



        Catch ex As Exception
            _lErrorLble.Text = "Error:HeaderTdSetting:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Sub Header2TdSetting(ByVal Td As TableCell, ByVal Width As String, ByVal HeaderText As String, ByVal ColSpan As String)
        Try
            Td.Text = HeaderText
            Td.ColumnSpan = ColSpan
            If Width <> "" Then
                Td.Style.Add("width", Width)
            End If
            Td.CssClass = "TdHeading"
            Td.Font.Size = 8
            Td.Height = 20
            Td.HorizontalAlign = HorizontalAlign.Center



        Catch ex As Exception
            _lErrorLble.Text = "Error:HeaderTdSetting:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Sub InnerTdSetting(ByVal Td As TableCell, ByVal Width As String, ByVal Align As String)
        Try

            If Width <> "" Then
                Td.Style.Add("width", Width)
            End If
            Td.Style.Add("text-align", Align)
            If Align = "Left" Then
                Td.Style.Add("padding-left", "5px")
            End If
            If Align = "Right" Then
                Td.Style.Add("padding-right", "5px")
            End If
            Td.Style.Add("font-size", "13px")
        Catch ex As Exception
            _lErrorLble.Text = "Error:InnerTdSetting:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Sub TextBoxSetting(ByVal txt As TextBox, ByVal Css As String)
        Try
            txt.CssClass = Css

        Catch ex As Exception
            _lErrorLble.Text = "Error:TextBoxSetting:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Sub LableSetting(ByVal lbl As Label, ByVal Css As String)
        Try
            lbl.CssClass = Css

        Catch ex As Exception
            _lErrorLble.Text = "Error:LableSetting:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Sub LeftTdSetting(ByVal Td As TableCell, ByVal Text As String, ByVal tr As TableRow, ByVal Css As String)
        Try
            Td.Text = Text
            InnerTdSetting(Td, "", "Left")
            tr.Controls.Add(Td)
            tr.CssClass = Css
        Catch ex As Exception
            _lErrorLble.Text = "Error:LeftTdSetting:" + ex.Message.ToString()
        End Try
    End Sub

    
    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Dim Material(9) As String
        Dim Thickness(9) As String
        Dim OTR(9) As String
        Dim WVTR(9) As String
        Dim i As New Integer
        Dim ObjUpIns As New E1UpInsData.UpdateInsert()
        Dim TempDs As New DataSet
        Dim RHDs As New DataSet
        Dim ObjGetData As New E1GetData.Selectdata()
        Dim GRADE(9) As String

        Dim obj As New CryptoHelper
        Try
            If ViewState("UnitId1") <> Session("UnitId") Then
                'If Not Session("Post") Is Nothing And Session("Post") <> Session("Prev") Then
                GetPageDetailsForBarrier()
                ScriptManager.RegisterStartupScript(Page, Me.GetType(), "JSScript", "alert('There has been done changes in Preference page,Please close this page and reopen again.');", True)
                Exit Sub
            End If

            If Not objRefresh.IsRefresh Then
                If ViewState("TabId").ToString() = "1" Then
                    For i = 1 To 10
                        Material(i - 1) = Request.Form("ctl00$E1InkContentPlaceHolder$hidMatid" + i.ToString() + "")
                        Thickness(i - 1) = Request.Form("ctl00$E1InkContentPlaceHolder$T" + i.ToString() + "")
                        OTR(i - 1) = Request.Form("ctl00$E1InkContentPlaceHolder$OTR" + i.ToString() + "")
                        WVTR(i - 1) = Request.Form("ctl00$E1InkContentPlaceHolder$WVTR" + i.ToString() + "")
                        GRADE(i - 1) = Request.Form("ctl00$E1InkContentPlaceHolder$hidGradeId" + i.ToString() + "")


                        'Check For IsNumric
                        If Not IsNumeric(Thickness(i - 1)) Then
                            Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE111").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                        End If

                        If Not IsNumeric(txtOTRHumidity.Text) Then
                            Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE111").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                        End If
                        If Not IsNumeric(txtWVTRHumidity.Text) Then
                            Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE111").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                        End If
                        If Not IsNumeric(txtWVTRTemp.Text) Then
                            Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE111").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                        End If
                        If Not IsNumeric(txtOTRTemp.Text) Then
                            Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE111").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                        End If


                        'Check For Dependant-Indepdant Error
                        If CInt(Material(i - 1)) <> 0 Then
                            'Checking Thickness
                            If CDbl(Thickness(i - 1)) <= CDbl(0.0) Then
                                Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE101").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                            End If
                            'If IsNumeric(OTR(i - 1)) Then
                            '    If CDbl(OTR(i - 1)) <= CDbl(0.0) Then
                            '        Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE101").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                            '    End If
                            'End If
                            'If IsNumeric(WVTR(i - 1)) Then
                            '    If CDbl(WVTR(i - 1)) <= CDbl(0.0) Then
                            '        Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE101").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                            '    End If
                            'End If

                        End If

                    Next


                    ObjUpIns.BarrierUpdate(CaseId, Material, Thickness, txtOTRTemp.Text, txtWVTRTemp.Text, txtOTRHumidity.Text, txtWVTRHumidity.Text, OTR, WVTR, GRADE)


                    ObjUpIns.ServerDateUpdate(CaseId, Session("E1UserName"))
                    GetPageDetailsForBarrier()
                ElseIf ViewState("TabId").ToString() = "2" Then

                ElseIf ViewState("TabId").ToString() = "3" Then

                End If

            End If
            ScriptManager.RegisterStartupScript(Page, Me.GetType(), "JSScript", "confirmExit();", True)

        Catch ex As Exception
            ErrorLable.Text = "Error:Update_Click:" + ex.Message.ToString() + ""
        End Try
    End Sub

    'Bug#399
    Public Function GetOTRFlag(ByVal Temp As String, ByVal RH As String) As String
        Dim OTRFlag As String
        Dim Dts1 As New DataSet()
        Dim Dts2 As New DataSet()
        Dim odbUtil As New DBUtil()
        Dim EconConnection As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
        Dim StrSql1 As String = String.Empty
        OTRFlag = "0"
        Try
            StrSql1 = "select * from BARRIERTEMP "
            StrSql1 = StrSql1 + "where(TEMPVAL = " + Temp + ") "
            Dts1 = odbUtil.FillDataSet(StrSql1, EconConnection)
            StrSql1 = String.Empty
            StrSql1 = "select * from BARRIERH "
            StrSql1 = StrSql1 + "where(RHVALUE = " + RH + ") "
            Dts2 = odbUtil.FillDataSet(StrSql1, EconConnection)
            If Dts1.Tables(0).Rows.Count > 0 And Dts2.Tables(0).Rows.Count > 0 Then
                OTRFlag = "1"
            ElseIf Dts1.Tables(0).Rows.Count = 0 And Dts2.Tables(0).Rows.Count = 0 Then
                OTRFlag = "2"
            ElseIf Dts1.Tables(0).Rows.Count > 0 And Dts2.Tables(0).Rows.Count = 0 Then
                OTRFlag = "3"
            ElseIf Dts1.Tables(0).Rows.Count = 0 And Dts2.Tables(0).Rows.Count > 0 Then
                OTRFlag = "4"
            End If


            Return OTRFlag
        Catch ex As Exception
            Return OTRFlag
            ErrorLable.Text = "Error:GetOTRFlag:" + ex.Message.ToString() + ""
        End Try
    End Function
    Public Function GetWVTRFlag(ByVal Temp As String, ByVal RH As String) As String
        Dim WVTRFlag As String
        Dim Dts1 As New DataSet()
        Dim Dts2 As New DataSet()
        Dim odbUtil As New DBUtil()
        Dim EconConnection As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
        Dim StrSql1 As String = String.Empty
        WVTRFlag = "0"
        Try
            StrSql1 = "select * from BARRIERTEMP "
            StrSql1 = StrSql1 + "where(TEMPVAL = " + Temp + ") "
            Dts1 = odbUtil.FillDataSet(StrSql1, EconConnection)
            StrSql1 = String.Empty
            StrSql1 = "select * from BARRIERH "
            StrSql1 = StrSql1 + "where(RHVALUE = " + RH + ") "
            Dts2 = odbUtil.FillDataSet(StrSql1, EconConnection)
            If Dts1.Tables(0).Rows.Count > 0 And Dts2.Tables(0).Rows.Count > 0 Then
                WVTRFlag = "1"
            ElseIf Dts1.Tables(0).Rows.Count = 0 And Dts2.Tables(0).Rows.Count = 0 Then
                WVTRFlag = "2"
            ElseIf Dts1.Tables(0).Rows.Count > 0 And Dts2.Tables(0).Rows.Count = 0 Then
                WVTRFlag = "3"
            ElseIf Dts1.Tables(0).Rows.Count = 0 And Dts2.Tables(0).Rows.Count > 0 Then
                WVTRFlag = "4"
            End If


            Return WVTRFlag
        Catch ex As Exception
            Return WVTRFlag
            ErrorLable.Text = "Error:GetWVTRFlag:" + ex.Message.ToString() + ""
        End Try
    End Function
End Class
