﻿
Partial Class Pages_Econ1_Assumptions_test
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim i As Integer
        i = FormatNumber(19999, 0)

    End Sub
End Class
