Imports DistGetData
Imports DistUpInsData
Imports System.Collections
Imports System.IO.StringWriter
Imports System.Math
Imports System.Web.UI.HtmlTextWriter
Imports System.Data
Partial Class Pages_Distribution_Assumptions_PalletInNew
    Inherits System.Web.UI.Page

#Region "Get Set Variables"
    Dim _lErrorLble As Label
    Dim _iCaseId As Integer
    Dim _iUserId As Integer
    Dim _strUserRole As String
    Dim _btnUpdate As ImageButton
    Dim _btnLogOff As ImageButton
    Dim _btnChart As ImageButton
    Dim _btnNotes As ImageButton
    Dim _btnFeedBack As ImageButton
    Dim _btnInstrutions As ImageButton
    Dim _divMainHeading As HtmlGenericControl
    Dim _ctlContentPlaceHolder As ContentPlaceHolder



    Public Property ErrorLable() As Label
        Get
            Return _lErrorLble
        End Get
        Set(ByVal Value As Label)
            _lErrorLble = Value
        End Set
    End Property

    Public Property CaseId() As Integer
        Get
            Return _iCaseId
        End Get
        Set(ByVal Value As Integer)
            _iCaseId = Value
        End Set
    End Property

    Public Property UserId() As Integer
        Get
            Return _iUserId
        End Get
        Set(ByVal Value As Integer)
            _iUserId = Value
        End Set
    End Property

    Public Property UserRole() As String
        Get
            Return _strUserRole
        End Get
        Set(ByVal Value As String)
            _strUserRole = Value
        End Set
    End Property

    Public Property Updatebtn() As ImageButton
        Get
            Return _btnUpdate
        End Get
        Set(ByVal value As ImageButton)
            _btnUpdate = value
        End Set
    End Property

    Public Property LogOffbtn() As ImageButton
        Get
            Return _btnLogOff
        End Get
        Set(ByVal value As ImageButton)
            _btnLogOff = value
        End Set
    End Property

    Public Property Chartbtn() As ImageButton
        Get
            Return _btnChart
        End Get
        Set(ByVal value As ImageButton)
            _btnChart = value
        End Set
    End Property

    Public Property Notesbtn() As ImageButton
        Get
            Return _btnNotes
        End Get
        Set(ByVal value As ImageButton)
            _btnNotes = value
        End Set
    End Property

    Public Property FeedBackbtn() As ImageButton
        Get
            Return _btnFeedBack
        End Get
        Set(ByVal value As ImageButton)
            _btnFeedBack = value
        End Set
    End Property

    Public Property Instrutionsbtn() As ImageButton
        Get
            Return _btnInstrutions
        End Get
        Set(ByVal value As ImageButton)
            _btnInstrutions = value
        End Set
    End Property

    Public Property MainHeading() As HtmlGenericControl
        Get
            Return _divMainHeading
        End Get
        Set(ByVal value As HtmlGenericControl)
            _divMainHeading = value
        End Set
    End Property

    Public Property ctlContentPlaceHolder() As ContentPlaceHolder
        Get
            Return _ctlContentPlaceHolder
        End Get
        Set(ByVal value As ContentPlaceHolder)
            _ctlContentPlaceHolder = value
        End Set
    End Property



    Public DataCnt As Integer
    Public CaseDesp As New ArrayList
#End Region

#Region "MastePage Content Variables"

    Protected Sub GetMasterPageControls()
        GetContentPlaceHolder()
        GetErrorLable()
        GetUpdatebtn()
        GetLogOffbtn()
        GetInstructionsbtn()
        GetChartbtn()
        GetFeedbackbtn()
        GetNotesbtn()
        GetMainHeadingdiv()

    End Sub

    Protected Sub GetErrorLable()
        ErrorLable = Page.Master.FindControl("lblError")
    End Sub

    Protected Sub GetUpdatebtn()
        Updatebtn = Page.Master.FindControl("imgUpdate")
        Updatebtn.Visible = True
        Updatebtn.Attributes.Add("onclick", "return checkNumericAll()")
        AddHandler Updatebtn.Click, AddressOf Update_Click
    End Sub

    Protected Sub GetLogOffbtn()
        LogOffbtn = Page.Master.FindControl("imgLogoff")
        LogOffbtn.Visible = False
        'AddHandler Updatebtn.Click, AddressOf Update_Click
    End Sub

    Protected Sub GetInstructionsbtn()
        Instrutionsbtn = Page.Master.FindControl("imgInstructions")
        Instrutionsbtn.Visible = True
        'AddHandler Updatebtn.Click, AddressOf Update_Click
    End Sub

    Protected Sub GetChartbtn()
        Chartbtn = Page.Master.FindControl("imgChart")
        Chartbtn.Visible = False
        'AddHandler Updatebtn.Click, AddressOf Update_Click
    End Sub

    Protected Sub GetFeedbackbtn()
        FeedBackbtn = Page.Master.FindControl("imgFeedback")
        FeedBackbtn.Visible = True
        'AddHandler Updatebtn.Click, AddressOf Update_Click
    End Sub

    Protected Sub GetNotesbtn()
        Notesbtn = Page.Master.FindControl("imgNotes")
        Notesbtn.Visible = True
        Notesbtn.OnClientClick = "return Notes('PALLETPKG2');"
        'AddHandler Updatebtn.Click, AddressOf Update_Click
    End Sub

    Protected Sub GetMainHeadingdiv()
        MainHeading = Page.Master.FindControl("divMainHeading")
        MainHeading.Attributes.Add("onmouseover", "Tip('Transport Package Configuration')")
        MainHeading.Attributes.Add("onmouseout", "UnTip()")
        MainHeading.InnerHtml = "EDist - Transport Package Configuration"
    End Sub

    Protected Sub GetContentPlaceHolder()
        ctlContentPlaceHolder = Page.Master.FindControl("DistributionContentPlaceHolder")
    End Sub



#End Region

#Region "Browser Refresh Check"
    Dim objRefresh As zCon.Net.Refresh

    Protected Sub Page_PreInit(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreInit
        objRefresh = New zCon.Net.Refresh("_PAGES_DISTRIBUTION_ASSUMPTIONS_PALLETINNEW")
    End Sub

    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        objRefresh.Render(Page)
    End Sub

#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            GetMasterPageControls()
            GetSessionDetails()
            If Not IsPostBack Then
                ViewState("TabId") = 1
                GetTransportType(Convert.ToInt32(ViewState("TabId")))
            End If
            CreateTab()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GetSessionDetails()
        Try
            UserId = Session("UserId")
            CaseId = Session("DistCaseId")
            UserRole = Session("DistUserRole")
        Catch ex As Exception
            _lErrorLble.Text = "Error:GetSessionDetails:" + ex.Message.ToString()
        End Try
    End Sub
    Protected Sub GetPageDetails()
        Dim ds As New DataSet
        Dim dsSug As New DataSet
        Dim dsMat As New DataSet
        Dim dsTotal As New DataSet
        Dim objGetData As New DistGetData.Selectdata
        Dim i As New Integer
        Dim j As New Integer
        Dim DWidth As String = String.Empty
        Dim trHeader As New TableRow
        Dim trHeader1 As New TableRow
        Dim trHeader2 As New TableRow
        Dim trHeaderFix As New TableRow
        Dim trHeaderFix1 As New TableRow
        Dim trHeaderFix2 As New TableRow
        Dim trInner As New TableRow
        Dim trInnerFix As New TableRow
        Dim tdHeader As TableCell
        Dim tdHeader1 As TableCell
        Dim tdHeader2 As TableCell
        Dim lbl As New Label
        Dim hid As New HiddenField
        Dim Link As New HyperLink
        Dim txt As New TextBox
        Dim tdInner As TableCell
        Dim Col As String = String.Empty

        Try
            Col = Chr(64 + Convert.ToInt32(ViewState("TabId"))).ToString()
            ds = objGetData.GetPalletInPref(CaseId, Col)
            dsSug = objGetData.GetPalletInSugg(CaseId, Col)

            tblComparision.Rows.Clear()
           
            If ddlType.SelectedValue = "TRK" Then
                For i = 1 To 9
                    tdHeader = New TableCell
                    tdHeader1 = New TableCell
                    tdHeader2 = New TableCell
                    Dim Title As String = String.Empty
                    'Header
                    Select Case i
                        Case 1
                            HeaderTdSetting(tdHeader, "50px", "Layers", "1")
                            HeaderTdSetting(tdHeader1, "0", "", "1")
                            Header2TdSetting(tdHeader2, "", "", "1")
                            trHeader.Controls.Add(tdHeader)
                            trHeader2.Controls.Add(tdHeader2)
                        Case 2
                            HeaderTdSetting(tdHeader, "150px", "Item", "1")
                            HeaderTdSetting(tdHeader1, "0", "", "1")
                            Header2TdSetting(tdHeader2, "", "", "1")
                            trHeader.Controls.Add(tdHeader)
                            trHeader2.Controls.Add(tdHeader2)
                        Case 3
                            HeaderTdSetting(tdHeader, "70px", "Number", "1")
                            Header2TdSetting(tdHeader2, "", "(per pallet)", "1")
                            HeaderTdSetting(tdHeader1, "0", "", "1")
                            trHeader.Controls.Add(tdHeader)
                            trHeader2.Controls.Add(tdHeader2)
                        Case 4
                            Title = "(Units)"
                            HeaderTdSetting(tdHeader, "", "Number Of Uses", "1")
                            Header2TdSetting(tdHeader2, "", Title, "1")
                            Header2TdSetting(tdHeader1, "", "", "1")
                            trHeader.Controls.Add(tdHeader)
                            trHeader2.Controls.Add(tdHeader2)
                        Case 5
                            Title = "(" + ds.Tables(0).Rows(0).Item("TITLE8").ToString() + ")"
                            HeaderTdSetting(tdHeader, "", "Weight", "2")
                            Header2TdSetting(tdHeader2, "", Title, "2")
                            Header2TdSetting(tdHeader1, "70px", "Suggested", "1")
                            trHeader.Controls.Add(tdHeader)
                            trHeader2.Controls.Add(tdHeader2)
                        Case 6
                            Header2TdSetting(tdHeader1, "70px", "Preferred", "1")
                        Case 7
                            Title = "(" + ds.Tables(0).Rows(0).Item("TITLE2").ToString() + ")"
                            HeaderTdSetting(tdHeader, "", "Price", "2")
                            Header2TdSetting(tdHeader2, "", Title, "2")
                            Header2TdSetting(tdHeader1, "70px", "Suggested", "1")
                            trHeader.Controls.Add(tdHeader)
                            trHeader2.Controls.Add(tdHeader2)
                        Case 8
                            Header2TdSetting(tdHeader1, "70px", "Preferred", "1")
                        Case 9
                            HeaderTdSetting(tdHeader, "120px", "Mfg. Dept.", "1")
                            Header2TdSetting(tdHeader2, "", "", "1")
                            HeaderTdSetting(tdHeader1, "0", "", "1")
                            trHeader.Controls.Add(tdHeader)
                            trHeader2.Controls.Add(tdHeader2)
                    End Select


                    trHeader1.Controls.Add(tdHeader1)

                Next
                tblComparision.Controls.Add(trHeader)
                tblComparision.Controls.Add(trHeader2)
                tblComparision.Controls.Add(trHeader1)


                'Inner
                For i = 1 To 10
                    trInner = New TableRow
                    For j = 1 To 9
                        tdInner = New TableCell

                        Select Case j
                            Case 1
                                'Layer
                                InnerTdSetting(tdInner, "", "Center")
                                tdInner.Text = "<b>" + i.ToString() + "</b>"
                                trInner.Controls.Add(tdInner)
                            Case 2
                                InnerTdSetting(tdInner, "", "Left")
                                Link = New HyperLink
                                hid = New HiddenField
                                Link.ID = "hypPalDes" + i.ToString()
                                hid.ID = "hidPalid" + i.ToString()
                                Link.Width = 150
                                Link.CssClass = "Link"
                                GetPalletDetails(Link, hid, CInt(ds.Tables(0).Rows(0).Item("PATID" + i.ToString() + "").ToString()))
                                tdInner.Controls.Add(hid)
                                tdInner.Controls.Add(Link)
                                trInner.Controls.Add(tdInner)
                            Case 3
                                InnerTdSetting(tdInner, "", "Center")
                                txt = New TextBox
                                txt.CssClass = "SmallTextBox"
                                txt.ID = "NUM" + i.ToString()
                                txt.Text = FormatNumber(ds.Tables(0).Rows(0).Item("NUM" + i.ToString() + "").ToString(), 2)
                                txt.MaxLength = 5
                                tdInner.Controls.Add(txt)
                                trInner.Controls.Add(tdInner)
                            Case 4
                                InnerTdSetting(tdInner, "", "Center")
                                txt = New TextBox
                                txt.CssClass = "SmallTextBox"
                                txt.ID = "NOFUSE" + i.ToString()
                                txt.Text = FormatNumber(ds.Tables(0).Rows(0).Item("USES" + i.ToString() + "").ToString(), 2)
                                txt.MaxLength = 4
                                tdInner.Controls.Add(txt)
                                trInner.Controls.Add(tdInner)
                            Case 5
                                InnerTdSetting(tdInner, "", "Right")
                                lbl = New Label
                                lbl.Text = FormatNumber(dsSug.Tables(0).Rows(0).Item("WEIGHT" + i.ToString() + "").ToString(), 2)
                                tdInner.Controls.Add(lbl)
                                trInner.Controls.Add(tdInner)
                            Case 6
                                InnerTdSetting(tdInner, "", "Center")
                                txt = New TextBox
                                txt.CssClass = "SmallTextBox"
                                txt.Width = 50
                                txt.ID = "W" + i.ToString()
                                txt.Text = FormatNumber(ds.Tables(0).Rows(0).Item("WEIGHT" + i.ToString() + "").ToString(), 2)
                                txt.MaxLength = 6
                                tdInner.Controls.Add(txt)
                                trInner.Controls.Add(tdInner)
                            Case 7
                                InnerTdSetting(tdInner, "", "Right")
                                lbl = New Label
                                lbl.Text = FormatNumber(dsSug.Tables(0).Rows(0).Item("PRICE" + i.ToString() + "").ToString(), 2)
                                tdInner.Controls.Add(lbl)
                                trInner.Controls.Add(tdInner)
                            Case 8
                                InnerTdSetting(tdInner, "", "Center")
                                txt = New TextBox
                                txt.CssClass = "SmallTextBox"
                                txt.Width = 50
                                txt.ID = "P" + i.ToString()
                                txt.Text = FormatNumber(ds.Tables(0).Rows(0).Item("PRICE" + i.ToString() + "").ToString(), 2)
                                txt.MaxLength = 6
                                tdInner.Controls.Add(txt)
                                trInner.Controls.Add(tdInner)
                            Case 9
                                InnerTdSetting(tdInner, "", "Left")
                                Link = New HyperLink
                                hid = New HiddenField
                                Link.ID = "hypPalletDep" + i.ToString()
                                hid.ID = "hidPalletDepid" + i.ToString()
                                Link.Width = 120
                                Link.CssClass = "Link"
                                GetDeptDetails(Link, hid, CInt(ds.Tables(0).Rows(0).Item("DEPT" + i.ToString() + "").ToString()))
                                tdInner.Controls.Add(hid)
                                tdInner.Controls.Add(Link)
                                trInner.Controls.Add(tdInner)
                        End Select
                    Next
                    If (i Mod 2 = 0) Then
                        trInner.CssClass = "AlterNateColor1"
                    Else
                        trInner.CssClass = "AlterNateColor2"
                    End If
                    tblComparision.Controls.Add(trInner)
                Next
            End If


        Catch ex As Exception
            _lErrorLble.Text = "Error:GetPageDetails:" + ex.Message.ToString()
        End Try
    End Sub
    Protected Sub GetPalletDetails(ByRef LinkMat As HyperLink, ByVal hid As HiddenField, ByVal palletId As Integer)
        Dim Ds As New DataSet
        Dim ObjGetdata As New DistGetData.Selectdata()
        Dim hidval As New HiddenField
        Dim Path As String = String.Empty
        Try

            Ds = ObjGetdata.GetPallets(palletId, "", "")
            LinkMat.Text = Ds.Tables(0).Rows(0).Item("PallteDes").ToString()
            hid.Value = palletId.ToString()
            Path = "../PopUp/GetPalletPopUp.aspx?Des=" + ctlContentPlaceHolder.ClientID.ToString() + "_" + LinkMat.ClientID + "&Id=" + ctlContentPlaceHolder.ClientID.ToString() + "_" + hid.ClientID + ""
            LinkMat.NavigateUrl = "javascript:ShowPopWindow('" + Path + "')"

        Catch ex As Exception
            ErrorLable.Text = "Error:Update_Click:" + ex.Message.ToString() + ""
        End Try
    End Sub
    Protected Sub GetDeptDetails(ByRef LinkDep As HyperLink, ByVal hid As HiddenField, ByVal ProcId As Integer)
        Dim Ds As New DataSet
        Dim ObjGetdata As New DistGetData.Selectdata()
        Dim Path As String = String.Empty
        Try
            Ds = ObjGetdata.GetDept(ProcId, "", "")
            Path = "../PopUp/GetDepPopUp.aspx?Des=" + ctlContentPlaceHolder.ClientID.ToString() + "_" + LinkDep.ClientID + "&Id=" + ctlContentPlaceHolder.ClientID.ToString() + "_" + hid.ClientID + ""
            If Ds.Tables(0).Rows.Count = 0 Then
                LinkDep.Text = "Dept. Conflict"
                LinkDep.ForeColor = Drawing.Color.DarkRed
            Else
                LinkDep.Text = Ds.Tables(0).Rows(0).Item("PROCDE").ToString()
            End If

            hid.Value = ProcId.ToString()
            LinkDep.NavigateUrl = "javascript:ShowPopWindow('" + Path + "')"
        Catch ex As Exception
            ErrorLable.Text = "Error:Update_Click:" + ex.Message.ToString() + ""
        End Try
    End Sub
    Protected Sub GetTransportType(ByVal tId As String)
        Dim Ds As New DataSet
        Dim DsType As New DataSet
        Dim ObjGetdata As New DistGetData.Selectdata()
        Dim Path As String = String.Empty
        '  Dim ddlType As New DropDownList()
        Try
            Ds = ObjGetdata.GetTransportType("")
            With ddlType
                .AutoPostBack = True
                .DataTextField = "NAME"
                .DataValueField = "CODE"
                .DataSource = Ds
                .DataBind()
            End With

            DsType = ObjGetdata.GetTransportTypeByID(tId, CaseId)
            ddlType.SelectedValue = DsType.Tables(0).Rows(0).Item("CODE").ToString()
            If ddlType.SelectedValue <> "NON" Then
                GetPageDetails()
            End If

        Catch ex As Exception
            ErrorLable.Text = "Error:GetTransportType:" + ex.Message.ToString() + ""
        End Try
    End Sub
    Protected Sub ddlType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlType.SelectedIndexChanged
        Try
            If ddlType.SelectedValue <> "NON" Then
                GetPageDetails()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub HeaderTdSetting(ByVal Td As TableCell, ByVal Width As String, ByVal HeaderText As String, ByVal ColSpan As String)
        Try
            Td.Text = HeaderText
            Td.ColumnSpan = ColSpan
            If Width <> "" Then
                Td.Style.Add("width", Width)
            End If
            Td.CssClass = "TdHeading"
            Td.Height = 20
            Td.Font.Size = 10
            Td.Font.Bold = True
            Td.HorizontalAlign = HorizontalAlign.Center



        Catch ex As Exception
            _lErrorLble.Text = "Error:HeaderTdSetting:" + ex.Message.ToString()
        End Try
    End Sub
    Protected Sub Header2TdSetting(ByVal Td As TableCell, ByVal Width As String, ByVal HeaderText As String, ByVal ColSpan As String)
        Try
            Td.Text = HeaderText
            Td.ColumnSpan = ColSpan
            If Width <> "" Then
                Td.Style.Add("width", Width)
            End If
            Td.CssClass = "TdHeading"
            Td.Font.Size = 8
            Td.Height = 20
            Td.HorizontalAlign = HorizontalAlign.Center



        Catch ex As Exception
            _lErrorLble.Text = "Error:HeaderTdSetting:" + ex.Message.ToString()
        End Try
    End Sub
    Protected Sub InnerTdSetting(ByVal Td As TableCell, ByVal Width As String, ByVal Align As String)
        Try

            If Width <> "" Then
                Td.Style.Add("width", Width)
            End If
            Td.Style.Add("text-align", Align)
            If Align = "Left" Then
                Td.Style.Add("padding-left", "5px")
            End If
            If Align = "Right" Then
                Td.Style.Add("padding-right", "5px")
            End If
            Td.Style.Add("font-size", "13px")
        Catch ex As Exception
            _lErrorLble.Text = "Error:InnerTdSetting:" + ex.Message.ToString()
        End Try
    End Sub
    Protected Sub TextBoxSetting(ByVal txt As TextBox, ByVal Css As String)
        Try
            txt.CssClass = Css

        Catch ex As Exception
            _lErrorLble.Text = "Error:TextBoxSetting:" + ex.Message.ToString()
        End Try
    End Sub
    Protected Sub LableSetting(ByVal lbl As Label, ByVal Css As String)
        Try
            lbl.CssClass = Css

        Catch ex As Exception
            _lErrorLble.Text = "Error:LableSetting:" + ex.Message.ToString()
        End Try
    End Sub
    Protected Sub LeftTdSetting(ByVal Td As TableCell, ByVal Text As String, ByVal tr As TableRow, ByVal Css As String)
        Try
            Td.Text = Text
            InnerTdSetting(Td, "", "Left")
            tr.Controls.Add(Td)
            tr.CssClass = Css
        Catch ex As Exception
            _lErrorLble.Text = "Error:LeftTdSetting:" + ex.Message.ToString()
        End Try
    End Sub
    Protected Sub CreateTab()
        Dim tr As New TableRow
        Dim td As New TableCell
        Dim i As New Integer
        Dim lnk As New LinkButton
        Try
            tblTab.Rows.Clear()
            For i = 1 To 5
                td = New TableCell
                lnk = New LinkButton
                lnk.Text = "Transport " + i.ToString()
                lnk.CssClass = "TabLinkTrans"
                lnk.ID = "lnkTran" + i.ToString()
                lnk.Attributes.Add("onclick", "return checkNumericAll()")
                AddHandler lnk.Click, AddressOf lnlTranp_Click
                If i = Convert.ToInt32(ViewState("TabId").ToString()) Then
                    td.CssClass = "AlterNateTab1"
                Else
                    td.CssClass = "AlterNateTab2"
                End If
                td.Controls.Add(lnk)
                tr.Controls.Add(td)
            Next
            tblTab.Controls.Add(tr)
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub lnlTranp_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim lnk As LinkButton = DirectCast(sender, System.Web.UI.WebControls.LinkButton)
            UpdatePage()
            ViewState("TabId") = Convert.ToInt32(lnk.ID.Replace("lnkTran", "").ToString())
            CreateTab()
            GetTransportType(Convert.ToInt32(ViewState("TabId")))
        Catch ex As Exception
            ErrorLable.Text = "Error:lnlTranp_Click:" + ex.Message.ToString() + ""
        End Try
    End Sub

    Protected Sub Update_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)

        Try
            If Not objRefresh.IsRefresh Then
                UpdatePage()

            End If
            If ddlType.SelectedValue = "TRK" Then
                GetPageDetails()
            End If

        Catch ex As Exception
            ErrorLable.Text = "Error:Update_Click:" + ex.Message.ToString() + ""
        End Try
    End Sub
    Protected Sub UpdatePage()
        Try
            Dim Pallet(10) As String
            Dim Number(10) As String
            Dim NoOfUses(10) As String
            Dim PrefWeight(10) As String
            Dim PrefPrice(10) As String
            Dim Dept(10) As String
          
            Dim i As New Integer
            Dim ObjUpIns As New DistUpInsData.UpdateInsert()
            Dim obj As New CryptoHelper
            Dim Col As String = String.Empty
            Col = Chr(64 + Convert.ToInt32(ViewState("TabId"))).ToString()
            If ddlType.SelectedValue = "TRK" Then
                For i = 1 To 10
                    Pallet(i) = Request.Form("ctl00$DistributionContentPlaceHolder$hidPalid" + i.ToString() + "")
                    Number(i) = Request.Form("ctl00$DistributionContentPlaceHolder$NUM" + i.ToString() + "")
                    NoOfUses(i) = Request.Form("ctl00$DistributionContentPlaceHolder$NOFUSE" + i.ToString() + "")
                    PrefWeight(i) = Request.Form("ctl00$DistributionContentPlaceHolder$W" + i.ToString() + "")
                    PrefPrice(i) = Request.Form("ctl00$DistributionContentPlaceHolder$P" + i.ToString() + "")
                    Dept(i) = Request.Form("ctl00$DistributionContentPlaceHolder$hidPalletDepid" + i.ToString() + "")

                    'Check For IsNumric
                    If Not IsNumeric(Number(i)) Then
                        Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE113").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                    End If
                    If Not IsNumeric(NoOfUses(i)) Then
                        Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE113").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                    End If
                    If Not IsNumeric(PrefWeight(i)) Then
                        Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE113").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                    End If
                    If Not IsNumeric(PrefPrice(i)) Then
                        Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE113").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                    End If
                   
                    'Check For Dependant-Indepdant Error
                    If CInt(Pallet(i)) <> 0 Then
                        'Checking Number
                        If CDbl(Number(i)) <= CDbl(0.0) Then
                            Response.Redirect("../Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE105").Replace("+", "!Plus!").Replace("#", "!Hash!").Replace("&", "!And!") + "")
                        End If
                    End If
                Next
                ObjUpIns.PalletInNewUpdate(CaseId, Col, Pallet, Number, NoOfUses, PrefWeight, PrefPrice, Dept)
                Calculate()
            End If
            

        Catch ex As Exception
            ErrorLable.Text = "Error:Update_Click:" + ex.Message.ToString() + ""
        End Try
    End Sub
    Protected Sub Calculate()
        Try
            Dim Econ1Conn As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
            Dim DistributionConn As String = System.Configuration.ConfigurationManager.AppSettings("DistributionConnectionString")
            Dim obj As New DistributionCalculation.DistCalculations(DistributionConn, Econ1Conn)
            obj.DistributionCalculate(CaseId)
        Catch ex As Exception
            ErrorLable.Text = "Error:Calculate:" + ex.Message.ToString() + ""
        End Try
    End Sub

End Class
