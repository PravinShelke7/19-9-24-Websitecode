﻿Imports System.Data
Imports System.Data.OleDb
Imports System
Imports System.Collections
Imports System.IO.StringWriter
Imports System.Math
Imports System.Web.UI.HtmlTextWriter
Partial Class Index
    Inherits System.Web.UI.Page

#Region "Get Set Variables"
    Dim _lErrorLble As Label
    Dim _ctlContentPlaceHolder As ContentPlaceHolder
    Dim _hypMHome As HyperLink


    Public Property ErrorLable() As Label
        Get
            Return _lErrorLble
        End Get
        Set(ByVal Value As Label)
            _lErrorLble = Value
        End Set
    End Property

    Public Property MHome() As HyperLink
        Get
            Return _hypMHome
        End Get
        Set(ByVal Value As HyperLink)
            _hypMHome = Value
        End Set
    End Property

    

   

    Public Property ctlContentPlaceHolder() As ContentPlaceHolder
        Get
            Return _ctlContentPlaceHolder
        End Get
        Set(ByVal value As ContentPlaceHolder)
            _ctlContentPlaceHolder = value
        End Set
    End Property



    Public DataCnt As Integer
    Public CaseDesp As New ArrayList
#End Region

#Region "MastePage Content Variables"

    Protected Sub GetMasterPageControls()
        Session("MenuItem") = "HM"
        GetErrorLable()

    End Sub

    Protected Sub GetErrorLable()
        ErrorLable = Page.Master.FindControl("lblError")
    End Sub

  


    Protected Sub GetContentPlaceHolder()
        ctlContentPlaceHolder = Page.Master.FindControl("Econ1ContentPlaceHolder")
    End Sub

#End Region

#Region "Browser Refresh Check"
    Dim objRefresh As zCon.Net.Refresh

    Protected Sub Page_PreInit(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreInit
        objRefresh = New zCon.Net.Refresh("_INDEX")
        Try
            If Request.ServerVariables("http_user_agent").IndexOf("Safari", StringComparison.CurrentCultureIgnoreCase) <> -1 Then
                Page.ClientTarget = "uplevel"
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        objRefresh.Render(Page)
    End Sub

#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            GetMasterPageControls()
            AddMetaData()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub AddMetaData()
        Dim metaTag As New HtmlMeta
        Dim HeadTag As HtmlHead = CType(Page.Header, HtmlHead)
        Try
            metaTag.Attributes.Add("name", "keywords")
            metaTag.Attributes.Add("content", "packaging, packaging industry, packaging information, packaging research, packaging consulting, packaging publications, market research, market analysis, market studies, economic analysis, retort pouches, pharmaceutical packaging,  microwaveable packaging, stand-up pouches, stick pouches, stick packs, flexible packaging, barrier films, barrier packaging, glass-coating, glass-coated films, savvypack, packaging studies, medical device packaging, oriented films, bi-oriented films, transparent oxide-coated films, SiOx-coated films, AlOx-coated films, flexible lidstock, lidstock, foodservice, lids, LCA, LCI data, Life Cycle Analysis, LCI tool, sustainability, sustainable packaging, environmental studies, environment, environmental analysis, packaging analysis, flexible lidstock, U.S. foodservice, foodservice market")
            HeadTag.Controls.Add(metaTag)
        Catch ex As Exception

        End Try
    End Sub
End Class
