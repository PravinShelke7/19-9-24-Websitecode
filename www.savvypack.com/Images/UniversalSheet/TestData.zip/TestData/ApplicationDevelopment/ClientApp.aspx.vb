﻿
Partial Class ApplicationDevelopment_ClientApp
    Inherits System.Web.UI.Page

End Class
