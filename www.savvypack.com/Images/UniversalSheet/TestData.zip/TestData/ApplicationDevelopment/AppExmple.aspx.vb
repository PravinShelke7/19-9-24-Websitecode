﻿
Partial Class ApplicationDevelopment_AppExmple
    Inherits System.Web.UI.Page

End Class
