﻿Imports Corda
Imports System.Web.UI.HtmlControls
Imports System.Data
Imports System.Data.OleDb
Imports System.Web.HttpBrowserCapabilities
Partial Class Charts_CombineCharts_Default
    Inherits System.Web.UI.Page
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub


    'Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    '    'CODEGEN: This method call is required by the Web Form Designer
    '    'Do not modify it using the code editor.
    '    InitializeComponent()
    'End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            If Session("back") = "" Then
                lblsession.Visible = True
                Charts.Visible = False
            Else

                'Begin Embedder Code
                InitializeComponent()
                If Not IsPostBack Then
                    GetData()
                End If


            End If



        Catch ex As Exception
            Response.Write("Error:" + ex.Message.ToString())


        End Try


    End Sub

    Private Sub DrawEPUChart(ByVal Dts As DataTable, ByVal DtsPref As DataTable)
        Try
            Dim pcScript As String = String.Empty
            Dim Graphtype As String = String.Empty
            Dim GraphName As String = String.Empty
            Dim Count As String = String.Empty

            Dim SalesVolumeUnit As New Decimal
            Dim Transportation As New Decimal
            Dim Process As New Decimal
            Dim Purchased As New Decimal


            GraphName = "Sargento_KraftPouchvsTray_Html3"
            Graphtype = "graph"


            Count = Dts.Rows.Count



            pcScript &= "" + Graphtype + ".transposed(true)" + Graphtype + ".setCategories(Transportation;Process;Purchased Materials)"
            Dim i As New Integer
            For i = 0 To Count - 1
                If Dts.Rows(i).Item("FINVOLMSI") > 0 Then
                    SalesVolumeUnit = FormatNumber(Dts.Rows(i).Item("FINVOLMSI") * DtsPref.Rows(0).Item("ConvArea"), 0)
                ElseIf Dts.Rows(i).Item("FINVOLMUNITS") > 0 Then
                    SalesVolumeUnit = Dts.Rows(i).Item("FINVOLMUNITS")
                End If


                Transportation = FormatNumber(Dts.Rows(i).Item("Transportation") / SalesVolumeUnit, 3)
                Process = FormatNumber(Dts.Rows(i).Item("Process") / SalesVolumeUnit, 3)
                Purchased = FormatNumber(Dts.Rows(i).Item("Purchased Materials") / SalesVolumeUnit, 3)

                pcScript &= "" + Graphtype + ".setSeries(" & Dts.Rows(i).Item("CASEDE") & ";" & Transportation & ";" & Process & ";" & Purchased & ")"
            Next



            GenrateChart(pcScript, GraphName, DtsPref.Rows(0).Item("Title6").ToString() + "/Unit")

        Catch ex As Exception
            Response.Write("DrawChart:Error:" + ex.Message.ToString())
        End Try
    End Sub

    Private Sub DrawEPWChart(ByVal Dts As DataTable, ByVal DtsPref As DataTable)
        Try
            Dim pcScript As String = String.Empty
            Dim Graphtype As String = String.Empty
            Dim GraphName As String = String.Empty
            Dim Count As String = String.Empty
            Dim SalesVolumeLb As New Decimal
            Dim Transportation As New Decimal
            Dim Process As New Decimal
            Dim Purchased As New Decimal




            Count = Dts.Rows.Count
            GraphName = "Sargento_KraftPouchvsTray"
            Graphtype = "graph"

            pcScript &= "" + Graphtype + ".transposed(true)" + Graphtype + ".setCategories(Transportation;Process;Purchased Materials)"
            Dim i As New Integer
            For i = 0 To Count - 1
                SalesVolumeLb = FormatNumber(Dts.Rows(i).Item("VOLUME") * DtsPref.Rows(0).Item("CONVERSIONFACTOR"), 0)

                Transportation = FormatNumber(Dts.Rows(i).Item("Transportation") / SalesVolumeLb, 3)
                Process = FormatNumber(Dts.Rows(i).Item("Process") / SalesVolumeLb, 3)
                Purchased = FormatNumber(Dts.Rows(i).Item("Purchased Materials") / SalesVolumeLb, 3)

                pcScript &= "" + Graphtype + ".setSeries(" & Dts.Rows(i).Item("CASEDE") & ";" & Transportation & ";" & Process & ";" & Purchased & ")"
            Next

            GenrateChart(pcScript, GraphName, DtsPref.Rows(0).Item("Title6").ToString() + "/" + DtsPref.Rows(0).Item("Title4").ToString())

        Catch ex As Exception
            Response.Write("DrawChart:Error:" + ex.Message.ToString())
        End Try
    End Sub

    Private Sub DrawTEChart(ByVal Dts As DataTable, ByVal DtsPref As DataTable)
        Try
            Dim pcScript As String = String.Empty
            Dim Graphtype As String = String.Empty
            Dim GraphName As String = String.Empty
            Dim Count As String = String.Empty
            Dim Transportation As New Decimal
            Dim Process As New Decimal
            Dim Purchased As New Decimal

            Count = Dts.Rows.Count
            GraphName = "Sargento_KraftPouchvsTray"
            Graphtype = "graph"

            pcScript &= "" + Graphtype + ".transposed(true)" + Graphtype + ".setCategories(Transportation;Process;Purchased Materials)"
            Dim i As New Integer
            For i = 0 To Count - 1
                Transportation = FormatNumber(Dts.Rows(i).Item("Transportation") * DtsPref.Rows(0).Item("CONVERSIONFACTOR"), 0)
                Process = FormatNumber(Dts.Rows(i).Item("Process") * DtsPref.Rows(0).Item("CONVERSIONFACTOR"), 0)
                Purchased = FormatNumber(Dts.Rows(i).Item("Purchased Materials") * DtsPref.Rows(0).Item("CONVERSIONFACTOR"), 0)

                pcScript &= "" + Graphtype + ".setSeries(" & Dts.Rows(i).Item("CASEDE") & ";" & Transportation & ";" & Process & ";" & Purchased & ")"
            Next

            GenrateChart(pcScript, GraphName, DtsPref.Rows(0).Item("TITLE6").ToString())

        Catch ex As Exception
            Response.Write("DrawChart:Error:" + ex.Message.ToString())
        End Try
    End Sub

    Private Sub GenrateChart(ByVal PcScript As String, ByVal GraphName As String, ByVal Pref As String)
        Try

            Dim control As HtmlGenericControl = FindControl("EnergyComp")
            Dim myImage As CordaEmbedder = New CordaEmbedder()



            myImage.externalServerAddress = "http://192.168.100.22:2001"
            myImage.internalCommPortAddress = "http://192.168.100.22:2002"
            myImage.imageTemplate = GraphName + ".itxml"
            myImage.userAgent = Request.UserAgent
            myImage.width = 700
            myImage.height = 400
            myImage.returnDescriptiveLink = True
            myImage.language = "EN"
            myImage.pcScript = PcScript + "Y-axis.SetText(" + Pref + ")"
            myImage.outputType = "JPEG"
            myImage.fallback = "STRICT"
            control.InnerHtml = myImage.getEmbeddingHTML

        Catch ex As Exception

        End Try
    End Sub



    Private Sub GetData()
        Try
            Dim CaseId1 As String = String.Empty
            Dim CaseId2 As String = String.Empty
            Dim odbutil As New DBUtil()
            Dim YearValue As String = String.Empty
            Dim UserName As String = String.Empty
            Dim Unit As String = String.Empty
            Dim StrSqlPref As String = String.Empty
            Dim MyConnection As String = String.Empty
            Dim MyEConnection As String = String.Empty
            Dim StrSQl As String = String.Empty
            Dim DtsPref As New DataTable()
            Dim Dts As New DataTable()


            UserName = Session("User")
            CaseId1 = Session("C1")
            CaseId2 = Session("C2")
            MyConnection = System.Configuration.ConfigurationManager.AppSettings("Sustain1ConnectionString")
            MyEConnection = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")







            If ddltype.SelectedValue = "1" Then
                StrSQl = "SELECT  DISTINCT  "
                StrSQl = StrSQl + "TOTAL.CASEID, "
                StrSQl = StrSQl + "( CASE WHEN TOTAL.CASEID <= 1000 THEN "
                StrSQl = StrSQl + "( SELECT (BASECASES.CASEID||':'||BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSQl = StrSQl + "FROM BASECASES "
                StrSQl = StrSQl + "WHERE  BASECASES.CASEID = TOTAL.CASEID "
                StrSQl = StrSQl + ") ELSE "
                StrSQl = StrSQl + "( SELECT DISTINCT (PERMISSIONSCASES.CASEID||':'||NVL(PERMISSIONSCASES.CASEDE1,'') || ' ' || NVL(PERMISSIONSCASES.CASEDE2,'') ) "
                StrSQl = StrSQl + "FROM PERMISSIONSCASES "
                StrSQl = StrSQl + "WHERE  PERMISSIONSCASES.CASEID = TOTAL.CASEID "
                StrSQl = StrSQl + ") "
                StrSQl = StrSQl + "END  ) AS CASEDE, "
                StrSQl = StrSQl + "RESULTSPL.FINVOLMSI,"
                StrSQl = StrSQl + "RESULTSPL.FINVOLMUNITS,"
                StrSQl = StrSQl + "ROUND((RMERGY+RMPACKERGY+DPPACKERGY),0) AS ""Purchased Materials"", "
                StrSQl = StrSQl + "ROUND((PROCERGY),0)AS ""Process"", "
                StrSQl = StrSQl + "ROUND((RMANDPACKTRNSPTERGY+DPTRNSPTERGY+TRSPTTOCUS),0) AS ""Transportation"" "
                StrSQl = StrSQl + "FROM TOTAL "
                StrSQl = StrSQl + "INNER JOIN RESULTSPL "
                StrSQl = StrSQl + "ON RESULTSPL.CASEID = TOTAL.CASEID "
                StrSQl = StrSQl + "WHERE TOTAL.CASEID IN (" + CaseId1 + "," + CaseId2 + ") "

            ElseIf ddltype.SelectedValue = "2" Then

                StrSQl = "SELECT  DISTINCT  "
                StrSQl = StrSQl + "TOTAL.CASEID, "
                StrSQl = StrSQl + "( CASE WHEN TOTAL.CASEID <= 1000 THEN "
                StrSQl = StrSQl + "( SELECT (BASECASES.CASEID||':'||BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSQl = StrSQl + "FROM BASECASES "
                StrSQl = StrSQl + "WHERE  BASECASES.CASEID = TOTAL.CASEID "
                StrSQl = StrSQl + ") ELSE "
                StrSQl = StrSQl + "( SELECT DISTINCT (PERMISSIONSCASES.CASEID||':'||NVL(PERMISSIONSCASES.CASEDE1,'') || ' ' || NVL(PERMISSIONSCASES.CASEDE2,'') ) "
                StrSQl = StrSQl + "FROM PERMISSIONSCASES "
                StrSQl = StrSQl + "WHERE  PERMISSIONSCASES.CASEID = TOTAL.CASEID "
                StrSQl = StrSQl + ") "
                StrSQl = StrSQl + "END  ) AS CASEDE, "
                StrSQl = StrSQl + "RESULTSPL.VOLUME, "
                StrSQl = StrSQl + "ROUND((RMERGY+RMPACKERGY+DPPACKERGY),0) AS ""Purchased Materials"", "
                StrSQl = StrSQl + "ROUND((PROCERGY),0)AS ""Process"", "
                StrSQl = StrSQl + "ROUND((RMANDPACKTRNSPTERGY+DPTRNSPTERGY+TRSPTTOCUS),0) AS ""Transportation"" "
                StrSQl = StrSQl + "FROM TOTAL "
                StrSQl = StrSQl + "INNER JOIN RESULTSPL "
                StrSQl = StrSQl + "ON RESULTSPL.CASEID = TOTAL.CASEID "
                StrSQl = StrSQl + "WHERE TOTAL.CASEID IN (" + CaseId1 + "," + CaseId2 + ") "
            ElseIf ddltype.SelectedValue = "3" Then
                StrSQl = "SELECT  DISTINCT  "
                StrSQl = StrSQl + "TOTAL.CASEID, "
                StrSQl = StrSQl + "( CASE WHEN TOTAL.CASEID <= 1000 THEN "
                StrSQl = StrSQl + "( SELECT (BASECASES.CASEID||':'||BASECASES.CASEDE1||' '||BASECASES.CASEDE2 ) "
                StrSQl = StrSQl + "FROM BASECASES "
                StrSQl = StrSQl + "WHERE  BASECASES.CASEID = TOTAL.CASEID "
                StrSQl = StrSQl + ") ELSE "
                StrSQl = StrSQl + "( SELECT DISTINCT (PERMISSIONSCASES.CASEID||':'||NVL(PERMISSIONSCASES.CASEDE1,'') || ' ' || NVL(PERMISSIONSCASES.CASEDE2,'') ) "
                StrSQl = StrSQl + "FROM PERMISSIONSCASES "
                StrSQl = StrSQl + "WHERE  PERMISSIONSCASES.CASEID = TOTAL.CASEID "
                StrSQl = StrSQl + ") "
                StrSQl = StrSQl + "END  ) AS CASEDE, "
                StrSQl = StrSQl + "ROUND((RMERGY+RMPACKERGY+DPPACKERGY),0) AS ""Purchased Materials"", "
                StrSQl = StrSQl + "ROUND((PROCERGY),0)AS ""Process"", "
                StrSQl = StrSQl + "ROUND((RMANDPACKTRNSPTERGY+DPTRNSPTERGY+TRSPTTOCUS),0) AS ""Transportation"" "
                StrSQl = StrSQl + "FROM TOTAL "
                StrSQl = StrSQl + "WHERE TOTAL.CASEID IN (" + CaseId1 + "," + CaseId2 + ") "

            End If
          

            Dts = odbutil.FillDataTable(StrSQl, MyConnection)



            StrSqlPref = "SELECT USERNAME, UNITS, CURRENCY, CURR, CONVERSIONFACTOR,CONVAREA, TITLE1, TITLE2, TITLE3, TITLE4, TITLE5, TITLE6 FROM  CHARTPREFERENCES WHERE USERNAME='" + Session("User").ToString() + "'"
            DtsPref = odbutil.FillDataTable(StrSqlPref, MyEConnection)

            If Dts.Rows.Count > 0 And DtsPref.Rows.Count > 0 Then
                If ddltype.SelectedValue = 1 Then
                    DrawEPUChart(Dts, DtsPref)
                ElseIf ddltype.SelectedValue = 2 Then
                    DrawEPWChart(Dts, DtsPref)
                ElseIf ddltype.SelectedValue = 3 Then
                    DrawTEChart(Dts, DtsPref)
                End If

            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try
            GetData()
        Catch ex As Exception

        End Try
    End Sub
End Class
