
Partial Class EconMaster
    Inherits System.Web.UI.MasterPage
End Class

