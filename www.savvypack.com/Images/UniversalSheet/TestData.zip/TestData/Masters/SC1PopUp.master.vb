﻿
Partial Class Masters_SC1PopUp
    Inherits System.Web.UI.MasterPage
End Class

