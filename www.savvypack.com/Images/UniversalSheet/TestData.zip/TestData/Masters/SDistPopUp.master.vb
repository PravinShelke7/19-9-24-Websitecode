
Partial Class Masters_SDistPopUp
    Inherits System.Web.UI.MasterPage
End Class

