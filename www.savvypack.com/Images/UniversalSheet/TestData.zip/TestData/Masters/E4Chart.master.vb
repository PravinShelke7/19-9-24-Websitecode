﻿
Partial Class Masters_E4Chart
    Inherits System.Web.UI.MasterPage
End Class

