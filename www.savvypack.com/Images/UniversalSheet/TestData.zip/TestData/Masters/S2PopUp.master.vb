
Partial Class Masters_S2PopUp
    Inherits System.Web.UI.MasterPage
End Class

