
Partial Class Masters_RetailPopup
    Inherits System.Web.UI.MasterPage
End Class

