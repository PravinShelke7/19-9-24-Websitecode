
Partial Class Masters_S1PopUp
    Inherits System.Web.UI.MasterPage
End Class

