
Partial Class Masters_ContractPopUp
    Inherits System.Web.UI.MasterPage
End Class

