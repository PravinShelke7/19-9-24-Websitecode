﻿
Partial Class Masters_M1PopUp
    Inherits System.Web.UI.MasterPage
End Class

