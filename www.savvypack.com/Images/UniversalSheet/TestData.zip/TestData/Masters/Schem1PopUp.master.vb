﻿
Partial Class Masters_Schem1PopUp
    Inherits System.Web.UI.MasterPage
End Class

