
Partial Class Masters_E2PopUp
    Inherits System.Web.UI.MasterPage
End Class

