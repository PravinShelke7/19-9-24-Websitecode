﻿Imports System
Imports System.Data
Partial Class Masters_Market1
    Inherits System.Web.UI.MasterPage
    Dim _iReportId As Integer
    Public Property ReportId() As Integer
        Get
            Return _iReportId
        End Get
        Set(ByVal Value As Integer)
            _iReportId = Value
        End Set
    End Property
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim obj As New CryptoHelper
        Try
            lblTag.Text = "Copyright 1997 - " + Now.Year().ToString() + " Allied Development Corp."
        Catch ex As Exception
        End Try
        If (Session("Back")) = Nothing Then

            ContentPage.Visible = False
            lblError.Text = "Session is Expired"
            Response.Redirect("~/Pages/Market1/Errors/Error.aspx?ErrorCode=" + obj.Encrypt("ALDE112") + "")
        Else
           
            ContentPage.Visible = True
        End If

    End Sub
    
End Class

