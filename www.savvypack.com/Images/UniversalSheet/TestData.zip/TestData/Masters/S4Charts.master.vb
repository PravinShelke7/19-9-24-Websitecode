﻿
Partial Class Masters_S4Charts
    Inherits System.Web.UI.MasterPage
End Class

