Imports System.Data
Imports System.Data.OleDb
Imports System
Imports E3GetData
Imports System.Collections
Imports System.IO.StringWriter
Imports System.Web.UI.HtmlTextWriter
Partial Class Pages_Econ3_Assumptions_Preferences
    Inherits System.Web.UI.Page

#Region "Get Set Variables"
    Dim _lErrorLble As Label
    Dim _strUserName As String
    Dim _strPassword As String
    Dim _iAssumptionId As Integer
    Dim _btnUpdate As ImageButton


    Public Property ErrorLable() As Label
        Get
            Return _lErrorLble
        End Get
        Set(ByVal Value As Label)
            _lErrorLble = Value
        End Set
    End Property

    Public Property UserName() As String
        Get
            Return _strUserName
        End Get
        Set(ByVal Value As String)
            _strUserName = Value
        End Set
    End Property

    Public Property Password() As String
        Get
            Return _strPassword
        End Get
        Set(ByVal Value As String)
            _strPassword = Value
        End Set
    End Property

    Public Property AssumptionId() As Integer
        Get
            Return _iAssumptionId
        End Get
        Set(ByVal Value As Integer)
            _iAssumptionId = Value
        End Set
    End Property

    Public Property Updatebtn() As ImageButton
        Get
            Return _btnUpdate
        End Get
        Set(ByVal value As ImageButton)
            _btnUpdate = value
        End Set
    End Property


    Public DataCnt As Integer
    Public CaseDesp As New ArrayList

#End Region

#Region "MastePage Content Variables"
    Protected Sub GetErrorLable()
        ErrorLable = Page.Master.FindControl("lblError")
    End Sub

    Protected Sub GetUpdatebtn()
        Updatebtn = Page.Master.FindControl("imgUpdate")
        Updatebtn.Visible = True

    End Sub

#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            Try
                GetErrorLable()
                GetUpdatebtn()
                GetSessionDetails()
                If Not IsPostBack Then
                    GetPageDetails()
                End If

            Catch ex As Exception

            End Try

        Catch ex As Exception
            _lErrorLble.Text = "Error:Page_Load:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Sub GetSessionDetails()
        Try
            UserName = Session("UserName")
            Password = Session("Password")
            AssumptionId = Session("AssumptionID")

            lblAID.Text = AssumptionId
            lblAdes.Text = Session("Description")

        Catch ex As Exception
            _lErrorLble.Text = "Error:GetSessionDetails:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Function GetCaseIds() As String()
        Dim CaseIds(0) As String
        Dim objGetData As New E3GetData.Selectdata
        Try
            CaseIds = objGetData.Cases(AssumptionId)
            Return CaseIds
        Catch ex As Exception
            Return CaseIds
            _lErrorLble.Text = "Error:GetCaseIds:" + ex.Message.ToString()
        End Try

    End Function

    Protected Sub GetPageDetails()
        Dim dstbl As New DataSet
        Dim dsCaseDetails As New DataSet
        Dim objGetData As New E1GetData.Selectdata
        Dim CaseIds As String = String.Empty
        'Dim DataCnt As New Integer
        Dim i As New Integer
        Dim j As New Integer
        Dim k As New Integer
        Dim DWidth As String = String.Empty
        Dim arrCaseID() As String
        Try
            arrCaseID = GetCaseIds()
            DataCnt = arrCaseID.Length - 1
            Dim trHeader As New TableRow
            Dim tdHeader As TableCell
            Dim tdInner As TableCell
            Dim trInner As New TableRow
            Dim ddl As DropDownList
            Dim lbl As New Label
            Dim lbl2 As New Label
            Dim txt As TextBox
            Dim btn As Button
            Dim rdeng As RadioButton
            Dim rdmatric As RadioButton
            Dim CasesVal(9) As String

            Dim Cunits As New Integer
            Dim Units As New Integer
            Dim Title As String = String.Empty
            Dim dsW As New DataSet
            Dim objGetDataW As New E3GetData.Selectdata
            dsW = objGetDataW.CompCOLWIDTH(AssumptionId)
            If dsW.Tables(0).Rows.Count > 0 Then
                txtDWidth.Text = dsW.Tables(0).Rows(0).Item("COLWIDTH").ToString()
            End If
            For i = 0 To 9
                If i <= DataCnt Then
                    CasesVal(i) = arrCaseID(i)
                Else
                    CasesVal(i) = Nothing
                End If
            Next
            Updatebtn.Attributes.Add("onClick", "return UpdateAll('" + CasesVal(0).ToString() + "','" + CasesVal(1).ToString() + "','" + CasesVal(2) + "','" + CasesVal(3) + "','" + CasesVal(4) + "','" + CasesVal(5) + "','" + CasesVal(6) + "','" + CasesVal(7) + "','" + CasesVal(8) + "','" + CasesVal(9) + "','" + (DataCnt + 1).ToString() + "');")

            DWidth = txtDWidth.Text + "px"


            tdHeader = New TableCell
            HeaderTdSetting(tdHeader, "200px", "<img alt='' src='../../Images/spacer.gif' Style='width:200px;height:0px;'  />", 1)
            trHeader.Controls.Add(tdHeader)
            trHeader.Height = 20
            trHeader.CssClass = "PageSSHeading"

            For i = 0 To DataCnt
                Dim ds As New DataSet
                ds = objGetData.GetPref(arrCaseID(i))
                ds.Tables(0).TableName = arrCaseID(i).ToString()
                dstbl.Tables.Add(ds.Tables(arrCaseID(i).ToString()).Copy())
            Next





            For i = 0 To DataCnt
                dsCaseDetails = objGetData.GetCaseDetails(arrCaseID(i).ToString())
                Cunits = Convert.ToInt32(dstbl.Tables(0).Rows(0).Item("Units").ToString())
                Units = Convert.ToInt32(dstbl.Tables(i).Rows(0).Item("Units").ToString())


                tdHeader = New TableCell
                Dim Headertext As String = String.Empty
                If Cunits <> Units Then
                    Headertext = "Case#:" + arrCaseID(i).ToString() + "<br/>" + dsCaseDetails.Tables(0).Rows(0).Item("CaseDes").ToString() + "<br/> <span  style='color:red'>Unit Mismatch</span>" + "<input type='hidden' value='" + arrCaseID(i).ToString() + "' name='Case" + i.ToString() + "'/>"
                Else
                    Headertext = "Case#:" + arrCaseID(i).ToString() + "<br/>" + dsCaseDetails.Tables(0).Rows(0).Item("CaseDes").ToString() + "<input type='hidden' value='" + arrCaseID(i).ToString() + "' name='Case" + i.ToString() + "'/>"
                End If

                CaseDesp.Add(arrCaseID(i).ToString())
                HeaderTdSetting(tdHeader, DWidth, Headertext, 1)
                trHeader.Controls.Add(tdHeader)


            Next
            tblComparision.Controls.Add(trHeader)
            For i = 1 To 1
                For j = 0 To 8
                    trInner = New TableRow()

                    Select Case j
                        Case 0
                            tdInner = New TableCell
                            LeftTdSetting(tdInner, "", trInner, "TdHeading")
                            tdInner.CssClass = "TdHeading"
                            For k = 0 To DataCnt
                                tdInner = New TableCell
                                tdInner.CssClass = "TdHeading"
                                If i = 1 Then
                                    btn = New Button
                                    btn.ID = "btn_" + (k + 1).ToString()
                                    btn.Text = "Update"
                                    btn.Height = 15
                                    btn.Style.Add("font-size", "9px")
                                    btn.CommandArgument = arrCaseID(k).ToString()
                                    btn.Attributes.Add("onClick", "return Update('" + arrCaseID(k).ToString() + "','" + (k).ToString() + "'," + DataCnt.ToString() + ");")
                                    tdInner.Controls.Add(btn)
                                Else
                                    tdInner.Text = "&nbsp;"
                                End If
                                InnerTdSetting(tdInner, "", "Center")
                                trInner.Controls.Add(tdInner)
                            Next

                        Case 1
                            tdInner = New TableCell
                            LeftTdSetting(tdInner, "Country of Manufacture: ", trInner, "")
                            trInner.ID = "CM" + i.ToString()
                            For k = 0 To DataCnt
                                ddl = New DropDownList
                                ddl.CssClass = "dropdownunit"
                                tdInner = New TableCell
                                ddl.ID = "ddlOid_" + k.ToString() + "_" + j.ToString() + "_" + i.ToString()
                                GetCountryDetails(ddl, dstbl.Tables(k).Rows(0).Item("OCOUNTRY").ToString())
                                tdInner.Controls.Add(ddl)
                                InnerTdSetting(tdInner, "", "Right")
                                trInner.Controls.Add(tdInner)
                            Next
                        Case 2
                            tdInner = New TableCell
                            LeftTdSetting(tdInner, "Country of Destination", trInner, "")
                            trInner.ID = "CD" + i.ToString()
                            For k = 0 To DataCnt
                                tdInner = New TableCell
                                ddl = New DropDownList
                                ddl.CssClass = "dropdownunit"
                                ddl.ID = "ddlOid_" + k.ToString() + "_" + j.ToString() + "_" + i.ToString()
                                GetCountryDetails(ddl, dstbl.Tables(k).Rows(0).Item("DCOUNTRY").ToString())
                                tdInner.Controls.Add(ddl)
                                InnerTdSetting(tdInner, "", "Right")
                                trInner.Controls.Add(tdInner)
                            Next
                        Case 3
                            tdInner = New TableCell
                            LeftTdSetting(tdInner, "Prefferred Unit", trInner, "")
                            trInner.ID = "PREFU" + i.ToString()
                            For k = 0 To DataCnt
                                rdeng = New RadioButton
                                rdmatric = New RadioButton
                                rdeng.GroupName = "unit" + k.ToString()
                                rdmatric.GroupName = "unit" + k.ToString()
                                rdeng.ID = "rdeid_" + k.ToString() + "_" + j.ToString() + "_" + i.ToString()
                                rdmatric.ID = "rdmid_" + k.ToString() + "_" + j.ToString() + "_" + i.ToString()
                                rdmatric.Text = "Matric"
                                rdeng.Text = "English"
                                tdInner = New TableCell
                                GetUnitDetails(rdeng, rdmatric, dstbl.Tables(k).Rows(0).Item("UNITS").ToString())
                                tdInner.Controls.Add(rdeng)
                                tdInner.Controls.Add(rdmatric)
                                InnerTdSetting(tdInner, "", "Right")
                                trInner.Controls.Add(tdInner)
                            Next
                        Case 4
                            tdInner = New TableCell
                            LeftTdSetting(tdInner, "Effective Date", trInner, "")
                            trInner.ID = "EFFDATE" + i.ToString()
                            For k = 0 To DataCnt
                                'lbl = New Label()
                                'lbl.Text = dstbl.Tables(k).Rows(0).Item("EDATE").ToString()
                                ddl = New DropDownList
                                ddl.CssClass = "dropdownunit"
                                ddl.ID = "ddlEffDateid_" + k.ToString() + "_" + j.ToString() + "_" + i.ToString()
                                GetEffdateDetails(ddl, dstbl.Tables(k).Rows(0).Item("EDATE").ToString())
                                tdInner = New TableCell
                                tdInner.Controls.Add(ddl)
                                InnerTdSetting(tdInner, "", "Right")
                                trInner.Controls.Add(tdInner)
                            Next
                        Case 5
                            tdInner = New TableCell
                            LeftTdSetting(tdInner, "Preferred Currency", trInner, "")
                            trInner.ID = "PREFCUR" + i.ToString()
                            For k = 0 To DataCnt
                                ddl = New DropDownList
                                ddl.CssClass = "dropdownunit"
                                ddl.ID = "ddlCurrid_" + k.ToString() + "_" + j.ToString() + "_" + i.ToString()
                                GetCurrencyDetails(ddl, dstbl.Tables(k).Rows(0).Item("CURRENCY").ToString())
                                tdInner = New TableCell
                                tdInner.Controls.Add(ddl)
                                InnerTdSetting(tdInner, "", "Right")
                                trInner.Controls.Add(tdInner)
                            Next
                        Case 6
                            tdInner = New TableCell
                            LeftTdSetting(tdInner, "Energy Calculations", trInner, "")
                            trInner.ID = "ERGYCAL" + i.ToString()
                            For k = 0 To DataCnt
                                lbl = New Label()
                                If dstbl.Tables(k).Rows(0).Item("ERGYCALC").ToString() = "Y" Then
                                    lbl.Text = "Adjust Automatically"
                                Else
                                    lbl.Text = "Use Capacity "
                                End If
                                tdInner = New TableCell
                                tdInner.Controls.Add(lbl)
                                InnerTdSetting(tdInner, "", "Right")
                                trInner.Controls.Add(tdInner)
                            Next
                        Case 7
                            tdInner = New TableCell
                            LeftTdSetting(tdInner, "Discrete Calculations", trInner, "")
                            trInner.ID = "DISCAL" + i.ToString()
                            For k = 0 To DataCnt
                                lbl = New Label()
                                If dstbl.Tables(k).Rows(0).Item("ISDSCTNEW").ToString() = "Y" Then
                                    lbl.Text = "Shipped together"
                                Else
                                    lbl.Text = "Shipped separately"
                                End If
                                tdInner = New TableCell
                                tdInner.Controls.Add(lbl)
                                InnerTdSetting(tdInner, "", "Right")
                                trInner.Controls.Add(tdInner)
                            Next
                        Case 8
                            tdInner = New TableCell
                            LeftTdSetting(tdInner, "Design Waste Calculations", trInner, "")
                            trInner.ID = "DESCAL" + i.ToString()
                            For k = 0 To DataCnt
                                lbl = New Label()
                                If dstbl.Tables(k).Rows(0).Item("DFLAG").ToString() = "N" Then
                                    lbl.Text = "Old"
                                Else
                                    lbl.Text = "New"
                                End If
                                tdInner = New TableCell
                                tdInner.Controls.Add(lbl)
                                InnerTdSetting(tdInner, "", "Right")
                                trInner.Controls.Add(tdInner)
                            Next
                    End Select

                    If (j Mod 2 = 0) Then
                        trInner.CssClass = "AlterNateColor1"
                    Else
                        trInner.CssClass = "AlterNateColor2"
                    End If



                    tblComparision.Controls.Add(trInner)
                Next
            Next



        Catch ex As Exception
            _lErrorLble.Text = "Error:GetPageDetails:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Sub HeaderTdSetting(ByVal Td As TableCell, ByVal Width As String, ByVal HeaderText As String, ByVal ColSpan As String)
        Try
            Td.Text = HeaderText
            Td.ColumnSpan = ColSpan
            If Width <> "" Then
                Td.Style.Add("width", Width)
            End If
            Td.CssClass = "TdHeading"
            Td.Height = 30
            Td.HorizontalAlign = HorizontalAlign.Center



        Catch ex As Exception

        End Try
    End Sub

    Protected Sub InnerTdSetting(ByVal Td As TableCell, ByVal Width As String, ByVal Align As String)
        Try

            If Width <> "" Then
                Td.Style.Add("width", Width)
            End If
            Td.Style.Add("text-align", Align)
            If Align = "Left" Then
                Td.Style.Add("padding-left", "5px")
            End If
            If Align = "Right" Then
                Td.Style.Add("padding-right", "5px")
            End If




        Catch ex As Exception

        End Try
    End Sub

    Protected Sub TextBoxSetting(ByVal txt As TextBox, ByVal Css As String, ByVal CaseId As Integer)
        Try
            txt.CssClass = Css
            If CaseId <= 1000 And Session("Password") <> "9krh65sve3" Then
                txt.Enabled = False
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub LableSetting(ByVal lbl As Label, ByVal Css As String)
        Try
            lbl.CssClass = Css

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub LeftTdSetting(ByVal Td As TableCell, ByVal Text As String, ByVal tr As TableRow, ByVal Css As String)
        Try
            Td.Text = Text
            InnerTdSetting(Td, "", "Left")
            tr.Controls.Add(Td)
            tr.CssClass = Css




        Catch ex As Exception
            _lErrorLble.Text = "Error:GetPageDetails:" + ex.Message.ToString()
        End Try
    End Sub

    Protected Sub GetCountryDetails(ByRef ddl As DropDownList, ByVal CountryId As Integer)
        Dim Ds As New DataSet
        Dim dscountries As New DataSet
        Dim ObjGetdata As New E1GetData.Selectdata()
        Dim hidval As New HiddenField
        Dim Path As String = String.Empty
        Try

            Ds = ObjGetdata.GetCountry("-1")
            'dscountries = ObjGetdata.GetCountries()
            With ddl
                .DataSource = Ds
                .DataTextField = "COUNTRYDE1"
                .DataValueField = "COUNTRYID"
                .DataBind()
            End With
            ddl.SelectedValue = CountryId.ToString()

            'lbl.Text = Ds.Tables(0).Rows(0).Item("COUNTRYDE1").ToString()

        Catch ex As Exception
            ErrorLable.Text = "Error:GetCountryDetails:" + ex.Message.ToString() + ""
        End Try
    End Sub
    Protected Sub GetEffdateDetails(ByRef ddl As DropDownList, ByVal Effdate As String)
        Dim Ds As New DataSet
        Dim dseffdate As New DataSet
        Dim ObjGetdata As New E1GetData.Selectdata()
        Dim hidval As New HiddenField
        Dim Path As String = String.Empty
        Try
            dseffdate = ObjGetdata.GetEffDate()
            With ddl
                .DataSource = dseffdate
                .DataTextField = "EDATE"
                .DataValueField = "EDATE"
                .DataBind()
            End With
            ddl.SelectedValue = Effdate.ToString()

            'lbl.Text = Ds.Tables(0).Rows(0).Item("COUNTRYDE1").ToString()

        Catch ex As Exception
            ErrorLable.Text = "Error:GetEffdateDetails:" + ex.Message.ToString() + ""
        End Try
    End Sub

    Protected Sub GetUnitDetails(ByRef rd As RadioButton, ByVal rd1 As RadioButton, ByVal UnitId As Integer)
        Dim Ds As New DataSet
        Dim ObjGetdata As New E1GetData.Selectdata()
        Dim hidval As New HiddenField
        Dim Path As String = String.Empty
        Try

            If UnitId = 0 Then
                rd.Checked = True
                rd1.Checked = False
            Else
                rd.Checked = False
                rd1.Checked = True
            End If

        Catch ex As Exception
            ErrorLable.Text = "Error:GetUnitDetails:" + ex.Message.ToString() + ""
        End Try
    End Sub

    Protected Sub GetCurrencyDetails(ByRef ddl As DropDownList, ByVal currId As Integer)
        Dim Ds As New DataSet
        Dim dscurr As New DataSet
        Dim ObjGetdata As New E1GetData.Selectdata()
        Dim hidval As New HiddenField
        Dim Path As String = String.Empty
        Try

            Ds = ObjGetdata.GetCurrancy("-1")
            'lbl.Text = Ds.Tables(0).Rows(0).Item("CURDE1").ToString()
            'dscurr = ObjGetdata.GetAllCurrancy()
            With ddl
                .DataSource = Ds
                .DataTextField = "CURDE1"
                .DataValueField = "CURID"
                .DataBind()
            End With
            ddl.SelectedValue = currId

        Catch ex As Exception
            ErrorLable.Text = "Error:GetCurrencyDetails:" + ex.Message.ToString() + ""
        End Try
    End Sub

    Protected Sub btnWidthSet_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnWidthSet.Click
        Try
            Dim objUpdateData As New E3UpInsData.UpdateInsert
            objUpdateData.EditCOLWIDTH(AssumptionId, txtDWidth.Text)
            GetPageDetails()
        Catch ex As Exception

        End Try
    End Sub

    <System.Web.Services.WebMethod()> _
    Public Shared Function UpdateCase(ByVal ocntry() As String, ByVal CaseID As String, ByVal unit As String)
        Try
            Dim WPT(10) As String
            Dim ObjGetData As New E1GetData.Selectdata()
            Dim EconConnection As String = System.Configuration.ConfigurationManager.AppSettings("EconConnectionString")
            Dim StrSqlUpadate As String = ""
            Dim StrSqlIUpadate As String = ""
            Dim odbUtil As New DBUtil()

            Dim dts As New DataSet()
            Dim ObjE3GetData As New E3GetData.Selectdata()
            Dim dsD As New DataSet
            Dim PageInfo As String = ""

            dts = ObjGetData.GetPref(CaseID)
            StrSqlUpadate = "UPDATE preferences SET"
            For Mat = 1 To 1

                StrSqlIUpadate = StrSqlIUpadate + " OCOUNTRY=" + ocntry(Mat).ToString() + ","
                StrSqlIUpadate = StrSqlIUpadate + " DCOUNTRY=" + ocntry(Mat + 1).ToString() + ","
                StrSqlIUpadate = StrSqlIUpadate + " UNITS=" + unit.ToString() + ","
                StrSqlIUpadate = StrSqlIUpadate + " EFFDATE=TO_DATE('" + ocntry(Mat + 3).ToString() + "','MON DD,YYYY'), "
                StrSqlIUpadate = StrSqlIUpadate + " CURRENCY=" + ocntry(Mat + 4).ToString() + ""
            Next

            StrSqlUpadate = StrSqlUpadate + StrSqlIUpadate
            StrSqlUpadate = StrSqlUpadate + " WHERE CASEID = " + CaseID + ""
            odbUtil.UpIns(StrSqlUpadate, EconConnection)


        Catch ex As Exception

        End Try
    End Function

 
End Class
